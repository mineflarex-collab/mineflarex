# Deploying minePanel on a VPS (behind Cloudflare)

Needs: Ubuntu/Debian VPS, root access, a domain on Cloudflare. The panel stays on `http://localhost:3000`; Cloudflare gives it https.

## 1. Install (one installer: the MineFlareX menu)
The panel has **no installer of its own**. Everything happens in the MineFlareX menu `install.sh`:
```bash
bash <(curl -s https://mineflarex.indevs.in/install.sh)
```
Pick **[2] MINE PANEL**. The menu clones the panel repo (`PANEL_REPO` at the top of that `install.sh`, or `MFX_PANEL_REPO`), installs Node.js 22, Python 3 and Java, copies the panel to `/opt/minepanel`, writes `.env` (random `SESSION_SECRET`), starts the `minepanel` systemd service on `127.0.0.1:3000` and, as the very last step, **asks for the admin email and password** (typed twice, hidden). The panel files (`server.js`, `package.json`, `src/`, `public/`, `deploy/` ...) must sit in the **root** of that repo.

**Update:** run the menu again and pick **[2] MINE PANEL**, answer `y`. Code is pulled, the database is backed up, and your data, servers, `.env` and admin login are kept (the admin is not asked again).

"Panel domain" is only the web address where you open the panel. The installer does not need it: Cloudflare connects an address to the panel (step 2A).

Logs: `journalctl -u minepanel -f` · Restart: `systemctl restart minepanel` · Config: `/opt/minepanel/.env`

## 2A. Cloudflare Tunnel -> localhost:3000 (recommended: no open web ports, no certificates)
Already have cloudflared? In Zero Trust open Networks > Tunnels > your tunnel > Public hostname, add your hostname with Service `HTTP` and URL `localhost:3000`. No domain at all? `cloudflared tunnel --url http://localhost:3000` prints a free temporary `trycloudflare.com` link.

First-time setup from the command line:
```bash
# install cloudflared: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/
cloudflared tunnel login
cloudflared tunnel create minepanel
cloudflared tunnel route dns minepanel panel.yourdomain.com
sudo mkdir -p /etc/cloudflared && sudo cp deploy/cloudflared-config.yml.example /etc/cloudflared/config.yml   # edit UUID + hostname
sudo cloudflared service install
```
(Or in Zero Trust dashboard: Networks > Tunnels > Public hostname > Service `HTTP` `localhost:3000`.)

## 2B. Orange-cloud proxy + nginx (alternative)
Use `deploy/nginx.conf.example` with a Cloudflare Origin Certificate, SSL mode **Full (strict)**, and allow 443 only from Cloudflare IPs.

## Notes
- `TRUST_PROXY=true` makes the panel trust `CF-Connecting-IP` / `X-Forwarded-Host`. Keep `HOST=127.0.0.1` so only the tunnel/nginx can reach it.
- Live console uses WebSockets: enabled by default on Cloudflare; no extra setting.
- Minecraft players connect straight to `VPS-IP:25565` (Cloudflare does not proxy game TCP). `ufw allow 25565/tcp` (and each server's port).
- Backup: `/opt/minepanel/data/minepanel.db` and `/opt/minepanel/data/servers/`.
- Update: unzip the new version over `/opt/minepanel` (keep `.env` and `data/`), `chown -R minepanel:minepanel /opt/minepanel`, `systemctl restart minepanel`.
- **Exit code 143 / servers stop when the panel restarts:** the service needs `KillMode=mixed` (already in `deploy/minepanel.service`). On an existing install add it as a drop-in, it survives updates:
  ```bash
  mkdir -p /etc/systemd/system/minepanel.service.d
  printf '[Service]\nKillMode=mixed\n' > /etc/systemd/system/minepanel.service.d/killmode.conf
  systemctl daemon-reload && systemctl restart minepanel
  ```
