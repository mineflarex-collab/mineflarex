'use strict';
function client(base) {
  const jar = {};
  const store = (res) => { for (const c of res.headers.getSetCookie()) {
    const [kv] = c.split(';'); const i = kv.indexOf('='); const k = kv.slice(0, i), val = kv.slice(i + 1);
    if (/Max-Age=0/i.test(c)) delete jar[k]; else jar[k] = val; } };
  const c = {
    jar,
    async req(path, { method = 'GET', form, json, headers = {}, signal } = {}) {
      const res = await fetch(base + path, { method, redirect: 'manual',
        headers: { cookie: Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; '), ...(form ? { 'content-type': 'application/x-www-form-urlencoded' } : {}), ...(json !== undefined ? { 'content-type': 'application/json' } : {}), ...headers },
        body: form ? new URLSearchParams(form) : json !== undefined ? JSON.stringify(json) : undefined, signal });
      store(res); return res;
    },
    async csrf(path = '/login') { const html = await (await c.req(path)).text(); return /name="_csrf" value="([^"]+)"/.exec(html)[1]; },
    async post(path, form, from) { return c.req(path, { method: 'POST', form: { _csrf: await c.csrf(from || path), ...form } }); },
    /** JSON API call with the session cookie and a valid CSRF header. */
    async api(path, json, { method = 'POST', csrf = true } = {}) {
      const token = csrf ? (await (await c.req('/api/dashboard/csrf', { headers: { accept: 'application/json' } })).json()).token : null;
      return c.req(path, { method, json, headers: { accept: 'application/json', ...(token ? { 'x-csrf-token': token } : {}) } });
    },
    async login(identifier, password) { return c.post('/login', { identifier, password }, '/login'); }
  };
  return c;
}
module.exports = { client };
