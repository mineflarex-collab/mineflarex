'use strict';
// Admin privacy: the main admin hides other people's servers from chosen admins (or from every new admin);
// only the main admin can give the administrator role.
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');

const PW = 'Sup3rSecretPass!';
let srv, base, boss, spy, okay, alice, bob, sAlice, sSpy, hash;
const text = async (c, path) => { const r = await c.req(path); return { status: r.status, body: await r.text() }; };

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  hash = await hashPassword(PW);
  boss = users.create({ username: 'boss', email: 'boss@gmail.com', passwordHash: hash, role: 'admin' });
  spy = users.create({ username: 'spy', email: 'spy@example.com', passwordHash: hash, role: 'admin' });
  okay = users.create({ username: 'okay', email: 'okay@example.com', passwordHash: hash, role: 'admin' });
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: hash });
  bob = users.create({ username: 'bob', email: 'bob@example.com', passwordHash: hash });
  sAlice = servers.create({ ownerId: alice.id, name: 'AliceSecretSrv' });
  sSpy = servers.create({ ownerId: spy.id, name: 'SpyOwnSrv' });
});
after(() => { srv.closeAllConnections?.(); srv.close(); });

test('Option 2: the main admin hides servers from a chosen admin; that admin sees and opens nothing of others', async () => {
  const o = client(base); await o.login('boss', PW);
  assert.equal((await o.post(`/admin/privacy/${spy.id}`, { hide: '1' }, '/admin/privacy')).status, 303);
  assert.equal(users.findById(spy.id).servers_hidden, 1);
  const s = client(base); await s.login('spy', PW);
  const k = client(base); await k.login('okay', PW);
  assert.match((await text(k, '/admin/servers/mc')).body, /AliceSecretSrv/);                       // an unrestricted admin sees it
  assert.doesNotMatch((await text(s, '/admin/servers/mc')).body, /AliceSecretSrv/);
  assert.doesNotMatch((await text(s, '/admin')).body, /AliceSecretSrv/);
  assert.doesNotMatch((await text(s, '/dashboard?all=1')).body, /AliceSecretSrv/);
  assert.equal((await text(s, `/dashboard/servers/${sAlice.identifier}/console`)).status, 404);
  assert.equal((await text(s, `/admin/servers/${sAlice.identifier}/edit`)).status, 404);
  assert.equal((await s.post(`/dashboard/servers/${sAlice.identifier}/force/stop`, {}, '/dashboard')).status, 404);
  const usage = await (await s.req('/api/admin/usage')).json();
  assert.ok(!JSON.stringify(usage.servers).includes(String(sAlice.id)) || usage.servers.every((x) => x.id !== sAlice.id));
  assert.match((await text(s, '/dashboard?all=1')).body, /SpyOwnSrv/);                             // own servers keep working
  assert.equal((await text(s, `/dashboard/servers/${sSpy.identifier}/console`)).status, 200);
  assert.equal(users.findById(boss.id).servers_hidden, 0);                                        // the main admin is never restricted
  assert.throws(() => users.setServersHidden(boss.id, true), /main administrator/);
  // a hidden admin sees an empty panel: no users either
  const usersHtml = (await text(s, '/admin/users')).body;
  assert.doesNotMatch(usersHtml, /alice@example\.com|okay@example\.com|boss@gmail\.com/); assert.doesNotMatch(usersHtml, /Add user/);
  assert.match((await text(k, '/admin/users')).body, /alice@example\.com/);
  assert.equal((await text(s, `/admin/users/${alice.id}/edit`)).status, 404);
  assert.equal((await text(s, `/admin/users/${boss.id}/edit`)).status, 404);
  assert.equal((await s.post(`/admin/users/${alice.id}/role`, { role: 'user' }, '/admin')).status, 404);
  assert.equal((await s.post('/admin/users', { username: 'x1', email: 'x1@example.com', password: PW }, '/admin')).status, 404);
  assert.equal((await text(s, `/admin/users/${spy.id}/edit`)).status, 200);                      // their own account still opens
  assert.equal((await o.post(`/admin/privacy/${spy.id}`, { hide: '0' }, '/admin/privacy')).status, 303);
  assert.equal((await text(s, `/dashboard/servers/${sAlice.identifier}/console`)).status, 200);   // and can be switched back
  assert.match((await text(s, '/admin/users')).body, /alice@example\.com/);
});

test('Option 1: every new admin (created or promoted) can be hidden from servers automatically', async () => {
  const o = client(base); await o.login('boss', PW);
  assert.equal((await o.post('/admin/privacy/new', { hide: '1' }, '/admin/privacy')).status, 303);
  const fresh = users.create({ username: 'fresh', email: 'fresh@example.com', passwordHash: hash, role: 'admin' });
  assert.equal(users.findById(fresh.id).servers_hidden, 1);
  users.setRole(bob.id, 'admin'); assert.equal(users.findById(bob.id).servers_hidden, 1);
  users.setRole(bob.id, 'user'); assert.equal(users.findById(bob.id).servers_hidden, 0);
  assert.equal(users.findById(okay.id).servers_hidden, 0);                                         // existing admins are not touched
  await o.post('/admin/privacy/new', { hide: '0' }, '/admin/privacy');
  const later = users.create({ username: 'later', email: 'later@example.com', passwordHash: hash, role: 'admin' });
  assert.equal(users.findById(later.id).servers_hidden, 0);
});

test('only the main admin can use the privacy page and see it in the menu', async () => {
  const k = client(base); await k.login('okay', PW);
  assert.equal((await text(k, '/admin/privacy')).status, 404);
  assert.equal((await k.post(`/admin/privacy/${spy.id}`, { hide: '1' }, '/admin')).status, 404);
  const hiddenAdmin = client(base); await hiddenAdmin.login('spy', PW); users.setServersHidden(spy.id, true);
  assert.equal((await text(hiddenAdmin, '/admin/privacy')).status, 404); assert.doesNotMatch((await text(hiddenAdmin, '/admin')).body, /Admin privacy/);
  users.setServersHidden(spy.id, false);
  assert.equal(users.findById(spy.id).servers_hidden, 0);
  assert.doesNotMatch((await text(k, '/admin')).body, /Admin privacy/);
  const o = client(base); await o.login('boss', PW);
  const page = await text(o, '/admin/privacy');
  assert.equal(page.status, 200); assert.match(page.body, /spy/); assert.match((await text(o, '/admin')).body, /Admin privacy/);
});

test('only the main admin can give (or remove) the administrator role', async () => {
  const k = client(base); await k.login('okay', PW);
  assert.equal((await k.post('/admin/users', { username: 'newadm', email: 'newadm@example.com', password: PW, role: 'admin' }, '/admin/users')).status, 403);
  assert.equal((await k.post(`/admin/users/${alice.id}/role`, { role: 'admin' }, '/admin/users')).status, 403);
  assert.equal((await k.post(`/admin/users/${alice.id}`, { username: 'alice', email: 'alice@example.com', role: 'admin' }, `/admin/users/${alice.id}/edit`)).status, 403);
  assert.equal((await k.post(`/admin/users/${spy.id}/role`, { role: 'user' }, '/admin/users')).status, 403);
  assert.equal(users.findById(alice.id).role, 'user'); assert.equal(users.findById(spy.id).role, 'admin');
  assert.equal((await k.post(`/admin/users/${alice.id}`, { username: 'alice', email: 'alice@example.com', first: 'Al' }, `/admin/users/${alice.id}/edit`)).status, 303);   // ordinary edits still work
  const o = client(base); await o.login('boss', PW);
  assert.equal((await o.post(`/admin/users/${bob.id}/role`, { role: 'admin' }, '/admin/users')).status, 303);
  assert.equal(users.findById(bob.id).role, 'admin');
});
