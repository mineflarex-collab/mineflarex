'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { sortPlugins, highestClassMajor } = require('../src/runtime/plugins');
const { makeZip, klass } = require('./fixtures/zipjar');

test('class version is read from the plugin main/loader class and from other classes', async () => {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-plug-'));
  fs.writeFileSync(path.join(d, 'a.jar'), makeZip({ 'plugin.yml': 'name: A\nmain: com.a.Main\n', 'com/a/Main.class': klass(65) }));
  fs.writeFileSync(path.join(d, 'b.jar'), makeZip({ 'paper-plugin.yml': 'main: com.b.Main\nloader: com.b.Loader\n', 'com/b/Main.class': klass(61), 'com/b/Loader.class': klass(69) }));
  fs.writeFileSync(path.join(d, 'c.jar'), Buffer.from('not a zip'));
  assert.equal(await highestClassMajor(path.join(d, 'a.jar')), 65);
  assert.equal(await highestClassMajor(path.join(d, 'b.jar')), 69);
  assert.equal(await highestClassMajor(path.join(d, 'c.jar')), 0);
});

test('plugins built for a newer Java are parked (the rest stay), and come back when Java is upgraded', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-srv-')), plugins = path.join(dir, 'plugins');
  fs.mkdirSync(plugins);
  fs.writeFileSync(path.join(plugins, 'Good.jar'), makeZip({ 'plugin.yml': 'main: g.Main\n', 'g/Main.class': klass(65) }));
  fs.writeFileSync(path.join(plugins, 'Veinminer.jar'), makeZip({ 'paper-plugin.yml': 'main: v.Main\nloader: v.Loader\n', 'v/Main.class': klass(65), 'v/Loader.class': klass(69) }));
  fs.writeFileSync(path.join(plugins, 'Broken.jar'), Buffer.from('junk'));
  fs.writeFileSync(path.join(plugins, 'config.yml'), 'x: 1\n');
  const lines = [];
  let r = await sortPlugins({ dir, java: 21, say: (l) => lines.push(l) });
  assert.deepEqual(r.moved, ['Veinminer.jar']);
  assert.ok(fs.existsSync(path.join(plugins, 'Good.jar')) && fs.existsSync(path.join(plugins, 'Broken.jar')) && fs.existsSync(path.join(plugins, 'config.yml')));
  assert.ok(fs.existsSync(path.join(plugins, '.unsupported', 'Veinminer.jar')) && !fs.existsSync(path.join(plugins, 'Veinminer.jar')));
  assert.match(lines[0], /Veinminer\.jar.*Java 25.*Java 21/);
  r = await sortPlugins({ dir, java: 21, say: (l) => lines.push(l) });          // second start: nothing changes
  assert.deepEqual(r, { moved: [], restored: [] });
  r = await sortPlugins({ dir, java: 25, say: (l) => lines.push(l) });          // Java upgraded
  assert.deepEqual(r.restored, ['Veinminer.jar']);
  assert.ok(fs.existsSync(path.join(plugins, 'Veinminer.jar')));
});

test('unknown Java version or missing plugins folder: nothing happens, never throws', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-srv-'));
  assert.deepEqual(await sortPlugins({ dir, java: null, say() {} }), { moved: [], restored: [] });
  assert.deepEqual(await sortPlugins({ dir, java: 21, say() {} }), { moved: [], restored: [] });
});

test('45 plugins are checked quickly and only the incompatible ones move', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-srv-')), plugins = path.join(dir, 'plugins');
  fs.mkdirSync(plugins);
  for (let i = 0; i < 45; i++) {
    const files = { 'plugin.yml': `main: p${i}.Main\n` };
    for (let c = 0; c < 300; c++) files[`p${i}/C${c}.class`] = klass(i % 15 === 0 ? 69 : 61);   // 3 of the 45 need Java 25
    fs.writeFileSync(path.join(plugins, `Plugin-${i}.jar`), makeZip({ ...files, [`p${i}/Main.class`]: klass(i % 15 === 0 ? 69 : 61) }));
  }
  const t = Date.now(), r = await sortPlugins({ dir, java: 21, say() {} });
  assert.equal(r.moved.length, 3);
  assert.equal(fs.readdirSync(plugins).filter((n) => n.endsWith('.jar')).length, 42);
  assert.ok(Date.now() - t < 5000, `took ${Date.now() - t} ms`);
});
