'use strict';
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const runtime = require('../src/dashboard/services/runtime');
const f = require('../src/dashboard/format');
const db = require('../src/db');
const { NetMeter, parseSs } = require('../src/runtime/netmeter');
const { Supervisor } = require('../src/runtime/supervisor');

const PW = 'Sup3rSecretPass!';
let srv, base, alice, on, off;
const html = async (c, s) => (await c.req(`/dashboard/servers/${s.identifier}/console`)).text();
const at = (h, needle) => { const i = h.indexOf(needle); assert.ok(i > 0, `missing: ${needle}`); return i; };

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: await hashPassword(PW) });
  on = servers.create({ ownerId: alice.id, name: 'Lifesteal smp', ramLimitMb: 2048, cpuLimitPct: 100, diskLimitMb: 10240, address: 'play.example.com:25570' });
  off = servers.create({ ownerId: alice.id, name: 'Sleeping', ramLimitMb: 1024, address: 'play.example.com:25571' });
  runtime.reportStatus(on.id, { status: 'online', cpuUsedPct: 2.1, ramUsedMb: 612, diskUsedMb: 3000, playersOnline: 3, netRxBytes: 5 * 1048576, netTxBytes: 123456, netRxBps: 2048, netTxBps: 512 });
  runtime.reportStatus(off.id, { status: 'offline', diskUsedMb: 2048 });
});
after(() => srv.close());

test('console page order is Console, Resources, picture, Network (Players, received, sent), Connection', async () => {
  const c = client(base); await c.login('alice', PW);
  const h = await html(c, on);
  const order = ['data-console="', 'id="res-title"', '/img/herobrine-art.png', 'id="net-title"', 'Network received', 'Network sent', 'id="conn-title"'].map((n) => at(h, n));
  assert.deepEqual([...order].sort((x, y) => x - y), order, 'sections appear in the requested order');
  assert.ok(at(h, '>Players<') > at(h, '/img/herobrine-art.png'), 'Players tile is below the picture');
});

test('Resources shows CPU, Memory and Storage with used / limit, percentage, bar, limit and free (real values)', async () => {
  const c = client(base); await c.login('alice', PW);
  const h = await html(c, on);
  for (const m of ['data-res="cpu"', 'data-res="ram"', 'data-res="disk"', '0.02 / 1 core', '612 MB / 2 GB', '2.9 GB / 10 GB', '>2.1%<', '>30%<', '>29%<',
    'Limit <b>1 core</b> \\(100%\\)', 'Limit <b>2 GiB</b>', 'Limit <b>10 GiB</b>', '2.1% of one core', '1.4 GB</b> free', '7.1 GB</b> free']) assert.match(h, new RegExp(m), m);
  assert.match(h, /<progress value="612" max="2048" data-live-progress="ram"/);
  assert.match(h, /<progress value="3000" max="10240" data-live-progress="disk"/);
});

test('Network shows measured totals and rates; Players uses the live count', async () => {
  const c = client(base); await c.login('alice', PW);
  const h = await html(c, on);
  assert.match(h, /data-live="net\.rx\.total"[^>]*>5\.00 MB</); assert.match(h, /data-live="net\.tx\.total"[^>]*>121 KB</);
  assert.match(h, /data-live="net\.rx\.rate"[^>]*>2\.00 KB\/s</); assert.match(h, /data-live="net\.tx\.rate"[^>]*>512 B\/s</);
  assert.match(h, /data-live="players"[^>]*>3 \/ 20</);
  assert.match(h, /TCP traffic on the server port/);
  assert.match(h, /<code>25570<\/code>/); assert.match(h, /play\.example\.com:25570/);
});

test('offline server: no invented numbers (usage and traffic are "—"), storage is still real', async () => {
  const c = client(base); await c.login('alice', PW);
  const h = await html(c, off);
  assert.match(h, /data-live="net\.rx\.total"[^>]*>—</); assert.match(h, /Server is offline/); assert.match(h, /Status query unavailable/);
  assert.match(h, /data-live="cpu\.text"[^>]*>—</); assert.match(h, /data-live="ram\.text"[^>]*>—</);
  assert.match(h, /data-live="disk\.text"[^>]*>2 GB \/ 10 GB</);
});

test('online but the host cannot measure traffic: says so instead of showing 0', async () => {
  const s = servers.create({ ownerId: alice.id, name: 'No ss', address: 'play.example.com:25572' });
  runtime.reportStatus(s.id, { status: 'online', ramUsedMb: 10, playersOnline: 0 });          // runtime sent no network numbers
  const c = client(base); await c.login('alice', PW);
  const h = await html(c, s);
  assert.match(h, /data-live="net\.rx\.total"[^>]*>—</); assert.match(h, /needs the ss tool/);
  const api = await (await c.req(`/api/dashboard/servers/${s.identifier}`, { headers: { accept: 'application/json' } })).json();
  assert.equal(api.server.net.available, false);
});

test('stored traffic is cleared when the server goes offline and API exposes it while online', async () => {
  const c = client(base); await c.login('alice', PW);
  const api = await (await c.req(`/api/dashboard/servers/${on.identifier}`, { headers: { accept: 'application/json' } })).json();
  assert.deepEqual(api.server.net, { available: true, note: api.server.net.note, rx: { bytes: 5242880, bps: 2048, total: '5.00 MB', rate: '2.00 KB/s' }, tx: { bytes: 123456, bps: 512, total: '121 KB', rate: '512 B/s' } });
  const tmp = servers.create({ ownerId: alice.id, name: 'Tmp', address: 'play.example.com:25573' });
  runtime.reportStatus(tmp.id, { status: 'online', netRxBytes: 10, netTxBytes: 10, netRxBps: 1, netTxBps: 1 });
  runtime.reportStatus(tmp.id, { status: 'offline' });
  const row = db.prepare('SELECT net_rx_bytes, net_tx_bytes, net_rx_bps, net_tx_bps FROM servers WHERE id = ?').get(tmp.id);
  assert.deepEqual({ ...row }, { net_rx_bytes: null, net_tx_bytes: null, net_rx_bps: null, net_tx_bps: null });
});

test('format helpers', () => {
  assert.deepEqual([f.bytes(0), f.bytes(1023), f.bytes(1536), f.bytes(5 * 1048576), f.bytes(150 * 1048576), f.bytes(null)], ['0 B', '1023 B', '1.50 KB', '5.00 MB', '150 MB', '—']);
  assert.equal(f.rate(2048), '2.00 KB/s'); assert.equal(f.pctText(2.1, 100), '2.1%'); assert.equal(f.pctText(450, 2048), '22%'); assert.equal(f.pctText(1, 0), '0%');
});

// ---------------------------------------------------------------- the meter (kernel TCP counters via `ss`)
const SS = (rows) => `State Recv-Q Send-Q Local Address:Port Peer Address:Port\n${rows.map(([peer, sent, recv]) => `ESTAB 0      0          10.0.0.5:25565   ${peer}\n\t cubic wscale:7,7 rto:204 rtt:3.2/1.5 mss:1448 cwnd:10 bytes_sent:${sent} bytes_acked:${sent} bytes_received:${recv} segs_out:10 segs_in:12\n`).join('')}`;

test('parseSs reads real ss -tin output (header, two lines per connection, IPv6)', () => {
  const out = parseSs(SS([['203.0.113.9:51234', 4096, 1500], ['[2001:db8::1]:40000', 10, 20]]));
  assert.deepEqual(out, [{ key: '10.0.0.5:25565>203.0.113.9:51234', sent: 4096, recv: 1500 }, { key: '10.0.0.5:25565>[2001:db8::1]:40000', sent: 10, recv: 20 }]);
  assert.deepEqual(parseSs(''), []); assert.deepEqual(parseSs('State Recv-Q Send-Q Local Address:Port Peer Address:Port\n'), []);
});

test('NetMeter adds up growth per connection, keeps totals after players leave, computes rates, survives counter resets', async () => {
  let text = SS([['1.1.1.1:1', 1000, 100]]), t = 0;
  const m = new NetMeter({ port: 25565, run: async () => text, now: () => t });
  let r = await m.sample();
  assert.deepEqual(r, { rx: 100, tx: 1000, rxBps: 0, txBps: 0 });                     // first sample: no interval yet
  t = 5000; text = SS([['1.1.1.1:1', 6000, 600], ['2.2.2.2:2', 500, 50]]);
  r = await m.sample();
  assert.deepEqual(r, { rx: 650, tx: 6500, rxBps: 110, txBps: 1100 });                // +500 +50 rx, +5000 +500 tx over 5 s
  t = 10000; text = SS([]);                                                           // everybody left
  r = await m.sample();
  assert.deepEqual(r, { rx: 650, tx: 6500, rxBps: 0, txBps: 0 });                     // totals stay
  t = 15000; text = SS([['1.1.1.1:1', 300, 30]]);                                     // same ends reconnected: counters start again at 0
  r = await m.sample();
  assert.deepEqual([r.rx, r.tx], [680, 6800]);
});

test('NetMeter without ss (ENOENT) reports "not measurable" and stops trying; no port = not measurable', async () => {
  let calls = 0;
  const m = new NetMeter({ port: 25565, run: async () => { calls++; throw Object.assign(new Error('spawn ss ENOENT'), { code: 'ENOENT' }); } });
  assert.equal(await m.sample(), null); assert.equal(await m.sample(), null); assert.equal(calls, 1);
  assert.equal(await new NetMeter({ port: null, run: async () => { throw new Error('never'); } }).sample(), null);
  const flaky = new NetMeter({ port: 1, run: async () => { throw new Error('timeout'); } });
  assert.equal(await flaky.sample(), null); assert.equal(flaky.broken, false, 'a temporary failure does not disable the meter');
});

test('supervisor: a running server reports traffic from the (fake) ss tool and clears it when stopped', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-net-')), counter = path.join(dir, 'n');
  fs.writeFileSync(counter, '0');
  const fakeSs = path.join(dir, 'fake-ss.js');                                          // prints a connection whose counters grow on every call
  fs.writeFileSync(fakeSs, `#!/usr/bin/env node\nconst fs=require('fs');const n=Number(fs.readFileSync(${JSON.stringify(counter)},'utf8'))+1;fs.writeFileSync(${JSON.stringify(counter)},String(n));\nprocess.stdout.write('State Recv-Q Send-Q Local Address:Port Peer Address:Port\\nESTAB 0 0 10.0.0.5:'+process.argv[process.argv.indexOf('sport')+2].slice(1)+' 9.9.9.9:5555\\n\\t cubic bytes_sent:'+(n*1000)+' bytes_received:'+(n*100)+'\\n');\n`, { mode: 0o755 });
  const owner = users.create({ username: 'ops', email: 'ops@example.com', passwordHash: 'x' });
  const s = servers.create({ ownerId: owner.id, name: 'Net', startCommand: `node "${path.join(__dirname, 'fixtures', 'fake-mc.js')}"`, ramLimitMb: 512 });
  const sup = new Supervisor({ dataDir: dir, pollMs: 40, metricsMs: 120, startTimeoutMs: 4000, stopTimeoutMs: 1500, killTimeoutMs: 800, ssBin: fakeSs, netStats: true, cgroups: false });
  sup.start();
  try {
    servers.requestCommand(owner, s.id, 'start', '127.0.0.1', { confirmed: true });
    const get = () => db.prepare('SELECT status, net_rx_bytes, net_tx_bytes FROM servers WHERE id = ?').get(s.id);
    const t0 = Date.now(); let row;
    while (Date.now() - t0 < 10000) { row = get(); if (row.status === 'online' && row.net_tx_bytes >= 3000) break; await new Promise((r) => setTimeout(r, 60)); }
    assert.equal(row.status, 'online'); assert.ok(row.net_tx_bytes >= 3000 && row.net_rx_bytes >= 300, JSON.stringify(row));
    servers.requestCommand(owner, s.id, 'stop', '127.0.0.1', { confirmed: true });
    const t1 = Date.now(); while (Date.now() - t1 < 10000 && get().status !== 'offline') await new Promise((r) => setTimeout(r, 60));
    assert.deepEqual({ ...get() }, { status: 'offline', net_rx_bytes: null, net_tx_bytes: null });
  } finally { await sup.shutdown(); fs.rmSync(dir, { recursive: true, force: true }); }
});
