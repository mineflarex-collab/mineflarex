'use strict';
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.VPS_RAM_MB = '1048576'; process.env.VPS_CPU_CORES = '1000'; process.env.VPS_DISK_MB = '10485760';   // a huge VPS: capacity limits are tested in admin.test.js
process.env.MAIL_QUIET = 'true';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const settings = require('../src/services/settings');
const capacity = require('../src/dashboard/services/capacity');

let srv, base, root, alice;
const PW = 'Sup3rSecretPass!';
const text = (r) => r.text();
// 1x1 PNG
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW);
  root = users.create({ username: 'root-admin', email: 'root@example.com', passwordHash: hash, role: 'admin' });
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: hash });
});
after(() => srv.close());

const admin = async () => { const a = client(base); await a.login('root-admin', PW); return a; };
// The shared test client only sends form / JSON bodies, so raw uploads go through fetch with the same cookies.
const rawPost = (a, path, body, headers = {}) => fetch(base + path, { method: 'POST', redirect: 'manual', body,
  headers: { cookie: Object.entries(a.jar).map(([k, v]) => `${k}=${v}`).join('; '), accept: 'application/json', ...headers } });
const upload = async (a, body, type = 'application/octet-stream') => rawPost(a, '/admin/settings/logo', body, { 'content-type': type, 'x-csrf-token': await a.csrf('/admin/settings') });

test('admin sidebar: Users, Servers nest (Bot Host + MC Host) and Settings', async () => {
  const a = await admin();
  const r = await a.req('/admin'); assert.equal(r.status, 200);
  const html = await text(r);
  assert.match(html, /href="\/admin\/users"[^>]*>.*?<span>Users<\/span>/s);
  assert.match(html, /<details class="mp-nav-group mp-nest" open><summary>.*?<span>Servers<\/span>/s);
  assert.match(html, /href="\/admin\/servers\/bots"[^>]*>.*?<span>Bot Host<\/span>/s);
  assert.match(html, /href="\/admin\/servers\/mc"[^>]*>.*?<span>MC Host<\/span>/s);
  assert.match(html, /href="\/admin\/settings"[^>]*>.*?<span>Settings<\/span>/s);
  assert.doesNotMatch(html, /MC UTILS/);
});

test('admin pages are admin-only', async () => {
  const u = client(base); await u.login('alice', PW);
  for (const p of ['/admin', '/admin/users', '/admin/servers/mc', '/admin/servers/bots', '/admin/settings']) assert.equal((await u.req(p)).status, 403, p);
  assert.equal((await u.post('/admin/settings/name', { name: 'Hacked' }, '/dashboard')).status, 403);
  const anon = client(base);
  assert.equal((await anon.req('/admin/users')).status, 303);
});

test('users: list, search, add, role and status changes, last admin is protected', async () => {
  const a = await admin();
  const list = await text(await a.req('/admin/users'));
  assert.match(list, /alice/); assert.match(list, /root-admin/);
  assert.doesNotMatch(await text(await a.req('/admin/users?q=zzzz')), /alice@example/);

  const bad = await a.post('/admin/users', { username: 'x', email: 'nope', password: 'short', role: 'user' }, '/admin/users');
  assert.equal(bad.status, 422);
  const ok = await a.post('/admin/users', { username: 'newbie', email: 'newbie@example.com', password: 'Sup3rSecretPass!', role: 'user' }, '/admin/users');
  assert.equal(ok.status, 303);
  const newbie = users.findByUsername('newbie'); assert.ok(newbie); assert.equal(newbie.role, 'user');
  assert.match(await text(await a.post('/admin/users', { username: 'newbie', email: 'other@example.com', password: PW, role: 'user' }, '/admin/users')), /username is taken/);

  assert.equal((await a.post(`/admin/users/${newbie.id}/role`, { role: 'admin' }, '/admin/users')).status, 303);
  assert.equal(users.findById(newbie.id).role, 'admin');
  assert.equal((await a.post(`/admin/users/${newbie.id}/role`, { role: 'user' }, '/admin/users')).status, 303);
  assert.equal((await a.post(`/admin/users/${newbie.id}/active`, { active: '0' }, '/admin/users')).status, 303);
  assert.equal(users.findById(newbie.id).is_active, 0);
  const dis = client(base);
  assert.match(await text(await dis.login('newbie', PW)), /disabled/);

  assert.equal((await a.post(`/admin/users/${root.id}/role`, { role: 'user' }, '/admin/users')).status, 400);   // cannot change yourself
  assert.equal(users.findById(root.id).role, 'admin');
  assert.equal(users.countActiveAdmins(), 1);
});

test('MC Host: Paper only; Bot Host: Python / Node.js bots', async () => {
  const a = await admin();
  // MC Host
  const mcForm = await text(await a.req('/admin/servers/new?kind=mc'));
  assert.match(mcForm, /value="Paper" disabled/); assert.match(mcForm, /name="software" value="paper"/); assert.doesNotMatch(mcForm, /name="runtime"/);
  const mc = await a.post('/admin/servers', { kind: 'mc', name: 'Lobby', owner: 'alice', software: 'forge', version: '1.21.4', ram: '2048', cpu: '100', disk: '4096', players: '20' }, '/admin/servers/new?kind=mc');
  assert.equal(mc.status, 303);
  const lobby = servers.listForOwner(alice.id).find((s) => s.name === 'Lobby');
  assert.equal(lobby.kind, 'mc'); assert.equal(lobby.software, 'paper'); assert.equal(lobby.runtime, null);

  // Bot Host
  const botForm = await text(await a.req('/admin/servers/new?kind=bot'));
  assert.match(botForm, /name="runtime"/); assert.match(botForm, />Python</); assert.match(botForm, />Node\.js</); assert.match(botForm, /already installed/);
  const bad = await a.post('/admin/servers', { kind: 'bot', name: 'B', owner: 'alice', runtime: 'ruby', ram: '512', cpu: '100', disk: '1024' }, '/admin/servers/new?kind=bot');
  assert.equal(bad.status, 422); assert.match(await text(bad), /Choose Python or Node\.js/);
  const evil = await a.post('/admin/servers', { kind: 'bot', name: 'B', owner: 'alice', runtime: 'python', entry: '../../etc/passwd', ram: '512', cpu: '100', disk: '1024' }, '/admin/servers/new?kind=bot');
  assert.equal(evil.status, 422);
  const py = await a.post('/admin/servers', { kind: 'bot', name: 'PyBot', owner: 'alice', runtime: 'python', ram: '512', cpu: '100', disk: '1024' }, '/admin/servers/new?kind=bot');
  assert.equal(py.status, 303);
  const js = await a.post('/admin/servers', { kind: 'bot', name: 'JsBot', owner: 'alice', runtime: 'nodejs', entry: 'src/bot.js', ram: '512', cpu: '100', disk: '1024' }, '/admin/servers/new?kind=bot');
  assert.equal(js.status, 303);
  const mine = servers.listForOwner(alice.id);
  const pyBot = mine.find((s) => s.name === 'PyBot'), jsBot = mine.find((s) => s.name === 'JsBot');
  assert.equal(pyBot.kind, 'bot'); assert.equal(pyBot.runtime, 'python'); assert.equal(pyBot.start_command, 'python3 -u main.py');
  assert.equal(jsBot.runtime, 'nodejs'); assert.equal(jsBot.start_command, 'node src/bot.js');

  // the two lists are separate
  const mcList = await text(await a.req('/admin/servers/mc')), botList = await text(await a.req('/admin/servers/bots'));
  assert.match(mcList, /Lobby/); assert.doesNotMatch(mcList, /PyBot/);
  assert.match(botList, /PyBot/); assert.match(botList, /JsBot/); assert.doesNotMatch(botList, /Lobby/);
  assert.match(botList, /Python/); assert.match(botList, /Node\.js/);
  assert.match(await text(await a.req('/admin/servers/bots?q=jsb')), /JsBot/);
  assert.doesNotMatch(await text(await a.req('/admin/servers/bots?q=jsb')), /PyBot/);

  // bot server pages hide the Minecraft tools
  const page = await text(await a.req(`/dashboard/servers/${pyBot.identifier}`));
  assert.doesNotMatch(page, /MC UTILS/); assert.match(page, /Bot Host/); assert.match(page, /python3 -u main\.py/);
  assert.match(await text(await a.req(`/dashboard/servers/${lobby.identifier}`)), /MC UTILS/);
});

test('Settings: panel name and logo', async () => {
  const a = await admin();
  assert.match(await text(await a.req('/admin/settings')), /name="name"/);
  // name
  assert.equal((await a.post('/admin/settings/name', { name: 'x' }, '/admin/settings')).status, 422);
  assert.equal((await a.post('/admin/settings/name', { name: 'Nebula <Host>' }, '/admin/settings')).status, 422);
  assert.equal((await a.post('/admin/settings/name', { name: 'Nebula Host' }, '/admin/settings')).status, 303);
  assert.equal(settings.brand(), 'Nebula Host');
  assert.match(await text(await client(base).req('/login')), /Nebula Host/);       // the sign-in page uses it too
  assert.match(await text(await a.req('/dashboard')), /<title>Dashboard · Nebula Host<\/title>/);
  // logo
  assert.equal((await client(base).req('/brand/logo')).status, 302);                // none uploaded yet: falls back to the default
  assert.equal((await upload(a, Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"></svg>'))).status, 422);   // SVG refused
  assert.equal((await upload(a, Buffer.from('just text'))).status, 422);
  assert.equal((await upload(a, Buffer.alloc(2 * 1024 * 1024, 1))).status, 413);
  assert.equal((await upload(a, PNG, 'text/plain')).status, 415);
  const ok = await upload(a, PNG); assert.equal(ok.status, 200);
  const url = (await ok.json()).url; assert.match(url, /^\/brand\/logo\?v=\d+$/);
  const anon = client(base), img = await anon.req('/brand/logo');
  assert.equal(img.status, 200); assert.equal(img.headers.get('content-type'), 'image/png');
  assert.deepEqual(Buffer.from(await img.arrayBuffer()), PNG);
  assert.match(await text(await a.req('/dashboard')), /src="\/brand\/logo\?v=\d+"/);
  // CSRF is required for uploads
  assert.equal((await rawPost(a, '/admin/settings/logo', PNG, { 'content-type': 'application/octet-stream' })).status, 403);
  // resets
  assert.equal((await a.post('/admin/settings/logo/reset', {}, '/admin/settings')).status, 303);
  assert.equal(settings.hasCustomLogo(), false);
  assert.equal((await a.post('/admin/settings/name', { reset: '1', name: '' }, '/admin/settings')).status, 303);
  assert.notEqual(settings.brand(), 'Nebula Host');
});

// A fake VPS: 8 GB RAM, 64 cores, 100 GB disk, with the given real usage (percent).
const fakeVps = (ramPct = 10, cpuPct = 10, diskPct = 10) => capacity.setProbe(() => ({
  ram: { total: 8192, used: 8192 * ramPct / 100 }, cpu: { total: 6400, used: 6400 * cpuPct / 100 }, disk: { total: 102400, used: 102400 * diskPct / 100 }
}));

test('VPS capacity: servers are unlimited while the VPS has room, and there is no Node option', async () => {
  fakeVps();
  const a = await admin();
  assert.doesNotMatch(await text(await a.req('/admin/servers/new?kind=bot')), /name="node"/);
  assert.doesNotMatch(await text(await a.req('/admin/servers/bots')), />Node</);
  const page = await text(await a.req('/admin/servers/mc'));
  assert.match(page, /VPS capacity/); assert.match(page, /no limit on the number of servers/); assert.doesNotMatch(page, /VPS is full/);
  for (let i = 1; i <= 6; i++) {      // no cap on how many: six small servers in a row
    const r = await a.post('/admin/servers', { kind: 'bot', name: `Many${i}`, owner: 'alice', runtime: 'python', ram: '256', cpu: '10', disk: '256' }, '/admin/servers/new?kind=bot');
    assert.equal(r.status, 303, `server ${i}`);
  }
  // one server that would push RAM past 90% of the VPS (8192 MB * 0.9 = 7372 MB) is refused
  const big = await a.post('/admin/servers', { kind: 'mc', name: 'TooBig', owner: 'alice', version: 'latest', ram: '8000', cpu: '100', disk: '1024', players: '20' }, '/admin/servers/new?kind=mc');
  assert.equal(big.status, 422); assert.match(await text(big), /above 90% of the VPS/);
  assert.equal(servers.listAll().some((s) => s.name === 'TooBig'), false);
});

test('VPS capacity: at 90% the admin gets a centred warning and no server can be created', async () => {
  fakeVps(91, 10, 10);                // RAM really in use: 91%
  const a = await admin();
  const home = await text(await a.req('/admin/users'));
  assert.match(home, /class="mp-capacity-alert" role="alert"/);
  assert.match(home, /VPS is full/); assert.match(home, /RAM 91%/);
  assert.match(home, /Do not create any more servers\. Upgrade your VPS to add more\./);
  assert.match(await text(await a.req('/admin/settings')), /VPS is full/);                       // on every admin page
  const list = await text(await a.req('/admin/servers/bots'));
  assert.match(list, /mp-btn-primary is-disabled/); assert.doesNotMatch(list, /href="\/admin\/servers\/new\?kind=bot"/);
  assert.match(await text(await a.req('/admin/servers/new?kind=mc')), /type="submit" class="mp-button mp-btn-inline" disabled/);
  const before = servers.countByKind('bot');
  const r = await a.post('/admin/servers', { kind: 'bot', name: 'Blocked', owner: 'alice', runtime: 'python', ram: '128', cpu: '10', disk: '128' }, '/admin/servers/new?kind=bot');
  assert.equal(r.status, 422); assert.match(await text(r), /Upgrade your VPS/);
  assert.equal(servers.countByKind('bot'), before);
  // allocation counts too: limits handed out to servers reaching 90% of the disk fill it up even if little is really used
  fakeVps(10, 10, 10);
  assert.doesNotMatch(await text(await a.req('/admin/users')), /VPS is full/);
  capacity.setProbe(() => ({ ram: { total: 8192, used: 0 }, cpu: { total: 6400, used: 0 }, disk: { total: 4000, used: 0 } }));   // tiny disk: servers already hold more than 90% of it
  assert.match(await text(await a.req('/admin/users')), /Disk \d+%/);
  // regular users never see the admin warning
  fakeVps(95, 95, 95);
  const u = client(base); await u.login('alice', PW);
  assert.doesNotMatch(await text(await u.req('/dashboard')), /VPS is full/);
  capacity.setProbe();
});

test('admin pencil: edit resources and IP of a server', async () => {
  const a = await admin();
  const s = servers.create({ kind: 'mc', ownerId: alice.id, name: 'EditMe', ramLimitMb: 1024, cpuLimitPct: 100, diskLimitMb: 2048 });
  const url = `/admin/servers/${s.identifier}/edit`;
  assert.match(await text(await a.req('/admin/servers/mc')), new RegExp(`href="${url}"`));   // pencil in the list
  const form = await text(await a.req(url)); assert.match(form, /name="ram" type="number" value="1024"/); assert.match(form, /name="address"/);

  const bad = await a.post(url, { ram: '5', cpu: '100', disk: '2048', address: 'bad ip!', players: '20' }, url);
  assert.equal(bad.status, 422);
  assert.equal(servers.getForOwner(alice.id, s.id).ram_limit_mb, 1024);

  const ok = await a.post(url, { ram: '4096', cpu: '200', disk: '8192', address: '203.0.113.10:25565', players: '50' }, url);
  assert.equal(ok.status, 303);
  const after = servers.getForOwner(alice.id, s.id);
  assert.equal(after.ram_limit_mb, 4096); assert.equal(after.cpu_limit_pct, 200); assert.equal(after.disk_limit_mb, 8192);
  assert.equal(after.address, '203.0.113.10:25565'); assert.equal(after.players_max, 50);
  assert.equal((await a.post(url, { ram: '4096', cpu: '200', disk: '8192', address: '', players: '50' }, url)).status, 303);
  assert.equal(servers.getForOwner(alice.id, s.id).address, null);

  assert.equal((await a.req('/admin/servers/deadbeef/edit')).status, 404);
  const u = client(base); await u.login('alice', PW);
  assert.equal((await u.req(url)).status, 403);
  assert.equal((await u.post(url, { ram: '999999', cpu: '100', disk: '2048' }, '/dashboard')).status, 403);
});

test('admin pencil: cannot raise limits past the VPS cap, lowering is always allowed', async () => {
  const a = await admin();
  capacity.setProbe(() => ({ ram: { total: 10000, used: 0 }, cpu: { total: 1000, used: 0 }, disk: { total: 100000, used: 0 } }));
  try {
    const s = servers.create({ kind: 'mc', ownerId: alice.id, name: 'CapEdit', ramLimitMb: 128, cpuLimitPct: 10, diskLimitMb: 128 });
    const url = `/admin/servers/${s.identifier}/edit`;
    const over = await a.post(url, { ram: '9999', cpu: '10', disk: '128', players: '20' }, url);
    assert.equal(over.status, 422); assert.match(await text(over), /above 90%/);
    assert.equal(servers.getForOwner(alice.id, s.id).ram_limit_mb, 128);
    assert.equal((await a.post(url, { ram: '128', cpu: '10', disk: '128', players: '20' }, url)).status, 303);
  } finally { capacity.setProbe(); }
});

test('users: edit page changes username, email, role, status and password; last admin and self are protected', async () => {
  const a = await admin();
  const u = users.create({ username: 'editme', email: 'editme@example.com', passwordHash: await hashPassword(PW) });
  const page = await text(await a.req(`/admin/users/${u.id}/edit`)); assert.match(page, /name="role"/);
  const ok = await a.post(`/admin/users/${u.id}`, { username: 'edited', email: 'edited@example.com', role: 'admin', active: '1', password: '' }, `/admin/users/${u.id}/edit`);
  assert.equal(ok.status, 303);
  const e = users.findById(u.id); assert.equal(e.username, 'edited'); assert.equal(e.role, 'admin'); assert.equal(e.email, 'edited@example.com');
  assert.equal((await a.post(`/admin/users/${u.id}`, { username: 'edited', email: 'edited@example.com', role: 'user', active: '0', password: 'N3wSecretPass!x' }, `/admin/users/${u.id}/edit`)).status, 303);
  const d = users.findById(u.id); assert.equal(d.role, 'user'); assert.equal(d.is_active, 0);
  const root = users.findByUsername('root-admin');                                    // own role cannot be changed through the form
  await a.post(`/admin/users/${root.id}`, { username: 'root-admin', email: 'root@example.com', role: 'user', active: '0' }, `/admin/users/${root.id}/edit`);
  assert.equal(users.findById(root.id).role, 'admin'); assert.equal(users.findById(root.id).is_active, 1);
  assert.equal((await a.post(`/admin/users/${u.id}`, { username: 'alice', email: 'x@example.com', role: 'user', active: '1' }, `/admin/users/${u.id}/edit`)).status, 422);   // username taken
});
