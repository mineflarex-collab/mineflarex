'use strict';
// Main administrator (the first admin = the installer's account): other admins cannot change, demote, disable or delete it.
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const db = require('../src/db');

const PW = 'Sup3rSecretPass!';
let srv, base, owner, other, plain;

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW);
  owner = users.create({ username: 'boss', email: 'boss@gmail.com', passwordHash: hash, role: 'admin' });
  other = users.create({ username: 'second', email: 'second@example.com', passwordHash: hash, role: 'admin' });
  plain = users.create({ username: 'plain', email: 'plain@example.com', passwordHash: hash });
});
after(() => { srv.closeAllConnections?.(); srv.close(); });

test('the first admin is the main admin; later admins and users are not', () => {
  assert.equal(users.findById(owner.id).is_owner, 1);
  assert.equal(users.findById(other.id).is_owner, 0);
  assert.equal(users.findById(plain.id).is_owner, 0);
  users.setRole(plain.id, 'admin'); users.setRole(plain.id, 'user');            // promoting someone later never moves the title
  assert.equal(users.findById(plain.id).is_owner, 0);
});

test('another admin cannot edit, reset the password of, demote, disable or delete the main admin', async () => {
  const a = client(base); await a.login('second', PW);
  const before = users.findById(owner.id);
  assert.equal((await a.req(`/admin/users/${owner.id}/edit`)).status, 403);
  for (const [path, body] of [[`/admin/users/${owner.id}`, { username: 'hacked', email: 'x@y.zz', role: 'user', password: 'N3wPassw0rd!!' }],
    [`/admin/users/${owner.id}/role`, { role: 'user' }], [`/admin/users/${owner.id}/active`, { active: '0' }], [`/admin/users/${owner.id}/delete`, {}]]) {
    const res = await a.post(path, body, '/admin/users');
    assert.equal(res.status, 403, path);
  }
  const after = users.findById(owner.id);
  assert.equal(after.role, 'admin'); assert.equal(after.is_active, 1); assert.equal(after.username, 'boss');
  assert.equal(after.password_hash, before.password_hash);
  const list = await (await a.req('/admin/users')).text();
  assert.match(list, /Main admin/); assert.match(list, /Protected/); assert.doesNotMatch(list, new RegExp(`/admin/users/${owner.id}/edit`));
});

test('the main admin can still edit its own profile and password; others stay editable', async () => {
  const o = client(base); await o.login('boss', PW);
  const res = await o.post(`/admin/users/${owner.id}`, { username: 'boss', email: 'boss@gmail.com', first: 'Main', last: 'Admin', password: 'An0therPassw0rd!' }, `/admin/users/${owner.id}/edit`);
  assert.equal(res.status, 303);
  assert.equal(users.findById(owner.id).first_name, 'Main');
  assert.equal((await o.post(`/admin/users/${other.id}/role`, { role: 'user' }, '/admin/users')).status, 303);   // the main admin can manage other admins
});

test('the service layer refuses to demote, disable or delete the main admin', () => {
  assert.throws(() => users.setRole(owner.id, 'user'), /main administrator/);
  assert.throws(() => users.setActive(owner.id, false), /main administrator/);
  assert.throws(() => users.remove(owner.id), /main administrator/);
  assert.throws(() => users.update(owner.id, { username: 'boss', email: 'boss@gmail.com', role: 'user' }), /main administrator/);
});
