'use strict';
// Unarchive: real archives (built here, no external tools), real files on disk, through the real HTTP API.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-unarch-'));
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';
process.env.RUNTIME_DATA_DIR = DATA;

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const access = require('../src/dashboard/services/access');
const activity = require('../src/dashboard/services/activity');
const archive = require('../src/lib/archive');

const PW = 'Sup3rSecretPass!';
let srv, base, alice, bob, dave, mine, small, OUTSIDE, root;
const sessions = new Map();
const as = async (name) => { if (!sessions.has(name)) { const c = client(base); await c.login(name, PW); sessions.set(name, c); } return sessions.get(name); };
const url = (s, tail = '') => `/api/dashboard/servers/${s.identifier}/files${tail}`;
const post = async (c, s, tail, json) => { const r = await c.api(url(s, tail), json); return { status: r.status, body: await r.json() }; };
const status = async (c, s) => (await (await c.req(url(s, '/unarchive'), { headers: { accept: 'application/json' } })).json()).job;
const waitDone = async (c, s, ms = 20000) => {
  const end = Date.now() + ms;
  for (;;) { const j = await status(c, s); if (j && j.state !== 'running') return j; if (Date.now() > end) throw new Error('job did not finish'); await new Promise((r) => setTimeout(r, 40)); }
};
const put = (srvRoot, rel, buf) => { const p = path.join(srvRoot, rel); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, buf); };

// ---- tiny archive builders (the code under test must read what OTHER tools write, so these follow the real formats) ----
function tarEntry({ name, data = Buffer.alloc(0), type = '0', mode = 0o644, link = '' }) {
  const h = Buffer.alloc(512);
  const nameBuf = Buffer.from(name);
  const octal = (v, n) => Buffer.from(v.toString(8).padStart(n - 1, '0') + '\0');
  nameBuf.copy(h, 0, 0, Math.min(100, nameBuf.length));
  octal(mode, 8).copy(h, 100); octal(0, 8).copy(h, 108); octal(0, 8).copy(h, 116);
  octal(type === '5' || type === '2' ? 0 : data.length, 12).copy(h, 124); octal(1700000000, 12).copy(h, 136);
  h.fill(0x20, 148, 156); h[156] = type.charCodeAt(0); Buffer.from(link).copy(h, 157);
  Buffer.from('ustar\0').copy(h, 257); Buffer.from('00').copy(h, 263);
  let sum = 0; for (const b of h) sum += b;
  Buffer.from(sum.toString(8).padStart(6, '0') + '\0 ').copy(h, 148);
  const body = type === '0' ? Buffer.concat([data, Buffer.alloc((512 - (data.length % 512)) % 512)]) : Buffer.alloc(0);
  return Buffer.concat([h, body]);
}
const tar = (entries) => Buffer.concat([...entries.map(tarEntry), Buffer.alloc(1024)]);
function zip(entries) {
  const locals = [], central = []; let off = 0;
  for (const e of entries) {
    const name = Buffer.from(e.name), raw = e.data || Buffer.alloc(0), deflate = e.deflate !== false && raw.length > 0;
    const body = deflate ? zlib.deflateRawSync(raw) : raw, crc = e.badCrc ? 1234 : zlib.crc32(raw);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(deflate ? 8 : 0, 8);
    lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(body.length, 18); lh.writeUInt32LE(raw.length, 22); lh.writeUInt16LE(name.length, 26);
    const cd = Buffer.alloc(46); cd.writeUInt32LE(0x02014b50, 0); cd.writeUInt16LE((3 << 8) | 20, 4); cd.writeUInt16LE(20, 6); cd.writeUInt16LE(deflate ? 8 : 0, 10);
    cd.writeUInt32LE(crc, 16); cd.writeUInt32LE(body.length, 20); cd.writeUInt32LE(raw.length, 24); cd.writeUInt16LE(name.length, 28);
    cd.writeUInt32LE(((e.mode ?? (name.toString().endsWith('/') ? 0o040755 : 0o100644)) << 16) >>> 0, 38); cd.writeUInt32LE(off, 42);
    locals.push(lh, name, body); central.push(cd, name); off += 30 + name.length + body.length;
  }
  const cdBuf = Buffer.concat(central), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10); end.writeUInt32LE(cdBuf.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...locals, cdBuf, end]);
}

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW);
  [alice, bob, dave] = ['alice', 'bob', 'dave'].map((u) => users.create({ username: u, email: `${u}@example.com`, passwordHash: hash }));
  mine = servers.create({ ownerId: alice.id, name: 'Unarch', ramLimitMb: 512 });
  small = servers.create({ ownerId: alice.id, name: 'Tiny disk', ramLimitMb: 512, diskLimitMb: 1 });
  access.grant({ serverId: mine.id, userId: bob.id, permissions: ['files.view'] });
  root = path.join(DATA, mine.identifier);
  fs.mkdirSync(root, { recursive: true });
  OUTSIDE = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-unarch-outside-'));
});
after(() => { srv.close(); fs.rmSync(DATA, { recursive: true, force: true }); fs.rmSync(OUTSIDE, { recursive: true, force: true }); });

test('kindOf recognises the supported archive names', () => {
  assert.equal(archive.kindOf('A.ZIP'), 'zip'); assert.equal(archive.kindOf('b.tar.gz'), 'tgz'); assert.equal(archive.kindOf('abad46a8-369c.tar.gz'), 'tgz');
  assert.equal(archive.kindOf('c.tgz'), 'tgz'); assert.equal(archive.kindOf('d.tar'), 'tar'); assert.equal(archive.kindOf('log.gz'), 'gz');
  assert.equal(archive.kindOf('x.7z'), null); assert.equal(archive.kindOf('x.rar'), null); assert.equal(archive.kindOf('x.tar.xz'), null); assert.equal(archive.kindOf('server.jar'), null);
});

test('tar.gz backup: extracts folders and files next to the archive, keeps content, reports counts, writes the activity log', async () => {
  const c = await as('alice'), big = Buffer.alloc(300000, 'minecraft '), listing = [];
  const t = tar([
    { name: './', type: '5' }, { name: './world/', type: '5' }, { name: './world/level.dat', data: big }, { name: './plugins/Essentials/config.yml', data: Buffer.from('a: 1\n') },
    { name: './empty.txt' }, { name: './ünï cödé/файл.txt', data: Buffer.from('utf8') }
  ]);
  put(root, 'backups/b1.tar.gz', zlib.gzipSync(t));
  const r = await post(c, mine, '/unarchive', { path: '/backups/b1.tar.gz' });
  assert.equal(r.status, 202); assert.equal(r.body.job.state, 'running'); assert.equal(r.body.job.dest, '/backups');
  const j = await waitDone(c, mine);
  assert.equal(j.state, 'done', JSON.stringify(j)); assert.equal(j.files, 4); assert.equal(j.skipped, 0); assert.equal(j.readBytes, j.archiveBytes);
  assert.deepEqual(fs.readFileSync(path.join(root, 'backups/world/level.dat')), big);
  assert.equal(fs.readFileSync(path.join(root, 'backups/plugins/Essentials/config.yml'), 'utf8'), 'a: 1\n');
  assert.equal(fs.statSync(path.join(root, 'backups/empty.txt')).size, 0);
  assert.equal(fs.readFileSync(path.join(root, 'backups/ünï cödé/файл.txt'), 'utf8'), 'utf8');
  assert.ok(fs.existsSync(path.join(root, 'backups/b1.tar.gz')), 'the archive itself is kept');
  assert.ok(activity.forServer(mine.id, 20).some((a) => a.type === 'file.unarchive' && /extracted \/backups\/b1\.tar\.gz/.test(a.message)));
  void listing;
});

test('"into" chooses (and creates) another folder; existing files are replaced', async () => {
  const c = await as('alice');
  put(root, 'new.zip', zip([{ name: 'server.properties', data: Buffer.from('motd=new\n') }, { name: 'logs/', data: null }, { name: 'logs/latest.log', data: Buffer.from('log') }]));
  put(root, 'restore/server.properties', 'motd=old\n');
  const r = await post(c, mine, '/unarchive', { path: '/new.zip', into: '/restore/deeper' });
  assert.equal(r.status, 202);
  const j = await waitDone(c, mine); assert.equal(j.state, 'done', JSON.stringify(j));
  assert.equal(fs.readFileSync(path.join(root, 'restore/deeper/server.properties'), 'utf8'), 'motd=new\n');
  assert.equal(fs.readFileSync(path.join(root, 'restore/deeper/logs/latest.log'), 'utf8'), 'log');
  assert.equal(fs.readFileSync(path.join(root, 'restore/server.properties'), 'utf8'), 'motd=old\n', 'other folders are untouched');
  put(root, 'again.zip', zip([{ name: 'server.properties', data: Buffer.from('motd=replaced\n') }]));
  await post(c, mine, '/unarchive', { path: '/again.zip', into: '/restore/deeper' }); await waitDone(c, mine);
  assert.equal(fs.readFileSync(path.join(root, 'restore/deeper/server.properties'), 'utf8'), 'motd=replaced\n');
});

test('zip: deflate + stored entries, CRC mismatch is reported and the bad file removed, the rest is still extracted', async () => {
  const c = await as('alice');
  put(root, 'z/mix.zip', zip([{ name: 'ok.txt', data: Buffer.from('fine fine fine fine') }, { name: 'bad.txt', data: Buffer.from('broken'), badCrc: true }, { name: 'stored.bin', data: Buffer.from('raw'), deflate: false }]));
  await post(c, mine, '/unarchive', { path: '/z/mix.zip' });
  const j = await waitDone(c, mine);
  assert.equal(j.state, 'done'); assert.equal(j.files, 2); assert.equal(j.skipped, 1); assert.match(j.skippedSamples[0].reason, /CRC/);
  assert.equal(fs.readFileSync(path.join(root, 'z/ok.txt'), 'utf8'), 'fine fine fine fine');
  assert.equal(fs.readFileSync(path.join(root, 'z/stored.bin'), 'utf8'), 'raw');
  assert.ok(!fs.existsSync(path.join(root, 'z/bad.txt')));
});

test('SECURITY: zip-slip names, absolute paths, symlinks and a link already in the way never write outside the server', async () => {
  const c = await as('alice');
  fs.mkdirSync(path.join(root, 'evil'), { recursive: true });
  fs.symlinkSync(OUTSIDE, path.join(root, 'evil', 'esc'));                                 // a link that already exists inside the destination
  const names = ['../pwn1.txt', '../../pwn2.txt', 'a/../../pwn3.txt', 'esc/pwn4.txt', '/etc/pwn5.txt', 'C:\\x\\..\\..\\pwn6.txt'];
  put(root, 'evil/slip.zip', zip(names.map((n) => ({ name: n, data: Buffer.from('PWNED') }))));
  put(root, 'evil/slip.tar', tar([
    ...names.map((n) => ({ name: n, data: Buffer.from('PWNED') })),
    { name: 'lnk', type: '2', link: OUTSIDE }, { name: 'lnk/pwn7.txt', data: Buffer.from('PWNED') }, { name: 'hard', type: '1', link: '/etc/passwd' }
  ]));
  for (const f of ['/evil/slip.zip', '/evil/slip.tar']) {
    await post(c, mine, '/unarchive', { path: f });
    const j = await waitDone(c, mine);
    assert.equal(j.state, 'done', JSON.stringify(j));
    assert.ok(j.skipped >= 3, `${f}: skipped ${j.skipped}`);
  }
  assert.deepEqual(fs.readdirSync(OUTSIDE), [], 'nothing was written through the link or ..');
  for (const p of ['pwn1.txt', 'pwn2.txt', 'pwn3.txt', 'evil/../pwn1.txt']) assert.ok(!fs.existsSync(path.join(DATA, p)) && !fs.existsSync(path.join(root, '..', p)));
  assert.ok(!fs.lstatSync(path.join(root, 'evil', 'esc')).isDirectory(), 'the existing link is still a link and was not followed');
  assert.ok(!fs.existsSync(path.join(root, 'evil', 'lnk')) || !fs.lstatSync(path.join(root, 'evil', 'lnk')).isSymbolicLink(), 'a symlink from the archive is never created');
  assert.ok(!fs.existsSync(path.join(root, 'evil', 'hard')));
});

test('SECURITY: a zip bomb is stopped by the disk allocation of the server', async () => {
  const c = await as('alice'), sroot = path.join(DATA, small.identifier);
  put(sroot, 'bomb.zip', zip([{ name: 'zeros.bin', data: Buffer.alloc(8 * 1024 * 1024) }]));            // ~8 KB compressed, 8 MiB unpacked, limit is 1 MB
  const r = await post(c, small, '/unarchive', { path: '/bomb.zip' });
  assert.equal(r.status, 202);
  let j = await waitDone(c, small);                                                                    // a zip lists its sizes: refused before anything is written
  assert.equal(j.state, 'failed'); assert.equal(j.errorCode, 'disk_full'); assert.ok(!fs.existsSync(path.join(sroot, 'zeros.bin')));
  put(sroot, 'bomb.tar.gz', zlib.gzipSync(tar([{ name: 'zeros.bin', data: Buffer.alloc(8 * 1024 * 1024) }])));
  const r2 = await post(c, small, '/unarchive', { path: '/bomb.tar.gz' });                               // size unknown up front: stopped while writing
  assert.equal(r2.status, 202);
  j = await waitDone(c, small);
  assert.equal(j.state, 'failed'); assert.equal(j.errorCode, 'disk_full');
  assert.ok(fs.existsSync(path.join(sroot, 'zeros.bin')) && fs.statSync(path.join(sroot, 'zeros.bin')).size <= 1048576 + 65536, 'writing stopped at the limit');
});

test('damaged and fake archives fail cleanly with a message (no crash)', async () => {
  const c = await as('alice');
  put(root, 'bad/junk.tar.gz', 'this is not gzip');
  await post(c, mine, '/unarchive', { path: '/bad/junk.tar.gz' }); let j = await waitDone(c, mine);
  assert.equal(j.state, 'failed'); assert.equal(j.errorCode, 'corrupt');
  put(root, 'bad/junk.zip', 'nope'); await post(c, mine, '/unarchive', { path: '/bad/junk.zip' }); j = await waitDone(c, mine);
  assert.equal(j.state, 'failed'); assert.match(j.error, /not a valid zip/);
  const good = zlib.gzipSync(tar([{ name: 'f.txt', data: Buffer.alloc(100000, 'x') }]));
  put(root, 'bad/cut.tar.gz', good.subarray(0, good.length - 40)); await post(c, mine, '/unarchive', { path: '/bad/cut.tar.gz' }); j = await waitDone(c, mine);
  assert.equal(j.state, 'failed'); assert.equal(j.errorCode, 'corrupt');
  put(root, 'bad/plain.tar', Buffer.alloc(2048, 7)); await post(c, mine, '/unarchive', { path: '/bad/plain.tar' }); j = await waitDone(c, mine);
  assert.equal(j.state, 'failed'); assert.match(j.error, /not a valid tar/);
});

test('single .gz is decompressed to the same name without .gz', async () => {
  const c = await as('alice');
  put(root, 'gz/latest.log.gz', zlib.gzipSync(Buffer.from('log line\n')));
  await post(c, mine, '/unarchive', { path: '/gz/latest.log.gz' }); const j = await waitDone(c, mine);
  assert.equal(j.state, 'done'); assert.equal(fs.readFileSync(path.join(root, 'gz/latest.log'), 'utf8'), 'log line\n');
});

test('a running extraction can be cancelled, one job per server, status survives reloads', async () => {
  const c = await as('alice'), entries = [];
  for (let i = 0; i < 20000; i++) entries.push({ name: `many/d${i % 50}/f${i}.txt`, data: Buffer.from(`file ${i}`) });
  put(root, 'many.tar.gz', zlib.gzipSync(tar(entries)));
  const r = await post(c, mine, '/unarchive', { path: '/many.tar.gz' });
  assert.equal(r.status, 202);
  const second = await post(c, mine, '/unarchive', { path: '/many.tar.gz' });
  assert.equal(second.status, 429); assert.equal(second.body.code, 'busy');
  const cancel = await post(c, mine, '/unarchive/cancel', {});
  assert.equal(cancel.status, 200);
  const j = await waitDone(c, mine);
  assert.equal(j.state, 'cancelled'); assert.ok(j.files < 20000, `extracted ${j.files} of 20000`);
  const none = await post(c, mine, '/unarchive/cancel', {});
  assert.equal(none.status, 404);
});

test('permissions and validation: view-only 403, stranger 404, not an archive 415, missing 404, traversal 400, login required', async () => {
  const b = await as('bob'), d = await as('dave'), a = await as('alice');
  put(root, 'perm/p.zip', zip([{ name: 'p.txt', data: Buffer.from('p') }]));
  assert.equal((await post(b, mine, '/unarchive', { path: '/perm/p.zip' })).status, 403);
  assert.equal((await post(b, mine, '/unarchive/cancel', {})).status, 403);
  assert.equal((await status(b, mine)) === undefined, false, 'view-only users may look at the status');
  assert.equal((await post(d, mine, '/unarchive', { path: '/perm/p.zip' })).status, 404);
  put(root, 'perm/server.jar', 'x');
  assert.deepEqual([(await post(a, mine, '/unarchive', { path: '/perm/server.jar' })).status, (await post(a, mine, '/unarchive', { path: '/perm/nope.zip' })).status], [415, 404]);
  assert.equal((await post(a, mine, '/unarchive', { path: '/../x.zip' })).status, 400);
  assert.equal((await post(a, mine, '/unarchive', { path: '/perm/p.zip', into: '/../../etc' })).status, 400);
  assert.equal((await post(a, mine, '/unarchive', { path: '/perm', into: '/' })).status, 404, 'a folder is not an archive');
  const anon = await fetch(`${base}${url(mine, '/unarchive')}`, { headers: { accept: 'application/json' }, redirect: 'manual' });
  assert.ok([401, 302, 303].includes(anon.status));
  const noCsrf = await a.api(url(mine, '/unarchive'), { path: '/perm/p.zip' }, { csrf: false });
  assert.ok([403, 401].includes(noCsrf.status), `without a CSRF token: ${noCsrf.status}`);
});

test('file manager page offers Unarchive (menu markup, dialog, progress card) only to people who can write', async () => {
  const a = await as('alice'), b = await as('bob');
  const html = await (await a.req(`/dashboard/servers/${mine.identifier}/files`)).text();
  for (const m of ['data-unarch-dialog', 'data-unarch-form', 'data-unarch-cancel', 'data-i="archive"', 'Extract into']) assert.match(html, new RegExp(m));
  const view = await (await b.req(`/dashboard/servers/${mine.identifier}/files`)).text();
  assert.doesNotMatch(view, /data-unarch-form/);
  const js = await (await a.req('/js/files.js')).text();
  assert.match(js, /Unarchive/); assert.match(js, /ARCHIVE_EXT/);
});
