'use strict';
// Servers keep running when the panel (supervisor) is restarted, and Stop / Restart act like Force stop / Force restart.
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const users = require('../src/services/users');
const servers = require('../src/dashboard/services/servers');
const consoleStore = require('../src/dashboard/services/serverConsole');
const db = require('../src/db');
const detached = require('../src/runtime/detached');
const { Supervisor } = require('../src/runtime/supervisor');

const FIXTURE = path.join(__dirname, 'fixtures', 'fake-mc.js');
const cmd = (extra = '') => `node "${FIXTURE}" ${extra}`;
let alice, dataDir, runDir;
const get = (id) => db.prepare('SELECT * FROM servers WHERE id = ?').get(id);
const act = (s, action) => servers.requestCommand(alice, s.id, action, '127.0.0.1', { confirmed: true });
const alive = (pid) => { try { process.kill(pid, 0); return true; } catch { return false; } };
async function waitFor(fn, what, ms = 10000) {
  const t = Date.now();
  while (Date.now() - t < ms) { const v = fn(); if (v) return v; await new Promise((r) => setTimeout(r, 40)); }
  assert.fail(`timed out waiting for: ${what}`);
}
const mk = (name, command) => servers.create({ ownerId: alice.id, name, startCommand: command, ramLimitMb: 512 });
const newSup = () => new Supervisor({ dataDir, runDir, persist: true, pollMs: 40, metricsMs: 150, startTimeoutMs: 6000, stopTimeoutMs: 1500, killTimeoutMs: 800, consoleFlushMs: 30, consoleInputMs: 30 });

before(() => {
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-persist-'));
  runDir = path.join(dataDir, '..', path.basename(dataDir) + '-run');
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: 'x' });
});
after(() => { fs.rmSync(dataDir, { recursive: true, force: true }); fs.rmSync(runDir, { recursive: true, force: true }); });

test('a server keeps running while the supervisor restarts, and the new supervisor takes it over', { skip: !detached.supported() }, async () => {
  const s = mk('Survivor', cmd());
  let sup = newSup(); sup.start();
  act(s, 'start');
  await waitFor(() => get(s.id).status === 'online', 'online');
  const pid = sup.entries.get(s.id).proc.pid;
  sup.entries.get(s.id).proc.stdin.write('join Steve\n');
  await waitFor(() => get(s.id).players_online === 1, '1 player');

  await sup.shutdown();                                                   // = the panel is updated / restarted
  assert.ok(alive(pid), 'the game process is still running after the panel shut down');
  assert.equal(get(s.id).status, 'online', 'and the panel did not mark it offline');

  sup = newSup(); sup.start();                                            // = the new panel process
  const e = sup.entries.get(s.id);
  assert.ok(e, 'the new supervisor adopted the running server');
  assert.equal(e.proc.pid, pid, 'same process');
  assert.equal(get(s.id).status, 'online');
  assert.equal(get(s.id).players_online, 1, 'players are remembered');

  e.proc.stdin.write('join Alex\n');                                      // commands still reach the process, output still comes back
  await waitFor(() => get(s.id).players_online === 2, '2 players after the restart');

  act(s, 'stop');                                                         // Stop works on an adopted server
  await waitFor(() => get(s.id).status === 'offline', 'offline');
  await waitFor(() => !alive(pid), 'process gone');
  await sup.shutdown();
});

test('Stop kills at once even when the server ignores the stop command and SIGTERM', { skip: !detached.supported() }, async () => {
  const s = mk('Stubborn', cmd('--ignore-stop --ignore-term'));
  const sup = newSup(); sup.start();
  act(s, 'start'); await waitFor(() => get(s.id).status === 'online', 'online');
  const pid = sup.entries.get(s.id).proc.pid;
  const t0 = Date.now();
  act(s, 'stop');
  await waitFor(() => get(s.id).status === 'offline', 'offline', 5000);
  assert.ok(Date.now() - t0 < 1200, `stopped in ${Date.now() - t0} ms (a graceful stop would wait for the 1500 ms timeout)`);
  await waitFor(() => !alive(pid), 'process gone');
  await sup.shutdown();
});

test('Restart kills and starts again with a new process, quickly', { skip: !detached.supported() }, async () => {
  const s = mk('Restarter', cmd('--ignore-stop'));
  const sup = newSup(); sup.start();
  act(s, 'start'); await waitFor(() => get(s.id).status === 'online', 'online');
  const pid = sup.entries.get(s.id).proc.pid;
  const t0 = Date.now();
  act(s, 'restart');
  await waitFor(() => { const e = sup.entries.get(s.id); return get(s.id).status === 'online' && e && e.proc.pid !== pid; }, 'online again with a new process', 6000);
  assert.ok(Date.now() - t0 < 2500, `restarted in ${Date.now() - t0} ms`);
  await waitFor(() => !alive(pid), 'the old process is gone');
  act(s, 'stop'); await waitFor(() => get(s.id).status === 'offline', 'offline');
  await sup.shutdown();
});

test('a server that was killed while the panel was down is reported as crashed, not adopted', { skip: !detached.supported() }, async () => {
  const s = mk('Died', cmd());
  let sup = newSup(); sup.start();
  act(s, 'start'); await waitFor(() => get(s.id).status === 'online', 'online');
  const pid = sup.entries.get(s.id).proc.pid;
  await sup.shutdown();
  process.kill(pid, 'SIGKILL'); await waitFor(() => !alive(pid), 'killed');
  sup = newSup(); sup.start();
  assert.equal(sup.entries.has(s.id), false);
  assert.equal(get(s.id).status, 'crashed', 'killed from outside (exit 137) = crashed, like before');
  await sup.shutdown();
});
