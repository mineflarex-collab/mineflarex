'use strict';
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';

const { test, before, after, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const { connect, frame } = require('./wsclient');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const access = require('../src/dashboard/services/access');
const activity = require('../src/dashboard/services/activity');
const store = require('../src/dashboard/services/serverConsole');
const db = require('../src/db');
const { Supervisor } = require('../src/runtime/supervisor');

const PW = 'Sup3rSecretPass!', FIXTURE = path.join(__dirname, 'fixtures', 'fake-mc.js');
let srv, base, sup, dataDir, alice, bob, carol, dave, live, idle, other;
const open = [];
const get = (id) => db.prepare('SELECT * FROM servers WHERE id = ?').get(id);
const cookieOf = (c) => Object.entries(c.jar).map(([k, v]) => `${k}=${v}`).join('; ');
const logins = new Map();           // sign in once per user (the panel rate-limits logins per IP)
const login = async (name) => { if (!logins.has(name)) { const c = client(base); await c.login(name, PW); logins.set(name, c); } return logins.get(name); };
const wsPath = (s) => `/api/dashboard/servers/${s.identifier}/console/ws`;
async function waitFor(fn, what, ms = 10000) {
  const t = Date.now();
  while (Date.now() - t < ms) { const v = await fn(); if (v) return v; await new Promise((r) => setTimeout(r, 30)); }
  assert.fail(`timed out waiting for: ${what}`);
}
/** Signs in as `name` and opens the console WebSocket of `server`; waits for hello. */
async function consoleOf(name, server, { after: afterId } = {}) {
  const c = await login(name);
  const r = await connect(base, wsPath(server) + (afterId != null ? `?after=${afterId}` : ''), { cookie: cookieOf(c), origin: base });
  assert.equal(r.status, 101, `handshake for ${name}`);
  open.push(r.ws);
  const hello = await r.ws.next((m) => m.type === 'hello', 'hello');
  return { ws: r.ws, hello, cookie: cookieOf(c), c };
}
const send = async (ws, command) => {
  const ref = Math.random();
  ws.sendJson({ type: 'command', command, ref });
  return ws.next((m) => m.type === 'ack' && m.ref === ref, `ack for "${String(command).slice(0, 20)}"`);
};
const seen = (ws, re) => ws.lines().some((l) => re.test(l.m));
const waitLine = (ws, re, what) => waitFor(() => ws.lines().find((l) => re.test(l.m)), what || String(re));

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW);
  [alice, bob, carol, dave] = ['alice', 'bob', 'carol', 'dave'].map((u) => users.create({ username: u, email: `${u}@example.com`, passwordHash: hash }));
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-con-'));
  sup = new Supervisor({ dataDir, pollMs: 40, metricsMs: 300, stopTimeoutMs: 3000, killTimeoutMs: 1000, consoleFlushMs: 30, consoleInputMs: 30 });
  sup.start();
  live = servers.create({ ownerId: alice.id, name: 'Live', ramLimitMb: 512, startCommand: `node "${FIXTURE}" --delay 200` });
  idle = servers.create({ ownerId: alice.id, name: 'Idle', startCommand: `node "${FIXTURE}"` });
  other = servers.create({ ownerId: dave.id, name: 'Daves' });
  access.grant({ serverId: live.id, userId: bob.id, permissions: ['console.view'] });             // watch only
  access.grant({ serverId: live.id, userId: carol.id, permissions: ['control.start'] });          // power, but no console
});
// Every test starts with no consoles open (the hub removes a connection when its socket closes).
afterEach(async () => { for (const w of open.splice(0)) w.socket.destroy(); await new Promise((r) => setTimeout(r, 60)); });
after(async () => {
  for (const w of open) w.socket.destroy();
  await sup.shutdown(); srv.closeAllConnections?.(); srv.close(); fs.rmSync(dataDir, { recursive: true, force: true });
});

// ------------------------------------------------------------------------------------------- handshake / access
test('handshake is refused without a session, from a foreign origin, and for servers the user cannot see', async () => {
  const anon = await connect(base, wsPath(live), { origin: base }); assert.equal(anon.status, 401);
  const a = await login('alice');
  const foreign = await connect(base, wsPath(live), { cookie: cookieOf(a), origin: 'https://evil.example' }); assert.equal(foreign.status, 403);
  const notMine = await connect(base, wsPath(other), { cookie: cookieOf(a), origin: base }); assert.equal(notMine.status, 404);
  const bad = await connect(base, '/api/dashboard/servers/zzzzzzzz/console/ws', { cookie: cookieOf(a), origin: base }); assert.equal(bad.status, 404);
  const noKey = await connect(base, wsPath(live), { cookie: cookieOf(a), origin: base, key: 'nope' }); assert.equal(noKey.status, 400);
  const oldVer = await connect(base, wsPath(live), { cookie: cookieOf(a), origin: base, version: '8' }); assert.equal(oldVer.status, 400);
  const carolC = await login('carol');
  const noPerm = await connect(base, wsPath(live), { cookie: cookieOf(carolC), origin: base }); assert.equal(noPerm.status, 403, 'shared with power rights only: no console');
});

test('console page: owner and console viewers get it, others do not; the details page links to it', async () => {
  const a = await login('alice'), b = await login('bob'), cr = await login('carol'), d = await login('dave');
  const page = await a.req(`/dashboard/servers/${live.identifier}/console`); assert.equal(page.status, 200);
  const html = await page.text();
  assert.match(html, /data-console="[0-9a-f]{8}"/); assert.match(html, /data-can-send="1"/); assert.match(html, /src="\/js\/console\.js(\?v=\w+)?"/);
  assert.doesNotMatch(await (await b.req(`/dashboard/servers/${live.identifier}/console`)).text(), /data-can-send="1"/, 'watch-only user cannot send');
  assert.equal((await cr.req(`/dashboard/servers/${live.identifier}/console`)).status, 403);
  assert.equal((await d.req(`/dashboard/servers/${live.identifier}/console`)).status, 404);
  assert.equal((await client(base).req(`/dashboard/servers/${live.identifier}/console`)).status, 303, 'anonymous -> login');
  assert.match(await (await a.req(`/dashboard/servers/${live.identifier}`)).text(), /Open console/);
  assert.doesNotMatch(await (await cr.req(`/dashboard/servers/${live.identifier}`)).text(), /Open console/);
});

test('CSP allows the WebSocket connection', async () => {
  const res = await client(base).req('/login');
  assert.match(res.headers.get('content-security-policy'), /connect-src 'self' ws:\/\/localhost:\d+/);
});

// ------------------------------------------------------------------------------------------- real output + commands
test('offline server: empty console, commands are refused', async () => {
  const { ws, hello } = await consoleOf('alice', idle);
  assert.equal(hello.server.status, 'offline'); assert.equal(hello.canSend, true); assert.deepEqual(hello.lines, []);
  const ack = await send(ws, 'say hi'); assert.equal(ack.ok, false); assert.match(ack.error, /offline/);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM console_input WHERE server_id = ?').get(idle.id).n, 0, 'nothing was queued');
});

test('real process output streams live, with status changes', async () => {
  const { ws } = await consoleOf('alice', live);
  const r = servers.requestCommand(alice, live.id, 'start', '127.0.0.1'); assert.equal(r.ok, true);
  await waitLine(ws, /Starting server\.\.\./, 'runtime notice');
  await waitLine(ws, /Starting minecraft server version 1\.21\.4/, 'first line printed by the real process');
  await waitLine(ws, /Done \(0\.100s\)!/, 'ready line');
  await ws.next((m) => m.type === 'status' && m.status === 'online', 'status online');
  const ids = ws.lines().map((l) => l.id);
  assert.deepEqual(ids, [...ids].sort((a, b) => a - b), 'lines arrive in order');
  assert.equal(new Set(ids).size, ids.length, 'no duplicates');
});

test('a command typed in the console reaches the real process, and its output comes back', async () => {
  const { ws, hello } = await consoleOf('alice', live);
  assert.ok(hello.lines.length >= 3, 'backlog is replayed on connect');
  const ack = await send(ws, 'say hello from the panel'); assert.equal(ack.ok, true);
  const echo = await waitLine(ws, /^alice> say hello from the panel$/); assert.equal(echo.s, 'in');
  const reply = await waitLine(ws, /\[Server\] hello from the panel/); assert.equal(reply.s, 'out');
  assert.ok(echo.id < reply.id, 'echo comes before the process answer');
  // proof that it is the real process reading stdin: the supervisor derives player counts from what the process printed
  await send(ws, 'join Steve');
  await waitFor(() => get(live.id).players_online === 1 || (get(live.id).metrics_at && sup.entries.get(live.id)?.players.has('Steve')), 'player joined through the console');
  assert.match(db.prepare('SELECT message FROM activity_log WHERE type = ? ORDER BY id DESC').get('console.command').message, /alice ran "join Steve" on Live/);
});

test('stderr, ANSI colour codes, warnings and large bursts are all delivered', async () => {
  const { ws } = await consoleOf('alice', live);
  await send(ws, 'err boom'); const e = await waitLine(ws, /stderr says boom/); assert.equal(e.s, 'err');
  await send(ws, 'ansi'); const a = await waitLine(ws, /green.*bold red/); assert.match(a.m, /\x1b\[32mgreen/, 'raw escape codes are passed through for the browser to colour');
  await send(ws, 'spam 800');
  await waitLine(ws, /spam line 800$/);
  const spam = ws.lines().filter((l) => /^\[12:00:00\] \[Server thread\/INFO\]: spam line \d+$/.test(l.m)).map((l) => Number(l.m.match(/(\d+)$/)[1]));
  assert.deepEqual(spam, Array.from({ length: 800 }, (_, i) => i + 1), 'all 800 lines, in order, none lost');
});

test('command history is stored per user and returned on connect (no consecutive duplicates)', async () => {
  const { ws } = await consoleOf('alice', live);
  await send(ws, 'say one'); await send(ws, 'say one'); await send(ws, 'say two');
  const { hello } = await consoleOf('alice', live);
  const h = hello.history;
  assert.deepEqual(h.slice(-2), ['say one', 'say two'], 'repeating the same command twice in a row stores it once');
  assert.equal(h.filter((x, i) => x === h[i - 1]).length, 0);
  const bobs = await consoleOf('bob', live); assert.deepEqual(bobs.hello.history, [], "another user's history is separate");
});

test('reconnect with ?after=<last id> resumes without gaps or duplicates; a stale id resets', async () => {
  const first = await consoleOf('alice', live);
  const last = first.hello.lastId; assert.ok(last > 0);
  await send(first.ws, 'say while-away-1'); await waitLine(first.ws, /while-away-1/);
  await first.ws.close();
  const direct = store.tail(live.id, 1)[0].id;
  const resumed = await consoleOf('alice', live, { after: last });
  assert.equal(resumed.hello.reset, false);
  const ids = resumed.hello.lines.map((l) => l.id);
  assert.ok(ids.length && ids[0] === last + 1, 'resumes exactly after the given id');
  assert.ok(ids.every((id) => id > last)); assert.equal(ids[ids.length - 1], direct);
  const stale = await consoleOf('alice', live, { after: 10 ** 9 });
  assert.equal(stale.hello.reset, true, 'unknown (too large) id: start over');
});

test('scrollback: older lines can be requested page by page', async () => {
  const { ws, hello } = await consoleOf('alice', live);
  assert.equal(hello.lines.length, 500, 'only the most recent 500 are sent first'); assert.equal(hello.more, true);
  const first = hello.lines[0].id;
  ws.sendJson({ type: 'older', before: first });
  const older = await ws.next((m) => m.type === 'older', 'older page');
  assert.ok(older.lines.length > 0 && older.lines.length <= 200);
  assert.ok(older.lines.every((l) => l.id < first)); assert.equal(older.lines[older.lines.length - 1].id < first, true);
  const ids = older.lines.map((l) => l.id); assert.deepEqual(ids, [...ids].sort((a, b) => a - b));
});

// ------------------------------------------------------------------------------------------- permissions + validation
test('watch-only users can read but not send; send permission is re-checked on every command', async () => {
  const b = await consoleOf('bob', live);
  assert.equal(b.hello.canSend, false); assert.ok(b.hello.lines.length > 0);
  const ack = await send(b.ws, 'say nope'); assert.equal(ack.ok, false); assert.match(ack.error, /not send commands/);
  access.grant({ serverId: live.id, userId: bob.id, permissions: ['console.send'] });           // console.send implies console.view
  assert.equal((await send(b.ws, 'say from bob')).ok, true);
  await waitLine(b.ws, /^bob> say from bob$/); await waitLine(b.ws, /\[Server\] from bob/);
  access.grant({ serverId: live.id, userId: bob.id, permissions: ['console.view'] });
  assert.equal((await send(b.ws, 'say again')).ok, false, 'revoked: refused immediately, without waiting for the heartbeat');
  assert.equal(seen(b.ws, /\[Server\] again/), false);
});

test('typing stop/restart in the console still needs the stop/restart permission', async () => {
  access.grant({ serverId: live.id, userId: bob.id, permissions: ['console.send'] });
  const b = await consoleOf('bob', live);
  for (const c of ['stop', '/stop', ' STOP now', 'restart']) { const ack = await send(b.ws, c); assert.equal(ack.ok, false, c); assert.match(ack.error, /permission to (stop|restart)/); }
  assert.ok(sup.entries.has(live.id), 'server still running');
  access.grant({ serverId: live.id, userId: bob.id, permissions: ['console.view'] });
});

test('invalid commands are refused without reaching the process', async () => {
  const { ws } = await consoleOf('alice', live);
  const before = db.prepare('SELECT COUNT(*) n FROM console_input').get().n;
  for (const bad of ['', '   ', 'say a\nstop', 'say a\r', 'say \u0000', 'x'.repeat(1001), 42, null, { a: 1 }]) assert.equal((await send(ws, bad)).ok, false, JSON.stringify(bad)?.slice(0, 20));
  assert.equal(db.prepare('SELECT COUNT(*) n FROM console_input').get().n, before);
  assert.equal(seen(ws, /stop/), false);
});

test('commands are rate limited per connection', async () => {
  const { ws } = await consoleOf('alice', live);
  const acks = await Promise.all(Array.from({ length: 40 }, (_, i) => send(ws, `say burst ${i}`)));
  const refused = acks.filter((a) => !a.ok);
  assert.ok(refused.length >= 15 && refused.every((a) => /Slow down/.test(a.error)), `refused ${refused.length}`);
  assert.ok(acks.filter((a) => a.ok).length >= 8);
});

test('malformed JSON closes the connection', async () => {
  const { ws } = await consoleOf('alice', live);
  ws.sendRaw(frame(1, 'not json')); const { code } = await ws.closed; assert.equal(code, 1007);
});

// ------------------------------------------------------------------------------------------- protocol
test('protocol: ping/pong, fragmentation, and violations are rejected with the right close codes', async () => {
  let { ws } = await consoleOf('alice', live);
  ws.sendJson({ type: 'ping' }); await ws.next((m) => m.type === 'pong', 'app-level pong');
  ws.sendRaw(frame(9, 'hi')); await waitFor(() => ws.pongs === 1, 'protocol-level pong');
  const msg = Buffer.from(JSON.stringify({ type: 'ping' }));                                      // one message in three fragments
  ws.sendRaw(Buffer.concat([frame(1, msg.subarray(0, 4), { fin: false }), frame(0, msg.subarray(4, 9), { fin: false }), frame(0, msg.subarray(9))]));
  await ws.next((m) => m.type === 'pong', 'pong from a fragmented message');
  await ws.close();

  ({ ws } = await consoleOf('alice', live)); ws.sendRaw(frame(1, '{}', { mask: false })); assert.equal((await ws.closed).code, 1002, 'unmasked frame');
  ({ ws } = await consoleOf('alice', live)); ws.sendRaw(frame(2, Buffer.from([1, 2]))); assert.equal((await ws.closed).code, 1003, 'binary frame');
  ({ ws } = await consoleOf('alice', live)); ws.sendRaw(frame(1, Buffer.alloc(20000, 97))); assert.equal((await ws.closed).code, 1009, 'oversized message');
  ({ ws } = await consoleOf('alice', live)); ws.sendRaw(frame(1, Buffer.from([0xff, 0xfe, 0xfd]))); assert.equal((await ws.closed).code, 1007, 'invalid UTF-8');
  ({ ws } = await consoleOf('alice', live)); ws.sendRaw(frame(0, 'x')); assert.equal((await ws.closed).code, 1002, 'continuation without start');
  ({ ws } = await consoleOf('alice', live)); ws.sendRaw(Buffer.from([0xC1, 0x80, 0, 0, 0, 0])); assert.equal((await ws.closed).code, 1002, 'reserved bit');
  ({ ws } = await consoleOf('alice', live)); ws.sendRaw(frame(9, Buffer.alloc(200))); assert.equal((await ws.closed).code, 1002, 'oversized control frame');
  ({ ws } = await consoleOf('alice', live)); assert.equal((await ws.close(1000)).code, 1000, 'clean close handshake');
});

test('at most 10 consoles per user at once', async () => {
  const c = await login('alice'), ck = cookieOf(c), made = [];
  for (;;) {
    const r = await connect(base, wsPath(idle), { cookie: ck, origin: base });
    if (r.status !== 101) { assert.equal(r.status, 429); break; }
    made.push(r.ws); open.push(r.ws); assert.ok(made.length <= 10, 'limit not enforced');
  }
  assert.equal(made.length, 10);
  for (const w of made) w.socket.destroy();                       // vanish without a close frame
  await waitFor(() => srv.consoleHub.count() === 0, 'abruptly disconnected clients are released');
});

// ------------------------------------------------------------------------------------------- stop + restart through the console
test('"stop" typed by the owner stops the real server and the console says so', async () => {
  const { ws } = await consoleOf('alice', live);
  assert.equal((await send(ws, 'stop')).ok, true);
  await waitLine(ws, /^alice> stop$/); await waitLine(ws, /Stopping server$/);
  await waitLine(ws, /\[minePanel\] Server process ended \(exit code 0\)/);
  await ws.next((m) => m.type === 'status' && m.status === 'offline', 'status offline');
  assert.equal(get(live.id).status, 'offline');
  const ack = await send(ws, 'say anyone there'); assert.equal(ack.ok, false); assert.match(ack.error, /offline/);
});

test('starting again keeps the earlier output (history survives restarts)', async () => {
  const before = store.lastId(live.id);
  servers.requestCommand(alice, live.id, 'start', '127.0.0.1');
  await waitFor(() => get(live.id).status === 'online', 'online again');
  const { hello } = await consoleOf('alice', live);
  assert.ok(hello.lines.some((l) => l.id <= before) && hello.lines.some((l) => l.id > before));
  assert.ok(store.after(live.id, 0, 100000).filter((l) => /Starting server\.\.\./.test(l.line)).length >= 2, 'both start-ups are in the stored log');
});

test('deleting a server does not break the console writer or hub', async () => {
  const doomed = servers.create({ ownerId: alice.id, name: 'Doomed', startCommand: `node "${FIXTURE}"` });
  servers.requestCommand(alice, doomed.id, 'start', '127.0.0.1');
  await waitFor(() => get(doomed.id).status === 'online', 'doomed online');
  db.prepare('DELETE FROM servers WHERE id = ?').run(doomed.id);
  await new Promise((r) => setTimeout(r, 400));
  assert.equal(db.prepare('SELECT COUNT(*) n FROM console_lines WHERE server_id = ?').get(doomed.id).n, 0);
  assert.ok(sup.entries.size >= 1);
  sup.entries.get(doomed.id)?.proc.kill('SIGKILL');
});

// ------------------------------------------------------------------------------------------- storage
test('Writer: batches, prunes to the retention limit, survives a deleted server, bounds its buffer', async () => {
  const s = servers.create({ ownerId: alice.id, name: 'Store' });
  const w = new store.Writer({ flushMs: 1000, keep: 100 });
  for (let i = 1; i <= 1000; i++) w.push(s.id, 'out', `line ${i}`);
  w.push(999999, 'out', 'orphan');                               // unknown server: must not fail the whole batch
  w.flush();
  const rows = store.tail(s.id, 5000);
  assert.equal(rows.length, 100); assert.equal(rows[99].line, 'line 1000'); assert.equal(rows[0].line, 'line 901');
  const big = new store.Writer({ flushMs: 1000, keep: 100000 });
  for (let i = 0; i < 6000; i++) big.push(s.id, 'out', `b${i}`);
  big.flush();
  const all = store.tail(s.id, 100000).map((r) => r.line);
  assert.ok(all.some((l) => /lines were dropped/.test(l)), 'overflow is reported, not silent');
  assert.equal(all[all.length - 1] === 'b5999' || /dropped/.test(all[all.length - 1]), true);
  big.push(s.id, 'out', `x${'y'.repeat(10000)}\u0000`); big.flush();
  const last = store.tail(s.id, 1)[0]; assert.equal(last.line.length, store.MAX_LINE); assert.ok(!last.line.includes('\u0000'));
});

test('Stale queued commands are failed, not run later', () => {
  const id = store.enqueueInput({ serverId: idle.id, user: alice, command: 'say stale' });
  assert.equal(store.failStale(60000).length, 0, 'fresh commands are left alone');
  assert.equal(store.failStale(-1).some((r) => r.id === id), true);
  assert.equal(db.prepare('SELECT status FROM console_input WHERE id = ?').get(id).status, 'failed');
  assert.equal(store.markInput(id, 'sent'), false, 'a failed command cannot be picked up afterwards');
});

test('the activity log records who ran which command', () => {
  const msgs = activity.recent(alice.id, 200).filter((a) => a.type === 'console.command').map((a) => a.message);
  assert.ok(msgs.some((m) => /bob ran "say from bob" on Live/.test(m)), 'actions of shared users are attributed to them in the owner\'s log');
});

test('static assets are served in full (regression: the router used to destroy the socket after the headers)', async () => {
  for (const [file, type] of [['/js/console.js', /javascript/], ['/css/console.css', /css/], ['/css/auth.css', /css/], ['/js/dashboard.js', /javascript/]]) {
    const res = await fetch(base + file);
    assert.equal(res.status, 200, file); assert.match(res.headers.get('content-type'), type);
    const body = await res.text(); assert.equal(Buffer.byteLength(body), Number(res.headers.get('content-length')), `${file} arrives complete`);
  }
  assert.equal((await fetch(base + '/js/nope.js')).status, 404);
  assert.equal((await fetch(base + '/js/../../package.json')).status, 404);
});
