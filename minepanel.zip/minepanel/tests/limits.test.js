'use strict';
// A server may use no more RAM / CPU / disk than it was given.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-lim-'));
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';
process.env.RUNTIME_DATA_DIR = DATA;
process.env.VPS_RAM_MB = '1048576'; process.env.VPS_CPU_CORES = '1000'; process.env.VPS_DISK_MB = '10485760';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { Readable } = require('node:stream');
const users = require('../src/services/users');
const servers = require('../src/dashboard/services/servers');
const files = require('../src/dashboard/services/files');
const db = require('../src/db');
const { Supervisor } = require('../src/runtime/supervisor');
const { Cgroups } = require('../src/runtime/limits');

const FIXTURE = path.join(__dirname, 'fixtures', 'fake-mc.js');
const cmd = () => `node "${FIXTURE}"`;
let alice, sup;
const get = (id) => db.prepare('SELECT * FROM servers WHERE id = ?').get(id);
const lastCmd = (id) => db.prepare('SELECT * FROM server_commands WHERE server_id = ? ORDER BY id DESC').get(id);
const act = (s, a) => servers.requestCommand(alice, s.id, a, '127.0.0.1', { confirmed: true });
async function waitFor(fn, what, ms = 10000) {
  const t = Date.now();
  while (Date.now() - t < ms) { const v = fn(); if (v) return v; await new Promise((r) => setTimeout(r, 40)); }
  assert.fail(`timed out waiting for: ${what}`);
}

before(() => {
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: 'x' });
  sup = new Supervisor({ pollMs: 40, metricsMs: 100, diskCheckMs: 100, diskHotMs: 100, startTimeoutMs: 4000, stopTimeoutMs: 1500, killTimeoutMs: 800 });
  sup.start();
});
after(async () => { await sup.shutdown(); fs.rmSync(DATA, { recursive: true, force: true }); });

// ---- cgroup v2 manager, on a fake cgroup tree ------------------------------------------------------------------
function fakeCgroupTree() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-cg-'));
  const svc = path.join(root, 'system.slice', 'minepanel.service');
  fs.mkdirSync(svc, { recursive: true });
  fs.writeFileSync(path.join(root, 'cgroup.controllers'), 'cpuset cpu io memory pids');
  fs.writeFileSync(path.join(svc, 'cgroup.controllers'), 'cpu io memory pids');
  fs.writeFileSync(path.join(svc, 'cgroup.subtree_control'), '');
  const self = path.join(root, 'self-cgroup');
  fs.writeFileSync(self, '0::/system.slice/minepanel.service\n');
  return { root, svc, self };
}

test('cgroups: setup moves the panel aside, enables controllers; apply writes RAM / CPU / pid limits', () => {
  const t = fakeCgroupTree();
  const cg = new Cgroups({ root: t.root, selfCgroup: t.self });
  assert.deepEqual(cg.setup(), { ok: true });
  assert.equal(fs.readFileSync(path.join(t.svc, 'mp-panel', 'cgroup.procs'), 'utf8'), String(process.pid));
  const g = cg.apply({ id: 7, ram_limit_mb: 1536, cpu_limit_pct: 150 });
  assert.equal(g.dir, path.join(t.svc, 'mp-srv-7'));
  assert.equal(fs.readFileSync(path.join(g.dir, 'memory.max'), 'utf8'), String(1536 * 1048576));
  assert.equal(fs.readFileSync(path.join(g.dir, 'memory.swap.max'), 'utf8'), '0');
  assert.equal(fs.readFileSync(path.join(g.dir, 'cpu.max'), 'utf8'), '150000 100000');          // 150% = 1.5 cores
  assert.equal(fs.readFileSync(path.join(g.dir, 'pids.max'), 'utf8'), '4096');
  cg.apply({ id: 7, ram_limit_mb: 512, cpu_limit_pct: 50 });                                    // an admin lowered the limits
  assert.equal(fs.readFileSync(path.join(g.dir, 'memory.max'), 'utf8'), String(512 * 1048576));
  assert.equal(fs.readFileSync(path.join(g.dir, 'cpu.max'), 'utf8'), '50000 100000');
  fs.writeFileSync(path.join(g.dir, 'memory.events'), 'low 0\nhigh 0\nmax 3\noom 1\noom_kill 1\n');
  assert.equal(cg.oomKills(g.dir), 1);
  const w = cg.wrap(['java', '-jar', 'a b.jar'], g.procsFile);
  assert.equal(w.cmd, '/bin/sh'); assert.deepEqual(w.args.slice(2), [g.procsFile, 'java', '-jar', 'a b.jar']);   // arguments are never joined into a shell string
  fs.rmSync(t.root, { recursive: true, force: true });
});

test('cgroups: unavailable cgroups are reported, not fatal', () => {
  const none = new Cgroups({ root: path.join(os.tmpdir(), 'mp-no-such-cgroup-root') });
  const r = none.setup(); assert.equal(r.ok, false); assert.ok(r.reason);
  const t = fakeCgroupTree(); fs.writeFileSync(path.join(t.svc, 'cgroup.controllers'), 'io pids');    // no memory / cpu controller delegated
  const r2 = new Cgroups({ root: t.root, selfCgroup: t.self }).setup();
  assert.equal(r2.ok, false); assert.match(r2.reason, /memory controller/);
  fs.rmSync(t.root, { recursive: true, force: true });
});

test('a supervisor with cgroups starts the server inside its cgroup (same pid, real process)', async () => {
  const t = fakeCgroupTree();
  const rt = new Supervisor({ dataDir: path.join(DATA, 'cg'), cgroups: true, cgroupRoot: t.root, cgroupSelf: t.self, pollMs: 40, metricsMs: 100, startTimeoutMs: 4000, stopTimeoutMs: 1500, killTimeoutMs: 800 });
  rt.start();
  try {
    assert.equal(rt.limitMode, 'cgroup');
    const s = servers.create({ ownerId: alice.id, name: 'InCgroup', startCommand: cmd(), ramLimitMb: 512, cpuLimitPct: 200 });
    act(s, 'start'); await waitFor(() => get(s.id).status === 'online', 'online');
    const e = rt.entries.get(s.id);
    assert.equal(e.cgroup, path.join(t.svc, `mp-srv-${s.id}`));
    assert.equal(fs.readFileSync(path.join(e.cgroup, 'cpu.max'), 'utf8'), '200000 100000');
    // the wrapper wrote its pid into cgroup.procs, then exec()ed the server: that pid IS the server process
    assert.equal(fs.readFileSync(path.join(e.cgroup, 'cgroup.procs'), 'utf8').trim(), String(e.proc.pid));
    db.prepare('UPDATE servers SET ram_limit_mb = 256, cpu_limit_pct = 100 WHERE id = ?').run(s.id);   // admin resizes a running server
    await waitFor(() => fs.readFileSync(path.join(e.cgroup, 'memory.max'), 'utf8') === String(256 * 1048576), 'new limit applied live');
    act(s, 'stop'); await waitFor(() => get(s.id).status === 'offline', 'offline');
  } finally { await rt.shutdown(); fs.rmSync(t.root, { recursive: true, force: true }); }
});

// ---- software watchdogs (always active; the only RAM protection when cgroups are unavailable) --------------------
test('RAM: without cgroups a server that stays above its RAM limit is killed and reported crashed', async () => {
  const s = servers.create({ ownerId: alice.id, name: 'RamHog', startCommand: cmd(), ramLimitMb: 8 });   // the fake server needs ~40 MB
  act(s, 'start');
  await waitFor(() => get(s.id).status === 'crashed', 'killed for RAM');
  assert.equal(sup.entries.has(s.id), false);
  const lines = () => db.prepare("SELECT line FROM console_lines WHERE server_id = ?").all(s.id).map((r) => r.line).join('\n');
  await waitFor(() => /more RAM .* than its limit \(8 MB\)/.test(lines()), 'explanation in the console');
});

test('disk: a server over its disk limit is stopped, reported crashed, and cannot start again until files are deleted', async () => {
  const s = servers.create({ ownerId: alice.id, name: 'DiskHog', startCommand: cmd(), diskLimitMb: 1 });   // the fake server writes 2 MB
  act(s, 'start');
  await waitFor(() => get(s.id).status === 'crashed', 'stopped for disk');
  assert.equal(sup.entries.has(s.id), false);
  act(s, 'start');
  await waitFor(() => lastCmd(s.id).status === 'failed', 'start refused');
  assert.match(lastCmd(s.id).error, /Disk limit reached/);
  fs.rmSync(path.join(DATA, s.identifier, 'world.dat'));                                               // the owner deletes the big file
  db.prepare('UPDATE servers SET disk_limit_mb = 10 WHERE id = ?').run(s.id);                          // (or an admin raises the limit)
  act(s, 'start'); await waitFor(() => get(s.id).status === 'online', 'online again');
  act(s, 'stop'); await waitFor(() => get(s.id).status === 'offline', 'offline');
});

// ---- File Manager respects the disk allocation -------------------------------------------------------------------
const chunk = (n) => Readable.from([Buffer.alloc(n, 1)]);
test('File Manager: uploads and saves that would exceed the disk limit are refused; room can be freed', async () => {
  const s = servers.create({ ownerId: alice.id, name: 'Quota', diskLimitMb: 2 });
  const MB = 1048576;
  const a = await files.receiveChunk(s, '/', 'a.bin', { offset: 0, total: MB, overwrite: false }, chunk(MB));
  assert.equal(a.done, true);
  await assert.rejects(files.receiveChunk(s, '/', 'b.bin', { offset: 0, total: 2 * MB, overwrite: false }, chunk(2 * MB)), (e) => e.code === 'disk_full' && e.status === 413 && /Not enough disk space/.test(e.message));
  assert.equal(fs.existsSync(path.join(DATA, s.identifier, 'b.bin')), false);
  assert.equal((await files.receiveChunk(s, '/', 'b.bin', { offset: 0, total: MB, overwrite: false }, chunk(MB))).done, true);   // exactly full is allowed
  const replaced = await files.receiveChunk(s, '/', 'a.bin', { offset: 0, total: MB, overwrite: true }, chunk(MB));              // replacing frees the old size
  assert.equal(replaced.done, true);
  await files.create(s, '/', 'x.txt', 'file');
  await assert.rejects(files.writeText(s, '/x.txt', 'y'.repeat(100)), (e) => e.code === 'disk_full');
  await files.remove(s, ['/b.bin']);
  assert.equal((await files.writeText(s, '/x.txt', 'ok')).name, 'x.txt');
});
