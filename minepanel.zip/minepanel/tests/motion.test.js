'use strict';
// Regression: animations must never leave a transform on an ancestor of position:fixed popups (the Files "..." menu was clipped).
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const css = fs.readFileSync(require('node:path').join(__dirname, '../public/css/motion.css'), 'utf8');

test('motion.css: panels do not get a hover transform, entrance animations do not keep a fill effect', () => {
  const hover = css.split('\n').filter((l) => /^\.mp-panel[^{]*:hover\s*\{/.test(l));
  assert.ok(hover.length > 0);
  for (const l of hover) assert.doesNotMatch(l, /transform\s*:/);
  assert.doesNotMatch(css, /animation:[^;]*\b(both|forwards)\b/);
});

test('glass.css: no blur/filter/transform on .mp-files or on a bare .mp-panel (they contain position:fixed popups)', () => {
  const glass = fs.readFileSync(require('node:path').join(__dirname, '../public/css/glass.css'), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '');
  for (const m of glass.matchAll(/([^{}]+)\{([^{}]*)\}/g)) {
    if (!/(backdrop-filter|[^-]filter|transform)\s*:/.test(m[2])) continue;
    for (const sel of m[1].split(',').map((s) => s.trim())) {
      assert.doesNotMatch(sel, /^\.mp-files\b/, sel);
      assert.ok(!/^\.mp-panel\b/.test(sel) || sel.includes(':not(.mp-files)'), `bare ${sel}`);
    }
  }
});
