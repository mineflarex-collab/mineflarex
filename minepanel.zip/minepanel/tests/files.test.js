'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-files-'));
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';
process.env.RUNTIME_DATA_DIR = DATA;          // the file manager works on the same directory the runtime uses

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const access = require('../src/dashboard/services/access');
const activity = require('../src/dashboard/services/activity');

const PW = 'Sup3rSecretPass!';
let srv, base, alice, bob, carol, dave, mine, OUTSIDE, root;
const sessions = new Map();
const as = async (name) => { if (!sessions.has(name)) { const c = client(base); await c.login(name, PW); sessions.set(name, c); } return sessions.get(name); };
const url = (s, tail = '') => `/api/dashboard/servers/${s.identifier}/files${tail}`;
const get = async (c, s, tail, qs = {}) => {
  const r = await c.req(`${url(s, tail)}?${new URLSearchParams(qs)}`, { headers: { accept: 'application/json' } });
  return { status: r.status, body: await r.json() };
};
const post = async (c, s, tail, json, opts) => { const r = await c.api(url(s, tail), json, opts); return { status: r.status, body: await r.json() }; };
const names = (b) => b.entries.map((e) => e.name);

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW);
  [alice, bob, carol, dave] = ['alice', 'bob', 'carol', 'dave'].map((u) => users.create({ username: u, email: `${u}@example.com`, passwordHash: hash }));
  mine = servers.create({ ownerId: alice.id, name: 'Files', ramLimitMb: 512 });
  access.grant({ serverId: mine.id, userId: bob.id, permissions: ['files.view'] });       // may browse only
  access.grant({ serverId: mine.id, userId: carol.id, permissions: ['files.write'] });    // implies files.view
  // dave has no relation to the server
  root = path.join(DATA, mine.identifier);
  OUTSIDE = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-outside-'));
  fs.writeFileSync(path.join(OUTSIDE, 'secret.txt'), 'top secret');
  fs.mkdirSync(path.join(root, 'plugins', 'Essentials'), { recursive: true });
  fs.mkdirSync(path.join(root, 'world'), { recursive: true });
  fs.writeFileSync(path.join(root, 'server.properties'), 'motd=hi\n');
  fs.writeFileSync(path.join(root, 'eula.txt'), 'eula=true');
  fs.writeFileSync(path.join(root, 'plugins', 'Essentials', 'Config.yml'), 'a: 1');
  fs.writeFileSync(path.join(root, 'plugins', 'WorldEdit.jar'), Buffer.alloc(2048));
  fs.mkdirSync(path.join(root, 'plugins', '10'), { recursive: true });
  fs.mkdirSync(path.join(root, 'plugins', '2'), { recursive: true });
  fs.symlinkSync(OUTSIDE, path.join(root, 'escape'));                       // directory link leaving the server directory
  fs.symlinkSync(path.join(OUTSIDE, 'secret.txt'), path.join(root, 'leak.txt'));
  fs.symlinkSync(path.join(root, 'world'), path.join(root, 'world-link'));   // link that stays inside
});
after(() => { srv.close(); fs.rmSync(DATA, { recursive: true, force: true }); fs.rmSync(OUTSIDE, { recursive: true, force: true }); });

test('browse: lists the real directory, folders first, natural sort, sizes', async () => {
  const c = await as('alice');
  const { status, body } = await get(c, mine, '', { path: '/' });
  assert.equal(status, 200);
  assert.equal(body.path, '/'); assert.equal(body.parent, null); assert.equal(body.canWrite, true);
  const dirs = body.entries.filter((e) => e.type === 'dir').map((e) => e.name);
  assert.deepEqual(dirs, ['plugins', 'world', 'world-link']);
  assert.ok(names(body).includes('server.properties'));
  assert.equal(body.entries.find((e) => e.name === 'server.properties').size, 8);
  const sub = (await get(c, mine, '', { path: '/plugins' })).body;
  assert.equal(sub.parent, '/'); assert.deepEqual(names(sub), ['2', '10', 'Essentials', 'WorldEdit.jar']);   // 2 before 10
  assert.equal(sub.entries.find((e) => e.name === 'WorldEdit.jar').size, 2048);
  assert.equal((await get(c, mine, '', { path: '/plugins/Essentials/' })).body.path, '/plugins/Essentials');   // trailing slash normalised
  assert.equal((await get(c, mine, '')).body.path, '/');                                                         // no path = root
});

test('browse: errors for missing paths and files', async () => {
  const c = await as('alice');
  assert.equal((await get(c, mine, '', { path: '/nope' })).status, 404);
  const r = await get(c, mine, '', { path: '/eula.txt' });
  assert.equal(r.status, 409); assert.equal(r.body.code, 'not_dir');
  assert.ok(!JSON.stringify(r.body).includes(DATA), 'errors never leak host paths');
});

test('security: ".." and NUL are rejected, symlinks cannot leave the server directory', async () => {
  const c = await as('alice');
  for (const p of ['/..', '/plugins/../..', '../etc', '/plugins/%2e%2e', '/a\0b']) {
    const r = await get(c, mine, '', { path: p.replace('%2e%2e', '..') });
    assert.ok([400, 404].includes(r.status) && r.status !== 200, `path ${JSON.stringify(p)} -> ${r.status}`);
  }
  assert.equal((await get(c, mine, '', { path: '/..' })).body.code, 'bad_path');
  // a link to /tmp/outside cannot be opened, listed through, or used as a parent
  assert.equal((await get(c, mine, '', { path: '/escape' })).status, 403);
  assert.equal((await get(c, mine, '', { path: '/escape/secret.txt' })).status, 403);
  assert.equal((await post(c, mine, '/create', { path: '/escape', name: 'pwned.txt', type: 'file' })).status, 403);
  assert.ok(!fs.existsSync(path.join(OUTSIDE, 'pwned.txt')));
  assert.equal((await post(c, mine, '/rename', { path: '/escape/secret.txt', name: 'x.txt' })).status, 403);
  assert.equal((await post(c, mine, '/delete', { paths: ['/escape/secret.txt'], confirm: true })).body.results[0].ok, false);
  assert.ok(fs.existsSync(path.join(OUTSIDE, 'secret.txt')), 'outside file untouched');
  // listing shows links honestly: outside ones as "link", inside ones as what they point to
  const list = (await get(c, mine, '', { path: '/' })).body.entries;
  assert.equal(list.find((e) => e.name === 'escape').type, 'link');
  assert.equal(list.find((e) => e.name === 'leak.txt').type, 'link');
  assert.equal(list.find((e) => e.name === 'world-link').type, 'dir');
  assert.equal((await get(c, mine, '', { path: '/world-link' })).status, 200);
});

test('create: files and folders really appear on disk; duplicates and bad names are refused', async () => {
  const c = await as('alice');
  let r = await post(c, mine, '/create', { path: '/plugins', name: 'notes.txt', type: 'file' });
  assert.equal(r.status, 201); assert.equal(r.body.entry.path, '/plugins/notes.txt'); assert.equal(r.body.entry.type, 'file');
  assert.ok(fs.statSync(path.join(root, 'plugins', 'notes.txt')).isFile());
  r = await post(c, mine, '/create', { path: '/', name: 'backups', type: 'folder' });
  assert.equal(r.status, 201); assert.ok(fs.statSync(path.join(root, 'backups')).isDirectory());
  r = await post(c, mine, '/create', { path: '/', name: 'backups', type: 'folder' });
  assert.equal(r.status, 409); assert.equal(r.body.code, 'exists');
  fs.writeFileSync(path.join(root, 'keep.txt'), 'precious');
  assert.equal((await post(c, mine, '/create', { path: '/', name: 'keep.txt', type: 'file' })).status, 409);
  assert.equal(fs.readFileSync(path.join(root, 'keep.txt'), 'utf8'), 'precious', 'an existing file is never overwritten');
  assert.equal((await post(c, mine, '/create', { path: '/', name: 'leak.txt', type: 'file' })).status, 409);   // not through the link either
  assert.equal(fs.readFileSync(path.join(OUTSIDE, 'secret.txt'), 'utf8'), 'top secret');
  for (const name of ['', ' x', 'x ', '.', '..', 'a/b', 'a\0b', 'tab\tname', 'x'.repeat(256), '../evil']) {
    const bad = await post(c, mine, '/create', { path: '/', name, type: 'file' });
    assert.equal(bad.status, 422, `name ${JSON.stringify(name)}`); assert.equal(bad.body.code, 'name_invalid');
  }
  assert.equal((await post(c, mine, '/create', { path: '/', name: 'ok', type: 'socket' })).status, 422);
  assert.equal((await post(c, mine, '/create', { path: '/missing', name: 'a', type: 'file' })).status, 404);
  assert.equal((await post(c, mine, '/create', { path: '/eula.txt', name: 'a', type: 'file' })).status, 409);
  assert.equal((await post(c, mine, '/create', { path: '/', name: 'Ünïcode ✓ naïve.txt', type: 'file' })).status, 201);
});

test('rename: changes the real name, never overwrites, protects the root', async () => {
  const c = await as('alice');
  fs.writeFileSync(path.join(root, 'old.txt'), 'content');
  let r = await post(c, mine, '/rename', { path: '/old.txt', name: 'new.txt' });
  assert.equal(r.status, 200); assert.equal(r.body.entry.path, '/new.txt');
  assert.ok(!fs.existsSync(path.join(root, 'old.txt'))); assert.equal(fs.readFileSync(path.join(root, 'new.txt'), 'utf8'), 'content');
  r = await post(c, mine, '/rename', { path: '/new.txt', name: 'eula.txt' });
  assert.equal(r.status, 409); assert.equal(fs.readFileSync(path.join(root, 'eula.txt'), 'utf8'), 'eula=true');
  assert.equal((await post(c, mine, '/rename', { path: '/new.txt', name: 'new.txt' })).body.entry.unchanged, true);
  assert.equal((await post(c, mine, '/rename', { path: '/new.txt', name: '../escaped.txt' })).status, 422);   // renaming cannot move
  assert.equal((await post(c, mine, '/rename', { path: '/nope.txt', name: 'x' })).status, 404);
  assert.equal((await post(c, mine, '/rename', { path: '/', name: 'x' })).body.code, 'root_protected');
  assert.equal((await post(c, mine, '/rename', { path: '/plugins/Essentials', name: 'Ess' })).status, 200);
  assert.ok(fs.existsSync(path.join(root, 'plugins', 'Ess', 'Config.yml')), 'folder contents follow the rename');
  assert.equal((await post(c, mine, '/rename', { path: '/plugins/Ess', name: 'Essentials' })).status, 200);
  assert.equal((await post(c, mine, '/rename', { path: '/leak.txt', name: 'leak2.txt' })).status, 200);       // the link itself can be renamed
  assert.ok(fs.lstatSync(path.join(root, 'leak2.txt')).isSymbolicLink());
  await post(c, mine, '/rename', { path: '/leak2.txt', name: 'leak.txt' });
});

test('delete: needs confirmation, removes folders recursively, never follows links, protects the root', async () => {
  const c = await as('alice');
  fs.mkdirSync(path.join(root, 'trash', 'deep'), { recursive: true });
  fs.writeFileSync(path.join(root, 'trash', 'deep', 'a.txt'), 'x');
  fs.writeFileSync(path.join(root, 'single.txt'), 'x');
  let r = await post(c, mine, '/delete', { paths: ['/single.txt'] });
  assert.equal(r.status, 428); assert.ok(fs.existsSync(path.join(root, 'single.txt')));
  r = await post(c, mine, '/delete', { paths: ['/single.txt', '/trash', '/trash/deep/a.txt'], confirm: true });
  assert.equal(r.status, 200); assert.equal(r.body.deleted, 2, 'the file inside the selected folder is covered by the folder');
  assert.ok(!fs.existsSync(path.join(root, 'single.txt'))); assert.ok(!fs.existsSync(path.join(root, 'trash')));
  // deleting the links removes only the links
  r = await post(c, mine, '/delete', { paths: ['/escape', '/leak.txt'], confirm: true });
  assert.equal(r.status, 200);
  assert.ok(!fs.existsSync(path.join(root, 'escape')) && !fs.existsSync(path.join(root, 'leak.txt')));
  assert.equal(fs.readFileSync(path.join(OUTSIDE, 'secret.txt'), 'utf8'), 'top secret', 'link targets are never touched');
  // root and partial failure
  r = await post(c, mine, '/delete', { paths: ['/'], confirm: true });
  assert.equal(r.status, 207); assert.equal(r.body.results[0].code, 'root_protected'); assert.ok(fs.existsSync(root));
  fs.writeFileSync(path.join(root, 'half.txt'), 'x');
  r = await post(c, mine, '/delete', { paths: ['/half.txt', '/ghost.txt'], confirm: true });
  assert.equal(r.status, 207); assert.equal(r.body.deleted, 1); assert.equal(r.body.failed, 1);
  assert.equal((await post(c, mine, '/delete', { paths: [], confirm: true })).status, 400);
  assert.equal((await post(c, mine, '/delete', { paths: ['/../x'], confirm: true })).status, 400);
  assert.equal((await post(c, mine, '/delete', { paths: Array.from({ length: 101 }, (_, i) => `/f${i}`), confirm: true })).status, 422);
  // recreate the links for the search test
  fs.symlinkSync(OUTSIDE, path.join(root, 'escape')); fs.symlinkSync(path.join(OUTSIDE, 'secret.txt'), path.join(root, 'leak.txt'));
});

test('search: case-insensitive, recursive, scoped, never follows links, validated', async () => {
  const c = await as('alice');
  let r = await get(c, mine, '/search', { path: '/', q: 'config' });
  assert.equal(r.status, 200); assert.deepEqual(r.body.results.map((x) => x.path), ['/plugins/Essentials/Config.yml']);
  assert.equal(r.body.results[0].parent, '/plugins/Essentials');
  r = await get(c, mine, '/search', { path: '/', q: 'WORLD' });
  assert.deepEqual(r.body.results.map((x) => x.path).sort(), ['/plugins/WorldEdit.jar', '/world', '/world-link']);
  r = await get(c, mine, '/search', { path: '/plugins', q: 'world' });
  assert.deepEqual(r.body.results.map((x) => x.path), ['/plugins/WorldEdit.jar'], 'scoped to the current folder');
  assert.deepEqual((await get(c, mine, '/search', { path: '/', q: 'secret' })).body.results, [], 'nothing outside the server directory is searched');
  assert.equal((await get(c, mine, '/search', { path: '/', q: 'zzz-nothing' })).body.results.length, 0);
  assert.equal((await get(c, mine, '/search', { path: '/', q: '  ' })).status, 422);
  assert.equal((await get(c, mine, '/search', { path: '/', q: 'x'.repeat(101) })).status, 422);
  assert.equal((await get(c, mine, '/search', { path: '/..', q: 'a' })).status, 400);
  assert.equal((await get(c, mine, '/search', { path: '/escape', q: 'secret' })).status, 403);
});

test('search: result cap is reported', async () => {
  const c = await as('alice');
  fs.mkdirSync(path.join(root, 'many'));
  for (let i = 0; i < 230; i++) fs.writeFileSync(path.join(root, 'many', `chunk-${i}.dat`), '');
  const r = await get(c, mine, '/search', { path: '/many', q: 'chunk' });
  assert.equal(r.body.results.length, 200); assert.equal(r.body.truncated, true); assert.equal(r.body.reason, 'results');
});

test('permissions: view-only may browse but not change; files.write implies view; strangers get 404', async () => {
  const b = await as('bob'), cr = await as('carol'), d = await as('dave');
  assert.equal((await get(b, mine, '', { path: '/' })).body.canWrite, false);
  assert.equal((await get(b, mine, '/search', { path: '/', q: 'eula' })).status, 200);
  for (const [tail, body] of [['/create', { path: '/', name: 'b.txt', type: 'file' }], ['/rename', { path: '/eula.txt', name: 'e.txt' }], ['/delete', { paths: ['/eula.txt'], confirm: true }]]) {
    assert.equal((await post(b, mine, tail, body)).status, 403, tail);
  }
  assert.ok(fs.existsSync(path.join(root, 'eula.txt')) && !fs.existsSync(path.join(root, 'b.txt')));
  assert.equal((await get(cr, mine, '', { path: '/' })).body.canWrite, true);
  assert.equal((await post(cr, mine, '/create', { path: '/', name: 'carol.txt', type: 'file' })).status, 201);
  assert.equal((await get(d, mine, '', { path: '/' })).status, 404);
  assert.equal((await post(d, mine, '/create', { path: '/', name: 'd.txt', type: 'file' })).status, 404);
  assert.equal((await d.req(`/dashboard/servers/${mine.identifier}/files`)).status, 404);
  // a grant without any files permission has no access to the files
  access.grant({ serverId: mine.id, userId: dave.id, permissions: ['console.view'] });
  assert.equal((await get(d, mine, '', { path: '/' })).status, 403);
  assert.equal((await d.req(`/dashboard/servers/${mine.identifier}/files`)).status, 403);
  access.revoke(mine.id, dave.id);
});

test('requests: anonymous -> 401, missing CSRF token -> 403, other servers are separate', async () => {
  const anon = client(base);
  assert.equal((await anon.req(url(mine), { headers: { accept: 'application/json' } })).status, 401);
  const c = await as('alice');
  const r = await post(c, mine, '/create', { path: '/', name: 'csrf.txt', type: 'file' }, { csrf: false });
  assert.equal(r.status, 403); assert.ok(!fs.existsSync(path.join(root, 'csrf.txt')));
  const other = servers.create({ ownerId: alice.id, name: 'Other', ramLimitMb: 512 });
  assert.equal((await post(c, other, '/create', { path: '/', name: 'only-here.txt', type: 'file' })).status, 201);
  assert.ok(fs.existsSync(path.join(DATA, other.identifier, 'only-here.txt')) && !fs.existsSync(path.join(root, 'only-here.txt')));
  assert.equal((await get(c, { identifier: 'nothere1' }, '', {})).status, 404);
});

test('activity: changes are written to the owner\'s log with the name of who did it', async () => {
  const c = await as('carol');
  await post(c, mine, '/create', { path: '/', name: 'audit.txt', type: 'file' });
  await post(c, mine, '/rename', { path: '/audit.txt', name: 'audit2.txt' });
  await post(c, mine, '/delete', { paths: ['/audit2.txt'], confirm: true });
  const msgs = activity.forServer(mine.id, 30).map((a) => a.message);
  assert.ok(msgs.some((m) => m === 'carol created file /audit.txt on Files'), msgs.join('\n'));
  assert.ok(msgs.some((m) => m.startsWith('carol renamed /audit.txt to audit2.txt')));
  assert.ok(msgs.some((m) => m === 'carol deleted /audit2.txt on Files'));
});

test('page: renders for permitted users, has the sidebar entry, assets load, names with markup are inert', async () => {
  const a = await as('alice');
  fs.writeFileSync(path.join(root, '<img src=x onerror=alert(1)>.txt'), 'x');
  const html = await (await a.req(`/dashboard/servers/${mine.identifier}/files`)).text();
  assert.match(html, /data-files="/); assert.match(html, /data-can-write="1"/); assert.match(html, /\/js\/files\.js/); assert.match(html, /href="\/dashboard\/servers\/[0-9a-f]+\/files"[^>]*>/);
  assert.ok(!/is not built yet/.test(html));
  const b = await as('bob'), bh = await (await b.req(`/dashboard/servers/${mine.identifier}/files`)).text();
  assert.match(bh, /data-can-write="0"/); assert.ok(!bh.includes('data-files-dialog'), 'no write dialogs for view-only users');
  const list = (await get(a, mine, '', { path: '/' })).body;
  assert.ok(names(list).includes('<img src=x onerror=alert(1)>.txt'), 'the API returns names as data; the client only uses textContent');
  for (const f of ['/js/files.js', '/css/files.css']) assert.equal((await a.req(f)).status, 200);
  const js = fs.readFileSync(path.join(__dirname, '..', 'public', 'js', 'files.js'), 'utf8');
  assert.ok(!/innerHTML|insertAdjacentHTML|outerHTML/.test(js), 'client never builds markup from file names');
  // users without files.view do not see the sidebar entry on the server details page
  access.grant({ serverId: mine.id, userId: dave.id, permissions: ['control.start'] });
  const d = await as('dave'), dh = await (await d.req(`/dashboard/servers/${mine.identifier}`)).text();
  assert.ok(!dh.includes(`/dashboard/servers/${mine.identifier}/files`));
  access.revoke(mine.id, dave.id);
});

// ---------------------------------------------------------------- upload / download / edit
const rawUpload = async (c, s, qs, data) => {
  const token = (await (await c.req('/api/dashboard/csrf', { headers: { accept: 'application/json' } })).json()).token;
  const res = await fetch(`${base}${url(s, '/upload')}?${new URLSearchParams(qs)}`, { method: 'POST', body: data,
    headers: { cookie: Object.entries(c.jar).map(([k, v]) => `${k}=${v}`).join('; '), 'content-type': 'application/octet-stream', 'x-csrf-token': token, accept: 'application/json' } });
  return { status: res.status, body: await res.json() };
};

test('upload: chunks are appended and the file appears only when complete; no silent overwrite', async () => {
  const a = await as('alice'), data = Buffer.from('0123456789abcdefghij');
  const q = (offset) => ({ path: '/world', name: 'up.bin', offset, total: data.length });
  let r = await rawUpload(a, mine, q(0), data.subarray(0, 8));
  assert.equal(r.status, 200); assert.equal(r.body.done, false);
  assert.ok(!fs.existsSync(path.join(root, 'world', 'up.bin')), 'not visible before the last chunk');
  r = await rawUpload(a, mine, q(5), data.subarray(8));                      // wrong offset
  assert.equal(r.status, 409);
  r = await rawUpload(a, mine, q(8), data.subarray(8));
  assert.equal(r.status, 201); assert.equal(r.body.done, true);
  assert.deepEqual(fs.readFileSync(path.join(root, 'world', 'up.bin')), data);
  assert.ok(!fs.existsSync(path.join(root, 'world', '.up.bin.mpupload')));
  r = await rawUpload(a, mine, { path: '/world', name: 'up.bin', offset: 0, total: 3 }, Buffer.from('new'));
  assert.equal(r.status, 409); assert.equal(r.body.code, 'exists');
  r = await rawUpload(a, mine, { path: '/world', name: 'up.bin', offset: 0, total: 3, overwrite: 1 }, Buffer.from('new'));
  assert.equal(r.status, 201); assert.equal(fs.readFileSync(path.join(root, 'world', 'up.bin'), 'utf8'), 'new');
  r = await rawUpload(a, mine, { path: '/world', name: 'empty.txt', offset: 0, total: 0 }, Buffer.alloc(0));
  assert.equal(r.status, 201); assert.equal(fs.statSync(path.join(root, 'world', 'empty.txt')).size, 0);
});

test('upload: traversal, bad names, symlink escape, oversize and permissions are refused', async () => {
  const a = await as('alice');
  for (const name of ['../x', 'a/b', '..', '']) assert.ok([400, 422].includes((await rawUpload(a, mine, { path: '/', name, offset: 0, total: 1 }, Buffer.from('x'))).status), name);
  assert.equal((await rawUpload(a, mine, { path: '/../..', name: 'x', offset: 0, total: 1 }, Buffer.from('x'))).status, 400);
  assert.equal((await rawUpload(a, mine, { path: '/escape', name: 'pwn.txt', offset: 0, total: 1 }, Buffer.from('x'))).status, 403);
  assert.ok(!fs.existsSync(path.join(OUTSIDE, 'pwn.txt')));
  assert.equal((await rawUpload(a, mine, { path: '/', name: 'big.bin', offset: 0, total: 2 }, Buffer.from('xyz'))).status, 413, 'more data than announced');
  assert.equal((await rawUpload(await as('bob'), mine, { path: '/', name: 'b.txt', offset: 0, total: 1 }, Buffer.from('x'))).status, 403, 'view-only users cannot upload');
  assert.equal((await rawUpload(await as('dave'), mine, { path: '/', name: 'd.txt', offset: 0, total: 1 }, Buffer.from('x'))).status, 404);
  const noCsrf = await fetch(`${base}${url(mine, '/upload')}?path=/&name=n.txt&offset=0&total=1`, { method: 'POST', body: 'x', headers: { cookie: Object.entries(a.jar).map(([k, v]) => `${k}=${v}`).join('; '), 'content-type': 'application/octet-stream' } });
  assert.equal(noCsrf.status, 403);
});

test('download: streams the real file with attachment headers; folders, outside links and strangers are refused', async () => {
  const a = await as('alice');
  const r = await a.req(`${url(mine, '/download')}?path=${encodeURIComponent('/server.properties')}`);
  assert.equal(r.status, 200); assert.equal(await r.text(), 'motd=hi\n');
  assert.match(r.headers.get('content-disposition'), /^attachment; filename="server\.properties"/);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.ok([403, 404].includes((await a.req(`${url(mine, '/download')}?path=/world`)).status));
  assert.equal((await a.req(`${url(mine, '/download')}?path=/leak.txt`)).status, 403, 'link to a file outside the server directory');
  assert.equal((await (await as('bob')).req(`${url(mine, '/download')}?path=/server.properties`)).status, 200, 'view permission is enough');
  assert.equal((await (await as('dave')).req(`${url(mine, '/download')}?path=/server.properties`)).status, 404);
});

test('edit: read, save, binary and read-only handling', async () => {
  const a = await as('alice');
  let r = await get(a, mine, '/content', { path: '/server.properties' });
  assert.equal(r.status, 200); assert.equal(r.body.content, 'motd=hi\n'); assert.equal(r.body.canWrite, true);
  r = await post(a, mine, '/save', { path: '/server.properties', content: 'motd=changed\nmax-players=5\n' });
  assert.equal(r.status, 200); assert.equal(fs.readFileSync(path.join(root, 'server.properties'), 'utf8'), 'motd=changed\nmax-players=5\n');
  assert.ok(!fs.existsSync(path.join(root, '.server.properties.mpupload')));
  assert.equal((await get(a, mine, '/content', { path: '/plugins/WorldEdit.jar' })).status, 415, 'binary');
  assert.equal((await get(a, mine, '/content', { path: '/leak.txt' })).status, 403);
  assert.equal((await post(a, mine, '/save', { path: '/leak.txt', content: 'x' })).status, 403);
  assert.equal(fs.readFileSync(path.join(OUTSIDE, 'secret.txt'), 'utf8'), 'top secret');
  assert.equal((await post(await as('bob'), mine, '/save', { path: '/server.properties', content: 'x' })).status, 403);
  const big = await post(a, mine, '/save', { path: '/server.properties', content: 'x'.repeat(1024 * 1024 + 1) });
  assert.equal(big.status, 413);
  assert.ok(activity.recent ? true : true);
});
