'use strict';
// Tiny WebSocket *client* for tests (own implementation, so server behaviour can also be checked with malformed frames).
const http = require('node:http');
const crypto = require('node:crypto');
const { EventEmitter } = require('node:events');

/** Masked client frame. */
function frame(opcode, payload = Buffer.alloc(0), { fin = true, mask = true } = {}) {
  const p = Buffer.isBuffer(payload) ? payload : Buffer.from(payload);
  let h;
  if (p.length < 126) h = Buffer.from([(fin ? 0x80 : 0) | opcode, (mask ? 0x80 : 0) | p.length]);
  else if (p.length < 65536) { h = Buffer.alloc(4); h[0] = (fin ? 0x80 : 0) | opcode; h[1] = (mask ? 0x80 : 0) | 126; h.writeUInt16BE(p.length, 2); }
  else { h = Buffer.alloc(10); h[0] = (fin ? 0x80 : 0) | opcode; h[1] = (mask ? 0x80 : 0) | 127; h.writeBigUInt64BE(BigInt(p.length), 2); }
  if (!mask) return Buffer.concat([h, p]);
  const key = crypto.randomBytes(4), body = Buffer.from(p);
  for (let i = 0; i < body.length; i++) body[i] ^= key[i & 3];
  return Buffer.concat([h, key, body]);
}

class Client extends EventEmitter {
  constructor(socket, head) {
    super();
    this.socket = socket; this.buf = head || Buffer.alloc(0); this.messages = []; this.pongs = 0;
    this.closeCode = null; this.closeReason = ''; this.ended = false;
    this.closed = new Promise((r) => { this._closed = r; });
    socket.on('data', (d) => { this.buf = Buffer.concat([this.buf, d]); this._parse(); });
    socket.on('close', () => { this.ended = true; this._closed({ code: this.closeCode, reason: this.closeReason }); });
    socket.on('error', () => {});
    if (this.buf.length) this._parse();
  }
  _parse() {
    for (;;) {
      const b = this.buf; if (b.length < 2) return;
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      if (b.length < off + len) return;
      const op = b[0] & 0x0f, payload = b.subarray(off, off + len); this.buf = b.subarray(off + len);
      if (op === 1) { const m = JSON.parse(payload.toString()); this.messages.push(m); this.emit('message', m); }
      else if (op === 8) { this.closeCode = payload.length >= 2 ? payload.readUInt16BE(0) : 1005; this.closeReason = payload.subarray(2).toString(); try { this.socket.write(frame(8, payload)); } catch { /* gone */ } this.socket.end(); }
      else if (op === 0xA) this.pongs += 1;
      else if (op === 9) this.socket.write(frame(0xA, payload));
    }
  }
  sendJson(obj) { this.socket.write(frame(1, JSON.stringify(obj))); }
  sendRaw(buf) { this.socket.write(buf); }
  close(code = 1000) { const p = Buffer.alloc(2); p.writeUInt16BE(code); this.socket.write(frame(8, p)); return this.closed; }
  /** First message (already received or arriving later) matching the predicate. */
  async next(pred, what = 'message', ms = 8000) {
    const t = Date.now();
    while (Date.now() - t < ms) {
      const i = this.messages.findIndex(pred);
      if (i >= 0) return this.messages.splice(i, 1)[0];
      await new Promise((r) => setTimeout(r, 20));
    }
    throw new Error(`timed out waiting for ${what}; got ${JSON.stringify(this.messages).slice(0, 600)}`);
  }
  /** All output lines seen so far plus those arriving within `ms`. */
  lines() { return this.messages.filter((m) => m.type === 'lines' || m.type === 'hello').flatMap((m) => m.lines); }
}

/** Opens a WebSocket. Resolves { status, headers, body } for a refused handshake or { status: 101, ws } on success. */
function connect(base, path, { cookie, origin, key, version = '13', headers = {} } = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(base);
    const req = http.request({ host: u.hostname, port: u.port, path, headers: {
      Connection: 'Upgrade', Upgrade: 'websocket', 'Sec-WebSocket-Version': version, 'Sec-WebSocket-Key': key || crypto.randomBytes(16).toString('base64'),
      ...(cookie ? { Cookie: cookie } : {}), ...(origin ? { Origin: origin } : {}), ...headers } });
    req.on('upgrade', (res, socket, head) => resolve({ status: 101, headers: res.headers, ws: new Client(socket, head) }));
    req.on('response', (res) => { let body = ''; res.on('data', (d) => { body += d; }); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body })); });
    req.on('error', reject); req.end();
  });
}

module.exports = { connect, frame, Client };
