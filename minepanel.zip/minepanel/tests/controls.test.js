'use strict';
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const access = require('../src/dashboard/services/access');
const events = require('../src/dashboard/services/events');
const runtime = require('../src/dashboard/services/runtime');
const db = require('../src/db');
const { Supervisor } = require('../src/runtime/supervisor');

const PW = 'Sup3rSecretPass!', FIXTURE = path.join(__dirname, 'fixtures', 'fake-mc.js');
let srv, base, sup, dataDir, alice, bob, carol, dave, real, idle, orphan;
const text = (r) => r.text();
const get = (id) => db.prepare('SELECT * FROM servers WHERE id = ?').get(id);
const cmds = (id) => db.prepare('SELECT * FROM server_commands WHERE server_id = ?').all(id);
const login = async (name) => { const c = client(base); await c.login(name, PW); return c; };
async function waitFor(fn, what, ms = 10000) {
  const t = Date.now();
  while (Date.now() - t < ms) { const v = await fn(); if (v) return v; await new Promise((r) => setTimeout(r, 40)); }
  assert.fail(`timed out waiting for: ${what}`);
}

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW);
  [alice, bob, carol, dave] = ['alice', 'bob', 'carol', 'dave'].map((u) => users.create({ username: u, email: `${u}@example.com`, passwordHash: hash }));
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-ctl-'));
  sup = new Supervisor({ dataDir, pollMs: 40, metricsMs: 200, stopTimeoutMs: 3000, killTimeoutMs: 1000 });
  sup.start();
  real = servers.create({ ownerId: alice.id, name: 'RealOne', ramLimitMb: 512, startCommand: `node "${FIXTURE}" --delay 300` });
  idle = servers.create({ ownerId: alice.id, name: 'Idle', startCommand: `node "${FIXTURE}"` });
  orphan = servers.create({ ownerId: dave.id, name: 'DavesServer' });
  access.grant({ serverId: real.id, userId: bob.id, permissions: ['control.start'] });
  access.grant({ serverId: real.id, userId: carol.id, permissions: [] });                 // view only
  access.grant({ serverId: idle.id, userId: bob.id, permissions: ['control.start', 'control.stop', 'control.restart'] });
});
after(async () => { await sup.shutdown(); srv.closeAllConnections?.(); srv.close(); fs.rmSync(dataDir, { recursive: true, force: true }); });

const power = (c, ident, body) => c.api(`/api/dashboard/servers/${ident}/power`, body);

test('permissions: owner, partial grant, view-only and unrelated users (API)', async () => {
  const b = await login('bob'), cr = await login('carol'), d = await login('dave');
  // permission is checked before state: bob has no stop/restart permission on RealOne
  for (const action of ['stop', 'restart']) {
    const r = await power(b, real.identifier, { action, confirm: true });
    assert.equal(r.status, 403, action); assert.equal((await r.json()).code, 'forbidden');
  }
  // view-only carol cannot do anything, but can read
  for (const action of ['start', 'stop', 'restart']) assert.equal((await power(cr, real.identifier, { action, confirm: true })).status, 403, action);
  const view = await (await cr.req(`/api/dashboard/servers/${real.identifier}`, { headers: { accept: 'application/json' } })).json();
  assert.equal(view.access, 'shared'); assert.deepEqual(view.permissions, []); assert.deepEqual(view.allowedActions, []);
  // dave has no relation to the server: indistinguishable from "does not exist"
  assert.equal((await power(d, real.identifier, { action: 'start' })).status, 404);
  assert.equal((await d.req(`/api/dashboard/servers/${real.identifier}`, { headers: { accept: 'application/json' } })).status, 404);
  assert.equal((await d.req(`/dashboard/servers/${real.identifier}`)).status, 404);
  assert.equal((await d.req(`/dashboard/servers/${real.identifier}/confirm/stop`)).status, 404);
  assert.equal(cmds(real.id).length, 0, 'nothing was queued by any rejected request');
  // bob: allowed actions are permission AND state
  const bd = await (await b.req(`/api/dashboard/servers/${real.identifier}`, { headers: { accept: 'application/json' } })).json();
  assert.deepEqual(bd.permissions, ['control.start']); assert.deepEqual(bd.allowedActions, ['start']);
});

test('permissions: the UI only offers what the user may do; shared servers are listed and marked', async () => {
  const b = await login('bob'), cr = await login('carol'), a = await login('alice');
  const bobPage = await text(await b.req(`/dashboard/servers/${real.identifier}`));
  assert.match(bobPage, />Start</); assert.doesNotMatch(bobPage, />Stop<|>Restart</);
  assert.match(bobPage, /Shared with you: Start/);
  const carolPage = await text(await cr.req(`/dashboard/servers/${real.identifier}`));
  assert.doesNotMatch(carolPage, />Start<|>Stop<|>Restart<|<button type="submit" name="action"/); assert.match(carolPage, /view-only access/);
  assert.match(await text(await cr.req('/dashboard/servers')), /RealOne<\/strong><\/a> <span class="mp-badge">shared<\/span>/);
  assert.match(await text(await a.req(`/dashboard/servers/${real.identifier}`)), /Your access<\/dt><dd>Owner/);
  // direct form post by a user without permission is refused by the server, whatever the UI showed
  const r = await carol_post(cr, real.id, 'start');
  assert.equal(r.status, 303); assert.equal(get(real.id).status, 'offline'); assert.equal(cmds(real.id).length, 0);
  assert.match(await text(await cr.req('/dashboard/servers')), /do not have permission to start RealOne/);
});
const carol_post = (c, id, action, extra = {}) => c.post('/dashboard/servers/action', { server_id: id, action, back: '/dashboard/servers', ...extra }, '/dashboard/servers');

test('confirmation is required for stop and restart (API and web), never for start', async () => {
  const a = await login('alice');
  runtime.reportStatus(idle.id, { status: 'online', ramUsedMb: 10, playersOnline: 3 });
  // API
  let r = await power(a, idle.identifier, { action: 'stop' });
  assert.equal(r.status, 428); assert.equal((await r.json()).code, 'confirmation_required');
  r = await power(a, idle.identifier, { action: 'restart', confirm: false }); assert.equal(r.status, 428);
  assert.equal(get(idle.id).status, 'online'); assert.equal(cmds(idle.id).length, 0);
  // web: redirected to the confirmation page instead of acting
  const w = await carol_post(a, idle.id, 'stop');
  assert.match(w.headers.get('location'), new RegExp(`^/dashboard/servers/${idle.identifier}/confirm/stop\\?back=`)); assert.equal(get(idle.id).status, 'online');
  const page = await text(await a.req(`/dashboard/servers/${idle.identifier}/confirm/stop`));
  assert.match(page, /Stop server\?/); assert.match(page, /3 players are online right now/); assert.match(page, /name="confirm" value="1"/); assert.match(page, /Cancel/);
  assert.match(await text(await a.req(`/dashboard/servers/${idle.identifier}/confirm/restart`)), /Restart server\?/);
  assert.equal((await a.req(`/dashboard/servers/${idle.identifier}/confirm/start`)).status, 404);   // start needs no confirmation page
  assert.equal((await a.req(`/dashboard/servers/${idle.identifier}/confirm/explode`)).status, 404);
  // the button on a running server leads to the confirmation page, not straight to the action
  assert.match(await text(await a.req(`/dashboard/servers/${idle.identifier}`)), new RegExp(`href="/dashboard/servers/${idle.identifier}/confirm/stop\\?back=`));
  // confirm page for an action that is not valid now bounces back with a message
  runtime.reportStatus(idle.id, { status: 'offline' });
  const bounce = await a.req(`/dashboard/servers/${idle.identifier}/confirm/stop`);
  assert.equal(bounce.status, 303); assert.match(await text(await a.req(`/dashboard/servers/${idle.identifier}`)), /cannot be stopped while it is offline/);
});

test('state, busy, unknown action, CSRF and auth checks on the API', async () => {
  const a = await login('alice');
  assert.equal((await power(a, idle.identifier, { action: 'stop', confirm: true })).status, 409);          // offline -> cannot stop
  assert.equal((await power(a, idle.identifier, { action: 'explode', confirm: true })).status, 422);
  assert.equal((await power(a, idle.identifier, {})).status, 422);
  runtime.reportStatus(idle.id, { status: 'online' });
  let r = await power(a, idle.identifier, { action: 'start' }); assert.equal(r.status, 409); assert.match((await r.json()).error, /cannot be started while it is online/);
  r = await power(a, idle.identifier, { action: 'restart', confirm: true }); assert.equal(r.status, 202);
  r = await power(a, idle.identifier, { action: 'restart', confirm: true }); assert.equal(r.status, 409); assert.equal((await r.json()).code, 'invalid_state');   // now "stopping"
  // "busy" is the second line of defence: a command is pending even though the status says it could be started
  const d = await login('dave');
  runtime.reportStatus(orphan.id, { status: 'crashed' });
  db.prepare("INSERT INTO server_commands (server_id, user_id, command, created_at) VALUES (?, ?, 'start', ?)").run(orphan.id, dave.id, Date.now());
  const busy = servers.requestCommand(dave, orphan.id, 'start', '127.0.0.1');     // synchronous: the runtime cannot interleave
  assert.equal(busy.code, 'busy');
  runtime.completeCommand(cmds(orphan.id)[0].id, { ok: false, error: 'test cleanup', status: 'offline' });
  // no CSRF header -> rejected; anonymous -> 401
  assert.equal((await a.api(`/api/dashboard/servers/${idle.identifier}/power`, { action: 'start' }, { csrf: false })).status, 403);
  const anon = client(base);
  // anonymous: stopped by the global CSRF check (403) before the auth guard could answer (401); never reaches the service
  const anonPost = await anon.req(`/api/dashboard/servers/${idle.identifier}/power`, { method: 'POST', json: { action: 'start' }, headers: { accept: 'application/json' } });
  assert.ok([401, 403].includes(anonPost.status), `anonymous POST got ${anonPost.status}`);
  assert.equal((await anon.req('/api/dashboard/csrf', { headers: { accept: 'application/json' } })).status, 401);
  assert.equal((await anon.req('/api/dashboard/events')).status, 401);
  // the runtime (a real supervisor is running) finishes the restart; clean up to a known state
  await waitFor(() => get(idle.id).status === 'online' && cmds(idle.id).every((c) => c.status !== 'pending'), 'restart finished');
  const s = await power(a, idle.identifier, { action: 'stop', confirm: true }); assert.equal(s.status, 202);
  await waitFor(() => get(idle.id).status === 'offline', 'stopped');
});

test('END TO END: API start -> real process online with real usage -> shared user start/stop rules -> confirmed stop', async () => {
  const a = await login('alice'), b = await login('bob');
  let r = await power(a, real.identifier, { action: 'start' });
  assert.equal(r.status, 202); let j = await r.json();
  assert.equal(j.server.status, 'starting'); assert.equal(j.command.status, 'pending'); assert.equal(j.command.command, 'start');
  await waitFor(() => get(real.id).status === 'online', 'real server online');
  const detail = await waitFor(async () => { const d = await (await a.req(`/api/dashboard/servers/${real.identifier}`, { headers: { accept: 'application/json' } })).json(); return d.server.ram.used > 20 ? d : null; }, 'real RAM usage visible via the API');
  assert.equal(detail.server.status, 'online'); assert.deepEqual(detail.allowedActions, ['stop', 'restart']); assert.ok(detail.server.startedAt);
  assert.ok(sup.entries.get(real.id).proc.pid > 0);
  // bob (start-only) cannot stop it; the details page for bob shows no actions available
  assert.equal((await power(b, real.identifier, { action: 'stop', confirm: true })).status, 403);
  assert.match(await text(await b.req(`/dashboard/servers/${real.identifier}`)), /No actions are available while the server is online/);
  // alice confirms the stop through the web flow
  const w = await carol_post(a, real.id, 'stop', { confirm: '1' });
  assert.equal(w.status, 303);
  await waitFor(() => get(real.id).status === 'offline', 'stopped');
  assert.equal(get(real.id).ram_used_mb, 0); assert.equal(cmds(real.id).at(-1).status, 'done');
  // bob may start it again (granted), and the owner's activity log says who did it
  assert.equal((await power(b, real.identifier, { action: 'start' })).status, 202);
  await waitFor(() => get(real.id).status === 'online', 'online again');
  assert.match(await text(await a.req('/dashboard/activity')), /Start requested for RealOne by bob/);
  await power(a, real.identifier, { action: 'stop', confirm: true });
  await waitFor(() => get(real.id).status === 'offline', 'stopped again');
});

test('real-time stream: snapshot, then status changes pushed as they really happen; scoped per user', async () => {
  const a = await login('alice'), d = await login('dave');
  const open = async (c) => {
    const ac = new AbortController(), res = await c.req('/api/dashboard/events', { signal: ac.signal, headers: { accept: 'text/event-stream' } });
    assert.equal(res.status, 200); assert.match(res.headers.get('content-type'), /text\/event-stream/);
    const st = { text: '', ac }; const dec = new TextDecoder(); const reader = res.body.getReader();
    (async () => { try { for (;;) { const { value, done } = await reader.read(); if (done) break; st.text += dec.decode(value); } } catch { /* aborted */ } })();
    return st;
  };
  db.prepare('UPDATE servers SET start_command = ? WHERE id = ?').run(`node "${FIXTURE}" --delay 2500`, real.id);   // slow enough to be observable between 1s ticks
  const sa = await open(a), sd = await open(d);
  await waitFor(() => sa.text.includes('event: snapshot') && sd.text.includes('event: snapshot'), 'snapshots');
  const snap = JSON.parse(/event: snapshot\ndata: (.*)\n/.exec(sa.text)[1]);
  assert.deepEqual(snap.map((x) => x.identifier).sort(), [idle.identifier, real.identifier].sort());
  assert.equal(events.count(alice.id), 1);
  // a real start: the stream shows starting then online without any polling by the client
  await power(a, real.identifier, { action: 'start' });
  await waitFor(() => /"identifier":"[0-9a-f]{8}","name":"RealOne","status":"starting"/.test(sa.text), 'starting pushed');
  await waitFor(() => /"name":"RealOne","status":"online"/.test(sa.text), 'online pushed');
  assert.ok(sa.text.indexOf('"status":"starting"') < sa.text.lastIndexOf('"status":"online"'));
  // dave only ever sees his own server
  assert.doesNotMatch(sd.text, /RealOne|Idle/); assert.match(sd.text, new RegExp(orphan.identifier));
  runtime.reportStatus(orphan.id, { status: 'online' });
  await waitFor(() => /DavesServer","status":"online"/.test(sd.text), 'dave gets his own update');
  assert.doesNotMatch(sa.text, /DavesServer/);
  sa.ac.abort(); sd.ac.abort();
  await waitFor(() => events.count(alice.id) === 0 && events.count(dave.id) === 0, 'connections cleaned up');
  await power(a, real.identifier, { action: 'stop', confirm: true });
  await waitFor(() => get(real.id).status === 'offline', 'stopped');
});

test('access grants: revoke removes visibility; unknown permissions are rejected', async () => {
  assert.throws(() => access.grant({ serverId: idle.id, userId: carol.id, permissions: ['control.delete'] }), /Unknown permission/);
  const b = await login('bob');
  assert.equal((await b.req(`/dashboard/servers/${idle.identifier}`)).status, 200);
  assert.equal(access.revoke(idle.id, bob.id), true);
  assert.equal((await b.req(`/dashboard/servers/${idle.identifier}`)).status, 404);
  assert.doesNotMatch(await text(await b.req('/dashboard/servers')), /Idle/);
  assert.deepEqual(access.listFor(real.id).map((x) => [x.username, x.permissions.length]), [['bob', 1], ['carol', 0]]);
});
