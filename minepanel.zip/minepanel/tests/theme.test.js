'use strict';
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.VPS_RAM_MB = '1048576'; process.env.VPS_CPU_CORES = '1000'; process.env.VPS_DISK_MB = '10485760';   // a huge VPS: capacity limits are tested in admin.test.js
process.env.MAIL_QUIET = 'true';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const nodes = require('../src/dashboard/services/nodes');

let srv, base, admin, alice, bob, s1, s2;
const PW = 'Sup3rSecretPass!';
const text = async (r) => r.text();

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW);
  admin = users.create({ username: 'root-admin', email: 'root@example.com', passwordHash: hash, role: 'admin' });
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: hash });
  bob = users.create({ username: 'bob', email: 'bob@example.com', passwordHash: hash });
  s1 = servers.create({ ownerId: alice.id, name: 'AliceSurvival' });
  s2 = servers.create({ ownerId: bob.id, name: 'BobCreative' });
  nodes.create({ name: 'Node-1', location: 'Frankfurt', fqdn: 'n1.internal' });
});
after(() => srv.close());

test('sign-in and register screens carry the themed markup', async () => {
  const c = client(base);
  const login = await text(await c.req('/login'));
  for (const m of ['Welcome Back', 'Email Address', 'under your control', 'Live Console', 'Secure by Default', 'Support', 'Create Account', '/img/logo.png']) assert.match(login, new RegExp(m));
  const reg = await text(await c.req('/register'));
  for (const m of ['First Name', 'Last Name', 'letters, numbers, dashes', 'min\\. 10 characters', 'repeat password', 'Back to login']) assert.match(reg, new RegExp(m));
});

test('register stores optional first/last name and accepts dashes in usernames', async () => {
  const c = client(base);
  const r = await c.post('/register', { first_name: 'Mine', last_name: 'Flare', username: 'mine-flare', email: 'mf@example.com', password: PW, confirm: PW }, '/register');
  assert.equal(r.status, 303);
  const u = users.findByUsername('mine-flare');
  assert.equal(u.first_name, 'Mine'); assert.equal(u.last_name, 'Flare');
  const bad = await c.post('/register', { first_name: '<b>', username: 'xx yy', email: 'x@example.com', password: PW, confirm: PW }, '/register');
  assert.equal(bad.status, 422);
  // names are optional
  const ok = await c.post('/register', { username: 'plain_user', email: 'pu@example.com', password: PW, confirm: PW }, '/register');
  assert.equal(ok.status, 303);
});

test('dashboard: search modal, avatar, sidebar and empty state', async () => {
  const c = client(base); await c.login('bob', PW);
  servers.create({ ownerId: bob.id, name: 'Extra' });
  const html = await text(await c.req('/dashboard'));
  for (const m of ['data-search-modal', 'Ctrl K', 'avatar-', '/img/server-banner.jpg|mp-srv-banner', 'Account', 'Search']) assert.match(html, new RegExp(m));
  assert.doesNotMatch(html, /Create Server|mp-switch/);      // admin-only controls
  assert.doesNotMatch(html, />Admin</);
  const empty = client(base); await empty.login('plain_user', PW);
  assert.match(await text(await empty.req('/dashboard')), /No servers found/);
});

test('admin sees the switch, Create Server and every server; regular users do not', async () => {
  const a = client(base); await a.login('root-admin', PW);
  const mine = await text(await a.req('/dashboard'));
  assert.match(mine, /Showing your servers/); assert.match(mine, /Create Server/); assert.match(mine, />Admin</);
  assert.doesNotMatch(mine, /AliceSurvival/);
  const all = await text(await a.req('/dashboard?all=1'));
  assert.match(all, /Showing all servers/); assert.match(all, /AliceSurvival/); assert.match(all, /BobCreative/); assert.match(all, /Owner: alice/);
  // an ordinary user cannot use ?all=1 nor the admin pages
  const u = client(base); await u.login('alice', PW);
  const html = await text(await u.req('/dashboard?all=1'));
  assert.match(html, /AliceSurvival/); assert.doesNotMatch(html, /BobCreative/);
  assert.equal((await u.req('/admin/servers/new')).status, 403);
  assert.equal((await u.post('/admin/servers', { name: 'x', owner: 'alice' }, '/dashboard')).status, 403);
  // admin may open and operate any server; non-admin still gets 404 for foreign servers
  assert.equal((await a.req(`/dashboard/servers/${s2.identifier}`)).status, 200);
  assert.equal((await a.req(`/dashboard/servers/${s2.identifier}/console`)).status, 200);
  assert.equal((await u.req(`/dashboard/servers/${s2.identifier}`)).status, 404);
});

test('admin Create Server: validation, creation, duplicates', async () => {
  const a = client(base); await a.login('root-admin', PW);
  const form = await text(await a.req('/admin/servers/new'));
  assert.match(form, /Server name/); assert.doesNotMatch(form, /Node-1/); assert.doesNotMatch(form, /name="node"/);
  const bad = await a.post('/admin/servers', { name: '', owner: 'nobody', software: 'paper', version: '1.21', ram: '5', cpu: 'x', disk: '1', players: '0' }, '/admin/servers/new');
  assert.equal(bad.status, 422);
  const html = await text(bad);
  for (const m of ['Enter a name', 'No account matches', 'between 128', 'between 10 and 6400', 'between 1 and 10000']) assert.match(html, new RegExp(m));
  const ok = await a.post('/admin/servers', { name: 'Made By Admin', owner: 'alice@example.com', software: 'Paper', version: '1.21.4', address: 'play.example.com:25565', ram: '4096', cpu: '200', disk: '20480', players: '40' }, '/admin/servers/new');
  assert.equal(ok.status, 303);
  const made = servers.listForOwner(alice.id).find((s) => s.name === 'Made By Admin');
  assert.ok(made); assert.equal(made.ram_limit_mb, 4096); assert.equal(made.node_id, null); assert.equal(made.software, 'paper');
  assert.match(ok.headers.get('location'), new RegExp(`/dashboard/servers/${made.identifier}`));
  const dup = await a.post('/admin/servers', { name: 'Made By Admin', owner: 'alice', software: 'paper', version: 'latest', ram: '1024', cpu: '100', disk: '1024', players: '10' }, '/admin/servers/new');
  assert.equal(dup.status, 422); assert.match(await text(dup), /already has a server/);
});

test('console page: banner, power buttons, side cards, themed sidebar', async () => {
  const c = client(base); await c.login('alice', PW);
  const html = await text(await c.req(`/dashboard/servers/${s1.identifier}/console`));
  for (const m of ['mp-banner', 'data-console-conn', '>Start<', '>Restart<', '>Stop<', 'Network received', 'Network sent', 'Status query unavailable', '/img/herobrine-art.png',
    'Resources', 'Connection', 'MC UTILS', 'Server Properties', 'Plugins Manager', 'Backups', 'Startup', 'All servers', 'Start the server to send commands']) assert.match(html, new RegExp(m));
  assert.match(html, /is-disabled[^>]*>[^<]*<svg[^>]*>.*?<span>Stop<\/span>/s);   // offline server: Stop is shown but disabled
});

test('server sub-pages: real ones render, unbuilt ones say so and never invent data', async () => {
  const c = client(base); await c.login('alice', PW);
  for (const slug of ['activity', 'users', 'network']) assert.equal((await c.req(`/dashboard/servers/${s1.identifier}/${slug}`)).status, 200, slug);
  assert.match(await text(await c.req(`/dashboard/servers/${s1.identifier}/users`)), /alice/);
  for (const slug of ['backups', 'plugins', 'server-properties']) {
    const html = await text(await c.req(`/dashboard/servers/${s1.identifier}/${slug}`));
    assert.match(html, /is not built yet/);
  }
  assert.equal((await c.req(`/dashboard/servers/${s2.identifier}/files`)).status, 404);   // someone else's server
  assert.match(await text(await c.req('/dashboard/api-credentials')), /API Credentials is not built yet/);
  assert.match(await text(await c.req('/dashboard/ssh-keys')), /SSH Keys is not built yet/);
});

test('account page layout matches the reference', async () => {
  const c = client(base); await c.login('alice', PW);
  const html = await text(await c.req('/dashboard/settings'));
  for (const m of ['Account settings', 'My panel colours', 'Update Password', 'Update Email Address', 'Two-Step Verification', 'API Credentials', 'SSH Keys', 'Activity', 'Save colours', 'Use panel defaults', 'Update Email']) assert.match(html, new RegExp(m));
  // email can still be changed through the new form
  const r = await c.post('/dashboard/settings/profile', { username: 'alice', email: 'alice2@example.com', current_password: PW }, '/dashboard/settings');
  assert.equal(r.status, 303); assert.equal(users.findById(alice.id).email, 'alice2@example.com');
});

test('static assets are served', async () => {
  for (const f of ['logo.png', 'bg.svg', 'avatar-steve.svg', 'avatar-alex.svg', 'server-icon.svg', 'server-banner.jpg', 'herobrine-art.png']) {
    const r = await fetch(`${base}/img/${f}`); assert.equal(r.status, 200, f); await r.arrayBuffer();
  }
});
