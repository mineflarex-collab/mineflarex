'use strict';
// Test stand-in for a Minecraft server *binary*: a real OS process with a Minecraft-like console.
// (The panel and runtime under test are real; only the game executable is replaced.)
//   --delay MS       time until the "Done" line      --ignore-stop    ignore the `stop` console command
//   --ignore-term    also ignore SIGTERM (needs SIGKILL)   --dump-env   write the process environment to env.json
const fs = require('node:fs');
const a = process.argv.slice(2), has = (f) => a.includes(f), val = (f, d) => (has(f) ? Number(a[a.indexOf(f) + 1]) : d);
const log = (m) => console.log(`[12:00:00] [Server thread/INFO]: ${m}`);
if (has('--dump-env')) fs.writeFileSync('env.json', JSON.stringify(process.env));
if (has('--ignore-term')) process.on('SIGTERM', () => log('SIGTERM ignored'));
fs.writeFileSync('world.dat', Buffer.alloc(2 * 1024 * 1024));          // something on disk to measure
const ballast = Buffer.alloc(30 * 1024 * 1024, 1);                     // something in RAM to measure
log('Starting minecraft server version 1.21.4');
setTimeout(() => log('Done (0.100s)! For help, type "help"'), val('--delay', 100));
require('node:readline').createInterface({ input: process.stdin }).on('line', (line) => {
  const [cmd, name] = line.trim().split(' ');
  if (cmd === 'stop') { if (has('--ignore-stop')) return log('stop ignored'); log('Stopping server'); process.exit(0); }
  if (cmd === 'join') log(`${name} joined the game`);
  if (cmd === 'leave') log(`${name} left the game`);
  if (cmd === 'crash') process.exit(2);
  if (cmd === 'say') log(`[Server] ${line.trim().slice(4)}`);
  if (cmd === 'spam') for (let i = 1; i <= Number(name); i++) log(`spam line ${i}`);                 // many lines at once
  if (cmd === 'ansi') console.log('\x1b[32mgreen\x1b[0m and \x1b[1;31mbold red\x1b[0m');
  if (cmd === 'err') console.error(`stderr says ${name}`);
  if (cmd === 'warn') console.log('[12:00:00] [Server thread/WARN]: careful');
});
setInterval(() => ballast[0]++, 1000);
