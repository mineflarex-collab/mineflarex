'use strict';
// Test helpers: a minimal zip/jar writer (deflated entries) and a tiny class-file header.
const zlib = require('node:zlib');

function makeZip(files) {
  const parts = [], cd = []; let off = 0;
  for (const [name, data] of Object.entries(files)) {
    const nm = Buffer.from(name), raw = Buffer.from(data), comp = zlib.deflateRawSync(raw), crc = zlib.crc32(raw);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(8, 8); lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(raw.length, 22); lh.writeUInt16LE(nm.length, 26);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(8, 10); c.writeUInt32LE(crc, 16); c.writeUInt32LE(comp.length, 20); c.writeUInt32LE(raw.length, 24); c.writeUInt16LE(nm.length, 28); c.writeUInt32LE(off, 42);
    parts.push(lh, nm, comp); cd.push(c, nm); off += 30 + nm.length + comp.length;
  }
  const cdBuf = Buffer.concat(cd), end = Buffer.alloc(22), n = Object.keys(files).length;
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(n, 8); end.writeUInt16LE(n, 10); end.writeUInt32LE(cdBuf.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cdBuf, end]);
}
const klass = (major) => { const b = Buffer.alloc(64); b.writeUInt32BE(0xcafebabe, 0); b.writeUInt16BE(0, 4); b.writeUInt16BE(major, 6); return b; };

module.exports = { makeZip, klass };
