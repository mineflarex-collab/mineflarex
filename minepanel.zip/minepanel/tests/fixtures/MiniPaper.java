// Test stand-in for Paper's plugin loading, run by a REAL JVM (java MiniPaper.java server.jar nogui):
// it scans ./plugins/*.jar in name order and loads each plugin's loader/main class exactly like a server would.
// Like Paper, an Error (UnsupportedClassVersionError is one) is not caught per plugin: it ends plugin loading for all later jars.
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;

public class MiniPaper {
  public static void main(String[] args) throws Exception {
    System.out.println("[00:00:00 INFO]: Initializing plugins...");
    List<String> loaded = new ArrayList<>();
    File[] jars = new File("plugins").listFiles((d, n) -> n.endsWith(".jar"));
    if (jars != null) {
      Arrays.sort(jars);
      try {
        for (File f : jars) {
          try (JarFile jf = new JarFile(f)) {
            JarEntry y = jf.getJarEntry("paper-plugin.yml");
            if (y == null) y = jf.getJarEntry("plugin.yml");
            if (y == null) throw new IOException("no plugin.yml");
            List<String> names = new ArrayList<>();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(jf.getInputStream(y)))) {
              String line;
              while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("loader:") || line.startsWith("main:")) names.add(line.substring(line.indexOf(':') + 1).trim());
              }
            }
            URLClassLoader cl = new URLClassLoader(new URL[] { f.toURI().toURL() }, MiniPaper.class.getClassLoader());
            for (String n : names) Class.forName(n, true, cl);
            loaded.add(f.getName());
            System.out.println("[00:00:00 INFO]: Loaded plugin " + f.getName());
          } catch (Exception e) {
            System.out.println("[00:00:00 ERROR]: Could not load " + f.getName() + ": " + e);
          }
        }
      } catch (Error e) {
        System.out.println("[00:00:00 ERROR]: " + e);
      }
    }
    Files.writeString(Path.of("loaded.txt"), String.join("\n", loaded));
    System.out.println("[00:00:01 INFO]: Done (0.1s)! For help, type \"help\"");
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    String line;
    while ((line = in.readLine()) != null) {
      line = line.trim();
      if (line.equals("stop")) { System.out.println("[00:00:02 INFO]: Stopping server"); System.exit(0); }
      if (line.equals("pl")) System.out.println("[00:00:02 INFO]: Server Plugins (" + loaded.size() + "): " + String.join(", ", loaded));
    }
  }
}
