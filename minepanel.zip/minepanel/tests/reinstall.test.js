'use strict';
// Reinstall: real panel, real supervisor, real child processes. Only two things are stood in for: the Minecraft
// binary (tests/fixtures/fake-mc.js) and the Paper download API (a local HTTP server below, so no internet is needed
// and the test can hold a download open to observe the "Reinstalling" state).
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const PW = 'Sup3rSecretPass!', FIXTURE = path.join(__dirname, 'fixtures', 'fake-mc.js');
const JAR_V2 = Buffer.from('FRESH-PAPER-JAR-'.repeat(64)), JAR_OLD = Buffer.from('OLD-PAPER-JAR');
const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');

// ---- mock Paper API -----------------------------------------------------------------------------
const paper = { fail: false, hold: null, hits: 0, jar: JAR_V2, server: null, url: '' };
function startMockPaper() {
  paper.server = http.createServer(async (req, res) => {
    const send = (code, body, type = 'application/json') => { res.writeHead(code, { 'Content-Type': type }); res.end(body); };
    if (paper.fail && !req.url.startsWith('/dl/')) return send(500, '{"error":"boom"}');
    if (req.url === '/paper') return send(200, JSON.stringify({ versions: { '1.21': ['1.21.4', '1.21.3', '1.21.4-rc1'] } }));
    if (/^\/paper\/versions\/[^/]+\/builds\/latest$/.test(req.url)) {
      paper.hits += 1;
      if (paper.hold) await paper.hold;                                  // lets a test observe the state while the download is "in progress"
      return send(200, JSON.stringify({ id: 99, downloads: { 'server:default': { name: 'paper-99.jar', url: `${paper.url}/dl/paper.jar`, checksums: { sha256: sha(paper.jar) } } } }));
    }
    if (req.url === '/dl/paper.jar') return send(200, paper.jar, 'application/java-archive');
    return send(404, '{}');
  });
  return new Promise((resolve) => paper.server.listen(0, '127.0.0.1', () => { paper.url = `http://127.0.0.1:${paper.server.address().port}`; resolve(); }));
}
/** Holds every download until release() is called. */
function hold() { let release; paper.hold = new Promise((r) => { release = () => { paper.hold = null; r(); }; }); return release; }

let srv, base, sup, dataDir, alice, bob, dave, root, mods;
let mc, mc2, custom, bot, spigot;
const text = (r) => r.text();
const get = (id) => mods.db.prepare('SELECT * FROM servers WHERE id = ?').get(id);
const cmds = (id) => mods.db.prepare('SELECT * FROM server_commands WHERE server_id = ? ORDER BY id').all(id);
const lastCmd = (id) => cmds(id).at(-1);
const jarPath = (s) => path.join(dataDir, s.identifier, 'server.jar');
const write = (s, rel, data) => { const f = path.join(dataDir, s.identifier, rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, data); };
const login = async (name) => { const c = mods.client(base); await c.login(name, PW); return c; };
const power = (c, s, body) => c.api(`/api/dashboard/servers/${s.identifier}/power`, body);
const detail = async (c, s) => (await c.req(`/api/dashboard/servers/${s.identifier}`, { headers: { accept: 'application/json' } })).json();
async function waitFor(fn, what, ms = 10000) {
  const t = Date.now();
  while (Date.now() - t < ms) { const v = await fn(); if (v) return v; await new Promise((r) => setTimeout(r, 30)); }
  assert.fail(`timed out waiting for: ${what}`);
}
const consoleText = (s) => mods.db.prepare('SELECT line FROM console_lines WHERE server_id = ? ORDER BY id').all(s.id).map((l) => l.line).join('\n');
/** Console output is written to the database in 100 ms batches, so wait for a line instead of reading once. */
const consoleHas = (s, re) => waitFor(() => re.test(consoleText(s)), `console line ${re}`);
const idleSupervisor = () => waitFor(() => !sup.inflight.size && !sup.entries.size, 'supervisor idle');

before(async () => {
  await startMockPaper();
  process.env.PAPER_API = `${paper.url}/paper`;                         // must be set before jar.js is loaded
  mods = {
    db: require('../src/db'), client: require('./helpers').client, users: require('../src/services/users'),
    servers: require('../src/dashboard/services/servers'), access: require('../src/dashboard/services/access'),
    activity: require('../src/dashboard/services/activity'), events: require('../src/dashboard/services/events'),
    console: require('../src/dashboard/services/serverConsole'), Supervisor: require('../src/runtime/supervisor').Supervisor
  };
  const { createServer } = require('../src/app'), { hashPassword } = require('../src/lib/crypto');
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW), mk = (u, role = 'user') => mods.users.create({ username: u, email: `${u}@example.com`, passwordHash: hash, role });
  alice = mk('alice'); bob = mk('bob'); dave = mk('dave'); root = mk('root', 'admin');
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-reinstall-'));
  sup = new mods.Supervisor({ dataDir, pollMs: 30, metricsMs: 200, stopTimeoutMs: 3000, killTimeoutMs: 1000 });
  sup.start();

  const S = mods.servers;
  // "server.jar" as the last argument is what makes the panel treat the command as the stock Paper setup (it is what the default command runs).
  mc = S.create({ ownerId: alice.id, name: 'Survival', software: 'paper', version: '1.21.4', startCommand: `node "${FIXTURE}" --delay 150 server.jar` });
  mc2 = S.create({ ownerId: alice.id, name: 'Creative', software: 'paper', version: 'latest', startCommand: `node "${FIXTURE}" --delay 150 server.jar` });
  custom = S.create({ ownerId: alice.id, name: 'Custom', startCommand: `node "${FIXTURE}"` });
  bot = S.create({ ownerId: alice.id, name: 'MyBot', kind: 'bot', runtime: 'nodejs' });
  spigot = S.create({ ownerId: alice.id, name: 'Spig', software: 'spigot', version: '1.21.4', startCommand: `node "${FIXTURE}" server.jar` });
  mods.access.grant({ serverId: mc.id, userId: bob.id, permissions: ['control.start', 'control.stop', 'control.restart'] });
});
after(async () => { await sup.shutdown(); srv.closeAllConnections?.(); srv.close(); paper.server.close(); fs.rmSync(dataDir, { recursive: true, force: true }); });

// ------------------------------------------------------------------------------------------------
test('reinstall a stopped server: confirmation, visible "reinstalling" state, other actions blocked, files kept, jar replaced', async () => {
  const a = await login('alice');
  write(mc, 'server.jar', JAR_OLD); write(mc, 'world/level.dat', 'MY-WORLD'); write(mc, 'plugins/keep.yml', 'x: 1');

  assert.equal((await power(a, mc, { action: 'reinstall' })).status, 428);                       // destructive: needs confirm
  assert.equal((await power(a, mc, { action: 'reinstall', confirm: false })).status, 428);
  assert.equal(get(mc.id).task, null); assert.equal(cmds(mc.id).length, 0);                      // nothing queued by a refused request

  const release = hold();
  const r = await power(a, mc, { action: 'reinstall', confirm: true });
  assert.equal(r.status, 202);
  const body = await r.json();
  assert.equal(body.server.task, 'reinstall'); assert.equal(body.server.status, 'offline');
  assert.match(body.message, /Reinstall command sent to Survival/);

  // while the runtime works: the panel says so, and offers nothing else
  await waitFor(() => paper.hits > 0, 'runtime started downloading');
  const d = await detail(a, mc);
  assert.equal(d.server.task, 'reinstall'); assert.deepEqual(d.allowedActions, []);
  for (const action of ['start', 'stop', 'restart', 'reinstall']) {
    const x = await power(a, mc, { action, confirm: true });
    assert.equal(x.status, 409, action); assert.equal((await x.json()).code, 'busy', action);
  }
  assert.equal(fs.readFileSync(jarPath(mc)).toString(), 'OLD-PAPER-JAR', 'old jar is kept until the new one is verified');

  release();
  await waitFor(() => lastCmd(mc.id).status === 'done', 'reinstall command done');
  const after = get(mc.id);
  assert.equal(after.task, null); assert.equal(after.status, 'offline');
  assert.deepEqual(fs.readFileSync(jarPath(mc)), JAR_V2);                                        // fresh jar
  assert.equal(fs.readFileSync(path.join(dataDir, mc.identifier, 'world/level.dat'), 'utf8'), 'MY-WORLD');   // data untouched
  assert.equal(fs.readFileSync(path.join(dataDir, mc.identifier, 'plugins/keep.yml'), 'utf8'), 'x: 1');
  assert.ok(!fs.existsSync(jarPath(mc) + '.part'), 'no temp file left behind');
  assert.deepEqual((await detail(a, mc)).allowedActions, ['start', 'reinstall']);                // buttons are back
  assert.match(await text(await a.req('/dashboard/activity')), /Survival was reinstalled/);
  await consoleHas(mc, /Press Start/);
  assert.match(consoleText(mc), /Reinstalling server software/); assert.match(consoleText(mc), /Reinstalled server\.jar/);
});

test('reinstall a running server: stopped first, stays stopped afterwards, nothing auto-starts', async () => {
  const a = await login('alice');
  assert.equal((await power(a, mc, { action: 'start' })).status, 202);
  await waitFor(() => get(mc.id).status === 'online', 'online');
  assert.deepEqual((await detail(a, mc)).allowedActions, ['stop', 'restart', 'reinstall']);
  const pid = sup.entries.get(mc.id).proc.pid;

  const release = hold();
  const r = await power(a, mc, { action: 'reinstall', confirm: true });
  assert.equal(r.status, 202); const body = await r.json();
  assert.equal(body.server.status, 'stopping'); assert.equal(body.server.task, 'reinstall');
  await waitFor(() => !sup.entries.has(mc.id), 'process gone');
  assert.throws(() => process.kill(pid, 0), 'the old process really ended');
  await waitFor(() => paper.hits > 1, 'download started');
  assert.equal(get(mc.id).status, 'offline'); assert.equal(get(mc.id).task, 'reinstall');      // still "reinstalling" while the download is open
  release();
  await waitFor(() => lastCmd(mc.id).status === 'done' && get(mc.id).task === null, 'finished');
  await new Promise((r2) => setTimeout(r2, 400));                                                // would be online by now if it had auto-started
  assert.equal(get(mc.id).status, 'offline'); assert.ok(!sup.entries.has(mc.id));
  // ... and it can be started again with the new jar
  assert.equal((await power(a, mc, { action: 'start' })).status, 202);
  await waitFor(() => get(mc.id).status === 'online', 'online again');
  assert.equal((await power(a, mc, { action: 'stop', confirm: true })).status, 202);
  await waitFor(() => get(mc.id).status === 'offline', 'stopped');
  await idleSupervisor();
});

test('a failed download keeps the old jar, reports the real reason, clears the task and leaves the server usable', async () => {
  const a = await login('alice');
  write(mc2, 'server.jar', 'KEEP-ME'); write(mc2, 'world/level.dat', 'W');
  paper.fail = true;
  try {
    assert.equal((await power(a, mc2, { action: 'reinstall', confirm: true })).status, 202);
    await waitFor(() => lastCmd(mc2.id).status === 'failed', 'command failed');
  } finally { paper.fail = false; }
  assert.match(lastCmd(mc2.id).error, /HTTP 500/);
  const s = get(mc2.id); assert.equal(s.task, null); assert.equal(s.status, 'offline');
  assert.equal(fs.readFileSync(jarPath(mc2), 'utf8'), 'KEEP-ME');                                // untouched
  assert.ok(!fs.existsSync(jarPath(mc2) + '.part'));
  await consoleHas(mc2, /Reinstall failed.*not changed/);
  assert.match(await text(await a.req('/dashboard/activity')), /reinstall failed for Creative/);
  assert.deepEqual((await detail(a, mc2)).allowedActions, ['start', 'reinstall']);               // try again any time
  // a corrupted download (checksum mismatch) must not replace the jar either
  const good = paper.jar; paper.jar = JAR_V2;
  const server = paper.server, orig = server.listeners('request')[0];
  server.removeListener('request', orig);
  server.on('request', (req, res) => { if (req.url === '/dl/paper.jar') { res.writeHead(200); return res.end('tampered'); } return orig(req, res); });
  try {
    assert.equal((await power(a, mc2, { action: 'reinstall', confirm: true })).status, 202);
    await waitFor(() => cmds(mc2.id).filter((c) => c.status === 'failed').length === 2, 'second failure');
  } finally { server.removeAllListeners('request'); server.on('request', orig); paper.jar = good; }
  assert.match(lastCmd(mc2.id).error, /checksum/); assert.equal(fs.readFileSync(jarPath(mc2), 'utf8'), 'KEEP-ME');
});

test('software other than Paper is refused by the runtime without touching any file', async () => {
  const a = await login('alice');
  write(spigot, 'server.jar', 'SPIGOT-JAR');
  assert.equal((await power(a, spigot, { action: 'reinstall', confirm: true })).status, 202);
  await waitFor(() => lastCmd(spigot.id).status === 'failed', 'failed');
  assert.match(lastCmd(spigot.id).error, /only supports Paper/); assert.equal(fs.readFileSync(jarPath(spigot), 'utf8'), 'SPIGOT-JAR');
  assert.equal(get(spigot.id).task, null);
});

test('bots and servers with a custom start command cannot be reinstalled (clear message, nothing queued)', async () => {
  const a = await login('alice');
  let r = await power(a, bot, { action: 'reinstall', confirm: true });
  let j = await r.json();
  assert.equal(r.status, 409); assert.equal(j.code, 'invalid_state'); assert.match(j.error, /is a bot/);
  r = await power(a, custom, { action: 'reinstall', confirm: true }); j = await r.json();
  assert.equal(r.status, 409); assert.match(j.error, /custom start command/);
  assert.equal(cmds(bot.id).length, 0); assert.equal(cmds(custom.id).length, 0);
  assert.equal(get(bot.id).task, null); assert.equal(get(custom.id).task, null);
  for (const s of [bot, custom]) assert.ok(!(await detail(a, s)).allowedActions.includes('reinstall'));
  // the web confirmation page bounces back with the reason instead of offering it
  const c = await a.req(`/dashboard/servers/${custom.identifier}/confirm/reinstall`);
  assert.equal(c.status, 303);
  assert.match(await text(await a.req(`/dashboard/servers/${custom.identifier}`)), /custom start command/);
  // ... and the detail page does not show a Reinstall button for them
  assert.doesNotMatch(await text(await a.req(`/dashboard/servers/${bot.identifier}`)), /confirm\/reinstall/);
});

test('permissions: only the owner and administrators can reinstall; shared users and strangers cannot', async () => {
  const b = await login('bob'), d = await login('dave'), ad = await login('root');
  let r = await power(b, mc, { action: 'reinstall', confirm: true });
  assert.equal(r.status, 403); assert.equal((await r.json()).code, 'forbidden');                 // even with start+stop+restart
  assert.ok(!(await detail(b, mc)).allowedActions.includes('reinstall'));
  assert.ok(!(await detail(b, mc)).permissions.includes('control.reinstall'));
  assert.equal((await power(d, mc, { action: 'reinstall', confirm: true })).status, 404);        // stranger: server "does not exist"
  assert.throws(() => mods.access.grant({ serverId: mc.id, userId: bob.id, permissions: ['control.reinstall'] }), /Unknown permission/);   // cannot be delegated
  assert.equal((await b.req(`/dashboard/servers/${mc.identifier}/confirm/reinstall`)).status, 303);
  assert.doesNotMatch(await text(await b.req(`/dashboard/servers/${mc.identifier}`)), /confirm\/reinstall/);
  assert.equal(get(mc.id).task, null);
  // an administrator may reinstall any server
  r = await power(ad, mc, { action: 'reinstall', confirm: true });
  assert.equal(r.status, 202);
  await waitFor(() => lastCmd(mc.id).status === 'done' && get(mc.id).task === null, 'admin reinstall finished');
  assert.match(mods.activity.recent(alice.id, 20).map((x) => x.message).join('\n'), /Reinstall requested for Survival by root/);
});

test('web UI: buttons on card, list, details and admin list; confirmation page; live "reinstalling" badge', async () => {
  const a = await login('alice'), ad = await login('root');
  const href = `/dashboard/servers/${mc.identifier}/confirm/reinstall`;
  // every place that lists a server offers Reinstall (card: in the "..." menu, the rest: as a button)
  assert.match(await text(await a.req('/dashboard')), new RegExp(href));
  assert.match(await text(await a.req('/dashboard/servers')), new RegExp(href));
  assert.match(await text(await a.req(`/dashboard/servers/${mc.identifier}`)), new RegExp(href));
  assert.match(await text(await ad.req('/admin/servers/mc')), new RegExp(href));
  assert.match(await text(await ad.req('/admin/servers/mc')), /<th>Actions<\/th>/);
  const botHref = `/confirm/reinstall`;
  assert.doesNotMatch(await text(await ad.req('/admin/servers/bots')), new RegExp(botHref));      // bots: Start only
  assert.match(await text(await a.req(`/dashboard/servers/${mc.identifier}/console`)), /mp-btn-reinstall/);   // console header
  assert.doesNotMatch(await text(await a.req(`/dashboard/servers/${bot.identifier}/console`)), /mp-btn-reinstall/);

  const page = await text(await a.req(`${href}?back=${encodeURIComponent('/dashboard/servers')}`));
  assert.match(page, /Reinstall server\?/); assert.match(page, /Your worlds, plugins and settings are kept/); assert.match(page, /Yes, reinstall server/);
  assert.match(page, /Paper 1\.21\.4/);

  // confirm through the form the page submits
  const release = hold();
  const post = await a.post('/dashboard/servers/action', { server_id: String(mc.id), action: 'reinstall', confirm: '1', back: '/dashboard/servers' }, '/dashboard');
  assert.equal(post.status, 303); assert.equal(post.headers.get('location'), '/dashboard/servers');
  const list = await text(await a.req('/dashboard/servers'));
  assert.match(list, new RegExp(`data-identifier="${mc.identifier}" data-status="offline" data-task="reinstall">reinstalling<`));
  const rowHtml = list.split('<tr>').find((r) => r.includes(`data-identifier="${mc.identifier}"`));
  assert.ok(rowHtml); assert.match(rowHtml, /Reinstalling/); assert.doesNotMatch(rowHtml, /mp-btn-(start|stop|restart|reinstall)/);   // no buttons while the job runs
  const card = await text(await a.req('/dashboard'));
  assert.match(card, /Reinstalling/); assert.match(card, new RegExp(`data-identifier="${mc.identifier}" data-status="offline" data-task="reinstall"`));
  assert.match(await text(await a.req(`/dashboard/servers/${mc.identifier}`)), /being reinstalled/);
  // the confirmation page of a busy server bounces back with the reason
  assert.equal((await a.req(href)).status, 303);
  assert.match(await text(await a.req('/dashboard/servers')), /is being reinstalled/);
  release();
  await waitFor(() => get(mc.id).task === null && lastCmd(mc.id).status === 'done', 'finished');
  assert.match(await text(await a.req('/dashboard/servers')), new RegExp(`data-identifier="${mc.identifier}" data-status="offline" data-task=""`));
});

test('real-time stream announces the reinstall and its end (status + task), scoped to the user', async () => {
  const a = await login('alice'), d = await login('dave');
  const open = async (c) => {
    const ac = new AbortController(), res = await c.req('/api/dashboard/events', { signal: ac.signal, headers: { accept: 'text/event-stream' } });
    const st = { text: '', ac }; const dec = new TextDecoder(), reader = res.body.getReader();
    (async () => { try { for (;;) { const { value, done } = await reader.read(); if (done) break; st.text += dec.decode(value); } } catch { /* aborted */ } })();
    return st;
  };
  const sa = await open(a), sd = await open(d);
  await waitFor(() => sa.text.includes('event: snapshot') && sd.text.includes('event: snapshot'), 'snapshots');
  assert.match(sa.text, /"identifier":"[0-9a-f]{8}","status":"offline","task":null/);             // snapshot carries the task too
  const release = hold();
  assert.equal((await power(a, mc, { action: 'reinstall', confirm: true })).status, 202);
  await waitFor(() => new RegExp(`"identifier":"${mc.identifier}","name":"Survival","status":"offline","task":"reinstall"`).test(sa.text), 'reinstalling pushed');
  release();
  await waitFor(() => new RegExp(`"name":"Survival","status":"offline","task":null`).test(sa.text.slice(sa.text.lastIndexOf('"task":"reinstall"'))), 'finished pushed');
  assert.doesNotMatch(sd.text, /Survival/);                                                      // dave never sees alice's servers
  sa.ac.abort(); sd.ac.abort();
  await waitFor(() => mods.events.count(alice.id) === 0 && mods.events.count(dave.id) === 0, 'streams closed');
});

test('the client script treats a finished job as a state change (status + task), so pages refresh when it ends', () => {
  const js = fs.readFileSync(path.join(__dirname, '..', 'public', 'js', 'dashboard.js'), 'utf8');
  assert.match(js, /stateKey\(s\.status, s\.task\)/); assert.match(js, /dataset\.task/);
});

test('a job marker left behind by a dead runtime is cleared on the next runtime start; the new command type is stored', async () => {
  mods.db.prepare("UPDATE servers SET task = 'reinstall' WHERE id = ?").run(mc2.id);
  const s2 = new mods.Supervisor({ dataDir, pollMs: 30 }); s2.start(); await s2.shutdown();
  assert.equal(get(mc2.id).task, null);
  // schema: reinstall is a valid command, anything else still is not (CHECK constraint survived the table rebuild)
  const ins = (c) => mods.db.prepare("INSERT INTO server_commands (server_id, user_id, command, status, created_at) VALUES (?, ?, ?, 'done', ?)").run(mc2.id, alice.id, c, Date.now());
  assert.doesNotThrow(() => ins('reinstall')); assert.throws(() => ins('format-disk'), /CHECK/);
  assert.throws(() => mods.db.prepare("UPDATE servers SET task = 'explode' WHERE id = ?").run(mc2.id), /CHECK/);
});
