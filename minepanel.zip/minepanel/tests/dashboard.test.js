'use strict';
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const runtime = require('../src/dashboard/services/runtime');
const activity = require('../src/dashboard/services/activity');
const db = require('../src/db');

let srv, base, alice, bob, s1, s2, s3, other;
const PW = 'Sup3rSecretPass!';
const text = async (r) => r.text();
const bound = (html, key) => new RegExp(`data-bind="${key}">([^<]*)<`).exec(html)?.[1];

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW);
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: hash });
  bob = users.create({ username: 'bob', email: 'bob@example.com', passwordHash: hash });
  s1 = servers.create({ ownerId: alice.id, name: 'Survival', ramLimitMb: 4096, cpuLimitPct: 200, diskLimitMb: 20480, playersMax: 30, address: 'play.example.com:25565' });
  s2 = servers.create({ ownerId: alice.id, name: 'Creative', ramLimitMb: 2048, playersMax: 20 });
  s3 = servers.create({ ownerId: alice.id, name: 'Skyblock', ramLimitMb: 1024, playersMax: 10 });
  other = servers.create({ ownerId: bob.id, name: 'BobsPrivate' });
  runtime.reportStatus(s1.id, { status: 'online', cpuUsedPct: 50, ramUsedMb: 1536, diskUsedMb: 3000, playersOnline: 7 });
  runtime.reportStatus(s3.id, { status: 'crashed', diskUsedMb: 500 });
});
after(() => srv.close());

test('dashboard requires auth', async () => {
  const c = client(base);
  const r = await c.req('/dashboard');
  assert.equal(r.status, 303);
  assert.match(r.headers.get('location'), /^\/login/);
  assert.equal((await c.req('/api/dashboard/summary', { headers: { accept: 'application/json' } })).status, 401);
});

test('login lands on the dashboard; server cards come from the database', async () => {
  const c = client(base);
  const login = await c.login('alice', PW);
  assert.equal(login.headers.get('location'), '/dashboard');
  const html = await text(await c.req('/dashboard'));
  assert.equal((html.match(/<article class="mp-srv">/g) || []).length, 3);
  assert.equal((html.match(/data-status="online"/g) || []).length, 1);
  assert.equal((html.match(/data-status="(offline|crashed)"/g) || []).length, 2);   // offline + crashed
  assert.match(html, /Survival/); assert.match(html, /Creative/);
  assert.doesNotMatch(html, /BobsPrivate/);              // isolation between users
  assert.match(await text(await c.req('/dashboard/activity')), /Survival is now online/);   // real activity from status change
  assert.match(await text(await c.req('/dashboard/profile')), /alice@example\.com/);
});

test('empty account shows an empty state (no dummy data)', async () => {
  users.create({ username: 'newbie', email: 'new@example.com', passwordHash: await hashPassword(PW) });
  const c = client(base); await c.login('newbie', PW);
  const html = await text(await c.req('/dashboard'));
  assert.doesNotMatch(html, /<article class="mp-srv">/);
  assert.match(html, /No servers found/);
  assert.match(await text(await c.req('/dashboard/activity')), /No activity yet/);
});
test('JSON summary endpoint', async () => {
  const c = client(base); await c.login('alice', PW);
  const j = await (await c.req('/api/dashboard/summary', { headers: { accept: 'application/json' } })).json();
  assert.equal(j.summary.total, 3); assert.equal(j.summary.online, 1);
  assert.deepEqual(j.servers.find((s) => s.id === s1.id), { id: s1.id, status: 'online' });
  assert.ok(!j.servers.some((s) => s.id === other.id));
});

test('quick actions: validated, owned, queued, logged', async () => {
  const c = client(base); await c.login('alice', PW);
  const act = (id, action) => c.post('/dashboard/servers/action', { server_id: id, action, back: '/dashboard/servers' }, '/dashboard/servers');

  // start on an offline server -> queued + 'starting'
  let r = await act(s2.id, 'start');
  assert.equal(r.status, 303); assert.equal(r.headers.get('location'), '/dashboard/servers');
  assert.equal(servers.getForOwner(alice.id, s2.id).status, 'starting');
  const cmd = db.prepare("SELECT * FROM server_commands WHERE server_id = ?").get(s2.id);
  assert.equal(cmd.command, 'start'); assert.equal(cmd.status, 'pending'); assert.equal(cmd.user_id, alice.id);

  // duplicate while pending, and invalid transition
  let page = await text(await c.req('/dashboard/servers'));
  assert.match(page, /Start requested for Creative|Start command sent to Creative/);
  await act(s2.id, 'start');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM server_commands WHERE server_id = ?").get(s2.id).n, 1);
  await act(s1.id, 'start');                              // already online
  assert.equal(db.prepare("SELECT COUNT(*) n FROM server_commands WHERE server_id = ?").get(s1.id).n, 0);

  // another user's server cannot be controlled
  await act(other.id, 'stop');
  assert.equal(servers.getForOwner(bob.id, other.id).status, 'offline');
  assert.equal(db.prepare("SELECT COUNT(*) n FROM server_commands WHERE server_id = ?").get(other.id).n, 0);

  // stop + restart on online server
  r = await act(s1.id, 'restart');                         // without confirmation nothing happens: redirected to the confirm page
  assert.match(r.headers.get('location'), /^\/dashboard\/servers\/[0-9a-f]{8}\/confirm\/restart/);
  assert.equal(servers.getForOwner(alice.id, s1.id).status, 'online');
  await c.post('/dashboard/servers/action', { server_id: s1.id, action: 'restart', confirm: '1', back: '/dashboard/servers' }, '/dashboard/servers');
  assert.equal(servers.getForOwner(alice.id, s1.id).status, 'stopping');

  // CSRF is enforced
  const noCsrf = await c.req('/dashboard/servers/action', { method: 'POST', form: { server_id: s3.id, action: 'start' } });
  assert.equal(noCsrf.status, 403);

  // runtime completes/fails commands and reports back
  assert.ok(runtime.pendingCommands().length >= 2);
  runtime.completeCommand(cmd.id, { ok: false, error: 'port in use' });
  assert.equal(servers.getForOwner(alice.id, s2.id).status, 'crashed');
  const log = activity.recent(alice.id, 50).map((a) => a.message).join('\n');
  assert.match(log, /Start requested for Creative/); assert.match(log, /start failed for Creative: port in use/);
});

test('activity page paginates and profile page renders', async () => {
  const c = client(base); await c.login('alice', PW);
  assert.equal((await c.req('/dashboard/activity?page=999')).status, 200);
  const p = await text(await c.req('/dashboard/profile'));
  assert.match(p, /alice@example\.com/); assert.match(p, /Member since/);
});

test('settings: profile update needs current password and unique values', async () => {
  const c = client(base); await c.login('alice', PW);
  const S = '/dashboard/settings';
  let r = await c.post(`${S}/profile`, { username: 'alice2', email: 'alice@example.com', current_password: 'wrong-password1' }, S);
  assert.equal(r.status, 422); assert.match(await text(r), /Incorrect password/);
  r = await c.post(`${S}/profile`, { username: 'bob', email: 'alice@example.com', current_password: PW }, S);
  assert.equal(r.status, 422); assert.match(await text(r), /already taken/);
  r = await c.post(`${S}/profile`, { username: 'alice2', email: 'Alice.New@example.com', current_password: PW }, S);
  assert.equal(r.status, 303);
  const u = users.findById(alice.id);
  assert.equal(u.username, 'alice2'); assert.equal(u.email, 'alice.new@example.com');
  assert.match(await text(await c.req(S)), /Profile updated/);
  assert.match(activity.recent(alice.id, 20).map((a) => a.message).join('|'), /Profile details updated/);
  users.setPassword; // restore names for later tests
  db.prepare('UPDATE users SET username = ?, email = ? WHERE id = ?').run('alice', 'alice@example.com', alice.id);
});

test('settings: change password signs out other devices, keeps this one', async () => {
  const a = client(base), b = client(base);
  await a.login('alice', PW); await b.login('alice', PW);
  const S = '/dashboard/settings';
  assert.match(await text(await a.req(S)), /Active sessions/);
  let r = await a.post(`${S}/password`, { current_password: 'nope-nope-12', password: 'N3wSecretPass!!', confirm: 'N3wSecretPass!!' }, S);
  assert.equal(r.status, 422);
  r = await a.post(`${S}/password`, { current_password: PW, password: 'weak', confirm: 'weak' }, S);
  assert.equal(r.status, 422);
  r = await a.post(`${S}/password`, { current_password: PW, password: 'N3wSecretPass!!', confirm: 'N3wSecretPass!!' }, S);
  assert.equal(r.status, 303);
  assert.equal((await a.req('/dashboard')).status, 200);   // current session survives
  assert.equal((await b.req('/dashboard')).status, 303);   // other device signed out
  assert.equal((await client(base).login('alice', PW)).status, 401);
  assert.equal((await client(base).login('alice', 'N3wSecretPass!!')).status, 303);
});

test('settings: revoke a specific session and all others', async () => {
  const PW2 = 'N3wSecretPass!!';
  const a = client(base), b = client(base), c2 = client(base);
  await a.login('alice', PW2); await b.login('alice', PW2); await c2.login('alice', PW2);
  const html = await text(await a.req('/dashboard/settings'));
  const ids = [...html.matchAll(/name="session_id" value="([0-9a-f]{64})"/g)].map((m) => m[1]);
  assert.ok(ids.length >= 2);
  // cannot revoke someone else's session by id
  const bobC = client(base); await bobC.login('bob', PW);
  const bobSession = db.prepare('SELECT id FROM sessions WHERE user_id = ?').get(bob.id).id;
  await a.post('/dashboard/settings/sessions/revoke', { session_id: bobSession }, '/dashboard/settings');
  assert.equal((await bobC.req('/dashboard')).status, 200);
  // revoke all others
  await a.post('/dashboard/settings/sessions/revoke-others', {}, '/dashboard/settings');
  assert.equal((await a.req('/dashboard')).status, 200);
  assert.equal((await b.req('/dashboard')).status, 303);
  assert.equal((await c2.req('/dashboard')).status, 303);
});

test('CSP-safe: no inline styles or scripts in dashboard HTML', async () => {
  const c = client(base); await c.login('alice', PW2());
  function PW2() { return 'N3wSecretPass!!'; }
  const html = await text(await c.req('/dashboard'));
  assert.doesNotMatch(html, /\sstyle=|<script>(?!<)/);
});
