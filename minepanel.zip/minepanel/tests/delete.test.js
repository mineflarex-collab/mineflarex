'use strict';
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.VPS_RAM_MB = '1048576'; process.env.VPS_CPU_CORES = '1000'; process.env.VPS_DISK_MB = '10485760';
process.env.MAIL_QUIET = 'true';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const db = require('../src/db');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const deletion = require('../src/dashboard/services/deletion');
const runtimeConfig = require('../src/runtime/config');

let srv, base, admin, c;
const PW = 'Sup3rSecretPass!';
const dirOf = (s) => path.join(runtimeConfig.dataDir, s.identifier);
const make = (name, kind = 'mc') => {
  const s = servers.create({ ownerId: admin.id, name, kind, runtime: kind === 'bot' ? 'python' : null });
  fs.mkdirSync(dirOf(s), { recursive: true }); fs.writeFileSync(path.join(dirOf(s), 'data.txt'), 'hello');
  return s;
};
const exists = (s) => !!db.prepare('SELECT 1 FROM servers WHERE id = ?').get(s.id);
const setStatus = (s, status) => db.prepare('UPDATE servers SET status = ? WHERE id = ?').run(status, s.id);

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  admin = users.create({ username: 'root-admin', email: 'root@example.com', passwordHash: await hashPassword(PW), role: 'admin' });
  c = client(base); await c.login('root-admin', PW);
});
after(() => srv.close());

test('edit page: three delete options (Delete, Safe delete, Force delete)', async () => {
  const s = make('EditMe');
  const html = await (await c.req(`/admin/servers/${s.identifier}/edit`)).text();
  assert.match(html, new RegExp(`action="/admin/servers/${s.identifier}/delete"`));
  for (const v of ['delete', 'safe', 'force']) assert.match(html, new RegExp(`name="mode" value="${v}"`));
  for (const t of ['Delete</button>', 'Safe delete</button>', 'Force delete</button>']) assert.ok(html.includes(t), t);
});

test('Delete: refuses a running server, erases the files of a stopped one', async () => {
  const s = make('PlainDelete'); setStatus(s, 'online');
  let r = await c.post(`/admin/servers/${s.identifier}/delete`, { mode: 'delete' }, `/admin/servers/${s.identifier}/edit`);
  assert.equal(r.status, 303); assert.ok(exists(s)); assert.ok(fs.existsSync(dirOf(s)));
  setStatus(s, 'offline');
  r = await c.post(`/admin/servers/${s.identifier}/delete`, { mode: 'delete' }, `/admin/servers/${s.identifier}/edit`);
  assert.equal(r.status, 303); assert.ok(!exists(s)); assert.ok(!fs.existsSync(dirOf(s)));
});

test('Safe delete: a stopped server is removed and its files are moved to the deleted folder, not erased', async () => {
  const s = make('SafeOne', 'bot');
  const r = await c.post(`/admin/servers/${s.identifier}/delete`, { mode: 'safe' }, `/admin/servers/${s.identifier}/edit`);
  assert.equal(r.status, 303); assert.ok(!exists(s)); assert.ok(!fs.existsSync(dirOf(s)));
  const trash = path.join(path.dirname(path.resolve(runtimeConfig.dataDir)), 'deleted');
  const kept = fs.readdirSync(trash).filter((n) => n.startsWith(`${s.identifier}-`));
  assert.equal(kept.length, 1); assert.equal(fs.readFileSync(path.join(trash, kept[0], 'data.txt'), 'utf8'), 'hello');
});

test('Safe delete: a server that does not stop in time is kept untouched', async () => {
  const s = make('Stubborn'); setStatus(s, 'online');
  await assert.rejects(deletion.deleteServer({ user: admin, server: s, mode: 'safe', stopWaitMs: 400 }), deletion.DeleteError);
  assert.ok(exists(s)); assert.ok(fs.existsSync(dirOf(s)));
});

test('Force delete: kills (force_stop is queued), then erases the files and the record even if the runtime is slow', async () => {
  const s = make('ForceMe'); setStatus(s, 'online');
  const r = await deletion.deleteServer({ user: admin, server: s, mode: 'force', killWaitMs: 400 });
  assert.ok(r.ok); assert.ok(!exists(s)); assert.ok(!fs.existsSync(dirOf(s)));
});

test('unknown mode and unknown server are rejected', async () => {
  const s = make('Odd');
  await assert.rejects(deletion.deleteServer({ user: admin, server: s, mode: 'nuke' }), deletion.DeleteError);
  const r = await c.post('/admin/servers/nope1234/delete', { mode: 'delete' }, `/admin/servers/${s.identifier}/edit`);
  assert.equal(r.status, 404);
});
