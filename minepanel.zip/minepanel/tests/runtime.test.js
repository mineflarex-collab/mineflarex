'use strict';
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';
process.env.SESSION_SECRET = 'must-not-leak-into-game-processes';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const users = require('../src/services/users');
const servers = require('../src/dashboard/services/servers');
const activity = require('../src/dashboard/services/activity');
const db = require('../src/db');
const { Supervisor, tokenize } = require('../src/runtime/supervisor');

const FIXTURE = path.join(__dirname, 'fixtures', 'fake-mc.js');
const cmd = (extra = '') => `node "${FIXTURE}" ${extra}`;
let sup, alice, dataDir;
const get = (id) => db.prepare('SELECT * FROM servers WHERE id = ?').get(id);
const lastCmd = (id) => db.prepare('SELECT * FROM server_commands WHERE server_id = ? ORDER BY id DESC').get(id);
const act = (s, action) => servers.requestCommand(alice, s.id, action, '127.0.0.1', { confirmed: true });
const alive = (pid) => { try { process.kill(pid, 0); return true; } catch { return false; } };
async function waitFor(fn, what, ms = 10000) {
  const t = Date.now();
  while (Date.now() - t < ms) { const v = fn(); if (v) return v; await new Promise((r) => setTimeout(r, 40)); }
  assert.fail(`timed out waiting for: ${what}`);
}
const mk = (name, command, extra = {}) => servers.create({ ownerId: alice.id, name, startCommand: command, ramLimitMb: 512, ...extra });
const pidOf = (s) => sup.entries.get(s.id).proc.pid;

before(() => {
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-rt-'));
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: 'x' });
  sup = new Supervisor({ dataDir, pollMs: 40, metricsMs: 150, startTimeoutMs: 4000, stopTimeoutMs: 1500, killTimeoutMs: 800 });
  sup.start();
});
after(async () => { await sup.shutdown(); fs.rmSync(dataDir, { recursive: true, force: true }); });

test('tokenizer: quotes, no shell, errors', () => {
  assert.deepEqual(tokenize('java -Xmx512M -jar "my server.jar" nogui'), ['java', '-Xmx512M', '-jar', 'my server.jar', 'nogui']);
  assert.deepEqual(tokenize("a 'b c' d"), ['a', 'b c', 'd']);
  assert.throws(() => tokenize('a "b'), /Unterminated/); assert.throws(() => tokenize('   '), /empty/);
});

test('start: a real process is spawned, status goes starting -> online, real usage is reported', async () => {
  const s = mk('Real', cmd());
  const r = act(s, 'start'); assert.equal(r.ok, true);
  assert.equal(get(s.id).status, 'starting');
  await waitFor(() => get(s.id).status === 'online', 'online');
  const pid = pidOf(s);
  assert.ok(alive(pid), 'the server process really exists');
  assert.equal(lastCmd(s.id).status, 'done');
  assert.ok(get(s.id).started_at > 0);
  const row = await waitFor(() => { const x = get(s.id); return x.ram_used_mb > 20 && x.disk_used_mb >= 2 ? x : null; }, 'real RAM + disk numbers');
  assert.ok(row.ram_used_mb < 400, `RSS ${row.ram_used_mb} MB is a real, plausible value`);
  assert.ok(fs.existsSync(path.join(dataDir, s.identifier, 'world.dat')), 'runs inside <dataDir>/<identifier>');
  assert.match(activity.recent(alice.id, 50).map((a) => a.message).join('\n'), /Real is now online/);
});

test('players are counted from the real console output', async () => {
  const s = mk('Players', cmd());
  act(s, 'start'); await waitFor(() => get(s.id).status === 'online', 'online');
  const stdin = sup.entries.get(s.id).proc.stdin;
  stdin.write('join Steve\njoin Alex\nleave Steve\n');
  await waitFor(() => get(s.id).players_online === 1, '1 player online');
});

test('stop: graceful console stop, process really ends, status offline, command done', async () => {
  const s = mk('Stopper', cmd());
  act(s, 'start'); await waitFor(() => get(s.id).status === 'online', 'online');
  const pid = pidOf(s);
  assert.equal(act(s, 'stop').ok, true); assert.equal(get(s.id).status, 'stopping');
  await waitFor(() => get(s.id).status === 'offline' && lastCmd(s.id).status === 'done', 'offline');
  await waitFor(() => !alive(pid), 'process gone');
  assert.equal(get(s.id).ram_used_mb, 0); assert.ok(get(s.id).disk_used_mb >= 2);
});

test('restart: old process ends, a NEW process starts, status passes through starting', async () => {
  const s = mk('Restarter', cmd('--delay 400'));
  act(s, 'start'); await waitFor(() => get(s.id).status === 'online', 'online');
  const oldPid = pidOf(s), seen = new Set();
  assert.equal(act(s, 'restart').ok, true);
  const t = Date.now();
  while (Date.now() - t < 10000 && !(get(s.id).status === 'online' && sup.entries.get(s.id) && pidOf(s) !== oldPid)) { seen.add(get(s.id).status); await new Promise((r) => setTimeout(r, 20)); }
  assert.ok(seen.has('stopping') || seen.has('starting')); assert.ok(!seen.has('offline'), 'no bogus offline flicker during restart');
  assert.notEqual(pidOf(s), oldPid); assert.ok(!alive(oldPid)); assert.ok(alive(pidOf(s)));
  await waitFor(() => lastCmd(s.id).status === 'done', 'restart command done');
});

test('crash: unexpected exit is detected and reported as crashed', async () => {
  const s = mk('Crasher', cmd());
  act(s, 'start'); await waitFor(() => get(s.id).status === 'online', 'online');
  sup.entries.get(s.id).proc.stdin.write('crash\n');
  await waitFor(() => get(s.id).status === 'crashed', 'crashed');
  assert.match(activity.recent(alice.id, 50).map((a) => a.message).join('\n'), /Crasher crashed/);
  assert.deepEqual(servers.allowedActions('crashed'), ['start', 'reinstall']);   // state rules only; Reinstall is further limited to stock Paper servers (see reinstall.test.js)
  act(s, 'start'); await waitFor(() => get(s.id).status === 'online', 'can start again after crash');   // recoverable
});

test('start failures report the real reason', async () => {
  const bad = mk('ExitsEarly', `node -e "console.log('boom: bad config'); process.exit(3)"`);
  act(bad, 'start');
  await waitFor(() => lastCmd(bad.id).status === 'failed', 'failed');
  assert.equal(get(bad.id).status, 'crashed'); assert.match(lastCmd(bad.id).error, /code 3.*boom: bad config/);
  const missing = mk('NoBinary', 'definitely-not-a-real-binary --x');
  act(missing, 'start');
  await waitFor(() => lastCmd(missing.id).status === 'failed', 'failed');
  assert.match(lastCmd(missing.id).error, /not found/); assert.equal(get(missing.id).status, 'crashed');
});

test('stop while still starting cancels the startup and ends offline', async () => {
  const s = mk('Slow', cmd('--delay 6000'));
  act(s, 'start'); await waitFor(() => sup.entries.get(s.id)?.proc, 'process spawned');
  const pid = pidOf(s);
  const r = act(s, 'stop'); assert.equal(r.ok, true, r.message);
  await waitFor(() => get(s.id).status === 'offline' && !sup.entries.has(s.id), 'offline');
  await waitFor(() => db.prepare("SELECT COUNT(*) n FROM server_commands WHERE server_id = ? AND status = 'pending'").get(s.id).n === 0, 'no pending commands');
  assert.ok(!alive(pid));
  const cmds = db.prepare('SELECT command, status, error FROM server_commands WHERE server_id = ? ORDER BY id').all(s.id);
  assert.deepEqual(cmds.map((c) => [c.command, c.status]), [['start', 'failed'], ['stop', 'done']]);
  assert.match(cmds[0].error, /Cancelled/);
});

test('a server that ignores the stop command is terminated (SIGTERM, then SIGKILL)', async () => {
  const s = mk('Stubborn', cmd('--ignore-stop'));
  act(s, 'start'); await waitFor(() => get(s.id).status === 'online', 'online');
  const pid = pidOf(s); act(s, 'stop');
  await waitFor(() => get(s.id).status === 'offline', 'offline after SIGTERM', 8000); assert.ok(!alive(pid));
  const h = mk('Harder', cmd('--ignore-stop --ignore-term'));
  act(h, 'start'); await waitFor(() => get(h.id).status === 'online', 'online');
  const pid2 = pidOf(h); act(h, 'stop');
  await waitFor(() => get(h.id).status === 'offline', 'offline after SIGKILL', 10000); assert.ok(!alive(pid2));
});

test('game processes do not inherit panel secrets', async () => {
  const s = mk('EnvCheck', cmd('--dump-env'));
  act(s, 'start'); await waitFor(() => get(s.id).status === 'online', 'online');
  const env = JSON.parse(fs.readFileSync(path.join(dataDir, s.identifier, 'env.json'), 'utf8'));
  assert.ok(env.PATH); assert.equal(env.SESSION_SECRET, undefined); assert.equal(env.HOME, path.join(dataDir, s.identifier));
});

test('placeholders and the default command use the real allocation', async () => {
  const s = mk('Placeholders', `node "${FIXTURE}" --ignore-ram {{RAM_MB}} {{HEAP_MB}} {{DIR}}`, { ramLimitMb: 1000 });
  act(s, 'start'); await waitFor(() => sup.entries.get(s.id)?.tokens, 'spawned');
  const t = sup.entries.get(s.id).tokens;
  assert.equal(t[3], '1000'); assert.equal(t[4], '750'); assert.equal(t[5], path.join(dataDir, s.identifier));
});

test('reconcile: servers recorded as running with no process are corrected on runtime start; shutdown stops real servers', async () => {
  const ghost = mk('Ghost', cmd()); db.prepare("UPDATE servers SET status = 'online' WHERE id = ?").run(ghost.id);
  const sup2 = new Supervisor({ dataDir: fs.mkdtempSync(path.join(os.tmpdir(), 'mp-rt2-')), pollMs: 40 });
  sup2.start(); assert.equal(get(ghost.id).status, 'offline'); await sup2.shutdown();
  const live = mk('ShutdownMe', cmd());
  act(live, 'start'); await waitFor(() => get(live.id).status === 'online', 'online');
  const pid = pidOf(live), sup3 = sup;
  await sup3.shutdown();
  assert.ok(!alive(pid)); assert.equal(get(live.id).status, 'offline');
});

// The shared supervisor was shut down by the test above, so the Bot Host tests run their own.
async function withBotRuntime(fn) {
  const rt = new Supervisor({ dataDir, pollMs: 40, metricsMs: 150, startTimeoutMs: 4000, stopTimeoutMs: 1500, killTimeoutMs: 800, botReadyMs: 300, botStopTimeoutMs: 1500 });
  rt.start();
  try { await fn(rt); } finally { await rt.shutdown(); }
}
const mkBot = (name, script) => {
  const s = servers.create({ ownerId: alice.id, name, kind: 'bot', runtime: 'nodejs', startCommand: 'node bot.js', ramLimitMb: 512 });
  const dir = path.join(dataDir, s.identifier); fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'bot.js'), script);
  return s;
};

test('Bot Host: a bot counts as online once its process stays alive, and is stopped with SIGTERM', () => withBotRuntime(async (rt) => {
  // no "Done!" line, no console stop command: it just runs until it receives SIGTERM
  const s = mkBot('RealBot', "console.log('bot logged in'); setInterval(() => {}, 1000); process.on('SIGTERM', () => { console.log('bye'); process.exit(0); });\n");
  assert.equal(act(s, 'start').ok, true);
  await waitFor(() => get(s.id).status === 'online', 'bot online');
  const pid = rt.entries.get(s.id).proc.pid;
  assert.ok(alive(pid), 'the bot process really exists');
  assert.equal(lastCmd(s.id).status, 'done');
  assert.equal(act(s, 'stop').ok, true);
  await waitFor(() => get(s.id).status === 'offline', 'bot offline');
  await waitFor(() => !alive(pid), 'bot process gone');
  const lines = () => db.prepare('SELECT line FROM console_lines WHERE server_id = ?').all(s.id).map((r) => r.line).join('\n');
  await waitFor(() => /bye/.test(lines()), 'console flushed');           // console lines are written to the database in batches
  assert.match(lines(), /bot logged in/); assert.match(lines(), /Stopping bot/);
}));

test('Bot Host: a bot that dies right away is reported as a failed start', () => withBotRuntime(async () => {
  const s = mkBot('DeadBot', "console.error('token missing'); process.exit(1);\n");
  assert.equal(act(s, 'start').ok, true);
  await waitFor(() => lastCmd(s.id).status === 'failed', 'failed start');
  assert.match(lastCmd(s.id).error, /token missing/);
  assert.notEqual(get(s.id).status, 'online');
}));

test('force restart kills the process at once and starts a new one; force stop leaves it offline; force start works from offline', async () => {
  const rt = new Supervisor({ dataDir, pollMs: 40, metricsMs: 150, startTimeoutMs: 4000, stopTimeoutMs: 1500, killTimeoutMs: 800 });
  rt.start();
  const pid = (s) => rt.entries.get(s.id).proc.pid, force = (s, a) => servers.requestForce(alice, s.id, a, '127.0.0.1');
  try {
    const s = mk('Forced', cmd());
    assert.equal(act(s, 'start').ok, true);
    await waitFor(() => get(s.id).status === 'online' && rt.entries.get(s.id), 'online');
    const oldPid = pid(s);
    assert.equal(force(s, 'force_restart').ok, true);
    await waitFor(() => get(s.id).status === 'online' && rt.entries.get(s.id) && pid(s) !== oldPid, 'new process after force restart');
    assert.ok(!alive(oldPid), 'old process was killed');
    const pid2 = pid(s);
    assert.equal(force(s, 'force_stop').ok, true);
    await waitFor(() => get(s.id).status === 'offline' && !alive(pid2), 'offline after force stop');
    assert.equal(force(s, 'force_start').ok, true);
    await waitFor(() => get(s.id).status === 'online' && rt.entries.get(s.id), 'online after force start');
    assert.equal(force(s, 'bogus').ok, false);
    assert.equal(force(s, 'force_stop').ok, true);
    await waitFor(() => get(s.id).status === 'offline', 'offline again');
  } finally { await rt.shutdown(); }
});
