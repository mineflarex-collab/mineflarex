'use strict';
// Separate file (= separate process and database): starting a Supervisor reconciles the whole database,
// which would disturb the supervisor used by console.test.js.
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const users = require('../src/services/users');
const servers = require('../src/dashboard/services/servers');
const store = require('../src/dashboard/services/serverConsole');
const db = require('../src/db');
const { Supervisor } = require('../src/runtime/supervisor');

test('commands queued while no runtime was running are failed on start, never replayed later', async () => {
  const alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: 'x' });
  const s = servers.create({ ownerId: alice.id, name: 'S' });
  const id = store.enqueueInput({ serverId: s.id, user: alice, command: 'op alice' });
  const sup = new Supervisor({ dataDir: require('node:os').tmpdir() + '/mp-rt-stale', pollMs: 40, consoleInputMs: 30 });
  sup.start();
  const row = db.prepare('SELECT * FROM console_input WHERE id = ?').get(id);
  assert.equal(row.status, 'failed'); assert.match(row.error, /not running/);
  await sup.shutdown();
});

test('a command for a server with no live process is reported in the console, not lost', async () => {
  const alice = users.findByEmail('alice@example.com'), s = db.prepare('SELECT * FROM servers').get();
  const sup = new Supervisor({ dataDir: require('node:os').tmpdir() + '/mp-rt-stale', pollMs: 40, consoleInputMs: 20, consoleFlushMs: 20 });
  sup.start();
  const id = store.enqueueInput({ serverId: s.id, user: alice, command: 'say hello' });
  const t = Date.now();
  while (Date.now() - t < 3000 && db.prepare('SELECT status FROM console_input WHERE id = ?').get(id).status === 'pending') await new Promise((r) => setTimeout(r, 20));
  assert.equal(db.prepare('SELECT status FROM console_input WHERE id = ?').get(id).status, 'failed');
  await new Promise((r) => setTimeout(r, 100));
  assert.match(store.tail(s.id, 5).map((l) => l.line).join('\n'), /Command not sent \(the server is not running\): say hello/);
  await sup.shutdown();
});
