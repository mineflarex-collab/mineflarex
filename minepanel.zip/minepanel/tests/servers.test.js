'use strict';
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const nodes = require('../src/dashboard/services/nodes');
const runtime = require('../src/dashboard/services/runtime');
const db = require('../src/db');

let srv, base, alice, bob, carol, admin, nFra, nNyc, a1, a2, a3, a4, bobs;
const PW = 'Sup3rSecretPass!';
const text = (r) => r.text();
const json = (c, path) => c.req(path, { headers: { accept: 'application/json' } }).then((r) => r.json());
// Names shown in the table rows, in order (server name is the first <strong> in each row's first cell)
const names = (html) => [...html.matchAll(/<tr>\s*<td><a href="\/dashboard\/servers\/[0-9a-f]{8}"><strong>([^<]*)<\/strong>/g)].map((m) => m[1]);

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW);
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: hash });
  bob = users.create({ username: 'bob', email: 'bob@example.com', passwordHash: hash });
  carol = users.create({ username: 'carol', email: 'carol@example.com', passwordHash: hash });
  admin = users.create({ username: 'root', email: 'root@example.com', passwordHash: hash, role: 'admin' });

  nFra = nodes.create({ name: 'Frankfurt-1', location: 'Frankfurt, DE', fqdn: 'fra1.internal.example', ramTotalMb: 65536, cpuTotalPct: 1600, diskTotalMb: 1048576 });
  nNyc = nodes.create({ name: 'NYC-1', location: 'New York, US', fqdn: 'nyc1.internal.example', status: 'maintenance' });

  a1 = servers.create({ ownerId: alice.id, name: 'Survival', software: 'paper', version: '1.21.4', ramLimitMb: 4096, cpuLimitPct: 200, diskLimitMb: 20480, playersMax: 30, address: 'play.example.com:25565', nodeId: nFra.id });
  a2 = servers.create({ ownerId: alice.id, name: 'Creative', software: 'purpur', version: '1.21.4', ramLimitMb: 2048, nodeId: nNyc.id });
  a3 = servers.create({ ownerId: alice.id, name: 'Skyblock', software: 'paper', ramLimitMb: 1024, address: 'sky.example.com:25566', nodeId: nFra.id });
  a4 = servers.create({ ownerId: alice.id, name: 'Lobby_100%', software: 'velocity', ramLimitMb: 512 });   // no node; name contains LIKE wildcards
  bobs = servers.create({ ownerId: bob.id, name: 'BobsPrivate', address: 'bob.example.com:1', nodeId: nFra.id });
  runtime.reportStatus(a1.id, { status: 'online', cpuUsedPct: 50, ramUsedMb: 1536, diskUsedMb: 3000, playersOnline: 7 });
  runtime.reportStatus(a3.id, { status: 'crashed', diskUsedMb: 500 });
  // 45 servers for pagination / sorting
  for (let i = 1; i <= 45; i++) servers.create({ ownerId: carol.id, name: `Srv-${String(i).padStart(2, '0')}`, ramLimitMb: 256 * i, nodeId: i % 2 ? nFra.id : nNyc.id });
});
after(() => srv.close());

test('identifiers are generated: 8 hex chars, unique, stored in the database', () => {
  const ids = db.prepare('SELECT identifier FROM servers').all().map((r) => r.identifier);
  assert.equal(new Set(ids).size, ids.length);
  assert.ok(ids.every((i) => /^[0-9a-f]{8}$/.test(i)));
  assert.match(a1.identifier, /^[0-9a-f]{8}$/);
});

test('list requires auth', async () => {
  const c = client(base);
  assert.equal((await c.req('/dashboard/servers')).status, 303);
  assert.equal((await c.req(`/dashboard/servers/${a1.identifier}`)).status, 303);
  assert.equal((await c.req('/api/dashboard/servers', { headers: { accept: 'application/json' } })).status, 401);
});

test('list shows name, identifier, status, RAM/CPU/disk allocation and node, only for the signed-in user', async () => {
  const c = client(base); await c.login('alice', PW);
  const html = await text(await c.req('/dashboard/servers'));
  assert.deepEqual(names(html), ['Creative', 'Lobby_100%', 'Skyblock', 'Survival']);
  assert.match(html, new RegExp(`<code>${a1.identifier}</code>`));
  assert.match(html, /mp-badge-online[^>]*>online</); assert.match(html, />crashed</); assert.match(html, />offline</);
  assert.match(html, /<strong>4 GB<\/strong>/);           // RAM allocation
  assert.match(html, /<strong>2 cores<\/strong>/);        // CPU allocation
  assert.match(html, /<strong>20 GB<\/strong>/);          // disk allocation
  assert.match(html, /1\.5 GB in use/); assert.match(html, /0\.5 cores in use/);
  assert.match(html, /Frankfurt-1/); assert.match(html, /Frankfurt, DE/);
  assert.match(html, /NYC-1/); assert.match(html, /mp-badge-maintenance[^>]*>maintenance</);
  assert.match(html, /Unassigned/);
  assert.match(html, /Showing 1&ndash;4 of 4 servers/);
  assert.doesNotMatch(html, /BobsPrivate|Srv-01/);
  assert.doesNotMatch(html, /fra1\.internal\.example/);   // node hostnames are not shown to regular users
});

test('search: name, identifier, address, node, software; case-insensitive; wildcards are literal', async () => {
  const c = client(base); await c.login('alice', PW);
  const q = async (s) => names(await text(await c.req(`/dashboard/servers?q=${encodeURIComponent(s)}`)));
  assert.deepEqual(await q('surv'), ['Survival']);
  assert.deepEqual(await q('SKYBLOCK'), ['Skyblock']);
  assert.deepEqual(await q(a2.identifier), ['Creative']);
  assert.deepEqual(await q(a2.identifier.toUpperCase()), ['Creative']);
  assert.deepEqual(await q('play.example.com'), ['Survival']);
  assert.deepEqual(await q('nyc-1'), ['Creative']);
  assert.deepEqual(await q('frankfurt'), ['Skyblock', 'Survival']);
  assert.deepEqual(await q('purpur'), ['Creative']);
  assert.deepEqual(await q('%'), ['Lobby_100%']);          // literal %, not "match everything"
  assert.deepEqual(await q('_'), ['Lobby_100%']);          // literal _, not "any character"
  assert.deepEqual(await q('bob'), []);                    // other users' servers never match
  const none = await text(await c.req('/dashboard/servers?q=zzzz'));
  assert.match(none, /No servers match your search or filters/);
  assert.match(await text(await c.req('/dashboard/servers?q=surv')), /value="surv"/);
});

test('filters: status, node, unassigned, software, combined with search; status chips carry counts', async () => {
  const c = client(base); await c.login('alice', PW);
  const list = async (qs) => names(await text(await c.req(`/dashboard/servers?${qs}`)));
  assert.deepEqual(await list('status=online'), ['Survival']);
  assert.deepEqual(await list('status=crashed'), ['Skyblock']);
  assert.deepEqual(await list('status=offline'), ['Creative', 'Lobby_100%']);
  assert.deepEqual(await list(`node=${nFra.id}`), ['Skyblock', 'Survival']);
  assert.deepEqual(await list('node=none'), ['Lobby_100%']);
  assert.deepEqual(await list('software=PAPER'), ['Skyblock', 'Survival']);
  assert.deepEqual(await list(`node=${nFra.id}&status=crashed`), ['Skyblock']);
  assert.deepEqual(await list(`node=${nFra.id}&q=sky&software=paper`), ['Skyblock']);
  assert.deepEqual(await list('status=bogus&node=abc&sort=evil;DROP TABLE servers'), ['Creative', 'Lobby_100%', 'Skyblock', 'Survival']); // invalid values ignored
  const html = await text(await c.req('/dashboard/servers'));
  assert.match(html, /All <span>4<\/span>/); assert.match(html, /Online <span>1<\/span>/); assert.match(html, /Crashed <span>1<\/span>/); assert.match(html, /Starting <span>0<\/span>/);
  // counts follow the other filters
  assert.match(await text(await c.req(`/dashboard/servers?node=${nFra.id}`)), /All <span>2<\/span>/);
  // drop-downs only list this user's nodes / software
  assert.match(html, /<option value="\d+">Frankfurt-1<\/option>/); assert.match(html, /value="velocity"/);
  assert.doesNotMatch(await text(await c.req('/dashboard/servers?status=online')), /No servers are assigned/);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM servers').get().n, 4 + 1 + 45);  // nothing was dropped
});

test('sorting and pagination', async () => {
  const c = client(base); await c.login('carol', PW);
  const p1 = await text(await c.req('/dashboard/servers'));
  assert.equal(names(p1).length, 20); assert.equal(names(p1)[0], 'Srv-01');
  assert.match(p1, /Showing 1&ndash;20 of 45 servers/); assert.match(p1, /Page 1 of 3/);
  const p3 = await text(await c.req('/dashboard/servers?page=3'));
  assert.equal(names(p3).length, 5); assert.match(p3, /Showing 41&ndash;45 of 45/);
  assert.equal(names(await text(await c.req('/dashboard/servers?page=999'))).length, 5);   // clamped to last page
  assert.equal(names(await text(await c.req('/dashboard/servers?page=-4'))).length, 20);
  assert.deepEqual(names(await text(await c.req('/dashboard/servers?sort=ram&dir=desc'))).slice(0, 2), ['Srv-45', 'Srv-44']);
  assert.deepEqual(names(await text(await c.req('/dashboard/servers?sort=name&dir=desc'))).slice(0, 2), ['Srv-45', 'Srv-44']);
  assert.match(await text(await c.req('/dashboard/servers?sort=ram&dir=desc')), /aria-sort="descending"/);
  // pagination links keep the active filters
  const f = await text(await c.req(`/dashboard/servers?node=${nFra.id}&sort=ram&dir=desc`));
  assert.match(f, /Page 1 of 2/); assert.match(f, new RegExp(`href="/dashboard/servers\\?node=${nFra.id}&amp;sort=ram&amp;dir=desc&amp;page=2"`));
  // sorting by node groups by node name
  const byNode = names(await text(await c.req('/dashboard/servers?sort=node&dir=asc')));
  assert.equal(byNode.length, 20);
});

test('details page: all fields come from the database', async () => {
  const c = client(base); await c.login('alice', PW);
  const r = await c.req(`/dashboard/servers/${a1.identifier}`);
  assert.equal(r.status, 200);
  const html = await text(r);
  assert.match(html, /<h1>Survival<\/h1>/);
  assert.match(html, new RegExp(`<code>${a1.identifier}</code>`));
  assert.match(html, /mp-badge-online/); assert.match(html, /play\.example\.com:25565/);
  assert.match(html, /paper 1\.21\.4/); assert.match(html, /7 \/ 30/);
  assert.match(html, /1\.5 GB \/ 4 GB/); assert.match(html, /0\.5 \/ 2 cores/); assert.match(html, /2\.9 GB \/ 20 GB/);
  assert.match(html, /allocated 4 GB/); assert.match(html, /allocated 2 cores/); assert.match(html, /allocated 20 GB/);
  assert.match(html, /<dt>Name<\/dt><dd>Frankfurt-1/); assert.match(html, /Frankfurt, DE/);
  assert.doesNotMatch(html, /fra1\.internal\.example/);
  assert.match(html, /Survival is now online/);            // activity for this server
  assert.match(html, /No commands have been sent/);
  assert.match(html, />Stop</); assert.match(html, />Restart</);
  // unassigned server
  assert.match(await text(await c.req(`/dashboard/servers/${a4.identifier}`)), /not assigned to a node yet/);
});

test('details page: 404 for unknown, malformed and other users’ identifiers', async () => {
  const c = client(base); await c.login('alice', PW);
  for (const id of ['deadbeef', 'nothex!!', 'a'.repeat(40), bobs.identifier, 'action']) {
    const r = await c.req(`/dashboard/servers/${id}`);
    assert.equal(r.status, 404, id);
  }
  assert.equal((await c.req('/dashboard/servers/%E0%A4%A')).status, 400);   // broken percent-encoding is a bad request
  assert.equal((await c.req(`/api/dashboard/servers/${bobs.identifier}`, { headers: { accept: 'application/json' } })).status, 404);
  assert.equal((await c.req(`/dashboard/servers/${bobs.identifier}`)).status, 404);
  // POST to the details URL is not allowed
  assert.equal((await c.post(`/dashboard/servers/${a1.identifier}`, {}, '/dashboard/servers')).status, 405);
});

test('actions from the details and list pages return to where they were sent from; queued command shows in history', async () => {
  const c = client(base); await c.login('alice', PW);
  const detail = `/dashboard/servers/${a2.identifier}`;
  let r = await c.post('/dashboard/servers/action', { server_id: a2.id, action: 'start', back: detail }, detail);
  assert.equal(r.status, 303); assert.equal(r.headers.get('location'), detail);
  const html = await text(await c.req(detail));
  assert.match(html, /Start command sent to Creative/);
  assert.match(html, /mp-badge-starting[^>]*>starting</);
  assert.match(html, /start waiting for the server runtime/);
  assert.match(html, /<td>Start<\/td><td><span class="mp-badge mp-badge-starting">pending/);
  assert.match(html, /No actions are available|<button/);   // page still renders with the transitional state
  // finish it with an error through the runtime interface
  const cmd = db.prepare("SELECT id FROM server_commands WHERE server_id = ?").get(a2.id);
  runtime.completeCommand(cmd.id, { ok: false, error: 'port in use' });
  const after = await text(await c.req(detail));
  assert.match(after, /port in use/); assert.match(after, /mp-badge-crashed[^>]*>crashed</);
  // list page action keeps filters/page via `back`
  const back = `/dashboard/servers?status=crashed`;
  r = await c.post('/dashboard/servers/action', { server_id: a2.id, action: 'start', back }, '/dashboard/servers');
  assert.equal(r.headers.get('location'), back);
});

test('JSON API: list with filters/pagination and details; no internal ids or owner leaked', async () => {
  const c = client(base); await c.login('carol', PW);
  const j = await json(c, `/api/dashboard/servers?node=${nNyc.id}&sort=ram&dir=desc&page=2`);
  assert.equal(j.total, 22); assert.equal(j.page, 2); assert.equal(j.pages, 2); assert.equal(j.servers.length, 2);
  assert.equal(j.counts.all, 22); assert.equal(j.servers[0].node.name, 'NYC-1');
  assert.ok(!('fqdn' in j.servers[0].node));
  assert.ok(!('id' in j.servers[0]) && !('owner_id' in j.servers[0]));
  const a = client(base); await a.login('alice', PW);
  const d = await json(a, `/api/dashboard/servers/${a1.identifier}`);
  assert.equal(d.server.identifier, a1.identifier); assert.equal(d.server.status, 'online');
  assert.deepEqual([d.server.ram.allocated, d.server.cpu.allocated, d.server.disk.allocated], ['4 GB', '2 cores', '20 GB']);
  assert.equal(d.server.players.online, 7); assert.deepEqual(d.allowedActions, ['stop', 'restart']);
  assert.equal(d.server.node.name, 'Frankfurt-1');
});

test('admins also see the node address; regular users never do', async () => {
  const own = servers.create({ ownerId: admin.id, name: 'AdminSrv', nodeId: nFra.id });
  const c = client(base); await c.login('root', PW);
  assert.match(await text(await c.req(`/dashboard/servers/${own.identifier}`)), /fra1\.internal\.example/);
  assert.equal((await json(c, `/api/dashboard/servers/${own.identifier}`)).server.node.fqdn, 'fra1.internal.example');
});

test('empty account and CSP-safe markup', async () => {
  users.create({ username: 'newbie', email: 'new@example.com', passwordHash: await hashPassword(PW) });
  const e = client(base); await e.login('newbie', PW);
  const html = await text(await e.req('/dashboard/servers'));
  assert.match(html, /No servers are assigned to your account yet/); assert.doesNotMatch(html, /Showing/);
  const c = client(base); await c.login('alice', PW);
  for (const path of ['/dashboard/servers', `/dashboard/servers?q=a&status=online`, `/dashboard/servers/${a1.identifier}`]) {
    assert.doesNotMatch(await text(await c.req(path)), /\sstyle=|<script>(?!<)/, path);
  }
});

test('XSS: server and node names are escaped everywhere', async () => {
  const evil = servers.create({ ownerId: alice.id, name: '<img src=x onerror=alert(1)>', address: '"><script>x</script>', nodeId: nodes.create({ name: '<b>n</b>', fqdn: 'x', location: '<i>' }).id });
  const c = client(base); await c.login('alice', PW);
  for (const path of ['/dashboard/servers', `/dashboard/servers/${evil.identifier}`, '/dashboard']) {
    const html = await text(await c.req(path));
    assert.doesNotMatch(html, /<img src=x|<script>x|<b>n<\/b>|<i>/, path);
  }
});
