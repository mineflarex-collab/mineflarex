'use strict';
// Move / copy / permissions in the file manager, two-step verification (authenticator app), Discord state, QR code, server header + Kill.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-feat-'));
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';
process.env.RUNTIME_DATA_DIR = DATA;
process.env.RATE_LIMIT = 'off';
process.env.DISCORD_CLIENT_ID = '123456789012345678';
process.env.DISCORD_CLIENT_SECRET = 'shh';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const access = require('../src/dashboard/services/access');
const totp = require('../src/lib/totp');
const qr = require('../src/lib/qr');
const twofactor = require('../src/services/twofactor');
const oauth = require('../src/services/oauth');

const PW = 'Sup3rSecretPass!';
let srv, base, alice, bob, mine, root;
const api = (s, tail) => `/api/dashboard/servers/${s.identifier}/files${tail}`;
const post = async (c, tail, json) => { const r = await c.api(api(mine, tail), json); return { status: r.status, body: await r.json() }; };
const get = async (c, tail, qs = {}) => { const r = await c.req(`${api(mine, tail)}?${new URLSearchParams(qs)}`, { headers: { accept: 'application/json' } }); return { status: r.status, body: await r.json() }; };

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW);
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: hash });
  bob = users.create({ username: 'bob', email: 'bob@example.com', passwordHash: hash });
  mine = servers.create({ ownerId: alice.id, name: 'Feat', ramLimitMb: 512 });
  root = path.join(DATA, mine.identifier);
  fs.mkdirSync(path.join(root, 'plugins'), { recursive: true });
  fs.mkdirSync(path.join(root, 'world', 'region'), { recursive: true });
  fs.writeFileSync(path.join(root, 'a.txt'), 'hello');
  fs.writeFileSync(path.join(root, 'world', 'region', 'r.dat'), 'x'.repeat(100));
  fs.symlinkSync('/etc', path.join(root, 'world', 'evil'));
});
after(() => { srv.close(); fs.rmSync(DATA, { recursive: true, force: true }); });

test('QR code encoder produces an SVG and rejects oversize text', () => {
  const svg = qr.svg('otpauth://totp/x:y?secret=ABC');
  assert.match(svg, /^<svg[^>]+viewBox="0 0 \d+ \d+"/);
  assert.throws(() => qr.svg('x'.repeat(400)), /too long/);
});

test('TOTP follows RFC 6238 and each code works once', () => {
  const secret = totp.base32Encode(Buffer.from('12345678901234567890'));
  assert.equal(totp.codeAt(secret, 59000), '287082');
  assert.equal(totp.codeAt(secret, 1111111109000), '081804');
  assert.equal(totp.verify(secret, '000000'), null);
  assert.equal(totp.open(totp.seal('s3cret')), 's3cret');
  assert.equal(totp.open('v1.bad.bad.bad'), null);
});

test('file manager: move, copy (next to original), permissions, and path safety', async () => {
  const c = client(base); await c.login('alice', PW);
  let r = await post(c, '/move', { paths: ['/a.txt'], to: '/plugins' });
  assert.equal(r.status, 200); assert.equal(r.body.moved, 1);
  assert.ok(fs.existsSync(path.join(root, 'plugins', 'a.txt')) && !fs.existsSync(path.join(root, 'a.txt')));

  r = await post(c, '/move', { paths: ['/plugins/a.txt'], to: '/plugins' });                 // already there
  assert.equal(r.status, 207); assert.equal(r.body.results[0].code, 'exists');
  r = await post(c, '/move', { paths: ['/world'], to: '/world/region' });                     // into itself
  assert.equal(r.status, 207); assert.equal(r.body.results[0].code, 'bad_path');
  r = await post(c, '/move', { paths: ['/plugins/a.txt'], to: '/../..' });                    // traversal
  assert.equal(r.status, 400);
  r = await post(c, '/move', { paths: ['/plugins/a.txt'], to: '/nope' });
  assert.equal(r.status, 404);

  r = await post(c, '/copy', { path: '/plugins/a.txt' });
  assert.equal(r.status, 201); assert.equal(r.body.entry.name, 'a copy.txt');
  r = await post(c, '/copy', { path: '/plugins/a.txt' });
  assert.equal(r.body.entry.name, 'a copy 2.txt');
  r = await post(c, '/copy', { path: '/world' });                                              // folder copy skips symlinks
  assert.equal(r.status, 201); assert.equal(r.body.entry.name, 'world copy');
  assert.ok(fs.existsSync(path.join(root, 'world copy', 'region', 'r.dat')));
  assert.ok(!fs.existsSync(path.join(root, 'world copy', 'evil')), 'symlink must not be copied');
  r = await post(c, '/copy', { path: '/world/evil' });
  assert.equal(r.status, 403);

  r = await post(c, '/chmod', { paths: ['/plugins/a.txt'], mode: '600' });
  assert.equal(r.status, 200);
  assert.equal((fs.statSync(path.join(root, 'plugins', 'a.txt')).mode & 0o777).toString(8), '600');
  r = await post(c, '/chmod', { paths: ['/plugins/a.txt'], mode: '000' });                     // owner keeps read/write
  assert.equal((fs.statSync(path.join(root, 'plugins', 'a.txt')).mode & 0o777).toString(8), '600');
  r = await post(c, '/chmod', { paths: ['/plugins/a.txt'], mode: '999' });
  assert.equal(r.status, 422);
  r = await post(c, '/chmod', { paths: ['/world/evil'], mode: '755' });
  assert.equal(r.status, 207);

  const l = await get(c, '', { path: '/plugins' });
  assert.equal(l.body.entries.find((e) => e.name === 'a.txt').mode, '600');
});

test('file manager: view-only users and strangers cannot move / copy / chmod', async () => {
  access.grant({ serverId: mine.id, userId: bob.id, permissions: ['files.view'] });
  const b = client(base); await b.login('bob', PW);
  for (const [tail, body] of [['/move', { paths: ['/plugins/a.txt'], to: '/' }], ['/copy', { path: '/plugins/a.txt' }], ['/chmod', { paths: ['/plugins/a.txt'], mode: '777' }]]) {
    assert.equal((await post(b, tail, body)).status, 403, tail);
  }
});

test('files page: toolbar buttons, new menu dialogs, power buttons incl. Kill', async () => {
  const c = client(base); await c.login('alice', PW);
  const html = await (await c.req(`/dashboard/servers/${mine.identifier}/files`)).text();
  for (const needle of ['data-files-code', 'data-files-refresh', 'data-files-new="folder"', 'data-files-upload>', 'data-files-upload-folder', 'webkitdirectory', 'data-files-new="file"',
    'data-files-move', 'data-files-perm', 'mp-srvhead', 'mp-btn-start', 'mp-btn-restart', 'mp-btn-stop', 'mp-btn-kill', '/force/stop', 'purple.css', 'ui.js', 'MANAGEMENT']) {
    assert.ok(html.includes(needle), `missing ${needle}`);
  }
  const js = fs.readFileSync(path.join(__dirname, '..', 'public', 'js', 'files.js'), 'utf8');
  for (const label of ["'Rename'", "'Move'", "'Copy'", "'Permissions'", "'Extract'", "'Download'", "'Delete'"]) assert.ok(js.includes(label), label);
  const kill = await c.post(`/dashboard/servers/${mine.identifier}/force/stop`, { back: `/dashboard/servers/${mine.identifier}/files` }, `/dashboard/servers/${mine.identifier}/files`);
  assert.equal(kill.status, 303); assert.equal(kill.headers.get('location'), `/dashboard/servers/${mine.identifier}/files`);
});

test('two-step verification: setup, login needs the code, replay and backup codes', async () => {
  const c = client(base); await c.login('alice', PW);
  let page = await (await c.req('/dashboard/settings')).text();
  assert.match(page, /Enable Two-Step/);
  const setup = await (await c.req('/dashboard/settings/2fa')).text();
  assert.match(setup, /<svg class="mp-qr"/); assert.match(setup, /otpauth:\/\/totp\//);
  const secret = twofactor.pendingSecret(alice.id); assert.ok(secret);
  let r = await c.post('/dashboard/settings/2fa/enable', { code: '000000' }, '/dashboard/settings/2fa');
  assert.equal(r.status, 422); assert.equal(twofactor.isEnabled(alice.id), false);
  r = await c.post('/dashboard/settings/2fa/enable', { code: totp.codeAt(secret) }, '/dashboard/settings/2fa');
  assert.equal(r.status, 200);
  const codes = [...(await r.text()).matchAll(/<code>([a-z0-9]{4}-[a-z0-9]{4})<\/code>/g)].map((m) => m[1]);
  assert.equal(codes.length, 10); assert.equal(twofactor.isEnabled(alice.id), true);
  assert.equal(JSON.stringify(require('../src/db').prepare('SELECT totp_secret FROM users WHERE id = ?').get(alice.id)).includes(secret), false, 'secret must be stored sealed');

  // new browser: password alone does not sign in
  const d = client(base);
  r = await d.login('alice', PW);
  assert.equal(r.status, 303); assert.equal(r.headers.get('location'), '/login/2fa');
  assert.equal((await d.req('/dashboard')).status, 303, 'no session yet');
  r = await d.post('/login/2fa', { code: '123456' }, '/login/2fa');
  assert.equal(r.status, 401);
  // a code already used during setup cannot be replayed
  r = await d.post('/login/2fa', { code: totp.codeAt(secret) }, '/login/2fa');
  assert.equal(r.status, 401, 'same time step as setup');
  r = await d.post('/login/2fa', { code: totp.codeAt(secret, Date.now() + 30000) }, '/login/2fa');
  assert.equal(r.status, 303); assert.equal(r.headers.get('location'), '/dashboard');
  assert.equal((await d.req('/dashboard')).status, 200);

  // backup code works once
  const e = client(base); await e.login('alice', PW);
  r = await e.post('/login/2fa', { code: codes[0] }, '/login/2fa'); assert.equal(r.status, 303);
  const f = client(base); await f.login('alice', PW);
  r = await f.post('/login/2fa', { code: codes[0] }, '/login/2fa'); assert.equal(r.status, 401, 'backup code is single use');
  assert.equal(twofactor.backupLeft(alice.id), 9);

  // turning it off needs the password
  r = await c.post('/dashboard/settings/2fa/disable', { current_password: 'wrong-password' }, '/dashboard/settings');
  assert.equal(twofactor.isEnabled(alice.id), true);
  await c.post('/dashboard/settings/2fa/disable', { current_password: PW }, '/dashboard/settings');
  assert.equal(twofactor.isEnabled(alice.id), false);
});

test('2fa step: tampered or missing pending cookie is refused', async () => {
  const c = client(base);
  assert.equal((await c.req('/login/2fa')).status, 303);
  c.jar.mp_2fa = encodeURIComponent('eyJ1IjoxLCJlIjo5OTk5OTk5OTk5OTk5fQ.forged');
  assert.equal((await c.req('/login/2fa')).status, 303);
  assert.equal(twofactor.readPending(twofactor.makePending(1, true, '/x')).userId, 1);
});

test('Discord: login page button, state is signed, callback refuses forged state, link/unlink', async () => {
  const c = client(base);
  assert.match(await (await c.req('/login')).text(), /Continue with Discord/);
  let r = await c.req('/auth/discord');
  assert.equal(r.status, 303);
  const loc = new URL(r.headers.get('location'));
  assert.equal(loc.origin + loc.pathname, 'https://discord.com/oauth2/authorize');
  assert.equal(loc.searchParams.get('client_id'), '123456789012345678');
  assert.equal(loc.searchParams.get('redirect_uri'), `${base}/auth/discord/callback`.replace(base, require('../src/config').baseUrl));
  const state = loc.searchParams.get('state'); assert.ok(oauth.readState(state));
  assert.equal(oauth.readState(state + 'x'), null);
  // callback with a state that does not match the cookie
  r = await c.req(`/auth/discord/callback?code=abc&state=${encodeURIComponent(oauth.makeState({ mode: 'login' }))}`);
  assert.equal(r.status, 303); assert.equal(r.headers.get('location'), '/login');
  assert.equal((await c.req('/dashboard')).status, 303);

  // linking needs a signed-in user; the link table works both ways
  assert.equal((await client(base).req('/auth/discord?link=1')).headers.get('location'), '/login');
  oauth.link('discord', '555000111', bob.id, 'bobby');
  assert.equal(oauth.find('discord', '555000111').user_id, bob.id);
  const b = client(base); await b.login('bob', PW);
  assert.match(await (await b.req('/dashboard/settings')).text(), /Linked to Discord/);
  await b.post('/dashboard/settings/discord/unlink', {}, '/dashboard/settings');
  assert.equal(oauth.find('discord', '555000111'), null);
});
