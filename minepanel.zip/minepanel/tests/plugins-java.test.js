'use strict';
// Real-JVM test of the "plugin built for a newer Java" handling. Needs `java` (21 or newer) with its compiler module
// (every normal JDK has it); the whole file is skipped when that is not available.
// Separate file = separate process and database: starting a Supervisor reconciles the whole database.
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { makeZip } = require('./fixtures/zipjar');

const MINI = path.join(__dirname, 'fixtures', 'MiniPaper.java');
const ver = spawnSync('java', ['-version'], { encoding: 'utf8' });
const major = (/version "(\d+)/.exec(`${ver.stderr}${ver.stdout}`) || [])[1];
const comp = major ? spawnSync('java', ['--module', 'jdk.compiler/com.sun.tools.javac.Main', '--version'], { encoding: 'utf8' }) : { status: 1 };
const SKIP = !major || Number(major) < 21 || comp.status !== 0 ? 'needs a JDK (java 21+ with the compiler module)' : false;

let work, jars, sup, alice, store, servers, db;
const PLUGINS = ['A-Good', 'Veinminer', 'Z-Good'];     // name order = load order; the one in the middle needs a newer Java

/** Compiles tiny plugin classes with the real compiler. `future` classes get a Java 25 class-file version (69). */
function buildJars() {
  const src = path.join(work, 'src'), out = path.join(work, 'out'); fs.mkdirSync(src, { recursive: true }); fs.mkdirSync(out);
  for (const n of ['a', 'v', 'z']) { fs.mkdirSync(path.join(src, n)); fs.writeFileSync(path.join(src, n, 'Main.java'), `package ${n}; public class Main { static { System.out.println("plugin ${n} init"); } }\n`); }
  fs.writeFileSync(path.join(src, 'v', 'Loader.java'), 'package v; public class Loader { }\n');
  const r = spawnSync('java', ['--module', 'jdk.compiler/com.sun.tools.javac.Main', '-d', out, ...['a/Main', 'v/Main', 'v/Loader', 'z/Main'].map((f) => path.join(src, `${f}.java`))], { encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr + r.stdout);
  const cls = (f, newer) => { const b = fs.readFileSync(path.join(out, `${f}.class`)); if (newer) b.writeUInt16BE(69, 6); return b; };
  return {
    'A-Good.jar': makeZip({ 'plugin.yml': 'name: A\nmain: a.Main\n', 'a/Main.class': cls('a/Main') }),
    'Veinminer.jar': makeZip({ 'paper-plugin.yml': 'name: V\nmain: v.Main\nloader: v.Loader\n', 'v/Main.class': cls('v/Main'), 'v/Loader.class': cls('v/Loader', true) }),
    'Z-Good.jar': makeZip({ 'plugin.yml': 'name: Z\nmain: z.Main\n', 'z/Main.class': cls('z/Main') })
  };
}
const putPlugins = (dir) => { fs.mkdirSync(path.join(dir, 'plugins'), { recursive: true }); for (const [n, b] of Object.entries(jars)) fs.writeFileSync(path.join(dir, 'plugins', n), b); };

before(() => {
  if (SKIP) return;
  work = fs.mkdtempSync(path.join(os.tmpdir(), 'mp-java-'));
  jars = buildJars();
  const users = require('../src/services/users');
  servers = require('../src/dashboard/services/servers'); store = require('../src/dashboard/services/serverConsole'); db = require('../src/db');
  const { Supervisor } = require('../src/runtime/supervisor');
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: 'x' });
  sup = new Supervisor({ dataDir: path.join(work, 'servers'), pollMs: 40, metricsMs: 500, consoleFlushMs: 30, startTimeoutMs: 60000, stopTimeoutMs: 10000 });
  sup.start();
});
after(async () => { if (sup) await sup.shutdown(); if (work) fs.rmSync(work, { recursive: true, force: true }); });

const waitFor = async (fn, what, ms = 40000) => { const t = Date.now(); while (Date.now() - t < ms) { const v = fn(); if (v) return v; await new Promise((r) => setTimeout(r, 50)); } assert.fail(`timed out waiting for: ${what}`); };
const consoleText = (id) => store.tail(id, 300).map((l) => l.line).join('\n');

test('CONTROL: without the panel, one plugin built for a newer Java stops loading of every plugin after it', { skip: SKIP }, () => {
  const dir = path.join(work, 'control'); putPlugins(dir);
  const r = spawnSync('java', [MINI, 'server.jar', 'nogui'], { cwd: dir, input: 'stop\n', encoding: 'utf8', timeout: 60000 });
  assert.match(r.stdout, /UnsupportedClassVersionError/);
  assert.equal(fs.readFileSync(path.join(dir, 'loaded.txt'), 'utf8'), 'A-Good.jar');          // Z-Good.jar never loaded
});

test('panel start: the incompatible plugin is parked, every other plugin loads, console explains', { skip: SKIP }, async () => {
  const s = servers.create({ ownerId: alice.id, name: 'Java', startCommand: `java "${MINI}" server.jar nogui`, ramLimitMb: 512 });
  const dir = path.join(work, 'servers', s.identifier); fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'server.jar'), 'placeholder'); putPlugins(dir);
  servers.requestCommand(alice, s.id, 'start', '127.0.0.1', { confirmed: true });
  await waitFor(() => db.prepare('SELECT status FROM servers WHERE id = ?').get(s.id).status === 'online', 'server online');
  assert.deepEqual(fs.readFileSync(path.join(dir, 'loaded.txt'), 'utf8').split('\n'), ['A-Good.jar', 'Z-Good.jar']);
  assert.ok(fs.existsSync(path.join(dir, 'plugins', '.unsupported', 'Veinminer.jar')));
  assert.ok(!fs.existsSync(path.join(dir, 'plugins', 'Veinminer.jar')));
  await waitFor(() => /Skipped plugin Veinminer\.jar: it needs Java 25 but this server runs Java \d+/.test(consoleText(s.id)), 'console message');
  assert.match(consoleText(s.id), /\[minePanel\] Command: java .*MiniPaper\.java server\.jar nogui/);
  assert.doesNotMatch(consoleText(s.id), /UnsupportedClassVersionError/);
  // the server really answers `pl` with the two compatible plugins
  const { enqueueInput } = store; enqueueInput({ serverId: s.id, user: alice, command: 'pl' });
  await waitFor(() => /Server Plugins \(2\): A-Good\.jar, Z-Good\.jar/.test(consoleText(s.id)), 'pl output');
  servers.requestCommand(alice, s.id, 'stop', '127.0.0.1', { confirmed: true });
  await waitFor(() => db.prepare('SELECT status FROM servers WHERE id = ?').get(s.id).status === 'offline', 'server offline');
  // second start: nothing is moved again, still the same plugins
  servers.requestCommand(alice, s.id, 'start', '127.0.0.1', { confirmed: true });
  await waitFor(() => db.prepare('SELECT status FROM servers WHERE id = ?').get(s.id).status === 'online', 'online again');
  assert.deepEqual(fs.readFileSync(path.join(dir, 'loaded.txt'), 'utf8').split('\n'), ['A-Good.jar', 'Z-Good.jar']);
  servers.requestCommand(alice, s.id, 'stop', '127.0.0.1', { confirmed: true });
  await waitFor(() => db.prepare('SELECT status FROM servers WHERE id = ?').get(s.id).status === 'offline', 'offline');
});
