'use strict';
// Auto-suspend: yellow warning at 90%+ of RAM / CPU / disk, suspension if it stays that high, admin can unsuspend.
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const db = require('../src/db');
const { Supervisor } = require('../src/runtime/supervisor');

const PW = 'Sup3rSecretPass!';
let srv, base, alice, admin, s1, sup;
const get = (id) => db.prepare('SELECT * FROM servers WHERE id = ?').get(id);

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW);
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: hash });
  admin = users.create({ username: 'root', email: 'root@example.com', passwordHash: hash });
  db.prepare("UPDATE users SET role = 'admin' WHERE id = ?").run(admin.id);
  s1 = servers.create({ ownerId: alice.id, name: 'Hot', ramLimitMb: 1000, cpuLimitPct: 100, diskLimitMb: 1000 });
  sup = new Supervisor({ usagePct: 90, usageWarnMs: 20, usageSuspendMs: 120 });
  sup.stopEntry = () => {};
  sup.console = { push() {} };
});
after(() => { srv.closeAllConnections?.(); srv.close(); });

const entry = () => ({ server: get(s1.id), diskMb: 0 });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

test('under 90%: no warning', () => {
  const e = entry();
  assert.equal(sup.checkUsage(e, get(s1.id), 50, 800), false);
  assert.equal(get(s1.id).usage_warning, null);
});

test('90%+ for a while: yellow warning, then suspended', async () => {
  const e = entry(), cur = get(s1.id);
  sup.checkUsage(e, cur, 10, 950); await sleep(40);
  assert.equal(sup.checkUsage(e, cur, 10, 950), false);
  assert.match(get(s1.id).usage_warning, /RAM 95%/);
  const page = await (await (async () => { const c = client(base); await c.login('alice', PW); return c.req(`/dashboard/servers/${s1.identifier}`); })()).text();
  assert.match(page, /class="mp-usage-warn"/);
  await sleep(120);
  assert.equal(sup.checkUsage(e, cur, 10, 950), true);
  const row = get(s1.id);
  assert.equal(row.suspended, 1); assert.match(row.suspended_reason, /RAM/); assert.equal(row.usage_warning, null);
});

test('suspended server cannot be started or restarted, banner is shown', async () => {
  const r = servers.requestCommand(alice, s1.id, 'start', '127.0.0.1');
  assert.equal(r.ok, false); assert.equal(r.code, 'suspended');
  const c = client(base); await c.login('alice', PW);
  assert.match(await (await c.req(`/dashboard/servers/${s1.identifier}`)).text(), /class="mp-suspended"/);
});

test('usage that drops back under the limit clears the warning', async () => {
  const s2 = servers.create({ ownerId: alice.id, name: 'Calm', ramLimitMb: 1000, cpuLimitPct: 100, diskLimitMb: 1000 });
  const e = { server: get(s2.id), diskMb: 0 }, cur = get(s2.id);
  sup.checkUsage(e, cur, 10, 950); await sleep(40); sup.checkUsage(e, cur, 10, 950);
  assert.ok(get(s2.id).usage_warning);
  sup.checkUsage(e, cur, 10, 300);
  assert.equal(get(s2.id).usage_warning, null);
});

test('admin can unsuspend; then it can be started again', async () => {
  const a = client(base); await a.login('root', PW);
  const edit = `/admin/servers/${s1.identifier}/edit`;
  assert.match(await (await a.req(edit)).text(), /Unsuspend server/);
  const res = await a.post(`/admin/servers/${s1.identifier}/unsuspend`, {}, edit);
  assert.equal(res.status, 303);
  assert.equal(get(s1.id).suspended, 0);
  assert.equal(servers.requestCommand(alice, s1.id, 'start', '127.0.0.1').ok, true);
});

test('admin can suspend manually', async () => {
  const s3 = servers.create({ ownerId: alice.id, name: 'Manual' });
  const a = client(base); await a.login('root', PW);
  const res = await a.post(`/admin/servers/${s3.identifier}/suspend`, {}, `/admin/servers/${s3.identifier}/edit`);
  assert.equal(res.status, 303);
  assert.equal(get(s3.id).suspended, 1);
});

test('validity: dd/mm/yyyy parsing and formatting', () => {
  const ts = servers.parseDate('20/12/2026');
  assert.ok(ts); assert.equal(servers.formatDate(ts), '20/12/2026');
  for (const bad of ['31/02/2026', '2026-12-20', '20/13/2026', '', 'abc']) assert.equal(servers.parseDate(bad), null, bad);
});

test('validity: set at creation, shown on the server page, expiry suspends, extending unsuspends', async () => {
  const a = client(base); await a.login('root', PW);
  const future = servers.formatDate(Date.now() + 10 * 86400000);
  const bad = await a.post('/admin/servers', { kind: 'mc', name: 'Valid1', owner: 'alice', version: 'latest', ram: '512', cpu: '100', disk: '1024', players: '20', valid: '99/99/2026' }, '/admin/servers/new?kind=mc');
  assert.equal(bad.status, 422);
  const ok = await a.post('/admin/servers', { kind: 'mc', name: 'Valid1', owner: 'alice', version: 'latest', ram: '512', cpu: '100', disk: '1024', players: '20', valid: future }, '/admin/servers/new?kind=mc');
  assert.equal(ok.status, 303);
  const row = db.prepare("SELECT * FROM servers WHERE name = 'Valid1'").get();
  assert.equal(servers.formatDate(row.expires_at), future);
  const c = client(base); await c.login('alice', PW);
  const page = await (await c.req(`/dashboard/servers/${row.identifier}`)).text();
  assert.match(page, new RegExp(`Expires <strong>${future.replace(/\//g, '\\/')}</strong>`));
  assert.match(page, /data-validity-left[^>]*>(9d|10d)</);
  // the day passes -> runtime suspends
  db.prepare('UPDATE servers SET expires_at = ? WHERE id = ?').run(Date.now() - 1000, row.id);
  sup.lastExpiry = 0; sup.expirySweep();
  const s = get(row.id);
  assert.equal(s.suspended, 1); assert.match(s.suspended_reason, /^Validity expired on \d\d\/\d\d\/\d{4}/);
  // admin upgrades time (separate page) -> unsuspended
  const ext = `/admin/servers/${row.identifier}/extend`;
  assert.match(await (await a.req(ext)).text(), /Quick upgrade/);
  const res = await a.post(ext, { date: future }, ext);
  assert.equal(res.status, 303);
  const after = get(row.id);
  assert.equal(after.suspended, 0); assert.equal(servers.formatDate(after.expires_at), future);
});

test('users: edit button in the list, Pterodactyl-style edit page, names saved, delete rules', async () => {
  const a = client(base); await a.login('root', PW);
  const bob = users.create({ username: 'bobby', email: 'bobby@example.com', passwordHash: await hashPassword(PW) });
  const list = await (await a.req('/admin/users')).text();
  assert.match(list, new RegExp(`href="/admin/users/${bob.id}/edit"`));
  const edit = `/admin/users/${bob.id}/edit`;
  const page = await (await a.req(edit)).text();
  for (const t of ['Identity', 'Permissions', 'Administrator', 'Associated servers', 'Update user', 'Delete user']) assert.ok(page.includes(t), t);
  const ok = await a.post(`/admin/users/${bob.id}`, { username: 'bobby', email: 'bobby@example.com', first: 'Bob', last: 'Marley', role: 'user', active: '1', password: '' }, edit);
  assert.equal(ok.status, 303);
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(bob.id);
  assert.equal(row.first_name, 'Bob'); assert.equal(row.last_name, 'Marley');
  // a user who owns servers cannot be deleted; one without can
  const owner = users.create({ username: 'owner1', email: 'owner1@example.com', passwordHash: 'x' });
  servers.create({ ownerId: owner.id, name: 'Owned' });
  assert.equal((await a.post(`/admin/users/${owner.id}/delete`, {}, `/admin/users/${owner.id}/edit`)).status, 400);
  assert.equal((await a.post(`/admin/users/${bob.id}/delete`, {}, edit)).status, 303);
  assert.equal(db.prepare('SELECT * FROM users WHERE id = ?').get(bob.id), undefined);
});

test('validity counter: 20d / 1m / 1y 1m 1d, hours under a day, Expired', () => {
  const f = require('../src/dashboard/format');
  const now = new Date(2026, 10, 22, 12, 0, 0).getTime(), end = (y, m, d) => new Date(y, m - 1, d, 23, 59, 59, 999).getTime();
  assert.equal(f.remaining(end(2026, 12, 12), now), '20d');
  assert.equal(f.remaining(end(2026, 12, 22), now), '1m');
  assert.equal(f.remaining(end(2027, 12, 23), now), '1y 1m 1d');
  assert.equal(f.remaining(end(2027, 11, 22), now), '1y');
  assert.match(f.remaining(end(2026, 11, 22), now), /^11h 59m \d+s$/);
  assert.equal(f.remaining(now - 1, now), 'Expired');
});

test('upgrade time: presets, custom days/months/years, month-end, bad input, remove expiry', async () => {
  const at = (y, m, d) => new Date(y, m - 1, d, 23, 59, 59, 999).getTime(), now = new Date(2026, 10, 22, 10, 0, 0).getTime();
  assert.equal(servers.formatDate(servers.extendFrom(at(2026, 12, 20), { days: 20 }, now)), '09/01/2027');
  assert.equal(servers.formatDate(servers.extendFrom(at(2026, 12, 20), { months: 1 }, now)), '20/01/2027');
  assert.equal(servers.formatDate(servers.extendFrom(at(2026, 12, 20), { years: 1 }, now)), '20/12/2027');
  assert.equal(servers.formatDate(servers.extendFrom(at(2027, 1, 31), { months: 1 }, now)), '28/02/2027');
  assert.equal(servers.formatDate(servers.extendFrom(null, { days: 10 }, now)), '02/12/2026');             // no expiry: counted from today
  assert.equal(servers.formatDate(servers.extendFrom(at(2026, 10, 1), { days: 5 }, now)), '27/11/2026');   // already expired: counted from today
  const a = client(base); await a.login('root', PW);
  const s = servers.create({ ownerId: alice.id, name: 'Upg', expiresAt: at(2030, 1, 1) });
  const ext = `/admin/servers/${s.identifier}/extend`;
  assert.equal((await a.post(ext, { preset: '1y' }, ext)).status, 303);
  assert.equal(servers.formatDate(get(s.id).expires_at), '01/01/2031');
  assert.equal((await a.post(ext, { amount: '3', unit: 'm' }, ext)).status, 303);
  assert.equal(servers.formatDate(get(s.id).expires_at), '01/04/2031');
  assert.equal((await a.post(ext, { amount: '0', unit: 'd' }, ext)).status, 422);
  assert.equal((await a.post(ext, { date: '31/02/2031' }, ext)).status, 422);
  assert.equal((await a.post(ext, { clear: '1' }, ext)).status, 303);
  assert.equal(get(s.id).expires_at, null);
  const list = await (await a.req('/admin/servers/mc')).text();
  assert.match(list, new RegExp(`/admin/servers/${s.identifier}/extend`));
});

test('server console page has Force stop/start/restart (+ Suspend for admins); force actions queue a command; strangers cannot', async () => {
  const s4 = servers.create({ ownerId: alice.id, name: 'ForceMe' });
  const page = `/dashboard/servers/${s4.identifier}/console`;
  const a = client(base); await a.login('root', PW);
  const html = await (await a.req(page)).text();
  for (const t of ['Suspend server', 'Force stop', 'Force start', 'Force restart']) assert.match(html, new RegExp(t));
  assert.doesNotMatch(await (await a.req(`/admin/servers/${s4.identifier}/edit`)).text(), /Force restart/);
  const u = client(base); await u.login('alice', PW);
  const uhtml = await (await u.req(page)).text();
  assert.match(uhtml, /Force restart/); assert.doesNotMatch(uhtml, /Suspend server/);
  const res = await u.post(`/dashboard/servers/${s4.identifier}/force/restart`, {}, page);
  assert.equal(res.status, 303);
  assert.equal(db.prepare('SELECT command FROM server_commands WHERE server_id = ? ORDER BY id DESC').get(s4.id).command, 'force_restart');
  const bob = users.create({ username: 'bob', email: 'bob@example.com', passwordHash: await hashPassword(PW) });
  const b = client(base); await b.login('bob', PW);
  const denied = await b.post(`/dashboard/servers/${s4.identifier}/force/stop`, {}, '/dashboard');
  assert.notEqual(denied.status, 303);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM server_commands WHERE server_id = ? AND command = 'force_stop'").get(s4.id).n, 0);
});
