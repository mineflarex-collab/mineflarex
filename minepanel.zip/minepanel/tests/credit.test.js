'use strict';
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');

let srv, base;
before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  users.create({ username: 'alice', email: 'alice@example.com', passwordHash: await hashPassword('Sup3rSecretPass!') });
});
after(() => srv.close());

test('"Made by MineFlareX" footer (purple, centered) is on the login page and on the dashboard', async () => {
  const c = client(base);
  const login = await (await c.req('/login')).text();
  assert.match(login, /<footer class="mp-credit">Made by MineFlareX<\/footer>/);
  await c.login('alice', 'Sup3rSecretPass!');
  const dash = await (await c.req('/dashboard')).text();
  assert.match(dash, /<footer class="mp-footer">Made by MineFlareX<\/footer>/);
  const css = await (await c.req('/css/dashboard.css')).text() + await (await c.req('/css/auth.css')).text();
  assert.match(css, /\.mp-footer \{[^}]*text-align:center;[^}]*color:var\(--accent\)/);
  assert.match(css, /\.mp-credit \{[^}]*text-align:center;[^}]*color:var\(--accent\)/);
});
