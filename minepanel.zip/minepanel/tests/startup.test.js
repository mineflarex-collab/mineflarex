'use strict';
// Startup page: variables build the bot command, validation, permissions, admin custom command.
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const { client } = require('./helpers');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');
const servers = require('../src/dashboard/services/servers');
const startup = require('../src/dashboard/services/startup');
const db = require('../src/db');

const PW = 'Sup3rSecretPass!';
let srv, base, alice, bob, admin, bot, mc;
const row = (id) => db.prepare('SELECT * FROM servers WHERE id = ?').get(id);

before(async () => {
  srv = createServer(); await new Promise((r) => srv.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${srv.address().port}`;
  const hash = await hashPassword(PW);
  alice = users.create({ username: 'alice', email: 'alice@example.com', passwordHash: hash });
  bob = users.create({ username: 'bob', email: 'bob@example.com', passwordHash: hash });
  admin = users.create({ username: 'root', email: 'root@example.com', passwordHash: hash });
  db.prepare("UPDATE users SET role = 'admin' WHERE id = ?").run(admin.id);
  bot = servers.create({ ownerId: alice.id, name: 'Bot', kind: 'bot', runtime: 'nodejs', startCommand: 'node bot.js', software: 'Node.js' });
  mc = servers.create({ ownerId: alice.id, name: 'World' });
  require('../src/dashboard/services/access').grant({ serverId: bot.id, userId: bob.id, permissions: [] });
});
after(() => { srv.closeAllConnections?.(); srv.close(); });

const login = async (name) => { const c = client(base); await c.login(name, PW); return c; };

test('existing bot: main file is read from its command, page shows it', async () => {
  assert.equal(startup.valuesOf(bot).MAIN_FILE, 'bot.js');
  const c = await login('alice'), res = await c.req(`/dashboard/servers/${bot.identifier}/startup`), html = await res.text();
  assert.equal(res.status, 200);
  assert.match(html, /Startup command/); assert.match(html, /node bot\.js/); assert.match(html, /MAIN_FILE/); assert.match(html, /Recommended/);
});

test('owner saves variables: command is rebuilt', async () => {
  const c = await login('alice');
  const r = await c.post(`/dashboard/servers/${bot.identifier}/startup`, { MAIN_FILE: 'src/main.js', NODE_ARGS: '--max-old-space-size=256', AUTO_INSTALL: '1' }, `/dashboard/servers/${bot.identifier}/startup`);
  assert.equal(r.status, 303);
  const s = row(bot.id);
  assert.equal(s.start_command, 'node --max-old-space-size=256 src/main.js');
  assert.deepEqual(JSON.parse(s.startup_vars), { MAIN_FILE: 'src/main.js', NODE_ARGS: '--max-old-space-size=256', AUTO_INSTALL: '1' });
  await c.post(`/dashboard/servers/${bot.identifier}/startup`, { MAIN_FILE: 'index.js', NODE_ARGS: '' }, `/dashboard/servers/${bot.identifier}/startup`);
  assert.equal(row(bot.id).start_command, 'node index.js');
  assert.equal(JSON.parse(row(bot.id).startup_vars).AUTO_INSTALL, '0');      // unchecked box
});

test('bad values are refused', async () => {
  const c = await login('alice');
  for (const form of [{ MAIN_FILE: '../etc/passwd' }, { MAIN_FILE: '-e', NODE_ARGS: '' }, { MAIN_FILE: 'a.js', NODE_ARGS: '; rm -rf /' }]) {
    const r = await c.post(`/dashboard/servers/${bot.identifier}/startup`, form, `/dashboard/servers/${bot.identifier}/startup`);
    assert.equal(r.status, 422);
  }
  assert.equal(row(bot.id).start_command, 'node index.js');
});

test('shared user can view but not change; a non-owner cannot see it at all', async () => {
  const b = await login('bob');
  assert.equal((await b.req(`/dashboard/servers/${bot.identifier}/startup`)).status, 200);
  const r = await b.post(`/dashboard/servers/${bot.identifier}/startup`, { MAIN_FILE: 'evil.js' }, `/dashboard/servers/${bot.identifier}/startup`);
  assert.equal(r.status, 403); assert.equal(row(bot.id).start_command, 'node index.js');
  assert.equal((await b.req(`/dashboard/servers/${mc.identifier}/startup`)).status, 404);
});

test('only an administrator can set a custom command', async () => {
  const a = await login('alice');
  await a.post(`/dashboard/servers/${mc.identifier}/startup`, { command: 'java -jar evil.jar' }, `/dashboard/servers/${mc.identifier}/startup`);
  assert.equal(row(mc.id).start_command, null);
  const r = await login('root');
  await r.post(`/dashboard/servers/${mc.identifier}/startup`, { command: 'java -Xmx{{HEAP_MB}}M -jar server.jar nogui' }, `/dashboard/servers/${mc.identifier}/startup`);
  assert.equal(row(mc.id).start_command, 'java -Xmx{{HEAP_MB}}M -jar server.jar nogui');
  await r.post(`/dashboard/servers/${mc.identifier}/startup`, { command: '' }, `/dashboard/servers/${mc.identifier}/startup`);
  assert.equal(row(mc.id).start_command, null);
  await r.post(`/dashboard/servers/${bot.identifier}/startup`, { MAIN_FILE: 'index.js', NODE_ARGS: '', AUTO_INSTALL: '1', command: 'node --inspect index.js' }, `/dashboard/servers/${bot.identifier}/startup`);
  assert.equal(row(bot.id).start_command, 'node --inspect index.js');
  assert.equal(startup.isCustom(row(bot.id)), true);
});

test('admin edit page links to Startup', async () => {
  const r = await login('root'), html = await (await r.req(`/admin/servers/${bot.identifier}/edit`)).text();
  assert.match(html, new RegExp(`/dashboard/servers/${bot.identifier}/startup`));
});
