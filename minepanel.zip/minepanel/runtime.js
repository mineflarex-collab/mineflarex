'use strict';
// Standalone runtime: `npm run runtime`. Run exactly one per database (not needed with RUNTIME=embedded).
require('./src/dashboard'); // ensure tables exist
const { Supervisor } = require('./src/runtime/supervisor');

const sup = new Supervisor({ log: (m) => console.log(`[runtime] ${m}`) });
sup.start();
let down = false;
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, async () => {
  if (down) return; down = true;
  console.log('[runtime] stopping servers...');
  await sup.shutdown();
  process.exit(0);
});
