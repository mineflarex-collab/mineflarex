'use strict';
const { createServer, config } = require('./src/app');
const events = require('./src/dashboard/services/events');
const runtimeConfig = require('./src/runtime/config');

const server = createServer();
let supervisor = null;
if (runtimeConfig.embedded) {
  const { Supervisor } = require('./src/runtime/supervisor');
  supervisor = new Supervisor({ log: (m) => console.log(`[runtime] ${m}`) });
  supervisor.start();
}
server.listen(config.port, config.host, () => {
  console.log(`minePanel auth listening on http://${config.host}:${config.port} (${config.prod ? 'production' : 'development'})${supervisor ? ' + embedded runtime' : ''}`);
});
let down = false;
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, async () => {
  if (down) return; down = true;
  events.closeAll();                       // open live-update streams would otherwise keep the server from closing
  if (supervisor) { console.log('[runtime] panel shutting down: servers keep running (or stop, with RUNTIME_PERSIST=off)...'); await supervisor.shutdown(); }
  server.closeAllConnections?.();
  server.close(() => process.exit(0));
});
