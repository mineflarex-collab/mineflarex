// Purple snowfall on every page: soft glowing flakes in three depths, gentle wind gusts, pauses when the tab is hidden.
(() => {
  if (window.__mpSnow || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  window.__mpSnow = true;
  const cv = document.createElement('canvas'); cv.className = 'mp-snow'; cv.setAttribute('aria-hidden', 'true');
  document.body.appendChild(cv);
  const ctx = cv.getContext('2d');
  const PALETTE = [[243, 232, 255], [233, 213, 255], [216, 180, 254], [192, 132, 252], [168, 85, 247]];
  const SIZES = [4, 7, 11, 16, 22];
  const sprites = PALETTE.map((rgb) => SIZES.map((px) => {
    const s = Math.ceil(px * 2 * 2), c = document.createElement('canvas'); c.width = c.height = s;   // drawn at 2x so flakes stay sharp on phones
    const g = c.getContext('2d'), gr = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2), k = rgb.join(',');
    gr.addColorStop(0, `rgba(${k},1)`); gr.addColorStop(.3, `rgba(${k},.85)`); gr.addColorStop(.62, `rgba(${k},.22)`); gr.addColorStop(1, `rgba(${k},0)`);
    g.fillStyle = gr; g.fillRect(0, 0, s, s); return c;
  }));
  let W = 0, H = 0, flakes = [], last = 0, t = 0, raf = 0, resizeTimer = 0;
  const rnd = (a, b) => a + Math.random() * (b - a);
  const make = (initial) => {
    const z = Math.random() ** 1.6;                                   // most flakes are far away (small, slow, faint)
    const si = Math.min(SIZES.length - 1, Math.floor(z * SIZES.length));
    return { x: rnd(0, W), y: initial ? rnd(-20, H) : rnd(-60, -10), z, si, ci: Math.floor(Math.random() * PALETTE.length),
      size: SIZES[si] * rnd(.85, 1.2), vy: 22 + z * 70 + rnd(0, 14), amp: rnd(8, 26) * (.4 + z), freq: rnd(.4, 1.1), ph: rnd(0, 6.28), a: .3 + z * .7 };
  };
  const resize = () => {
    const dpr = Math.min(window.devicePixelRatio || 1, 2); W = innerWidth; H = innerHeight;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const n = Math.max(40, Math.min(110, Math.round(W * H / 15000)));
    while (flakes.length < n) flakes.push(make(true));
    flakes.length = n; for (const f of flakes) if (f.x > W) f.x = rnd(0, W);
  };
  const frame = (now) => {
    raf = requestAnimationFrame(frame);
    const dt = Math.min(.05, (now - last) / 1000 || .016); last = now; t += dt;
    const wind = Math.sin(t * .23) * 16 + Math.sin(t * .071) * 10;      // slow gusts, px/s
    ctx.clearRect(0, 0, W, H);
    for (const f of flakes) {
      f.y += f.vy * dt; f.x += (Math.cos(t * f.freq + f.ph) * f.amp * .6 + wind * (.4 + f.z)) * dt;
      if (f.y > H + f.size) Object.assign(f, make(false)); else if (f.x < -f.size) f.x = W + f.size; else if (f.x > W + f.size) f.x = -f.size;
      ctx.globalAlpha = f.a; ctx.drawImage(sprites[f.ci][f.si], f.x - f.size, f.y - f.size, f.size * 2, f.size * 2);
    }
  };
  const start = () => { if (!raf && !document.hidden) { last = performance.now(); raf = requestAnimationFrame(frame); } };
  const stop = () => { cancelAnimationFrame(raf); raf = 0; };
  addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(resize, 150); });
  document.addEventListener('visibilitychange', () => (document.hidden ? stop() : start()));
  resize(); start();
})();
