// Progressive enhancement only. The server re-validates everything.
(() => {
  const RULES = {
    required: (v) => (v ? '' : 'This field is required.'),
    optional: () => '',
    email: (v) => (!v ? 'Email is required.' : /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? '' : 'Enter a valid email address.'),
    username: (v) => (/^[A-Za-z0-9_-]{3,20}$/.test(v) ? '' : 'Use 3–20 characters: letters, numbers, dashes and underscores.'),
    password: (v) => (!v ? 'Password is required.' : v.length < 10 ? 'Use at least 10 characters.'
      : v.length > 128 ? 'Use at most 128 characters.' : !/[A-Za-z]/.test(v) || !/\d/.test(v) ? 'Include at least one letter and one number.' : ''),
    confirm: (v, input) => (v === document.getElementById(input.dataset.match)?.value ? '' : 'Passwords do not match.')
  };

  function check(input) {
    const value = input.dataset.rule === 'required' || input.type === 'password' ? input.value : input.value.trim();
    const msg = (RULES[input.dataset.rule] || RULES.required)(value, input);
    const out = document.getElementById(input.id + '-err');
    input.closest('.mp-field').classList.toggle('has-error', !!msg);
    input.toggleAttribute('aria-invalid', !!msg);
    if (out) { out.textContent = msg; out.hidden = !msg; }
    return !msg;
  }

  document.querySelectorAll('form[data-validate]').forEach((form) => {
    const inputs = [...form.querySelectorAll('input[data-rule]')];
    inputs.forEach((i) => {
      i.addEventListener('blur', () => i.value && check(i));
      i.addEventListener('input', () => i.closest('.mp-field').classList.contains('has-error') && check(i));
    });
    form.addEventListener('submit', (e) => {
      const bad = inputs.filter((i) => !check(i));
      if (bad.length) { e.preventDefault(); bad[0].focus(); return; }
      form.querySelector('button[type=submit]').disabled = true; // prevent double submit
    });
  });

  document.querySelectorAll('[data-toggle-password]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const input = document.getElementById(btn.dataset.togglePassword);
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.setAttribute('aria-pressed', String(show));
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });
  });
})();
