// Admin > Settings: logo picker with preview, then a raw upload (the logo bytes are sent as the request body).
(() => {
  const file = document.querySelector('[data-logo-file]'), btn = document.querySelector('[data-logo-upload]');
  if (!file || !btn) return;
  const preview = document.querySelector('[data-logo-preview]'), status = document.querySelector('[data-logo-status]');
  const MAX = 1024 * 1024, TYPES = ['image/png', 'image/jpeg', 'image/webp', 'image/gif'];
  const say = (msg) => { status.textContent = msg; };

  file.addEventListener('change', () => {
    const f = file.files[0];
    btn.disabled = true; say('');
    if (!f) return;
    if (!TYPES.includes(f.type)) return say('Use a PNG, JPG, WebP or GIF image.');
    if (f.size > MAX) return say('The logo must be 1 MB or smaller.');
    const reader = new FileReader();                     // data: URLs are allowed by the CSP, blob: URLs are not
    reader.onload = () => { preview.src = reader.result; btn.disabled = false; };
    reader.readAsDataURL(f);
  });

  btn.addEventListener('click', async () => {
    const f = file.files[0];
    if (!f) return;
    btn.disabled = true; say('Uploading…');
    try {
      const res = await fetch('/admin/settings/logo', {
        method: 'POST', credentials: 'same-origin', body: f,
        headers: { 'Content-Type': 'application/octet-stream', 'X-CSRF-Token': btn.dataset.csrf, Accept: 'application/json' }
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) { say(data.error || 'Upload failed.'); btn.disabled = false; return; }
      location.reload();
    } catch { say('Upload failed. Check your connection and try again.'); btn.disabled = false; }
  });
})();
