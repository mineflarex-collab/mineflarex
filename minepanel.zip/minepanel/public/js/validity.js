'use strict';
// Live validity counter (left side of the validity strip). The expiry date on the right never changes.
(function () {
  function remaining(expiresAt, now) {
    var ms = expiresAt - now;
    if (ms <= 0) return 'Expired';
    if (ms < 86400000) {
      return Math.floor(ms / 3600000) + 'h ' + Math.floor(ms % 3600000 / 60000) + 'm ' + Math.floor(ms % 60000 / 1000) + 's';
    }
    var a = new Date(now), b = new Date(expiresAt);
    var y = b.getFullYear() - a.getFullYear(), mo = b.getMonth() - a.getMonth(), d = b.getDate() - a.getDate();
    if (d < 0) { mo -= 1; d += new Date(b.getFullYear(), b.getMonth(), 0).getDate(); }
    if (mo < 0) { y -= 1; mo += 12; }
    if (!y && !mo && !d) d = 1;
    return [y && y + 'y', mo && mo + 'm', d && d + 'd'].filter(Boolean).join(' ');
  }
  var boxes = document.querySelectorAll('[data-expires]');
  if (!boxes.length) return;
  function tick() {
    var now = Date.now();
    boxes.forEach(function (box) {
      var at = Number(box.getAttribute('data-expires')), left = box.querySelector('[data-validity-left]');
      if (left) left.textContent = remaining(at, now);
      var days = Math.floor((at - now) / 86400000);
      box.classList.toggle('is-expired', at <= now);
      box.classList.toggle('is-soon', at > now && days <= 7);
    });
  }
  tick();
  setInterval(tick, 1000);
})();
