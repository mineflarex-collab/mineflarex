// File manager: browse, search, create, rename, delete, upload (chunked, with progress), download and edit text files -
// all against the real server directory through the JSON API.
// File names are untrusted (players and plugins create them): they are only ever inserted with textContent / element nodes.
(() => {
  const root = document.querySelector('[data-files]');
  if (!root) return;
  const $ = (s, r = root) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const identifier = root.dataset.files, canWrite = root.dataset.canWrite === '1', csrf = root.dataset.csrf;
  const api = `/api/dashboard/servers/${encodeURIComponent(identifier)}/files`;
  const CHUNK = 32 * 1024 * 1024;                  // stays well below Cloudflare's 100 MB request limit
  const TEXT_EXT = /\.(txt|log|md|json|ya?ml|properties|cfg|conf|config|ini|toml|xml|html?|css|js|ts|sh|bat|csv|lang|mcmeta|secret|env|skript|sk|cmd|py|java|kts?|gradle|sql)$/i;
  const el = {
    crumbs: $('[data-files-crumbs]'), body: $('[data-files-body]'), empty: $('[data-files-empty]'), foot: $('[data-files-foot]'), toast: $('[data-files-toast]'),
    banner: $('[data-files-banner]'), wrap: $('[data-files-wrap]'), form: $('[data-files-search]'), q: $('[data-files-q]'), clear: $('[data-files-clear]'),
    all: $('[data-files-all]'), bulk: $('[data-files-bulk]'), bulkCount: $('[data-files-bulk-count]'), menu: $('[data-files-rowmenu]'),
    uploads: $('[data-files-uploads]'), uploadList: $('[data-files-upload-list]'), uploadTitle: $('[data-files-uploads-title]'), drop: $('[data-files-drop]')
  };
  const icons = $('[data-files-icons]').content;
  const icon = (n) => icons.querySelector(`[data-i="${n}"]`).firstElementChild.cloneNode(true);

  let state = { path: '/', q: '' }, rows = [], selected = new Set(), seq = 0, canWriteHere = canWrite, toastTimer = null, searchTimer = null;

  // ------------------------------------------------------------------ helpers
  const join = (dir, name) => `${dir === '/' ? '' : dir}/${name}`;
  const href = (path, q) => `?path=${encodeURIComponent(path)}${q ? `&q=${encodeURIComponent(q)}` : ''}`;
  const fmtSize = (n) => {
    if (n == null) return '—';
    if (n < 1024) return `${n} Bytes`;
    const u = ['KiB', 'MiB', 'GiB', 'TiB']; let i = -1; do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
    return `${n.toFixed(2)} ${u[i]}`;
  };
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], p2 = (n) => String(n).padStart(2, '0');
  const fmtDate = (ms) => { const d = new Date(ms); return `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()} ${p2(d.getHours())}:${p2(d.getMinutes())}`; };
  const tag = (name, cls, text) => { const e = document.createElement(name); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const ARCHIVE_EXT = /\.(zip|tar|tar\.gz|tgz|gz)$/i;
  const isArchive = (e) => e.type === 'file' && ARCHIVE_EXT.test(e.name);
  const isText = (e) => e.type === 'file' && TEXT_EXT.test(e.name);

  function toast(message, isError) {
    el.toast.textContent = message; el.toast.hidden = false; el.toast.classList.toggle('is-error', !!isError);
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.toast.hidden = true; }, isError ? 7000 : 3500);
  }

  async function call(method, url, body) {
    let res;
    try {
      res = await fetch(url, { method, headers: { Accept: 'application/json', ...(body ? { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf } : {}) }, body: body ? JSON.stringify(body) : undefined, credentials: 'same-origin' });
    } catch { return { ok: false, status: 0, data: { error: 'Could not reach the panel. Check your connection and try again.' } }; }
    if (res.status === 401) { location.href = `/login?next=${encodeURIComponent(location.pathname + location.search)}`; return { ok: false, status: 401, data: {} }; }
    let data = {}; try { data = await res.json(); } catch { /* not JSON */ }
    return { ok: res.ok, status: res.status, data };
  }

  // ------------------------------------------------------------------ rendering
  function renderCrumbs() {
    el.crumbs.replaceChildren(tag('span', 'mp-crumb-sep', '/'), tag('span', 'mp-crumb', 'home'), tag('span', 'mp-crumb-sep', '/'));
    const segs = state.path.split('/').filter(Boolean);
    const add = (label, path, last) => {
      if (el.crumbs.children.length > 3) el.crumbs.append(tag('span', 'mp-crumb-sep', '/'));
      if (last && !state.q) { const s = tag('span', 'mp-crumb is-current', label); s.setAttribute('aria-current', 'page'); el.crumbs.append(s); return; }
      const a = tag('a', 'mp-crumb', label); a.href = href(path); a.dataset.nav = path; el.crumbs.append(a);
    };
    add('container', '/', !segs.length);
    segs.forEach((s, i) => add(s, `/${segs.slice(0, i + 1).join('/')}`, i === segs.length - 1));
    if (state.q) { el.crumbs.append(tag('span', 'mp-crumb-sep', '/')); el.crumbs.append(tag('span', 'mp-crumb is-current', `search: ${state.q}`)); }
    else el.crumbs.append(tag('span', 'mp-crumb-sep', '/'));
  }

  function updateBulk() {
    if (!el.bulk) return;
    const n = selected.size;
    el.bulk.hidden = n === 0;
    el.bulkCount.textContent = `${n} selected`;
    if (el.all) { const total = rows.length; el.all.checked = total > 0 && n === total; el.all.indeterminate = n > 0 && n < total; }
  }

  function renderRows(isSearch) {
    el.body.replaceChildren();
    for (const e of rows) {
      const tr = tag('tr', 'mp-files-row');
      if (canWriteHere) {
        const td = tag('td', 'mp-files-check'), cb = document.createElement('input');
        cb.type = 'checkbox'; cb.dataset.path = e.path; cb.checked = selected.has(e.path); cb.setAttribute('aria-label', `Select ${e.name}`);
        td.append(cb); tr.append(td);
      }
      const nameTd = tag('td', 'mp-files-namecell'), line = tag('div', 'mp-files-nameline');
      const ico = tag('span', `mp-files-ico mp-ico-${e.type}`); ico.append(icon(e.type));
      let label;
      if (e.type === 'dir') { label = tag('a', 'mp-files-name', e.name); label.href = href(e.path); label.dataset.nav = e.path; }
      else if (isText(e)) { label = tag('button', 'mp-files-name mp-files-linkbtn', e.name); label.type = 'button'; label.dataset.act = 'edit'; label.dataset.path = e.path; }
      else { label = tag('span', 'mp-files-name', e.name); if (e.type === 'link') label.title = 'A link that points outside the server directory or to nothing'; }
      line.append(ico, label);
      if (e.symlink) line.append(tag('span', 'mp-files-badge', 'link'));
      nameTd.append(line);
      if (isSearch) { const p = tag('a', 'mp-files-where', e.parent === '/' ? 'server root' : e.parent); p.href = href(e.parent); p.dataset.nav = e.parent; nameTd.append(p); }
      tr.append(nameTd, tag('td', 'mp-files-size', e.type === 'dir' ? '-' : fmtSize(e.size)));
      const d = tag('td', 'mp-files-date', fmtDate(e.modified)); d.title = new Date(e.modified).toISOString(); tr.append(d);
      const act = tag('td', 'mp-files-act'), b = tag('button', 'mp-icon-btn'); b.type = 'button'; b.dataset.menu = e.path; b.title = `Actions for ${e.name}`; b.setAttribute('aria-label', `Actions for ${e.name}`); b.setAttribute('aria-haspopup', 'menu'); b.append(icon('dots'));
      act.append(b); tr.append(act);
      el.body.append(tr);
    }
    updateBulk();
  }

  function setEmpty(text) { el.empty.hidden = !text; el.empty.textContent = text || ''; }
  function banner(text) { el.banner.hidden = !text; el.banner.textContent = text || ''; }

  // ------------------------------------------------------------------ loading
  async function load({ keepToast = false } = {}) {
    const mine = ++seq;
    el.wrap.setAttribute('aria-busy', 'true');
    if (!keepToast) el.toast.hidden = true;
    const isSearch = !!state.q;
    const url = isSearch ? `${api}/search?path=${encodeURIComponent(state.path)}&q=${encodeURIComponent(state.q)}` : `${api}?path=${encodeURIComponent(state.path)}`;
    const r = await call('GET', url);
    if (mine !== seq) return;                       // a newer request replaced this one
    el.wrap.setAttribute('aria-busy', 'false');
    el.q.placeholder = 'Search…';
    el.clear.hidden = !state.q;
    if (!r.ok) {
      rows = []; selected.clear(); renderRows(false); renderCrumbs(); banner('');
      el.foot.textContent = '';
      setEmpty(r.data.error || 'Could not load this folder.');
      if (r.status === 404 || r.status === 400 || r.status === 409) { const a = tag('a', null, ' Go to the server root'); a.href = href('/'); a.dataset.nav = '/'; el.empty.append(a); }
      return;
    }
    rows = isSearch ? r.data.results : r.data.entries.map((e) => ({ ...e, path: join(r.data.path, e.name), parent: r.data.path }));
    state.path = r.data.path;
    if (!isSearch) canWriteHere = canWrite && r.data.canWrite;
    for (const p of [...selected]) if (!rows.some((x) => x.path === p)) selected.delete(p);
    renderCrumbs(); renderRows(isSearch);
    if (isSearch) {
      const why = { results: `Showing the first ${rows.length} matches. Narrow the search to see the rest.`, time: 'The search took too long and was stopped. Showing what was found so far.', scanned: 'This folder is very large; the search stopped early. Showing what was found so far.' }[r.data.reason];
      banner(why || '');
      setEmpty(rows.length ? '' : `No files or folders in ${state.path === '/' ? 'the server' : state.path} match “${state.q}”.`);
      el.foot.textContent = rows.length ? `${rows.length} match${rows.length === 1 ? '' : 'es'}` : '';
    } else {
      banner(r.data.truncated ? `This folder has ${r.data.total} items; only the first ${rows.length} are shown. Use search to find the rest.` : '');
      setEmpty(rows.length ? '' : 'This folder is empty.');
      const dirs = rows.filter((x) => x.type === 'dir').length;
      el.foot.textContent = rows.length ? `${dirs} folder${dirs === 1 ? '' : 's'}, ${rows.length - dirs} file${rows.length - dirs === 1 ? '' : 's'}` : '';
    }
  }

  function go(path, q = '', push = true) {
    state = { path, q };
    if (push) history.pushState(null, '', href(path, q));
    selected.clear(); el.q.value = q;
    return load();
  }
  const fromUrl = () => { const u = new URLSearchParams(location.search); return { path: u.get('path') || '/', q: u.get('q') || '' }; };
  window.addEventListener('popstate', () => { const s = fromUrl(); state = s; selected.clear(); el.q.value = s.q; load(); });

  // ------------------------------------------------------------------ row menu (the "..." button)
  const closeMenus = () => { el.menu.hidden = true; const cm = $('[data-files-create-menu]', document); if (cm) { cm.hidden = true; $('[data-files-create]', document).setAttribute('aria-expanded', 'false'); } };
  function openRowMenu(btn, e) {
    const items = [];
    if (e.type === 'file') {
      if (!isArchive(e) && !/\.(jar|png|jpe?g|gif|webp|dat|mca|db|exe|so|dll)$/i.test(e.name) && (e.size == null || e.size <= 1024 * 1024)) items.push(['edit', 'edit', canWrite ? 'Edit' : 'View']);
    }
    if (canWriteHere) items.push(['rename', 'edit', 'Rename'], ['move', 'move', 'Move'], ['copy', 'copy', 'Copy'], ['perm', 'lock', 'Permissions']);
    if (canWriteHere && isArchive(e)) items.push(['unarchive', 'archive', 'Extract']);
    if (e.type === 'file') items.push(['download', 'download', 'Download']);
    if (canWriteHere) items.push(['delete', 'trash', 'Delete', true]);
    if (!items.length) return;
    el.menu.replaceChildren();
    for (const [act, ico, text, danger] of items) {
      const b = tag('button', danger ? 'is-danger' : ''); b.type = 'button'; b.setAttribute('role', 'menuitem'); b.dataset.act = act; b.dataset.path = e.path; b.append(icon(ico), document.createTextNode(` ${text}`)); el.menu.append(b);
    }
    el.menu.hidden = false;
    const r = btn.getBoundingClientRect(), w = el.menu.offsetWidth, h = el.menu.offsetHeight;
    el.menu.style.left = `${Math.max(8, Math.min(window.innerWidth - w - 8, r.right - w))}px`;
    el.menu.style.top = `${r.bottom + h + 8 > window.innerHeight ? Math.max(8, r.top - h - 4) : r.bottom + 4}px`;
    el.menu.querySelector('button').focus();
  }

  // ------------------------------------------------------------------ navigation + selection + actions
  root.addEventListener('click', (ev) => {
    const nav = ev.target.closest('[data-nav]');
    if (nav && !ev.ctrlKey && !ev.metaKey && !ev.shiftKey && ev.button === 0) { ev.preventDefault(); go(nav.dataset.nav); return; }
    const m = ev.target.closest('[data-menu]');
    if (m) { ev.stopPropagation(); const open = !el.menu.hidden && el.menu.dataset.for === m.dataset.menu; closeMenus(); if (!open) { el.menu.dataset.for = m.dataset.menu; const e = rows.find((x) => x.path === m.dataset.menu); if (e) openRowMenu(m, e); } return; }
    const act = ev.target.closest('[data-act]');
    if (act) {
      closeMenus();
      const e = rows.find((x) => x.path === act.dataset.path); if (!e) return;
      if (act.dataset.act === 'rename') openName('rename', e);
      else if (act.dataset.act === 'delete') openDelete([e]);
      else if (act.dataset.act === 'unarchive') openUnarchive(e);
      else if (act.dataset.act === 'move') openMove([e]);
      else if (act.dataset.act === 'copy') doCopy(e);
      else if (act.dataset.act === 'perm') openPerm(e);
      else if (act.dataset.act === 'edit') openEditor(e);
      else if (act.dataset.act === 'download') { const a = tag('a'); a.href = `${api}/download?path=${encodeURIComponent(e.path)}`; a.download = e.name; document.body.append(a); a.click(); a.remove(); }
    }
  });
  document.addEventListener('click', (ev) => { if (!ev.target.closest('.mp-files-popup, [data-menu], [data-files-create]')) closeMenus(); });
  document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') closeMenus(); });
  window.addEventListener('scroll', closeMenus, true); window.addEventListener('resize', closeMenus);
  root.addEventListener('change', (ev) => {
    const t = ev.target;
    if (t.matches('tbody input[type="checkbox"]')) { if (t.checked) selected.add(t.dataset.path); else selected.delete(t.dataset.path); updateBulk(); }
    else if (t === el.all) { selected = new Set(t.checked ? rows.map((x) => x.path) : []); el.body.querySelectorAll('input[type="checkbox"]').forEach((c) => { c.checked = t.checked; }); updateBulk(); }
  });
  $('[data-files-bulk-clear]')?.addEventListener('click', () => { selected.clear(); el.body.querySelectorAll('input[type="checkbox"]').forEach((c) => { c.checked = false; }); updateBulk(); });
  $('[data-files-bulk-delete]')?.addEventListener('click', () => openDelete(rows.filter((x) => selected.has(x.path))));
  $('[data-files-refresh]', document).addEventListener('click', () => load());

  // Create dropdown
  const createBtn = $('[data-files-create]', document), createMenu = $('[data-files-create-menu]', document);
  createBtn?.addEventListener('click', (ev) => { ev.stopPropagation(); const open = createMenu.hidden; closeMenus(); createMenu.hidden = !open; createBtn.setAttribute('aria-expanded', String(open)); });

  // ------------------------------------------------------------------ search
  const runSearch = () => { clearTimeout(searchTimer); const q = el.q.value.trim(); if (q === state.q) return; go(state.path, q); };
  el.form.addEventListener('submit', (ev) => { ev.preventDefault(); runSearch(); });
  el.q.addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(runSearch, 500); });
  el.q.addEventListener('keydown', (ev) => { if (ev.key === 'Escape' && (el.q.value || state.q)) { el.q.value = ''; runSearch(); } });
  el.clear.addEventListener('click', () => { el.q.value = ''; runSearch(); el.q.focus(); });

  // ------------------------------------------------------------------ create / rename dialog
  const dlg = $('[data-files-dialog]', document), dform = dlg && $('[data-files-dialog-form]', dlg);
  let dctx = null;
  function dErr(msg) { const p = $('[data-files-error]', dlg); p.hidden = !msg; p.textContent = msg || ''; $('[data-files-name]', dlg).setAttribute('aria-invalid', msg ? 'true' : 'false'); }
  function openName(kind, entry) {
    if (!dlg) return;
    closeMenus();
    dctx = { kind, entry };
    const input = $('[data-files-name]', dlg);
    const where = state.path === '/' ? 'the server root' : state.path;
    $('[data-files-dialog-title]', dlg).textContent = kind === 'rename' ? 'Rename' : kind === 'folder' ? 'New folder' : kind === 'code' ? 'Code editor' : 'New file';
    $('[data-files-label]', dlg).textContent = kind === 'rename' ? 'New name' : kind === 'code' ? 'File name' : 'Name';
    $('[data-files-dialog-hint]', dlg).textContent = kind === 'rename' ? `Renaming “${entry.name}”. It stays in the same folder.` : kind === 'code' ? `Opens the file in ${where} in the editor. It is created if it does not exist yet.` : `It will be created in ${where}.`;
    $('[data-files-dialog-ok]', dlg).textContent = kind === 'rename' ? 'Rename' : kind === 'code' ? 'Open' : 'Create';
    input.value = kind === 'rename' ? entry.name : ''; dErr('');
    dlg.showModal(); input.focus();
    if (kind === 'rename') { const dot = entry.type === 'dir' ? -1 : entry.name.lastIndexOf('.'); input.setSelectionRange(0, dot > 0 ? dot : entry.name.length); }
  }
  $$('[data-files-new]').forEach((b) => b.addEventListener('click', () => openName(b.dataset.filesNew)));
  if (dlg) {
    $('[data-files-dialog-cancel]', dlg).addEventListener('click', () => dlg.close());
    dform.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const name = $('[data-files-name]', dlg).value, ok = $('[data-files-dialog-ok]', dlg);
      if (!name.trim()) return dErr('Enter a name.');
      ok.disabled = true;
      const { kind, entry } = dctx;
      if (kind === 'code') {
        ok.disabled = true;
        const path = join(state.path, name.trim());
        let made = await call('POST', `${api}/create`, { path: state.path, name, type: 'file' });
        ok.disabled = false;
        if (!made.ok && made.data.code !== 'exists') return dErr(made.data.error || 'That did not work. Try again.');
        dlg.close(); if (made.ok) load({ keepToast: true });
        return openEditor({ path, name: name.trim(), type: 'file' });
      }
      const r = kind === 'rename' ? await call('POST', `${api}/rename`, { path: entry.path, name }) : await call('POST', `${api}/create`, { path: state.path, name, type: kind });
      ok.disabled = false;
      if (!r.ok) return dErr(r.data.error || 'That did not work. Try again.');
      dlg.close();
      toast(kind === 'rename' ? (r.data.entry.unchanged ? 'The name was not changed.' : `Renamed to “${r.data.entry.name}”.`) : `Created ${kind === 'folder' ? 'folder' : 'file'} “${r.data.entry.name}”.`);
      load({ keepToast: true });
    });
  }


  // ------------------------------------------------------------------ code editor button (opens the selected text file, or asks for a file name)
  $('[data-files-code]', document)?.addEventListener('click', () => {
    const picked = rows.filter((x) => selected.has(x.path) && x.type === 'file');
    if (picked.length === 1 && (picked[0].size == null || picked[0].size <= 1024 * 1024)) return openEditor(picked[0]);
    if (canWrite) return openName('code');
    toast('Click a text file in the list to view it.', false);
  });

  // ------------------------------------------------------------------ move
  const mdlg = $('[data-files-move]', document);
  let moving = [];
  function mErr(msg) { const p = $('[data-files-move-error]', mdlg); p.hidden = !msg; p.textContent = msg || ''; }
  function openMove(entries) {
    if (!mdlg || !entries.length) return;
    closeMenus(); moving = entries; mErr('');
    $('[data-files-move-title]', mdlg).textContent = entries.length === 1 ? `Move “${entries[0].name}”` : `Move ${entries.length} items`;
    $('[data-files-move-hint]', mdlg).textContent = 'Type the folder it should be moved into.';
    const input = $('[data-files-move-to]', mdlg); input.value = state.q ? '/' : state.path;
    mdlg.showModal(); input.focus(); input.select();
  }
  if (mdlg) {
    $('[data-files-move-cancel]', mdlg).addEventListener('click', () => mdlg.close());
    $('[data-files-move-form]', mdlg).addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const to = $('[data-files-move-to]', mdlg).value.trim() || '/', ok = $('[data-files-move-ok]', mdlg);
      ok.disabled = true;
      const r = await call('POST', `${api}/move`, { paths: moving.map((x) => x.path), to: to.startsWith('/') ? to : `/${to}` });
      ok.disabled = false;
      if (!r.ok && !r.data.results) return mErr(r.data.error || 'That did not work. Try again.');
      const bad = (r.data.results || []).find((x) => !x.ok);
      if (bad && !r.data.moved) return mErr(bad.error);
      mdlg.close(); selected.clear();
      toast(bad ? `Moved ${r.data.moved}, but “${bad.path}”: ${bad.error}` : `Moved ${r.data.moved} item${r.data.moved === 1 ? '' : 's'}.`, !!bad);
      load({ keepToast: true });
    });
  }
  $('[data-files-bulk-move]', document)?.addEventListener('click', () => openMove(rows.filter((x) => selected.has(x.path))));

  // ------------------------------------------------------------------ copy (next to the original, "name copy.ext")
  async function doCopy(e) {
    toast(`Copying “${e.name}”…`);
    const r = await call('POST', `${api}/copy`, { path: e.path });
    if (!r.ok) return toast(r.data.error || 'Could not copy that.', true);
    toast(`Copied to “${r.data.entry.name}”.`); load({ keepToast: true });
  }

  // ------------------------------------------------------------------ permissions (rwx grid <-> octal mode)
  const pdlg = $('[data-files-perm]', document);
  let permFor = null;
  if (pdlg) {
    const boxes = $$('[data-perm]', pdlg), modeIn = $('[data-perm-mode]', pdlg);
    const fromBoxes = () => { const d = [0, 0, 0]; boxes.forEach((b) => { if (b.checked) d['ugo'.indexOf(b.dataset.perm[0])] += Number(b.dataset.bit); }); modeIn.value = d.join(''); };
    const toBoxes = (m) => boxes.forEach((b) => { b.checked = !!(Number(m['ugo'.indexOf(b.dataset.perm[0])]) & Number(b.dataset.bit)); });
    boxes.forEach((b) => b.addEventListener('change', fromBoxes));
    modeIn.addEventListener('input', () => { if (/^[0-7]{3}$/.test(modeIn.value)) toBoxes(modeIn.value); });
    const pErr = (msg) => { const p = $('[data-files-perm-error]', pdlg); p.hidden = !msg; p.textContent = msg || ''; };
    window.mpOpenPerm = (e) => {
      closeMenus(); permFor = e; pErr('');
      const m = /^[0-7]{3}$/.test(e.mode || '') ? e.mode : (e.type === 'dir' ? '755' : '644');
      $('[data-files-perm-hint]', pdlg).textContent = `“${e.name}” · currently ${e.mode || 'unknown'}`;
      modeIn.value = m; toBoxes(m); pdlg.showModal(); modeIn.focus();
    };
    $('[data-files-perm-cancel]', pdlg).addEventListener('click', () => pdlg.close());
    $('[data-files-perm-form]', pdlg).addEventListener('submit', async (ev) => {
      ev.preventDefault();
      if (!/^[0-7]{3}$/.test(modeIn.value)) return pErr('Enter three digits from 0 to 7, like 644 or 755.');
      const ok = $('[data-files-perm-ok]', pdlg); ok.disabled = true;
      const r = await call('POST', `${api}/chmod`, { paths: [permFor.path], mode: modeIn.value });
      ok.disabled = false;
      const bad = (r.data.results || []).find((x) => !x.ok);
      if (!r.ok || bad) return pErr(bad ? bad.error : (r.data.error || 'That did not work. Try again.'));
      pdlg.close(); toast(`Permissions of “${permFor.name}” set to ${modeIn.value}.`); load({ keepToast: true });
    });
  }
  const openPerm = (e) => window.mpOpenPerm?.(e);

  // ------------------------------------------------------------------ delete dialog
  const cdlg = $('[data-files-confirm]', document);
  let doomed = [];
  function openDelete(entries) {
    if (!cdlg || !entries.length) return;
    doomed = entries;
    const list = $('[data-files-confirm-list]', cdlg); list.replaceChildren();
    for (const e of entries.slice(0, 8)) list.append(tag('li', null, `${e.type === 'dir' ? '📁 ' : ''}${e.path}`));
    if (entries.length > 8) list.append(tag('li', 'mp-muted', `…and ${entries.length - 8} more`));
    $('[data-files-confirm-text]', cdlg).textContent = entries.length === 1 ? `Delete “${entries[0].name}”?` : `Delete these ${entries.length} items?`;
    $('[data-files-confirm-online]', cdlg).hidden = !['online', 'starting'].includes(root.dataset.status);
    const err = $('[data-files-confirm-error]', cdlg); err.hidden = true;
    cdlg.showModal(); $('[data-files-confirm-cancel]', cdlg).focus();
  }
  if (cdlg) {
    $('[data-files-confirm-cancel]', cdlg).addEventListener('click', () => cdlg.close());
    $('[data-files-confirm-form]', cdlg).addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const ok = $('[data-files-confirm-ok]', cdlg), err = $('[data-files-confirm-error]', cdlg);
      ok.disabled = true;
      const r = await call('POST', `${api}/delete`, { paths: doomed.map((e) => e.path), confirm: true });
      ok.disabled = false;
      if (r.status === 200 || r.status === 207) {
        cdlg.close(); selected.clear();
        const { deleted, failed, results } = r.data;
        if (failed) toast(`Deleted ${deleted}, but ${failed} could not be deleted: ${results.find((x) => !x.ok).error}`, true);
        else toast(`Deleted ${deleted} item${deleted === 1 ? '' : 's'}.`);
        return load({ keepToast: true });
      }
      err.hidden = false; err.textContent = r.data.error || 'That did not work. Try again.';
    });
  }


  // ------------------------------------------------------------------ unarchive (background job on the server, polled here)
  const ua = $('[data-unarch]', document), udlg = $('[data-unarch-dialog]', document);
  let uaTimer = null, uaJob = null, uaTarget = null;
  const fmtBytes = (n) => fmtSize(n).replace(' Bytes', ' B');
  function uaRender(j) {
    if (!ua) return;
    uaJob = j; ua.hidden = false;
    const running = j.state === 'running', pct = j.archiveBytes > 0 ? Math.min(100, Math.floor((j.readBytes / j.archiveBytes) * 100)) : (running ? 0 : 100);
    ua.classList.toggle('is-done', j.state === 'done'); ua.classList.toggle('is-failed', j.state === 'failed' || j.state === 'cancelled');
    $('[data-unarch-title]', ua).textContent = running ? (j.cancelled ? 'Cancelling…' : 'Unarchiving…') : j.state === 'done' ? 'Unarchived' : j.state === 'cancelled' ? 'Cancelled' : 'Unarchive failed';
    $('[data-unarch-file]', ua).textContent = `${j.file} → ${j.dest}`;
    $('[data-unarch-bar]', ua).value = j.state === 'done' ? 100 : pct;
    $('[data-unarch-bar]', ua).hidden = !running;
    $('[data-unarch-pct]', ua).textContent = j.state === 'done' ? '100%' : running ? `${pct}%` : '';
    $('[data-unarch-meta]', ua).textContent = running ? `${fmtBytes(j.readBytes)} of ${fmtBytes(j.archiveBytes)} read` : j.state === 'done' ? `${j.files} file${j.files === 1 ? '' : 's'}, ${j.dirs} folder${j.dirs === 1 ? '' : 's'}, ${fmtBytes(j.bytes)} written` : (j.error || 'Stopped.');
    $('[data-unarch-ring]', ua).hidden = false;
    $('[data-unarch-cancel]', ua).hidden = !running || !!j.cancelled; $('[data-unarch-dismiss]', ua).hidden = running;
    const sk = $('[data-unarch-skipped]', ua);
    sk.hidden = !j.skipped; sk.textContent = j.skipped ? `${j.skipped} entr${j.skipped === 1 ? 'y was' : 'ies were'} skipped: ${j.skippedSamples.slice(0, 5).map((x) => `${x.name} (${x.reason})`).join(', ')}${j.skipped > 5 ? ', …' : ''}` : '';
  }
  async function uaPoll() {
    clearTimeout(uaTimer);
    const r = await call('GET', `${api}/unarchive`);
    if (!r.ok || !r.data.job) { if (uaJob && uaJob.state === 'running') uaTimer = setTimeout(uaPoll, 3000); return; }
    const j = r.data.job, was = uaJob && uaJob.id === j.id ? uaJob.state : null;
    uaRender(j);
    if (j.state === 'running') { uaTimer = setTimeout(uaPoll, 1500); return; }
    if (was === 'running') { toast(j.state === 'done' ? `Unarchived ${j.files} file${j.files === 1 ? '' : 's'} into ${j.dest}.` : j.state === 'cancelled' ? 'Extraction cancelled. Files already extracted were kept.' : (j.error || 'Extraction failed.'), j.state !== 'done'); load({ keepToast: true }); }
  }
  function openUnarchive(entry) {
    if (!udlg) return;
    uaTarget = entry;
    $('[data-unarch-text]', udlg).textContent = `Extract “${entry.name}” (${fmtSize(entry.size)}).`;
    const into = $('[data-unarch-into]', udlg); into.value = entry.parent || state.path || '/';
    const err = $('[data-unarch-error]', udlg); err.hidden = true;
    $('[data-unarch-online]', udlg).hidden = !['online', 'starting'].includes(root.dataset.status);
    udlg.showModal(); into.focus(); into.select();
  }
  if (udlg) {
    $('[data-unarch-dialog-cancel]', udlg).addEventListener('click', () => udlg.close());
    $('[data-unarch-form]', udlg).addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const ok = $('[data-unarch-ok]', udlg), err = $('[data-unarch-error]', udlg), into = $('[data-unarch-into]', udlg).value.trim() || '/';
      ok.disabled = true;
      const r = await call('POST', `${api}/unarchive`, { path: uaTarget.path, into: into.startsWith('/') ? into : `/${into}` });
      ok.disabled = false;
      if (!r.ok) { err.hidden = false; err.textContent = r.data.error || 'That did not work. Try again.'; return; }
      udlg.close(); uaRender(r.data.job); uaTimer = setTimeout(uaPoll, 800);
    });
    $('[data-unarch-cancel]', ua).addEventListener('click', async () => { const r = await call('POST', `${api}/unarchive/cancel`, {}); if (r.ok) uaRender(r.data.job); else toast(r.data.error || 'Could not cancel.', true); });
    $('[data-unarch-dismiss]', ua).addEventListener('click', () => { ua.hidden = true; });
    // A job started earlier (or in another tab) keeps running on the server: show it again after a reload.
    call('GET', `${api}/unarchive`).then((r) => { const j = r.ok && r.data.job; if (j && (j.state === 'running' || Date.now() - j.finishedAt < 120000)) { uaRender(j); if (j.state === 'running') uaTimer = setTimeout(uaPoll, 1500); } });
  }

  // ------------------------------------------------------------------ editor
  const edlg = $('[data-files-editor]', document);
  let editing = null;
  async function openEditor(entry) {
    if (!edlg) return;
    const r = await call('GET', `${api}/content?path=${encodeURIComponent(entry.path)}`);
    if (!r.ok) return toast(r.data.error || 'Could not open that file.', true);
    editing = { path: entry.path, original: r.data.content, canWrite: canWrite && r.data.canWrite };
    const ta = $('[data-files-editor-text]', edlg);
    $('[data-files-editor-title]', edlg).textContent = r.data.name;
    $('[data-files-editor-meta]', edlg).textContent = `${entry.path} · ${fmtSize(r.data.size)}${editing.canWrite ? '' : ' · read only'}`;
    ta.value = r.data.content; ta.readOnly = !editing.canWrite;
    const err = $('[data-files-editor-error]', edlg); err.hidden = true;
    edlg.showModal(); ta.focus(); ta.setSelectionRange(0, 0);
  }
  async function saveEditor() {
    if (!editing || !editing.canWrite) return;
    const ta = $('[data-files-editor-text]', edlg), err = $('[data-files-editor-error]', edlg), btn = $('[data-files-editor-save]', edlg);
    btn.disabled = true;
    const r = await call('POST', `${api}/save`, { path: editing.path, content: ta.value });
    btn.disabled = false;
    if (!r.ok) { err.hidden = false; err.textContent = r.data.error || 'Could not save.'; return; }
    editing.original = ta.value; err.hidden = true; toast(`Saved “${r.data.entry.name}”.`); load({ keepToast: true });
  }
  if (edlg) {
    const ta = $('[data-files-editor-text]', edlg);
    const close = () => { if (editing?.canWrite && ta.value !== editing.original && !confirm('Discard your unsaved changes?')) return; edlg.close(); editing = null; };
    $('[data-files-editor-close]', edlg).addEventListener('click', close);
    edlg.addEventListener('cancel', (ev) => { ev.preventDefault(); close(); });
    $('[data-files-editor-form]', edlg).addEventListener('submit', (ev) => { ev.preventDefault(); saveEditor(); });
    ta.addEventListener('keydown', (ev) => {
      if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === 's') { ev.preventDefault(); saveEditor(); }
      else if (ev.key === 'Tab' && !ta.readOnly) { ev.preventDefault(); ta.setRangeText('  ', ta.selectionStart, ta.selectionEnd, 'end'); }
    });
  }

  // ------------------------------------------------------------------ upload (split into chunks, progress per file, cancellable)
  const queue = []; let running = false, total = 0;
  const upInput = $('[data-files-input]', document);
  function refreshUploadCard() {
    const n = el.uploadList.children.length;
    el.uploads.hidden = n === 0;
    el.uploadTitle.textContent = `Uploading ${n} file${n === 1 ? '' : 's'}`;
  }
  function sendChunk(job, offset, blob, overwrite) {
    return new Promise((resolve) => {
      const x = new XMLHttpRequest();
      job.xhr = x;
      x.open('POST', `${api}/upload?path=${encodeURIComponent(job.dir)}&name=${encodeURIComponent(job.file.name)}&offset=${offset}&total=${job.file.size}${overwrite ? '&overwrite=1' : ''}`);
      x.setRequestHeader('Content-Type', 'application/octet-stream'); x.setRequestHeader('X-CSRF-Token', csrf); x.setRequestHeader('Accept', 'application/json');
      x.upload.onprogress = (e) => job.progress(offset + e.loaded);
      x.onload = () => { let data = {}; try { data = JSON.parse(x.responseText); } catch { /* not JSON */ } resolve({ ok: x.status >= 200 && x.status < 300, status: x.status, data }); };
      x.onerror = () => resolve({ ok: false, status: 0, data: { error: 'Network error. Check your connection.' } });
      x.onabort = () => resolve({ ok: false, status: -1, data: {} });
      x.send(blob);
    });
  }
  async function runJob(job) {
    let overwrite = false, offset = 0;
    const size = job.file.size;
    for (;;) {
      const end = Math.min(size, offset + CHUNK);
      const r = await sendChunk(job, offset, job.file.slice(offset, end), overwrite);
      if (job.cancelled) return { cancelled: true };
      if (r.status === 409 && r.data.code === 'exists' && offset === 0 && !overwrite) {
        if (!confirm(`“${job.file.name}” already exists here. Replace it?`)) return { skipped: true };
        overwrite = true; continue;
      }
      if (!r.ok) return { error: r.data.error || `Upload failed (${r.status || 'network'}).` };
      offset = end; job.progress(offset);
      if (r.data.done) return { done: true };
    }
  }
  async function pump() {
    if (running) return; running = true;
    let okCount = 0;
    while (queue.length) {
      const job = queue.shift();
      const res = await runJob(job);
      job.row.remove(); refreshUploadCard();
      if (res.done) okCount++;
      else if (res.error) toast(`“${job.file.name}”: ${res.error}`, true);
      if (res.error || res.cancelled) call('POST', `${api}/upload/cancel`, { path: job.dir, name: job.file.name });
    }
    running = false;
    if (okCount) { toast(`Uploaded ${okCount} file${okCount === 1 ? '' : 's'}.`); load({ keepToast: true }); }
  }
  function addFiles(list, relDirOf) {
    if (!canWriteHere) return toast('You do not have permission to upload here.', true);
    for (const file of list) {
      if (!file.name || file.name.includes('/')) continue;
      const row = tag('li', 'mp-up'), ring = tag('span', 'mp-up-ring'), info = tag('div', 'mp-up-info'), pct = tag('span', 'mp-up-pct', '0%'), x = tag('button', 'mp-icon-btn mp-up-x'); x.type = 'button'; x.setAttribute('aria-label', `Cancel upload of ${file.name}`); x.append(icon('x'));
      const name = tag('strong', null, file.name), meta = tag('span', 'mp-muted', `Waiting… · ${fmtSize(file.size)}`);
      info.append(name, meta); row.append(ring, info, pct, x); el.uploadList.append(row);
      const base = state.q ? '/' : state.path, sub = relDirOf ? relDirOf(file) : '';
      const job = { file, dir: sub ? join(base, sub) : base, row, xhr: null, cancelled: false,
        progress(done) { const p = file.size ? Math.min(100, Math.floor((done / file.size) * 100)) : 100; pct.textContent = `${p}%`; meta.textContent = `Uploading… · ${fmtSize(done).replace(/^0 Bytes$/, '0 Bytes')} / ${fmtSize(file.size)}`; } };
      x.addEventListener('click', () => { job.cancelled = true; job.xhr?.abort(); const i = queue.indexOf(job); if (i >= 0) { queue.splice(i, 1); row.remove(); refreshUploadCard(); call('POST', `${api}/upload/cancel`, { path: job.dir, name: file.name }); } });
      queue.push(job);
    }
    refreshUploadCard(); pump();
  }
  $('[data-files-upload]', document)?.addEventListener('click', () => { closeMenus(); upInput.click(); });
  upInput?.addEventListener('change', () => { addFiles([...upInput.files]); upInput.value = ''; });
  // Upload folder: create the folder tree first, then upload every file into its own folder.
  const dirInput = $('[data-files-folder-input]', document);
  $('[data-files-upload-folder]', document)?.addEventListener('click', () => { closeMenus(); dirInput?.click(); });
  dirInput?.addEventListener('change', async () => {
    const files = [...dirInput.files]; dirInput.value = '';
    if (!files.length) return;
    const relDir = (f) => (f.webkitRelativePath || '').split('/').slice(0, -1).join('/');
    const base = state.q ? '/' : state.path, dirs = new Set();
    for (const f of files) { const parts = relDir(f).split('/').filter(Boolean); for (let i = 1; i <= parts.length; i++) dirs.add(parts.slice(0, i).join('/')); }
    toast(`Preparing ${dirs.size} folder${dirs.size === 1 ? '' : 's'}…`);
    for (const d of [...dirs].sort((a, b) => a.split('/').length - b.split('/').length)) {
      const parts = d.split('/'), name = parts.pop(), r = await call('POST', `${api}/create`, { path: join(base, parts.join('/')) || '/', name, type: 'folder' });
      if (!r.ok && r.data.code !== 'exists') return toast(`Could not create folder “${d}”: ${r.data.error || 'error'}`, true);
    }
    addFiles(files, relDir);
  });
  // drag & drop
  let dragDepth = 0;
  const hasFiles = (ev) => [...(ev.dataTransfer?.types || [])].includes('Files');
  if (canWrite) {
    window.addEventListener('dragenter', (ev) => { if (!hasFiles(ev)) return; ev.preventDefault(); dragDepth++; el.drop.hidden = false; });
    window.addEventListener('dragover', (ev) => { if (hasFiles(ev)) ev.preventDefault(); });
    window.addEventListener('dragleave', (ev) => { if (!hasFiles(ev)) return; dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) el.drop.hidden = true; });
    window.addEventListener('drop', (ev) => { if (!hasFiles(ev)) return; ev.preventDefault(); dragDepth = 0; el.drop.hidden = true; addFiles([...ev.dataTransfer.files].filter((f) => f.size > 0 || f.type)); });
  }
  window.addEventListener('beforeunload', (ev) => { if (running || queue.length) { ev.preventDefault(); ev.returnValue = ''; } });

  state = fromUrl(); el.q.value = state.q; load();
})();
