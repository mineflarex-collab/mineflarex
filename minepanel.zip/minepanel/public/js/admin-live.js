'use strict';
// Admin pages: refreshes the VPS meters and the usage of every server row by itself (red "Live" tag).
(() => {
  const INTERVAL = 3000;
  const tags = document.querySelectorAll('[data-live-indicator]');
  const panel = document.querySelector('[data-capacity]');
  const rows = document.querySelectorAll('[data-srv]');
  if (!panel && !rows.length) return;
  const initialFull = panel ? panel.dataset.full === '1' : null;
  let busy = false;

  const state = (ok) => tags.forEach((t) => { t.classList.toggle('is-off', !ok); t.lastChild.textContent = ok ? 'Live' : 'Offline'; });

  function apply(d) {
    if (panel) {
      for (const [key, r] of Object.entries(d.vps)) {
        const el = panel.querySelector(`[data-vps="${key}"]`); if (!el) continue;
        el.classList.toggle('is-full', r.full);
        el.querySelector('[data-vps-text]').textContent = r.text;
        el.querySelector('[data-vps-pct]').textContent = `${r.pct}%`;
        el.querySelector('[data-vps-bar]').value = Math.min(100, r.pct);
        el.querySelector('[data-vps-sub]').textContent = r.sub;
        el.querySelector('[data-vps-full]').textContent = r.full ? ' · FULL' : '';
      }
      if (initialFull !== null && d.full !== initialFull) { location.reload(); return; }   // the "VPS is full" warning and the Create buttons change
    }
    const by = new Map(d.servers.map((s) => [s.identifier, s]));
    rows.forEach((cell) => {
      const s = by.get(cell.dataset.srv); if (!s) return;
      const v = s[cell.dataset.f];
      if (cell.dataset.f === 'badge') { if (cell.innerHTML !== v) cell.innerHTML = v; }
      else if (cell.textContent !== v) cell.textContent = v;
    });
  }

  async function tick() {
    if (busy || document.hidden) return;
    busy = true;
    try {
      const res = await fetch('/api/admin/usage', { headers: { Accept: 'application/json' }, credentials: 'same-origin', cache: 'no-store' });
      if (!res.ok) throw new Error(String(res.status));
      apply(await res.json()); state(true);
    } catch { state(false); }
    busy = false;
  }
  setInterval(tick, INTERVAL);
  document.addEventListener('visibilitychange', tick);
  tick();
})();
