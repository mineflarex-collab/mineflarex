// Back button (every page except the overview): goes to the previous page, or to the link's own href when there is no history.
document.addEventListener('click', (e) => {
  const a = e.target.closest('a[data-back]');
  if (!a || e.ctrlKey || e.metaKey || e.shiftKey || e.button !== 0) return;
  if (history.length > 1 && document.referrer && new URL(document.referrer).origin === location.origin) { e.preventDefault(); history.back(); }
});
