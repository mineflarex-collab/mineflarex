// Live updates + copy buttons + filter auto-submit. Every page is fully usable without JS.
(() => {
  const get = (obj, path) => path.split('.').reduce((o, k) => (o == null ? o : o[k]), obj);

  document.querySelectorAll('[data-copy]').forEach((btn) => btn.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(btn.dataset.copy); const t = btn.textContent; btn.textContent = 'Copied'; setTimeout(() => { btn.textContent = t; }, 1200); }
    catch { /* clipboard unavailable */ }
  }));

  // Filter drop-downs apply immediately; the Search button still works without JS.
  document.querySelectorAll('form[data-autosubmit] select').forEach((sel) => sel.addEventListener('change', () => sel.form.submit()));

  // Search modal (Ctrl/Cmd+K or the "Search" entries). Results come from the same JSON API as the server list.
  const modal = document.querySelector('[data-search-modal]');
  if (modal) {
    const input = modal.querySelector('[data-search-input]'), hint = modal.querySelector('[data-search-hint]'), results = modal.querySelector('[data-search-results]');
    const HINT = 'Enter a server name, uuid, or allocation to begin searching.';
    let timer = null, seq = 0;
    const open = () => { modal.hidden = false; document.body.classList.add('mp-modal-open'); input.focus(); input.select(); };
    const close = () => { modal.hidden = true; document.body.classList.remove('mp-modal-open'); };
    const render = (list) => {
      results.textContent = '';
      hint.textContent = list.length ? '' : 'No servers found.';
      list.slice(0, 8).forEach((srv) => {
        const li = document.createElement('li'), a = document.createElement('a'), name = document.createElement('strong'), meta = document.createElement('span');
        a.href = `/dashboard/servers/${encodeURIComponent(srv.identifier)}`;
        name.textContent = srv.name; meta.textContent = `${srv.status} · ${srv.identifier}`;
        a.append(name, meta); li.append(a); results.append(li);
      });
    };
    const run = async () => {
      const q = input.value.trim(), mine = ++seq;
      if (!q) { results.textContent = ''; hint.textContent = HINT; return; }
      try {
        const res = await fetch('/api/dashboard/servers?' + new URLSearchParams({ q }), { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
        if (res.status === 401) return location.assign('/login');
        if (!res.ok || mine !== seq) return;
        render((await res.json()).servers);
      } catch { hint.textContent = 'Search is unavailable right now.'; }
    };
    input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 200); });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { const first = results.querySelector('a'); if (first) location.assign(first.href); } });
    document.querySelectorAll('[data-search-open]').forEach((el) => el.addEventListener('click', (e) => { e.preventDefault(); open(); }));
    modal.querySelector('[data-search-close]').addEventListener('click', close);
    modal.addEventListener('mousedown', (e) => { if (e.target === modal) close(); });
    document.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); open(); }
      else if (e.key === 'Escape' && !modal.hidden) close();
    });
  }

  // Close the "..." menu on cards when clicking elsewhere.
  document.addEventListener('click', (e) => document.querySelectorAll('details.mp-more[open]').forEach((d) => { if (!d.contains(e.target)) d.removeAttribute('open'); }));

  // Personal panel colours: stored in this browser only (CSS variables are set from script, which the CSP allows).
  const VARS = { accent: '--accent', bg: '--bg', surface: '--card', sidebar: '--card-2' };
  const KEY = 'mp-colours';
  const saved = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; } };
  const apply = (c) => Object.entries(VARS).forEach(([k, v]) => { if (/^#[0-9a-f]{6}$/i.test(c[k] || '')) document.documentElement.style.setProperty(v, c[k]); else document.documentElement.style.removeProperty(v); });
  apply(saved());
  const pickers = [...document.querySelectorAll('[data-colour]')];
  if (pickers.length) {
    const cur = saved(); pickers.forEach((p) => { if (cur[p.dataset.colour]) p.value = cur[p.dataset.colour]; });
    const defaults = Object.fromEntries(pickers.map((p) => [p.dataset.colour, p.defaultValue]));
    pickers.forEach((p) => p.addEventListener('input', () => apply(Object.fromEntries(pickers.map((x) => [x.dataset.colour, x.value])))));
    document.querySelector('[data-colour-save]')?.addEventListener('click', (e) => {
      try { localStorage.setItem(KEY, JSON.stringify(Object.fromEntries(pickers.map((x) => [x.dataset.colour, x.value])))); e.target.textContent = 'Saved'; setTimeout(() => { e.target.textContent = 'Save colours'; }, 1200); } catch { /* storage blocked */ }
    });
    document.querySelector('[data-colour-reset]')?.addEventListener('click', () => {
      try { localStorage.removeItem(KEY); } catch { /* storage blocked */ }
      apply({}); pickers.forEach((p) => { p.value = defaults[p.dataset.colour]; });
    });
  }

  // Banner uptime: ticks every second from the server's start time (the page reloads on every status change).
  const upEls = [...document.querySelectorAll('[data-uptime-since]')];
  if (upEls.length) {
    const pad = (n) => String(n).padStart(2, '0');
    const fmt = (ms) => { const t = Math.max(0, Math.floor(ms / 1000)), d = Math.floor(t / 86400), h = Math.floor((t % 86400) / 3600), m = Math.floor((t % 3600) / 60), s = t % 60;
      return d ? `${d}d ${pad(h)}h ${pad(m)}m` : h ? `${h}h ${pad(m)}m ${pad(s)}s` : `${m}m ${pad(s)}s`; };
    const tick = () => upEls.forEach((el) => { el.textContent = fmt(Date.now() - Number(el.dataset.uptimeSince)); });
    tick(); setInterval(tick, 1000);
  }

  const badges = [...document.querySelectorAll('[data-identifier][data-status]')];
  const live = document.querySelector('[data-server-live]');
  const hasBind = !!document.querySelector('[data-bind]');
  if (!badges.length && !hasBind) return;

  // A server's "state" is its status plus the job it is busy with (e.g. a reinstall), so a finished job also refreshes the page.
  const stateKey = (status, task) => `${status}|${task || ''}`;
  const rendered = new Map(badges.map((el) => [el.dataset.identifier, stateKey(el.dataset.status, el.dataset.task)]));
  let streaming = false; // true while the Server-Sent Events connection is healthy

  // A status change alters which buttons are valid, so re-render the page from the server.
  const statusChanged = (list) => list.some((s) => rendered.has(s.identifier) && rendered.get(s.identifier) !== stateKey(s.status, s.task));

  // Details page: update usage numbers in place.
  function paint(server) {
    if (!live || live.dataset.serverLive !== server.identifier) return;
    live.querySelectorAll('[data-live]').forEach((el) => {
      const v = el.dataset.live === 'players' ? `${server.players.online} / ${server.players.max}` : get(server, el.dataset.live);
      if (v != null) el.textContent = v;
    });
    live.querySelectorAll('progress[data-live-progress]').forEach((el) => {
      const r = server[el.dataset.liveProgress]; if (r) { el.max = r.limit || 1; el.value = r.used; }
    });
  }

  // 1) Real-time stream
  if ('EventSource' in window) {
    const es = new EventSource('/api/dashboard/events');
    es.onopen = () => { streaming = true; };
    es.onerror = () => { streaming = false; }; // the browser reconnects by itself; polling below covers the gap
    es.addEventListener('snapshot', (e) => { if (statusChanged(JSON.parse(e.data))) location.reload(); });
    es.addEventListener('update', (e) => {
      const list = JSON.parse(e.data);
      if (statusChanged(list)) return location.reload();
      list.forEach(paint);
    });
    window.addEventListener('beforeunload', () => es.close());
  }

  // 2) Polling: keeps overview totals fresh, and is the fallback when the stream is unavailable
  async function poll() {
    if (document.hidden) return;
    try {
      if (live && !streaming) {
        const res = await fetch(`/api/dashboard/servers/${encodeURIComponent(live.dataset.serverLive)}`, { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
        if (res.status === 401) return location.assign('/login');
        if (res.ok) { const { server } = await res.json(); if (statusChanged([server])) return location.reload(); paint(server); }
      }
      if (hasBind) {
        const res = await fetch('/api/dashboard/summary', { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
        if (res.status === 401) return location.assign('/login');
        if (!res.ok) return;
        const data = await res.json();
        if (!streaming && data.servers.some((s) => { const b = badges.find((el) => el.dataset.serverStatus === String(s.id)); return b && stateKey(b.dataset.status, b.dataset.task) !== stateKey(s.status, s.task); })) return location.reload();
        document.querySelectorAll('[data-bind]').forEach((el) => { const v = get(data.summary, el.dataset.bind); if (v != null) el.textContent = v; });
        document.querySelectorAll('progress[data-progress]').forEach((el) => {
          const r = data.summary[el.dataset.progress]; if (r) { el.max = r.limit || 1; el.value = r.used; }
        });
        const ch = document.querySelector('[data-bind-show]'); if (ch) ch.hidden = !data.summary.changing;
      } else if (!live && !streaming && badges.length) {
        const res = await fetch('/api/dashboard/servers?' + new URLSearchParams(location.search), { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
        if (res.ok) { const data = await res.json(); if (statusChanged(data.servers)) location.reload(); }
      }
    } catch { /* offline: try again next tick */ }
  }
  setInterval(poll, 10000);
})();
