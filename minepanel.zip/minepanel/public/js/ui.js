// Interface motion + small helpers (loaded on every page).
//  * Sidebar groups (details.mp-nav-group): clicking slides the list DOWN open, clicking again slides it back UP closed.
//  * Buttons: a purple ripple where you press, plus a press-down / spring-up feel (CSS in purple.css).
//  * <form data-confirm="..."> asks before submitting (used by Kill).
// All of it is skipped for people who asked their system for reduced motion.
(() => {
  const still = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // ---- animated open / close of <details>
  const running = new WeakMap();
  function slide(details, opening) {
    const summary = details.querySelector(':scope > summary');
    if (!summary || still() || !details.animate) { details.open = opening; return; }
    running.get(details)?.cancel();
    const head = summary.offsetHeight;
    details.style.overflow = 'hidden';
    let from, to;
    if (opening) { details.open = true; from = head; to = details.scrollHeight; }
    else { from = details.offsetHeight; to = head; }
    details.classList.toggle('is-opening', opening); details.classList.toggle('is-closing', !opening);
    const anim = details.animate({ height: [`${from}px`, `${to}px`] }, { duration: opening ? 340 : 260, easing: 'cubic-bezier(.22,1,.36,1)' });
    running.set(details, anim);
    const done = () => {
      if (running.get(details) !== anim) return;
      running.delete(details);
      if (!opening) details.open = false;
      details.style.overflow = ''; details.classList.remove('is-opening', 'is-closing');
    };
    anim.onfinish = done; anim.oncancel = () => { details.style.overflow = ''; };
  }
  document.addEventListener('click', (ev) => {
    const summary = ev.target.closest('details.mp-nav-group > summary');
    if (!summary) return;
    ev.preventDefault();
    const d = summary.parentElement, opening = !d.open || d.classList.contains('is-closing');
    slide(d, opening);
  });

  // ---- press ripple
  const RIPPLE = '.mp-button, .mp-btn-sm, .mp-tool, .mp-send, .mp-nav-link, .mp-chip';
  document.addEventListener('pointerdown', (ev) => {
    if (still() || ev.button > 0) return;
    const t = ev.target.closest(RIPPLE);
    if (!t || t.matches('.is-disabled, :disabled')) return;
    const r = t.getBoundingClientRect(), size = Math.max(r.width, r.height) * 2, dot = document.createElement('span');
    dot.className = 'mp-ripple';
    dot.style.width = dot.style.height = `${size}px`;
    dot.style.left = `${ev.clientX - r.left - size / 2}px`; dot.style.top = `${ev.clientY - r.top - size / 2}px`;
    t.classList.add('mp-rippling'); t.append(dot);
    dot.addEventListener('animationend', () => { dot.remove(); if (!t.querySelector('.mp-ripple')) t.classList.remove('mp-rippling'); });
  }, { passive: true });

  // ---- confirm before a dangerous form (Kill)
  document.addEventListener('submit', (ev) => {
    const msg = ev.target.closest?.('form[data-confirm]')?.dataset.confirm;
    if (msg && !window.confirm(msg)) ev.preventDefault();
  });
})();
