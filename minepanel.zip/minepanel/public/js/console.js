// Live server console: WebSocket log stream, command input with history, auto-scroll, scrollback.
// Output is only ever inserted with textContent / createElement (never innerHTML), so server output cannot inject markup.
(() => {
  const root = document.querySelector('[data-console]');
  if (!root || !('WebSocket' in window)) return;

  const $ = (sel) => root.querySelector(sel);
  const out = $('[data-console-out]'), input = $('[data-console-input]'), form = $('[data-console-form]'), sendBtn = $('[data-console-send]');
  const connEl = document.querySelector('[data-console-conn]') || document.createElement('span'), statusEl = document.querySelector('[data-console-status]') || document.createElement('span'), noteEl = $('[data-console-note]');
  const autoBtn = $('[data-console-autoscroll]'), jump = $('[data-console-jump]');
  const identifier = root.dataset.console;

  const MAX_LINES = 3000;            // lines kept in the page; older ones are dropped from the top (the server still has them)
  const ONLINE = ['online', 'starting'];

  let ws = null, lastId = 0, firstId = 0, hasMore = false, loadingOlder = false;
  let canSend = root.dataset.canSend === '1', status = root.dataset.status;
  const renderedStatus = root.dataset.status; let reloading = false;
  let auto = true, unseen = 0, retry = 0, retryTimer = null, pingTimer = null, pongTimer = null, closedForGood = false;
  let history = [], hIdx = 0, draft = '', ref = 0;
  let queue = [], frame = 0;
  const pendingAcks = new Map();

  // ---------------------------------------------------------------- rendering
  const ANSI_RE = /\x1b\[([0-9;]*)m/g;
  const OTHER_ESC = /\x1b(?:\[[0-9;?]*[A-Za-ln-z]|\][^\x07\x1b]*(?:\x07|\x1b\\)?|[()][0-9A-B])/g;

  /** Turns text with ANSI colour codes into spans with classes; everything else is plain text nodes. */
  function renderText(el, raw) {
    const text = raw.replace(OTHER_ESC, '');
    if (!text.includes('\x1b')) { el.textContent = text; return; }
    let cls = [], last = 0, m;
    const add = (s) => {
      if (!s) return;
      if (!cls.length) el.append(s);
      else { const sp = document.createElement('span'); sp.className = cls.join(' '); sp.textContent = s; el.append(sp); }
    };
    ANSI_RE.lastIndex = 0;
    while ((m = ANSI_RE.exec(text))) {
      add(text.slice(last, m.index)); last = ANSI_RE.lastIndex;
      const p = m[1] === '' ? [0] : m[1].split(';').map(Number);
      for (let i = 0; i < p.length; i++) {
        const c = p[i];
        if (c === 0) cls = [];
        else if (c === 1) cls = cls.filter((x) => x !== 'a-b').concat('a-b');
        else if (c === 3) cls = cls.filter((x) => x !== 'a-i').concat('a-i');
        else if (c === 4) cls = cls.filter((x) => x !== 'a-u').concat('a-u');
        else if (c === 22) cls = cls.filter((x) => x !== 'a-b');
        else if ((c >= 30 && c <= 37) || (c >= 90 && c <= 97)) cls = cls.filter((x) => !x.startsWith('a-f')).concat(`a-f${c}`);
        else if (c === 39) cls = cls.filter((x) => !x.startsWith('a-f'));
        else if (c === 38 || c === 48) i += p[i + 1] === 5 ? 2 : p[i + 1] === 2 ? 4 : 0;   // 256/true colour: skip its parameters
      }
    }
    add(text.slice(last));
  }

  function levelClass(text) {
    if (/[\[\/](?:ERROR|FATAL|SEVERE)\]/.test(text) || /^\s*(?:Exception|Caused by:|java\.[\w.]+(?:Exception|Error))/.test(text)) return 'mp-lvl-error';
    if (/[\[\/]WARN(?:ING)?\]/.test(text)) return 'mp-lvl-warn';
    if (/[\[\/]DEBUG\]/.test(text)) return 'mp-lvl-debug';
    return '';
  }

  function lineEl(l) {
    const d = document.createElement('div');
    d.className = `mp-line mp-s-${l.s}`;
    const lv = l.s === 'out' || l.s === 'err' ? levelClass(l.m) : '';
    if (lv) d.classList.add(lv);
    d.dataset.id = l.id || '';
    if (l.placeholder) d.dataset.placeholder = '1';
    renderText(d, l.m);
    return d;
  }

  const atBottom = () => out.scrollHeight - out.scrollTop - out.clientHeight < 24;
  const toBottom = () => { out.scrollTop = out.scrollHeight; };

  function setAuto(on) {
    auto = on;
    autoBtn.textContent = 'Auto scroll';
    autoBtn.setAttribute('aria-pressed', String(on));
    if (on) { unseen = 0; jump.hidden = true; }
  }

  function trim() {
    const extra = out.childElementCount - MAX_LINES;
    if (extra <= 0) return;
    const h = out.scrollHeight;
    for (let i = 0; i < extra; i++) out.firstElementChild.remove();
    if (!auto) out.scrollTop -= h - out.scrollHeight;            // keep what the reader is looking at in place
    const first = out.firstElementChild && Number(out.firstElementChild.dataset.id);
    if (first) { firstId = first; hasMore = true; }
  }

  /** Appends queued lines in one DOM update per animation frame (a busy server can print thousands of lines a second). */
  function flush() {
    frame = 0;
    if (!queue.length) return;
    let lines = queue; queue = [];
    let skipped = 0;
    if (lines.length > MAX_LINES) { skipped = lines.length - MAX_LINES; lines = lines.slice(-MAX_LINES); }
    const stick = auto;
    const frag = document.createDocumentFragment();
    if (skipped) { const g = document.createElement('div'); g.className = 'mp-console-gap'; g.textContent = `… ${skipped} lines skipped (too fast to display) …`; frag.append(g); }
    for (const l of lines) frag.append(lineEl(l));
    out.append(frag);
    trim();
    if (stick) toBottom();
    else { unseen += lines.length; jump.textContent = `↓ ${unseen} new line${unseen === 1 ? '' : 's'}`; jump.hidden = false; }
  }
  function push(lines) {
    if (lines.length && lines.some((l) => l.id)) { const ph = out.querySelector('[data-placeholder]'); if (ph) ph.remove(); }   // real output replaces "No output yet."
    for (const l of lines) { if (l.id) { lastId = Math.max(lastId, l.id); if (!firstId) firstId = l.id; } queue.push(l); }
    if (!frame) frame = requestAnimationFrame(flush);
  }
  const local = (message, placeholder) => push([{ id: 0, s: 'local', m: message, placeholder }]);
  const note = (text, error) => { noteEl.textContent = text || ''; noteEl.classList.toggle('is-error', !!error); };

  // ---------------------------------------------------------------- scroll behaviour
  out.addEventListener('scroll', () => {
    const bottom = atBottom();
    if (bottom && !auto) setAuto(true);
    else if (!bottom && auto) setAuto(false);
    if (out.scrollTop < 60 && hasMore && !loadingOlder && ws && ws.readyState === 1) {
      loadingOlder = true; ws.send(JSON.stringify({ type: 'older', before: firstId }));
    }
  }, { passive: true });
  autoBtn.addEventListener('click', () => { setAuto(!auto); if (auto) toBottom(); });
  jump.addEventListener('click', () => { setAuto(true); toBottom(); });

  function prependOlder(lines, more) {
    loadingOlder = false; hasMore = more;
    if (!lines.length) return;
    const h = out.scrollHeight, top = out.scrollTop, frag = document.createDocumentFragment();
    for (const l of lines) frag.append(lineEl(l));
    out.prepend(frag);
    out.scrollTop = top + (out.scrollHeight - h);                // stay on the same line instead of jumping to the new top
    firstId = lines[0].id;
  }

  // ---------------------------------------------------------------- toolbar
  $('[data-console-clear]').addEventListener('click', () => { out.textContent = ''; queue = []; unseen = 0; jump.hidden = true; hasMore = false; });
  $('[data-console-download]').addEventListener('click', () => {
    const text = [...out.children].map((n) => n.textContent).join('\n') + '\n';
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: 'text/plain' }));
    a.download = `${identifier}-console-${new Date().toISOString().replace(/[:.]/g, '-')}.log`;
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });

  // ---------------------------------------------------------------- command input + history
  function applyState() {
    const ok = canSend && ONLINE.includes(status);
    input.disabled = !ok; sendBtn.disabled = !ok;
    input.placeholder = !canSend ? 'You can watch the console but not send commands'
      : ok ? 'Type a command and press Enter (↑ ↓ for history)' : 'Start the server to send commands';
    statusEl.textContent = status; statusEl.className = `mp-badge mp-badge-${status}`;
    // The power buttons in the header are rendered for the status the page loaded with: reload once if it changes.
    if (status !== renderedStatus && !reloading) { reloading = true; setTimeout(() => location.reload(), 500); }
  }

  function remember(cmd) {
    if (history[history.length - 1] !== cmd) { history.push(cmd); if (history.length > 100) history.shift(); }
    hIdx = history.length; draft = '';
  }

  function sendCommand(cmd) {
    if (!ws || ws.readyState !== 1) { note('Not connected. Reconnecting…', true); return false; }
    const id = ++ref;
    pendingAcks.set(id, cmd);
    ws.send(JSON.stringify({ type: 'command', command: cmd, ref: id }));
    return true;
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const cmd = input.value.trim();
    if (!cmd || input.disabled) return;
    if (!sendCommand(cmd)) return;
    remember(cmd); input.value = ''; note('');
    if (!auto) { setAuto(true); toBottom(); }                    // you sent something: show what happens
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowUp' && history.length) {
      e.preventDefault();
      if (hIdx === history.length) draft = input.value;
      hIdx = Math.max(0, hIdx - 1); input.value = history[hIdx];
    } else if (e.key === 'ArrowDown' && hIdx < history.length) {
      e.preventDefault();
      hIdx += 1; input.value = hIdx === history.length ? draft : history[hIdx];
    } else if (e.key === 'Escape') { input.value = ''; hIdx = history.length; draft = ''; }
    else if (e.key === 'l' && e.ctrlKey) { e.preventDefault(); $('[data-console-clear]').click(); }
  });
  // Clicking the output focuses the input again, unless the reader is selecting text.
  out.addEventListener('mouseup', () => { if (!String(getSelection()) && !input.disabled) input.focus(); });

  // ---------------------------------------------------------------- connection
  function setConn(state, text) { connEl.dataset.state = state; connEl.textContent = text; root.dataset.conn = state; }

  function handle(msg) {
    switch (msg.type) {
      case 'hello':
        retry = 0; status = msg.server.status; canSend = msg.canSend; history = msg.history || []; hIdx = history.length;
        if (msg.reset) { out.textContent = ''; queue = []; firstId = 0; lastId = 0; hasMore = msg.more; setAuto(true); }
        push(msg.lines); if (msg.reset && !msg.lines.length) local('No output yet.', true);
        if (!msg.reset) lastId = Math.max(lastId, msg.lastId || 0);
        applyState(); setConn('live', 'Live'); note('');
        if (!input.disabled) input.focus({ preventScroll: true });
        break;
      case 'lines': push(msg.lines); break;
      case 'older': prependOlder(msg.lines, msg.more); break;
      case 'status': status = msg.status; applyState(); break;
      case 'perm': canSend = msg.canSend; applyState(); note(canSend ? 'You can now send commands.' : 'Your permission to send commands was removed.', !canSend); break;
      case 'ack': {
        const cmd = pendingAcks.get(msg.ref); pendingAcks.delete(msg.ref);
        if (!msg.ok) { note(msg.error || 'Command failed.', true); if (cmd && !input.value) input.value = cmd; }
        break;
      }
      case 'pong': clearTimeout(pongTimer); break;
    }
  }

  function connect() {
    clearTimeout(retryTimer);
    setConn('connecting', retry ? 'Reconnecting…' : 'Connecting…');
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    const url = `${proto}://${location.host}/api/dashboard/servers/${encodeURIComponent(identifier)}/console/ws${lastId ? `?after=${lastId}` : ''}`;
    let sock;
    try { sock = new WebSocket(url); } catch { return scheduleRetry(); }
    ws = sock;
    sock.onmessage = (e) => { try { handle(JSON.parse(e.data)); } catch { /* ignore malformed frame */ } };
    sock.onopen = () => {
      clearInterval(pingTimer);
      // Detects half-open connections (laptop woke up, Wi-Fi changed): no answer to a ping means reconnect.
      pingTimer = setInterval(() => {
        if (sock.readyState !== 1) return;
        sock.send('{"type":"ping"}');
        clearTimeout(pongTimer); pongTimer = setTimeout(() => sock.close(), 10000);
      }, 20000);
    };
    sock.onclose = (e) => {
      clearInterval(pingTimer); clearTimeout(pongTimer); pendingAcks.clear(); loadingOlder = false;
      if (sock !== ws) return;
      if (e.code === 4401) { location.assign('/login?next=' + encodeURIComponent(location.pathname)); return; }
      if (e.code === 4403 || e.code === 4404) { closedForGood = true; setConn('closed', 'Access ended'); canSend = false; applyState(); note(e.reason || 'You no longer have access to this console.', true); return; }
      scheduleRetry();
    };
  }

  function scheduleRetry() {
    if (closedForGood) return;
    retry += 1;
    const wait = Math.min(10000, 500 * 2 ** Math.min(retry, 5)) * (0.75 + Math.random() * 0.5);
    setConn('retry', `Disconnected – retrying in ${Math.ceil(wait / 1000)}s`);
    retryTimer = setTimeout(connect, wait);
  }

  // Coming back to the tab (or the network returning) should not wait for the retry timer.
  document.addEventListener('visibilitychange', () => { if (!document.hidden && (!ws || ws.readyState > 1) && !closedForGood) { retry = 0; connect(); } });
  window.addEventListener('online', () => { if ((!ws || ws.readyState > 1) && !closedForGood) { retry = 0; connect(); } });
  window.addEventListener('beforeunload', () => { closedForGood = true; if (ws) ws.close(1000); });

  applyState();
  connect();
})();
