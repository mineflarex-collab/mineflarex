'use strict';
// Markup only: class names are prefixed "mp-" so the theme can be applied purely from CSS.
const { icon } = require('./icons');
const config = require('../config');
const settings = require('../services/settings');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const brandLogo = (size) => `<img class="mp-logo" src="${settings.logoUrl()}" width="${size}" height="${size}" alt="">`;

function layout({ title, body }) {
  const { links } = config, brand = settings.brand();
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)} · ${esc(brand)}</title>
<link rel="icon" href="${settings.logoUrl()}">
<link rel="stylesheet" href="/css/auth.css">
<link rel="stylesheet" href="/css/skin.css?v=4">
</head>
<body class="mp-auth">
<header class="mp-auth-top">
<a class="mp-auth-brand" href="/">${brandLogo(44)}<span>${esc(brand)}</span></a>
<nav class="mp-auth-links" aria-label="Help"><a href="${esc(links.support)}">Support</a><a href="${esc(links.status)}">Status</a><a href="${esc(links.docs)}">Docs</a></nav>
</header>
<main class="mp-shell">
<section class="mp-hero" aria-label="About ${esc(brand)}">
<p class="mp-hero-eyebrow">Game server control panel</p>
<h1 class="mp-hero-title">Your servers,<br><span>under your control</span></h1>
<p class="mp-hero-text">Start, stop and watch your Minecraft servers live from one clean panel.</p>
<ul class="mp-hero-list">
<li><span class="mp-hero-ico">${icon('zap', 18)}</span><div><strong>Live Console</strong><span>Real-time logs and commands</span></div></li>
<li><span class="mp-hero-ico">${icon('shield', 18)}</span><div><strong>Secure by Default</strong><span>Hardened sessions and CSRF protection</span></div></li>
<li><span class="mp-hero-ico">${icon('monitor', 18)}</span><div><strong>File Manager</strong><span>Upload, edit and download in the browser</span></div></li>
</ul>
<dl class="mp-hero-stats"><div><dt>Instant</dt><dd>Power controls</dd></div><div><dt>Multi</dt><dd>Node ready</dd></div></dl>
</section>
<div class="mp-card">
<div class="mp-card-logo">${brandLogo(84)}</div>
<h2 class="mp-brand">${esc(brand)}</h2>
${body}
</div>
</main>
<script src="/js/auth.js" defer></script>
</body>
</html>`;
}

const alert = (flash) => (flash
  ? `<div class="mp-alert mp-alert-${flash.type}" role="${flash.type === 'error' ? 'alert' : 'status'}">${esc(flash.message)}</div>`
  : '');

function field({ name, label, type = 'text', value = '', error, autocomplete = 'off', rule = 'required', match, extra = '', icon: ico = '', placeholder = '', optional = false }) {
  const id = `f-${name}`;
  const toggle = type === 'password'
    ? `<button type="button" class="mp-toggle" data-toggle-password="${id}" aria-label="Show password" aria-pressed="false"><span class="mp-eye-on">${icon('eye', 16)}</span><span class="mp-eye-off">${icon('eyeOff', 16)}</span></button>` : '';
  return `<div class="mp-field${error ? ' has-error' : ''}">
<label for="${id}">${esc(label)}</label>
<div class="mp-input-wrap${ico ? ' has-icon' : ''}">
${ico ? `<span class="mp-input-icon">${icon(ico, 16)}</span>` : ''}<input id="${id}" name="${name}" type="${type}" value="${esc(value)}" autocomplete="${autocomplete}"${placeholder ? ` placeholder="${esc(placeholder)}"` : ''} data-rule="${optional ? 'optional' : rule}"${match ? ` data-match="f-${match}"` : ''}${optional ? '' : ' required'}${error ? ` aria-invalid="true"` : ''} aria-describedby="${id}-err" ${extra}>
${toggle}
</div>
<p class="mp-error" id="${id}-err" data-error-for="${name}"${error ? '' : ' hidden'}>${esc(error || '')}</p>
</div>`;
}

const form = ({ action, csrf, fields, submit, hidden = {} }) => `<form method="post" action="${action}" class="mp-form" novalidate data-validate>
<input type="hidden" name="_csrf" value="${esc(csrf)}">
${Object.entries(hidden).filter(([, v]) => v).map(([k, v]) => `<input type="hidden" name="${esc(k)}" value="${esc(v)}">`).join('\n')}
${fields}
<button type="submit" class="mp-button"><span>${esc(submit)}</span>${icon('arrowRight', 15)}</button>
</form>`;

module.exports = { esc, brandLogo, layout, alert, field, form };
