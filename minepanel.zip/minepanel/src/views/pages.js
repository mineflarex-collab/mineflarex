'use strict';
const settings = require('../services/settings');
const { esc, layout, alert, field, form } = require('./layout');
const config = require('../config');
const { icon } = require('./icons');

const login = ({ csrf, flash, errors = {}, values = {}, next }) => layout({ title: 'Sign in', body: `
<h2 class="mp-title">Welcome Back</h2>
<p class="mp-sub">Login to your ${esc(settings.brand())} account</p>
${alert(flash)}
${form({
  action: '/login', csrf, submit: 'Login', hidden: { next },
  fields: field({ name: 'identifier', label: 'Email Address', value: values.identifier, error: errors.identifier, autocomplete: 'username', extra: 'autofocus', icon: 'mail' })
    + field({ name: 'password', label: 'Password', type: 'password', error: errors.password, autocomplete: 'current-password', icon: 'lock' })
    + `<div class="mp-row"><label class="mp-check"><input type="checkbox" name="remember" value="1"${values.remember ? ' checked' : ''}> Remember me</label>
<a href="/forgot-password">Forgot password?</a></div>`
})}
<div class="mp-or"><span>OR</span></div>
${config.discord.enabled ? `<a class="mp-button mp-button-discord mp-button-link" href="/auth/discord${next ? `?next=${encodeURIComponent(next)}` : ''}">${icon('discord', 16)}<span>Continue with Discord</span></a>` : ''}
<a class="mp-button mp-button-secondary mp-button-link" href="/register">${icon('user', 15)}<span>Create Account</span></a>` });

/** Second step of the login: the 6-digit code from the authenticator app (or a backup code). */
const twofa = ({ csrf, flash }) => layout({ title: 'Two-step verification', body: `
<h2 class="mp-title">Two-step verification</h2>
<p class="mp-sub">Open your authenticator app (Google Authenticator, Authy, ...) and enter the 6-digit code for ${esc(settings.brand())}.</p>
${alert(flash)}
<form method="post" action="/login/2fa" class="mp-form" novalidate><input type="hidden" name="_csrf" value="${esc(csrf)}">
<div class="mp-field"><label for="f-code">Authentication code</label><div class="mp-input-wrap"><input id="f-code" class="mp-code-input" name="code" type="text" inputmode="text" autocomplete="one-time-code" maxlength="12" autocapitalize="off" spellcheck="false" autofocus required></div></div>
<button type="submit" class="mp-button">Verify</button></form>
<p class="mp-muted mp-center">Lost your phone? Enter one of your backup codes instead.</p>
<div class="mp-or"><span>OR</span></div>
<a class="mp-button mp-button-secondary mp-button-link" href="/login">${icon('arrowLeft', 15)}<span>Back to sign in</span></a>` });

const register = ({ csrf, flash, errors = {}, values = {} }) => layout({ title: 'Create account', body: `
<h2 class="mp-title">Create Account</h2>
<p class="mp-sub">Register your new ${esc(settings.brand())} account</p>
${alert(flash)}
${form({
  action: '/register', csrf, submit: 'Create Account',
  fields: field({ name: 'first_name', label: 'First Name', value: values.firstName, error: errors.first_name, autocomplete: 'given-name', rule: 'optional', optional: true, extra: 'autofocus', icon: 'user', placeholder: 'Optional' })
    + field({ name: 'last_name', label: 'Last Name', value: values.lastName, error: errors.last_name, autocomplete: 'family-name', rule: 'optional', optional: true, icon: 'user', placeholder: 'Optional' })
    + field({ name: 'username', label: 'Username', value: values.username, error: errors.username, autocomplete: 'username', rule: 'username', icon: 'square', placeholder: 'letters, numbers, dashes' })
    + field({ name: 'email', label: 'Email Address', type: 'email', value: values.email, error: errors.email, autocomplete: 'email', rule: 'email', icon: 'mail', placeholder: 'you@example.com' })
    + field({ name: 'password', label: 'Password', type: 'password', error: errors.password, autocomplete: 'new-password', rule: 'password', icon: 'lock', placeholder: `min. ${config.password.minLength} characters` })
    + field({ name: 'confirm', label: 'Confirm Password', type: 'password', error: errors.confirm, autocomplete: 'new-password', rule: 'confirm', match: 'password', icon: 'lock', placeholder: 'repeat password' })
})}
<p class="mp-alt"><a href="/login">${icon('arrowLeft', 13)} Back to login</a></p>` });

const forgot = ({ csrf, flash, errors = {}, values = {} }) => layout({ title: 'Forgot password', body: `
<h2 class="mp-title">Forgot your password?</h2>
<p class="mp-text">Enter your account email and we'll send you a reset link.</p>
${alert(flash)}
${form({
  action: '/forgot-password', csrf, submit: 'Send reset link',
  fields: field({ name: 'email', label: 'Email', type: 'email', value: values.email, error: errors.email, autocomplete: 'email', rule: 'email', extra: 'autofocus', icon: 'mail' })
})}
<p class="mp-alt"><a href="/login">${icon('arrowLeft', 13)} Back to login</a></p>` });

const reset = ({ csrf, flash, errors = {}, token }) => layout({ title: 'Reset password', body: `
<h2 class="mp-title">Choose a new password</h2>
${alert(flash)}
${form({
  action: '/reset-password', csrf, submit: 'Reset password', hidden: { token },
  fields: field({ name: 'password', label: 'New password', type: 'password', error: errors.password, autocomplete: 'new-password', rule: 'password', extra: 'autofocus' })
    + `<p class="mp-hint">At least ${config.password.minLength} characters with a letter and a number.</p>`
    + field({ name: 'confirm', label: 'Confirm new password', type: 'password', error: errors.confirm, autocomplete: 'new-password', rule: 'confirm', match: 'password' })
})}` });

const resetInvalid = () => layout({ title: 'Link expired', body: `
<h2 class="mp-title">Link invalid or expired</h2>
<div class="mp-alert mp-alert-error" role="alert">This password reset link is invalid, expired or has already been used.</div>
<p class="mp-alt"><a href="/forgot-password">Request a new link</a></p>` });

const logoutForm = (csrf) => `<form method="post" action="/logout" class="mp-inline-form"><input type="hidden" name="_csrf" value="${esc(csrf)}"><button type="submit" class="mp-button mp-button-secondary">Sign out</button></form>`;

// Temporary landing pages that prove route protection works. Replace with the real dashboard.
const placeholder = ({ title, user, csrf, note }) => layout({ title, body: `
<h2 class="mp-title">${esc(title)}</h2>
<p class="mp-text">Signed in as <strong>${esc(user.username)}</strong> (${esc(user.role)}).</p>
<p class="mp-text">${esc(note)}</p>
${logoutForm(csrf)}` });

const error = ({ status, message }) => layout({ title: `Error ${status}`, body: `
<h2 class="mp-title">${esc(status === 404 ? 'Page not found' : status === 403 ? 'Access denied' : 'Something went wrong')}</h2>
<div class="mp-alert mp-alert-error" role="alert">${esc(message)}</div>
<p class="mp-alt"><a href="/">Go home</a></p>` });

module.exports = { twofa, login, register, forgot, reset, resetInvalid, placeholder, error };
