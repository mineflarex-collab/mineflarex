'use strict';
const http = require('node:http');
const config = require('./config');
const { createRouter, parseBody, HttpError } = require('./lib/http');
const auth = require('./middleware/auth');
const pages = require('./views/pages');
const sessions = require('./services/sessions');
const resets = require('./services/passwordResets');

function onError(err, ctx) {
  const status = err instanceof HttpError ? err.status : 500;
  if (status >= 500) console.error('[error]', err);
  const message = status >= 500 ? 'An unexpected error occurred. Please try again.' : err.message;
  if (ctx.wantsJson()) return ctx.json(status, { error: message });
  ctx.csrfToken ??= '';
  return ctx.html(status, pages.error({ status, message }));
}

function createServer() {
  const router = createRouter({ onError });
  router.use(auth.securityHeaders);
  router.use(parseBody);
  router.use(auth.csrfCookie);
  router.use(auth.csrfProtect);
  router.use(auth.loadSession);

  require('./routes/auth')(router);
  require('./routes/protected')(router);
  require('./dashboard')(router);

  const server = http.createServer(router.handler);
  server.consoleHub = require('./dashboard/consoleSocket').attach(server);   // live console WebSocket (Upgrade requests never reach the router)
  const timer = setInterval(() => { sessions.purgeExpired(); resets.purgeExpired(); }, 60 * 60 * 1000);
  timer.unref();
  server.on('close', () => clearInterval(timer));
  return server;
}

module.exports = { createServer, config };
