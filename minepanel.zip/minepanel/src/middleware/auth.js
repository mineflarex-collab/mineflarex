'use strict';
const config = require('../config');
const { HttpError, requestHost } = require('../lib/http');
const { randomToken, hmac, safeEqual } = require('../lib/crypto');
const sessions = require('../services/sessions');

const CSRF_COOKIE = 'mp_csrf';
const sign = (raw) => `${raw}.${hmac(config.secret, raw)}`;
function validCsrf(token) {
  const [raw, sig] = String(token || '').split('.');
  return !!raw && !!sig && safeEqual(sig, hmac(config.secret, raw));
}

/** Security headers on every response. */
async function securityHeaders(ctx, next) {
  const h = {
    'Content-Security-Policy': config.csp, 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer', 'Cache-Control': 'no-store', 'Cross-Origin-Opener-Policy': 'same-origin',
    'Permissions-Policy': 'geolocation=(), camera=(), microphone=()'
  };
  if (config.prod) h['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
  for (const [k, v] of Object.entries(h)) ctx.res.setHeader(k, v);
  return next();
}

/** Issues the signed CSRF cookie and exposes ctx.csrfToken for forms. */
async function csrfCookie(ctx, next) {
  let token = ctx.cookies[CSRF_COOKIE];
  if (!validCsrf(token)) {
    token = sign(randomToken(24));
    ctx.cookies[CSRF_COOKIE] = token;
    ctx.setCookie(CSRF_COOKIE, token);
  }
  ctx.csrfToken = token;
  return next();
}

/** Rejects unsafe requests without a matching token (double-submit) or from a foreign Origin. */
async function csrfProtect(ctx, next) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(ctx.req.method)) return next();
  const origin = ctx.req.headers.origin;
  if (origin && origin !== 'null') {
    let host; try { host = new URL(origin).host; } catch { host = ''; }
    if (host !== requestHost(ctx.req)) throw new HttpError(403, 'Cross-origin request blocked.');
  }
  const submitted = ctx.body?._csrf || ctx.req.headers['x-csrf-token'];
  if (!submitted || !validCsrf(submitted) || !safeEqual(submitted, ctx.cookies[CSRF_COOKIE])) {
    throw new HttpError(403, 'Your session form expired. Please go back, refresh the page and try again.');
  }
  return next();
}

/** Resolves the session cookie into ctx.user / ctx.session. */
async function loadSession(ctx, next) {
  const found = sessions.resolve(ctx.cookies[config.session.cookie]);
  if (found) { ctx.user = found.user; ctx.session = found.session; }
  else if (ctx.cookies[config.session.cookie]) ctx.clearCookie(config.session.cookie);
  return next();
}

const loginUrl = (ctx) => '/login?next=' + encodeURIComponent(ctx.url.pathname + ctx.url.search);

/** Route guard: must be signed in. */
async function requireAuth(ctx, next) {
  if (ctx.user) return next();
  if (ctx.wantsJson()) return ctx.json(401, { error: 'Authentication required.' });
  if (ctx.req.method === 'GET') { ctx.flash('info', 'Please sign in to continue.'); return ctx.redirect(loginUrl(ctx)); }
  return ctx.redirect('/login');
}

/** Route guard: must be signed in AND hold one of the roles. */
const requireRole = (...roles) => async (ctx, next) => {
  if (!ctx.user) return requireAuth(ctx, next);
  if (!roles.includes(ctx.user.role)) {
    if (ctx.wantsJson()) return ctx.json(403, { error: 'Forbidden.' });
    throw new HttpError(403, 'You do not have permission to view this page.');
  }
  return next();
};
const requireAdmin = requireRole('admin');

/** Route guard for login/register/etc: signed-in users go to their landing page. */
async function guestOnly(ctx, next) {
  if (ctx.user) return ctx.redirect(config.landing[ctx.user.role] || '/');
  return next();
}

/** Only allow same-site relative redirects (blocks open redirects). */
function safeNext(value) {
  const v = String(value || '');
  return v.startsWith('/') && !v.startsWith('//') && !v.includes('\\') && !/[\r\n]/.test(v) ? v : null;
}

module.exports = { securityHeaders, csrfCookie, csrfProtect, loadSession, requireAuth, requireRole, requireAdmin, guestOnly, safeNext };
