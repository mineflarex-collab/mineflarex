'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
require('./lib/env');                 // loads .env (real environment variables take priority)
const env = process.env;

const prod = env.NODE_ENV === 'production';
const port = Number(env.PORT) || 3000;
const dbPath = env.DB_PATH || path.join(__dirname, '..', 'data', 'minepanel.db');

function loadSecret() {
  if (env.SESSION_SECRET) return env.SESSION_SECRET;
  if (prod) throw new Error('SESSION_SECRET must be set in production.');
  if (dbPath === ':memory:') return crypto.randomBytes(32).toString('hex');
  const file = path.join(path.dirname(dbPath), '.secret');
  try { return fs.readFileSync(file, 'utf8').trim(); } catch { /* create below */ }
  const secret = crypto.randomBytes(32).toString('hex');
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, secret, { mode: 0o600 });
  return secret;
}

module.exports = {
  prod,
  brand: env.PANEL_NAME || 'ZynexNode™',
  links: { support: env.SUPPORT_URL || '#', status: env.STATUS_URL || '#', docs: env.DOCS_URL || '#' },
  host: env.HOST || '127.0.0.1',
  port,
  baseUrl: (env.BASE_URL || `http://localhost:${port}`).replace(/\/$/, ''),
  dbPath,
  secret: loadSecret(),
  trustProxy: env.TRUST_PROXY === 'true',
  secureCookies: prod || env.COOKIE_SECURE === 'true',
  bodyLimit: 20 * 1024,
  rateLimit: env.RATE_LIMIT !== 'off',

  session: {
    cookie: 'mp_sid',
    ttlMs: 12 * 60 * 60 * 1000,          // sliding, browser-session cookie
    rememberMs: 30 * 24 * 60 * 60 * 1000, // sliding, persistent cookie
    touchEveryMs: 60 * 1000
  },
  lockout: { maxAttempts: 5, durationMs: 15 * 60 * 1000 },
  reset: { ttlMs: 60 * 60 * 1000, cooldownMs: 60 * 1000 },
  password: { minLength: 10, maxLength: 128 },

  // Where each role lands after login (change when the dashboard exists)
  landing: { admin: '/dashboard', user: '/dashboard' },   // admins use the same user interface as everyone (their own servers) and open /admin from the Admin link

  // Edit if your theme needs external fonts/CDNs
  csp: "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; " +
       "form-action 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'; " +
       // Live console WebSocket. 'self' covers it in current browsers; the explicit ws(s):// origin covers the ones that
       // do not treat 'self' as matching ws:// (derived from BASE_URL).
       `connect-src 'self' ${(env.BASE_URL || `http://localhost:${port}`).replace(/\/$/, '').replace(/^http/, 'ws')}`,

  mail: {
    driver: env.MAIL_DRIVER || 'log',
    from: env.MAIL_FROM || `${env.PANEL_NAME || 'minePanel'} <no-reply@localhost>`,
    host: env.SMTP_HOST, port: Number(env.SMTP_PORT) || 587,
    secure: env.SMTP_SECURE === 'true', user: env.SMTP_USER, pass: env.SMTP_PASS,
    quiet: env.MAIL_QUIET === 'true'
  }
};
