'use strict';
// Example protected routes. The real dashboard / admin panel plug in the same way:
//   router.get('/servers', requireAuth, handler)
//   (the admin panel lives in src/dashboard/adminPanel.js)
const config = require('../config');
const { requireAuth } = require('../middleware/auth');
const pages = require('../views/pages');

module.exports = function register(router) {
  router.get('/', (ctx) => ctx.redirect(ctx.user ? config.landing[ctx.user.role] || '/account' : '/login'));

  router.get('/account', requireAuth, (ctx) => ctx.html(200, pages.placeholder({
    title: 'Account', user: ctx.user, csrf: ctx.csrfToken, note: 'Authenticated area (placeholder). Any signed-in user can see this.'
  })));

  router.get('/api/me', requireAuth, (ctx) => ctx.json(200, { user: ctx.user }));
  router.get('/healthz', (ctx) => ctx.json(200, { ok: true }));
};
