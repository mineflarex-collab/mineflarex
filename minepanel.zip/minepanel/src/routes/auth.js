'use strict';
const config = require('../config');
const v = require('../lib/validate');
const { rateLimit } = require('../lib/rateLimit');
const { hashPassword, verifyPassword, needsRehash, dummyVerify } = require('../lib/crypto');
const users = require('../services/users');
const sessions = require('../services/sessions');
const resets = require('../services/passwordResets');
const twofactor = require('../services/twofactor');
const oauth = require('../services/oauth');
const { guestOnly, safeNext } = require('../middleware/auth');
const pages = require('../views/pages');

const view = (ctx, extra = {}) => ({ csrf: ctx.csrfToken, flash: ctx.takeFlash(), ...extra });
const GENERIC_LOGIN_ERROR = 'Incorrect email/username or password.';

function startSession(ctx, user, remember) {
  sessions.destroy(ctx.cookies[config.session.cookie]); // never reuse a pre-login session id
  const s = sessions.create(user.id, { remember, ip: ctx.ip, userAgent: ctx.req.headers['user-agent'] });
  ctx.setCookie(config.session.cookie, s.token, { maxAge: remember ? s.ttl : undefined });
}

/** Signs in, or asks for the authenticator code first when the account has two-step verification on. */
function completeLogin(ctx, user, remember, next) {
  if (twofactor.isEnabled(user.id)) {
    ctx.setCookie(twofactor.PENDING_COOKIE, twofactor.makePending(user.id, remember, next), { maxAge: twofactor.PENDING_MS });
    return ctx.redirect('/login/2fa');
  }
  users.recordSuccess(user.id);
  startSession(ctx, user, remember);
  return ctx.redirect(next || config.landing[user.role] || '/');
}

module.exports = function register(router) {
  /* ---------- Login ---------- */
  router.get('/login', guestOnly, (ctx) => ctx.html(200, pages.login(view(ctx, { next: safeNext(ctx.query.next) }))));

  router.post('/login', rateLimit({ name: 'login', windowMs: 15 * 60 * 1000, max: 30 }), guestOnly, async (ctx) => {
    const identifier = String(ctx.body.identifier ?? '').trim();
    const password = String(ctx.body.password ?? '');
    const remember = ctx.body.remember === '1';
    const next = safeNext(ctx.body.next);
    const values = { identifier, remember };
    const fail = (status, message, errors = {}) =>
      ctx.html(status, pages.login({ csrf: ctx.csrfToken, flash: message ? { type: 'error', message } : null, errors, values, next }));

    const errors = {};
    if (!identifier) errors.identifier = 'Enter your email or username.';
    if (!password) errors.password = 'Enter your password.';
    if (Object.keys(errors).length) return fail(422, null, errors);
    if (identifier.length > 254 || password.length > config.password.maxLength) return fail(401, GENERIC_LOGIN_ERROR);

    const user = users.findByLogin(identifier);
    if (!user) { await dummyVerify(password); return fail(401, GENERIC_LOGIN_ERROR); }

    if (user.locked_until && user.locked_until > Date.now()) {
      const mins = Math.ceil((user.locked_until - Date.now()) / 60000);
      return fail(429, `Too many failed attempts. Try again in ${mins} minute${mins === 1 ? '' : 's'} or reset your password.`);
    }
    if (user.locked_until) users.clearLock(user.id);

    if (!(await verifyPassword(password, user.password_hash))) {
      users.recordFailure(user.id);
      return fail(401, GENERIC_LOGIN_ERROR);
    }
    if (!user.is_active) return fail(403, 'This account has been disabled. Contact an administrator.');

    if (needsRehash(user.password_hash)) users.setPassword(user.id, await hashPassword(password));
    return completeLogin(ctx, user, remember, next);
  });

  /* ---------- Two-step verification (second step of the login) ---------- */
  router.get('/login/2fa', guestOnly, (ctx) => {
    if (!twofactor.readPending(ctx.cookies[twofactor.PENDING_COOKIE])) { ctx.flash('info', 'Please sign in again.'); return ctx.redirect('/login'); }
    return ctx.html(200, pages.twofa(view(ctx)));
  });

  router.post('/login/2fa', rateLimit({ name: 'login-2fa', windowMs: 15 * 60 * 1000, max: 20 }), guestOnly, (ctx) => {
    const pending = twofactor.readPending(ctx.cookies[twofactor.PENDING_COOKIE]);
    if (!pending) { ctx.flash('error', 'That sign-in expired. Please sign in again.'); return ctx.redirect('/login'); }
    const user = users.findById(pending.userId);
    const fail = (status, message) => ctx.html(status, pages.twofa({ csrf: ctx.csrfToken, flash: { type: 'error', message } }));
    if (!user || !user.is_active) { ctx.clearCookie(twofactor.PENDING_COOKIE); return ctx.redirect('/login'); }
    if (user.locked_until && user.locked_until > Date.now()) return fail(429, 'Too many failed attempts. Try again later.');
    const how = twofactor.check(user.id, ctx.body.code);
    if (!how) { users.recordFailure(user.id); return fail(401, 'That code is not right. Check the code in your authenticator app and try again.'); }
    ctx.clearCookie(twofactor.PENDING_COOKIE);
    users.recordSuccess(user.id);
    startSession(ctx, user, pending.remember);
    if (how === 'backup') ctx.flash('info', `You used a backup code. ${twofactor.backupLeft(user.id)} left. You can make new ones in Account settings.`);
    return ctx.redirect(pending.next || config.landing[user.role] || '/');
  });

  /* ---------- Login with Discord (only accounts that linked Discord in Account settings) ---------- */
  router.get('/auth/discord', rateLimit({ name: 'discord-start', windowMs: 15 * 60 * 1000, max: 30 }), (ctx) => {
    if (!config.discord.enabled) { ctx.flash('error', 'Discord login is not set up on this panel.'); return ctx.redirect(ctx.user ? '/dashboard/settings' : '/login'); }
    const link = ctx.query.link === '1';
    if (link && !ctx.user) return ctx.redirect('/login');
    if (!link && ctx.user) return ctx.redirect(config.landing[ctx.user.role] || '/');
    const state = oauth.makeState({ mode: link ? 'link' : 'login', userId: link ? ctx.user.id : 0, next: safeNext(ctx.query.next) || '' });
    ctx.setCookie(oauth.STATE_COOKIE, state, { maxAge: 10 * 60 * 1000 });
    return ctx.redirect(oauth.authorizeUrl(state));
  });

  router.get('/auth/discord/callback', rateLimit({ name: 'discord-cb', windowMs: 15 * 60 * 1000, max: 30 }), async (ctx) => {
    const st = oauth.readState(ctx.query.state), cookie = ctx.cookies[oauth.STATE_COOKIE];
    ctx.clearCookie(oauth.STATE_COOKIE);
    const back = st && st.m === 'link' ? '/dashboard/settings' : '/login';
    if (!config.discord.enabled || !st || !cookie || cookie !== ctx.query.state) { ctx.flash('error', 'The Discord sign-in expired or was not started here. Please try again.'); return ctx.redirect(back); }
    if (ctx.query.error || !ctx.query.code) { ctx.flash('info', 'Discord sign-in was cancelled.'); return ctx.redirect(back); }
    let profile;
    try { profile = await oauth.discordProfile(ctx.query.code); } catch (err) { console.error('[discord]', err.message); ctx.flash('error', 'Could not talk to Discord. Please try again.'); return ctx.redirect(back); }

    if (st.m === 'link') {                                   // signed-in user links Discord to their account
      if (!ctx.user || ctx.user.id !== st.u) { ctx.flash('error', 'Please sign in and try linking again.'); return ctx.redirect('/login'); }
      const taken = oauth.find('discord', profile.id);
      if (taken && taken.user_id !== ctx.user.id) { ctx.flash('error', 'That Discord account is already linked to another panel account.'); return ctx.redirect(back); }
      if (!taken) { oauth.unlink('discord', ctx.user.id); oauth.link('discord', profile.id, ctx.user.id, profile.handle); }
      ctx.flash('success', `Discord account ${profile.handle || ''} linked. You can now sign in with Discord.`.replace('  ', ' '));
      return ctx.redirect(back);
    }
    const linked = oauth.find('discord', profile.id), user = linked && users.findById(linked.user_id);
    if (!user) { ctx.flash('error', 'No panel account is linked to that Discord account. Sign in with your password, then link Discord in Account settings.'); return ctx.redirect('/login'); }
    if (!user.is_active) { ctx.flash('error', 'This account has been disabled. Contact an administrator.'); return ctx.redirect('/login'); }
    if (user.locked_until && user.locked_until > Date.now()) { ctx.flash('error', 'Too many failed attempts on this account. Try again later.'); return ctx.redirect('/login'); }
    return completeLogin(ctx, user, false, st.x || null);   // two-step verification is still asked for when it is on
  });

  /* ---------- Registration ---------- */
  router.get('/register', guestOnly, (ctx) => ctx.html(200, pages.register(view(ctx))));

  router.post('/register', rateLimit({ name: 'register', windowMs: 60 * 60 * 1000, max: 10 }), guestOnly, async (ctx) => {
    const b = ctx.body;
    const values = { username: String(b.username ?? '').trim(), email: String(b.email ?? '').trim(),
      firstName: String(b.first_name ?? '').trim(), lastName: String(b.last_name ?? '').trim() };
    const errors = v.collect({
      username: v.username(b.username), email: v.email(b.email),
      password: v.password(b.password), confirm: v.confirm(b.confirm, b.password),
      first_name: v.optionalName(b.first_name), last_name: v.optionalName(b.last_name)
    });
    if (!errors.username && users.findByUsername(values.username)) errors.username = 'That username is already taken.';
    if (!errors.email && users.findByEmail(values.email)) errors.email = 'An account with that email already exists.';
    const rerender = () => ctx.html(422, pages.register({ csrf: ctx.csrfToken, flash: { type: 'error', message: 'Please fix the highlighted fields.' }, errors, values }));
    if (Object.keys(errors).length) return rerender();

    try {
      users.create({ username: values.username, email: values.email, firstName: values.firstName, lastName: values.lastName, passwordHash: await hashPassword(String(b.password)) });
    } catch (err) {
      const field = users.uniqueViolation(err);
      if (!field) throw err;
      errors[field] = field === 'email' ? 'An account with that email already exists.' : 'That username is already taken.';
      return rerender();
    }
    ctx.flash('success', 'Account created. You can now sign in.');
    return ctx.redirect('/login');
  });

  /* ---------- Forgot password ---------- */
  router.get('/forgot-password', guestOnly, (ctx) => ctx.html(200, pages.forgot(view(ctx))));

  router.post('/forgot-password', rateLimit({ name: 'forgot', windowMs: 60 * 60 * 1000, max: 8 }), guestOnly, async (ctx) => {
    const email = String(ctx.body.email ?? '').trim();
    const emailError = v.email(email);
    if (emailError) return ctx.html(422, pages.forgot({ csrf: ctx.csrfToken, errors: { email: emailError }, values: { email } }));
    // Fire-and-forget so response time doesn't reveal whether the account exists.
    resets.request(email, ctx.ip).catch((err) => console.error('[reset] failed to send email:', err.message));
    ctx.flash('info', 'If an account exists for that email, a reset link is on its way. It expires in 1 hour.');
    return ctx.redirect('/login');
  });

  /* ---------- Reset password ---------- */
  router.get('/reset-password', guestOnly, (ctx) => {
    const token = ctx.query.token;
    if (!resets.isValid(token)) return ctx.html(400, pages.resetInvalid());
    return ctx.html(200, pages.reset(view(ctx, { token })));
  });

  router.post('/reset-password', rateLimit({ name: 'reset', windowMs: 60 * 60 * 1000, max: 15 }), guestOnly, async (ctx) => {
    const { token, password, confirm } = ctx.body;
    if (!resets.isValid(token)) return ctx.html(400, pages.resetInvalid());
    const errors = v.collect({ password: v.password(password), confirm: v.confirm(confirm, password) });
    if (Object.keys(errors).length) return ctx.html(422, pages.reset({ csrf: ctx.csrfToken, errors, token }));
    if (!resets.consume(token, await hashPassword(String(password)))) return ctx.html(400, pages.resetInvalid());
    ctx.flash('success', 'Password updated. Sign in with your new password.');
    return ctx.redirect('/login');
  });

  /* ---------- Logout (POST + CSRF only, so it can't be triggered by a link/image) ---------- */
  router.post('/logout', (ctx) => {
    sessions.destroy(ctx.cookies[config.session.cookie]);
    ctx.clearCookie(config.session.cookie);
    ctx.flash('success', 'You have been signed out.');
    return ctx.redirect('/login');
  });
};
