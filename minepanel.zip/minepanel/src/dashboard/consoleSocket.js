'use strict';
// Live console over WebSocket:  GET /api/dashboard/servers/:identifier/console/ws   (Upgrade: websocket)
//
// Authentication: the normal session cookie (the browser sends it with the handshake). The Origin header must match
// the Host (blocks cross-site WebSocket hijacking). Permissions are re-checked every 15 s and on every command, so
// signing out, revoking a device or removing a grant takes effect on open consoles.
//
// Server -> client messages (JSON text frames):
//   hello   { server:{identifier,name,status}, canSend, lines:[{id,t,s,m}], more, reset, lastId, history:[cmd...] }
//   lines   { lines:[{id,t,s,m}] }               new output (s = out | err | in | sys)
//   older   { lines:[...], more }                answer to "older"
//   status  { status }                           online | offline | starting | stopping | crashed
//   perm    { canSend }                          permissions changed while connected
//   ack     { ref, ok, error? }                  answer to "command"
//   pong    {}
// Client -> server:
//   command { command, ref }   older { before }   ping {}
const config = require('../config');
const sessions = require('../services/sessions');
const { parseCookies, clientIp, requestHost } = require('../lib/http');
const ws = require('../lib/websocket');
const servers = require('./services/servers');
const access = require('./services/access');
const activity = require('./services/activity');
const store = require('./services/serverConsole');

const PATH = /^\/api\/dashboard\/servers\/([0-9a-f]{8})\/console\/ws$/;
const TICK_MS = 100;                 // how often new output is pushed
const HEARTBEAT_TICKS = 150;         // 15 s: ping, drop dead sockets, re-check session + permissions
const INPUT_TIMEOUT_MS = 10 * 1000;  // a queued command nobody picked up in this time is reported as not delivered
const BACKLOG = 500, RESUME_MAX = 2000, OLDER_PAGE = 200;
const MAX_COMMAND = 1000, MAX_PER_USER = 10;
const ONLINE = new Set(['online', 'starting']);          // states in which the process exists and reads its console

const wire = (r) => ({ id: r.id, t: r.ts, s: r.stream, m: r.line });
const stopGuard = (command) => {                         // typing "stop" in the console must not bypass control.stop
  const first = command.replace(/^\//, '').trim().split(/\s+/)[0].toLowerCase();
  return first === 'stop' ? 'control.stop' : first === 'restart' ? 'control.restart' : null;
};

class Hub {
  constructor(httpServer) {
    this.http = httpServer; this.clients = new Set(); this.timer = null; this.n = 0;
    httpServer.on('upgrade', (req, socket, head) => this.onUpgrade(req, socket, head));
    // Upgraded sockets are not tracked by http.Server, so server.close() would wait for them forever.
    const close = httpServer.close.bind(httpServer);
    httpServer.close = (cb) => { this.closeAll(1001, 'Server shutting down'); return close(cb); };
  }

  onUpgrade(req, socket, head) {
    socket.on('error', () => {});
    let url;
    try { url = new URL(req.url.replace(/^\/+/, '/'), 'http://localhost'); } catch { return ws.reject(socket, 400, 'Bad request.'); }
    const m = PATH.exec(url.pathname);
    if (!m) return ws.reject(socket, 404, 'Not found.');
    const problem = ws.checkUpgrade(req);
    if (problem) return ws.reject(socket, 400, problem);

    const origin = req.headers.origin;                    // browsers always send it; command-line clients may not
    if (origin) { let host = ''; try { host = new URL(origin).host; } catch { /* invalid */ } if (host !== requestHost(req)) return ws.reject(socket, 403, 'Cross-origin WebSocket blocked.'); }

    const token = parseCookies(req.headers.cookie)[config.session.cookie];
    const found = sessions.resolve(token);
    if (!found) return ws.reject(socket, 401, 'Authentication required.');
    const user = found.user;
    const server = servers.getByIdentifier(user.id, m[1]);
    const acc = server && access.forUser(user.id, server);
    if (!server || !acc) return ws.reject(socket, 404, 'Server not found.');
    if (!acc.has('console.view')) return ws.reject(socket, 403, 'You do not have access to this console.');
    if ([...this.clients].filter((c) => c.user.id === user.id).length >= MAX_PER_USER) return ws.reject(socket, 429, 'Too many open consoles.');

    const conn = ws.accept(req, socket, head, { maxPayload: 16 * 1024 });
    const c = { ws: conn, user, token, server, canSend: acc.has('console.send'), lastId: 0, status: server.status, alive: true, ip: clientIp(req),
      tokens: 10, refilled: Date.now() };
    this.clients.add(c);
    conn.on('message', (text) => this.onMessage(c, text));
    conn.on('pong', () => { c.alive = true; });
    conn.on('close', () => this.clients.delete(c));
    this.hello(c, url.searchParams.get('after'));
    if (!this.timer) { this.timer = setInterval(() => this.tick(), TICK_MS); this.timer.unref(); }
  }

  send(c, obj) { return c.ws.send(JSON.stringify(obj)); }

  hello(c, afterParam) {
    const id = c.server.id, last = store.lastId(id);
    const after = /^\d{1,15}$/.test(afterParam || '') ? Number(afterParam) : null;
    let lines, reset, more;
    if (after !== null && after <= last) {                // reconnect: only what the client has not seen yet
      lines = store.after(id, after, RESUME_MAX); reset = false; more = false;
    } else {                                              // first connection (or the log was reset): show the most recent lines
      lines = store.tail(id, BACKLOG); reset = true; more = lines.length === BACKLOG;
    }
    c.lastId = lines.length ? lines[lines.length - 1].id : (after !== null && after <= last ? after : last);
    this.send(c, { type: 'hello', server: { identifier: c.server.identifier, name: c.server.name, status: c.server.status },
      canSend: c.canSend, lines: lines.map(wire), more, reset, lastId: c.lastId, history: store.history(c.user.id, id) });
  }

  // ---- client -> server -----------------------------------------------------------------------------
  onMessage(c, text) {
    let msg;
    try { msg = JSON.parse(text); } catch { return c.ws.close(1007, 'Invalid JSON'); }
    if (!msg || typeof msg !== 'object') return c.ws.close(1008, 'Invalid message');
    // Token bucket: 5 messages per second sustained, bursts of 10.
    const now = Date.now();
    c.tokens = Math.min(10, c.tokens + (now - c.refilled) / 200); c.refilled = now;
    if (msg.type === 'ping') return this.send(c, { type: 'pong' });
    if (c.tokens < 1) return msg.type === 'command' ? this.send(c, { type: 'ack', ref: msg.ref, ok: false, error: 'Slow down: too many commands.' }) : undefined;
    c.tokens -= 1;

    if (msg.type === 'command') return this.onCommand(c, msg);
    if (msg.type === 'older') {
      const before = Number(msg.before);
      if (!Number.isInteger(before) || before < 1) return;
      const lines = store.before(c.server.id, before, OLDER_PAGE);
      return this.send(c, { type: 'older', lines: lines.map(wire), more: lines.length === OLDER_PAGE });
    }
  }

  onCommand(c, msg) {
    const ack = (ok, error) => this.send(c, { type: 'ack', ref: msg.ref, ok, ...(error ? { error } : {}) });
    if (typeof msg.command !== 'string') return ack(false, 'Invalid command.');
    // Checked on the raw text, before trimming: a line break must never be quietly dropped or let a second command through.
    if (/[\u0000-\u001f\u007f]/.test(msg.command)) return ack(false, 'Commands cannot contain control characters or line breaks.');
    const command = msg.command.trim();
    if (!command) return ack(false, 'Type a command first.');
    if (command.length > MAX_COMMAND) return ack(false, `Commands can be at most ${MAX_COMMAND} characters.`);

    // Re-check everything against the database right now (the connection may be minutes old).
    const server = servers.getByIdentifier(c.user.id, c.server.identifier), acc = server && access.forUser(c.user.id, server);
    if (!server || !acc || !acc.has('console.view')) return ack(false, 'You no longer have access to this server.');
    if (!acc.has('console.send')) return ack(false, 'You can watch this console but not send commands.');
    const needed = stopGuard(command);
    if (needed && !acc.has(needed)) return ack(false, `You do not have permission to ${needed.split('.')[1]} this server.`);
    if (!ONLINE.has(server.status)) return ack(false, `The server is ${server.status}. Start it to send commands.`);

    store.enqueueInput({ serverId: server.id, user: c.user, command });
    store.addHistory(c.user.id, server.id, command);
    activity.record({ userId: server.owner_id, serverId: server.id, serverName: server.name, type: 'console.command',
      message: `${c.user.username} ran "${command.length > 120 ? `${command.slice(0, 120)}…` : command}" on ${server.name}`, ip: c.ip });
    return ack(true);
  }

  // ---- server -> client -----------------------------------------------------------------------------
  tick() {
    this.n += 1;
    const by = new Map();
    for (const c of this.clients) { if (!c.ws.open) continue; if (!by.has(c.server.id)) by.set(c.server.id, []); by.get(c.server.id).push(c); }
    for (const [id, conns] of by) {
      let rows = [];
      try { rows = store.after(id, Math.min(...conns.map((c) => c.lastId)), 1000); } catch { /* db busy: next tick */ }
      const status = store.serverStatus(id);
      for (const c of conns) {
        const batch = rows.filter((r) => r.id > c.lastId);
        if (batch.length) { c.lastId = batch[batch.length - 1].id; this.send(c, { type: 'lines', lines: batch.map(wire) }); }
        if (status && status !== c.status) { c.status = status; this.send(c, { type: 'status', status }); }
      }
    }
    if (this.n % 10 === 0) this.sweepInput();
    if (this.n % HEARTBEAT_TICKS === 0) this.heartbeat();
    if (!this.clients.size) { clearInterval(this.timer); this.timer = null; }
  }

  /** Commands that nobody picked up (runtime down) are marked failed and the console says so. */
  sweepInput() {
    try {
      for (const r of store.failStale(INPUT_TIMEOUT_MS)) store.appendNow(r.server_id, 'sys', `[minePanel] Command not delivered (the server runtime is not responding): ${r.command}`);
    } catch { /* retry on the next sweep */ }
  }

  heartbeat() {
    for (const c of [...this.clients]) {
      if (!c.alive) { c.ws.terminate(); continue; }           // no pong since the last ping: dead connection
      c.alive = false; c.ws.ping();
      if (!sessions.resolve(c.token)) { c.ws.close(4401, 'Session expired'); continue; }
      const server = servers.getByIdentifier(c.user.id, c.server.identifier), acc = server && access.forUser(c.user.id, server);
      if (!server) { c.ws.close(4404, 'Server not found'); continue; }
      if (!acc.has('console.view')) { c.ws.close(4403, 'Access removed'); continue; }
      const canSend = acc.has('console.send');
      if (canSend !== c.canSend) { c.canSend = canSend; this.send(c, { type: 'perm', canSend }); }
    }
    store.purgeInput();
  }

  closeAll(code = 1001, reason = '') { for (const c of [...this.clients]) c.ws.close(code, reason); }
  count() { return this.clients.size; }
}

/** Adds the console WebSocket endpoint to an http.Server. */
const attach = (httpServer) => new Hub(httpServer);

module.exports = { attach, Hub, PATH };
