'use strict';
// Markup only, using .mp-* classes; styling lives in public/css/dashboard.css (placeholder until the theme).
const { esc, alert, brandLogo } = require('../views/layout');
const f = require('./format');
const servers = require('./services/servers');
const access = require('./services/access');

const { icon } = require('../views/icons');

const settings = require('../services/settings');
const capacity = require('./services/capacity');
const cap = (x) => x.charAt(0).toUpperCase() + x.slice(1);
// Pages keep their own `active` key; the sidebar groups them (activity/settings/api/ssh are tabs of "Account").
const GROUP = { overview: 'dashboard', servers: 'search', settings: 'account', profile: 'account', activity: 'account', api: 'account', ssh: 'account' };
const TABS = [['settings', '/dashboard/settings', 'Account'], ['api', '/dashboard/api-credentials', 'API Credentials'], ['ssh', '/dashboard/ssh-keys', 'SSH Keys'], ['activity', '/dashboard/activity', 'Activity']];

// Server sidebar. `real` pages exist; everything else renders an honest "not built yet" page (see serverPages.js).
const SERVER_NAV = [
  { key: 'console', label: 'Console', ico: 'terminal', path: '/console', needsConsole: true },
  { group: 'MC UTILS', items: [
    { key: 'server-properties', label: 'Server Properties', ico: 'sliders' }, { key: 'players', label: 'Players Manager', ico: 'users' },
    { key: 'worlds', label: 'World Manager', ico: 'globe' }, { key: 'world-viewer', label: 'World Viewer', ico: 'globe' },
    { key: 'versions', label: 'Versions Manager', ico: 'layers' }, { key: 'plugins', label: 'Plugins Manager', ico: 'puzzle' }] },
  { key: 'files', label: 'Files', ico: 'folder', needsFiles: true, real: true }, { key: 'databases', label: 'Databases', ico: 'database' },
  { key: 'schedules', label: 'Schedules', ico: 'calendar' }, { key: 'users', label: 'Users', ico: 'users', real: true },
  { key: 'backups', label: 'Backups', ico: 'cloud' }, { key: 'network', label: 'Network', ico: 'globe', real: true },
  { key: 'startup', label: 'Startup', ico: 'rocket' }, { key: 'details', label: 'Settings', ico: 'gear', path: '', real: true },
  { key: 'activity-server', label: 'Activity', ico: 'chart', path: '/activity', real: true }
];

// Admin sidebar: Users, the Servers nest (Bot Host + MC Host) and Settings (panel name + logo).
const ADMIN_NAV = [
  { key: 'admin-overview', label: 'Overview', ico: 'chart', href: '/admin' },
  { key: 'admin-users', label: 'Users', ico: 'users', href: '/admin/users' },
  { nest: 'Servers', ico: 'layers', items: [
    { key: 'admin-bots', label: 'Bot Host', ico: 'cpu', href: '/admin/servers/bots' },
    { key: 'admin-mc', label: 'MC Host', ico: 'globe', href: '/admin/servers/mc' }] },
  { key: 'admin-settings', label: 'Settings', ico: 'gear', href: '/admin/settings' }
];

/** The red pulsing "Live" tag: the numbers next to it refresh by themselves (public/js/admin-live.js). */
const liveTag = () => `<span class="mp-live" data-live-indicator title="Updates by itself every few seconds"><span class="mp-live-dot"></span>Live</span>`;

/** RAM / CPU / Disk meters: what the VPS really uses right now (the bar), and what is given to servers. */
function capacityPanel(cap = capacity.status()) {
  const row = (r) => `<div class="mp-resource${r.full ? ' is-full' : ''}" data-vps="${r.key}"><div class="mp-resource-head"><span>${r.label}</span>
<span><span data-vps-text>${esc(r.usedText)} of ${esc(r.totalText)} in use</span> · <strong data-vps-pct>${Math.round(r.usedPct)}%</strong></span></div>
<progress value="${Math.min(100, Math.round(r.usedPct))}" max="100" aria-label="${r.label} usage" data-vps-bar></progress>
<div class="mp-muted mp-resource-sub"><span data-vps-sub>${esc(r.allocatedText)} limit given to servers (a ceiling, only what they use is taken)</span><strong data-vps-full>${r.full ? ' · FULL' : ''}</strong></div></div>`;
  return `<section class="mp-panel mp-capacity" data-capacity data-full="${cap.full ? '1' : '0'}"><div class="mp-capacity-head"><h2>VPS capacity</h2>${liveTag()}</div><p class="mp-muted">There is no limit on the number of servers. A server only takes what it really uses. New servers are blocked once the VPS really uses ${cap.limitPct}% of its RAM, CPU or disk.</p>${cap.resources.map(row).join('')}</section>`;
}

/** Centred warning shown to administrators while the VPS has no room left (see services/capacity.js). */
function capacityBanner() {
  const w = capacity.warning();
  if (!w) return '';
  return `<section class="mp-capacity-alert" role="alert"><span class="mp-capacity-icon">${icon('shield', 26)}</span><h2>${esc(w.title)}</h2>${w.lines.map((l, i) => (i ? `<p><strong>${esc(l)}</strong></p>` : `<p>${esc(l)}</p>`)).join('')}</section>`;
}

const avatarFor = (user) => (user.id % 2 ? '/img/avatar-steve.svg' : '/img/avatar-alex.svg');

function shell({ title, sub = '', active, user, csrf, flash, body, styles = [], scripts = [], server = null, hero = '', admin = false }) {
  const brandName = settings.brand();
  const link = (key, href, label, ico, on, attrs = '') => `<a href="${href}" class="mp-nav-link${on ? ' is-active' : ''}"${on ? ' aria-current="page"' : ''}${attrs}>${icon(ico, 16)}<span>${label}</span></a>`;
  const g = GROUP[active] || active;
  let nav;
  if (admin) {
    const one = (i) => link(i.key, i.href, i.label, i.ico, active === i.key);
    nav = ADMIN_NAV.map((e) => (e.nest
      ? `<details class="mp-nav-group mp-nest" open><summary>${icon(e.ico, 16)}<span>${e.nest}</span>${icon('chevron', 12)}</summary>${e.items.map(one).join('')}</details>`
      : one(e))).join('\n');
  } else if (server) {
    const base = `/dashboard/servers/${esc(server.identifier)}`;
    const item = (i) => {
      if (i.needsConsole && !server.canConsole) return '';
      if (i.needsFiles && !server.canFiles) return '';
      const href = `${base}${i.path !== undefined ? i.path : `/${i.key}`}`;
      return link(i.key, href, i.label, i.ico, active === i.key);
    };
    nav = SERVER_NAV.map((e) => (e.group && server.kind === 'bot' ? '' : e.group
      ? `<details class="mp-nav-group"${e.items.some((i) => i.key === active) ? ' open' : ''}><summary><span>${e.group}</span>${icon('chevron', 12)}</summary>${e.items.map(item).join('')}</details>`
      : item(e))).join('\n');
  } else {
    nav = [link('dashboard', '/dashboard', 'Dashboard', 'layers', g === 'dashboard'), link('account', '/dashboard/settings', 'Account', 'user', g === 'account'),
      link('search', '/dashboard/servers', 'Search', 'search', g === 'search', ' data-search-open')].join('\n');
  }
  const tabs = !server && g === 'account'
    ? `<nav class="mp-tabs" aria-label="Account">${TABS.map(([k, h, l]) => `<a href="${h}" class="mp-tab${k === active ? ' is-active' : ''}"${k === active ? ' aria-current="page"' : ''}>${l}</a>`).join('')}</nav>` : '';
  const foot = admin
    ? `<a href="/dashboard" class="mp-nav-link mp-nav-back">${icon('arrowLeft', 15)}<span>User dashboard</span></a>`
    : server
      ? `<a href="/dashboard" class="mp-nav-link mp-nav-back">${icon('arrowLeft', 15)}<span>All servers</span></a>`
      : '';
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)} · ${esc(brandName)}</title><link rel="icon" href="${settings.logoUrl()}">
<link rel="stylesheet" href="/css/auth.css"><link rel="stylesheet" href="/css/dashboard.css">${styles.map((h) => `<link rel="stylesheet" href="${esc(h)}">`).join('')}<link rel="stylesheet" href="/css/skin.css?v=5">
</head><body class="mp-body">
<header class="mp-topbar">
<a class="mp-topbar-brand" href="${admin ? '/admin' : '/dashboard'}">${brandLogo(44)}<span>${esc(brandName)}</span></a>
<a class="mp-topsearch" href="/dashboard/servers" data-search-open role="search" aria-label="Search servers">${icon('search', 15)}<span>Search servers…</span><kbd>Ctrl K</kbd></a>
</header>
<div class="mp-dash">
<aside class="mp-sidebar">
<div class="mp-sidebar-head">
<a class="mp-topuser" href="/dashboard/settings"><img class="mp-avatar" src="${avatarFor(user)}" width="32" height="32" alt=""><span class="mp-topuser-text"><strong>${esc(user.username)}</strong><small>Account</small></span></a>
${user.role === 'admin' ? (admin ? `<a class="mp-nav-link mp-headlink" href="/dashboard">${icon('layers', 15)}<span>My servers</span></a>` : `<a class="mp-nav-link mp-headlink" href="/admin">${icon('gear', 15)}<span>Admin</span></a>`) : ''}
<form method="post" action="/logout"><input type="hidden" name="_csrf" value="${esc(csrf)}"><button type="submit" class="mp-nav-link mp-nav-signout">${icon('logout', 16)}<span>Sign out</span></button></form>
</div>
<nav class="mp-nav" aria-label="Main">
${nav}
</nav>
<div class="mp-sidebar-foot">
${foot}
</div>
</aside>
<main class="mp-dash-main">
${tabs}
${hero || `<header class="mp-dash-header"><h1>${esc(title)}</h1>${sub ? `<p class="mp-sub">${esc(sub)}</p>` : ''}</header>`}
${admin ? capacityBanner() : ''}${alert(flash)}
${body}
<footer class="mp-footer">${esc(brandName)}</footer>
</main>
</div>
<div class="mp-modal" data-search-modal hidden>
<button type="button" class="mp-modal-close" data-search-close aria-label="Close search">${icon('x', 20)}</button>
<div class="mp-modal-box" role="dialog" aria-modal="true" aria-label="Search servers">
<label class="mp-modal-label" for="search-term">Search term</label>
<div class="mp-modal-input">${icon('search', 16)}<input id="search-term" type="search" placeholder="Search servers…" maxlength="100" autocomplete="off" data-search-input></div>
<p class="mp-modal-hint" data-search-hint>Enter a server name, uuid, or allocation to begin searching.</p>
<ul class="mp-modal-results" data-search-results></ul>
</div></div>
<script src="/js/auth.js" defer></script><script src="/js/dashboard.js" defer></script>${scripts.map((h) => `<script src="${esc(h)}" defer></script>`).join('')}
</body></html>`;
}

// While a job such as a reinstall runs, the badge says so instead of the plain status (data-task lets the live script notice the change).
const badge = (s) => `<span class="mp-badge mp-badge-${s.task ? 'starting' : s.status}" data-server-status="${s.id}" data-identifier="${esc(s.identifier)}" data-status="${s.status}" data-task="${esc(s.task || '')}">${s.task === 'reinstall' ? 'reinstalling' : esc(s.status)}</span>`;
const empty = (text) => `<p class="mp-empty">${esc(text)}</p>`;

/**
 * Power buttons for one server row: only actions the user is permitted to use in the server's current state.
 * Start is a plain POST; stop / restart / reinstall link to a confirmation page (the server re-checks confirmation on POST).
 * `reinstall: false` leaves Reinstall out (the dashboard cards keep it in their "..." menu to save room).
 */
const ACT_ICON = { start: icon('play', 12), stop: icon('stop', 12), restart: icon('restart', 13), reinstall: icon('download', 13) };
function actionButtons(s, { csrf, back, userId, reinstall = true }) {
  const acc = access.forUser(userId, s);
  const acts = servers.allowedActionsFor(acc, s).filter((a) => reinstall || a !== 'reinstall');
  if (s.task) return `<span class="mp-muted">${s.task === 'reinstall' ? 'Reinstalling&hellip;' : 'Working&hellip;'}</span>`;
  if (!acts.length) return `<span class="mp-muted">${acc && !acc.permissions.size ? 'View only' : '—'}</span>`;
  const confirmHref = (a) => `/dashboard/servers/${esc(s.identifier)}/confirm/${a}?back=${encodeURIComponent(back)}`;
  return `<div class="mp-actions">${acts.map((a) => (servers.CONFIRM.has(a)
    ? `<a class="mp-btn-sm mp-btn-${a}" href="${confirmHref(a)}">${ACT_ICON[a]} <span>${servers.TRANSITIONS[a].label}</span></a>`
    : `<form method="post" action="/dashboard/servers/action" class="mp-actions"><input type="hidden" name="_csrf" value="${esc(csrf)}"><input type="hidden" name="server_id" value="${s.id}"><input type="hidden" name="back" value="${esc(back)}"><button type="submit" name="action" value="${a}" class="mp-btn-sm mp-btn-${a}">${ACT_ICON[a]} <span>${servers.TRANSITIONS[a].label}</span></button></form>`)).join('')}</div>`;
}

const meter = (used, limit, label) => `<progress value="${used}" max="${limit || 1}" aria-label="${esc(label)}"></progress>`;

const LABEL = { online: 'Online', offline: 'Offline', starting: 'Starting', stopping: 'Stopping', crashed: 'Crashed' };
const statusText = (s) => (s.task === 'reinstall' ? 'Reinstalling' : LABEL[s.status] || cap(s.status));

function serverCard(s, ctx) {
  const live = s.status === 'online', d = f.describeServer(s, { admin: ctx.user.role === 'admin' });
  const href = `/dashboard/servers/${esc(s.identifier)}`;
  const stat = (ico, val, label) => `<span class="mp-srv-stat" title="${label}">${icon(ico, 13)}<b>${val}</b><span class="mp-sr">${label}</span></span>`;
  const acc = access.forUser(ctx.user.id, s);
  const canReinstall = servers.allowedActionsFor(acc, s).includes('reinstall');
  const menu = `<details class="mp-more"><summary class="mp-btn-sm mp-btn-more" aria-label="More options">${icon('dots', 16)}</summary><div class="mp-menu">${acc && acc.has('console.view') ? `<a href="${href}/console">${icon('terminal', 14)} Console</a>` : ''}${canReinstall ? `<a href="${href}/confirm/reinstall?back=${encodeURIComponent(ctx.back || '/dashboard')}">${icon('download', 14)} Reinstall</a>` : ''}<a href="${href}">${icon('sliders', 14)} Server details</a><a href="${href}/activity">${icon('chart', 14)} Activity</a><a href="${href}/network">${icon('globe', 14)} Network</a></div></details>`;
  return `<article class="mp-srv">
<a class="mp-srv-banner" href="${href}" aria-label="Open ${esc(s.name)}">
<img class="mp-srv-icon" src="/img/server-icon.svg" width="40" height="40" alt="">
<span class="mp-srv-id"><strong>${esc(s.name)}</strong><span class="mp-srv-status mp-st-${s.task ? 'starting' : esc(s.status)}" data-server-status="${s.id}" data-identifier="${esc(s.identifier)}" data-status="${s.status}" data-task="${esc(s.task || '')}"><span class="mp-dot"></span>${esc(statusText(s))}</span></span>
</a>
<div class="mp-srv-stats">${s.kind === 'bot' ? stat('terminal', servers.RUNTIMES[s.runtime]?.label || 'Bot', 'Runtime') : stat('users', live ? s.players_online : '—', 'Players')}${stat('cpu', live ? `${d.cpu.pct}%` : '—', 'CPU')}${stat('ram', live ? f.mb(s.ram_used_mb) : '—', 'Memory')}${stat('hdd', live ? f.mb(s.disk_used_mb) : '—', 'Disk')}</div>
<div class="mp-srv-actions">${actionButtons(s, { csrf: ctx.csrfToken, back: ctx.back || '/dashboard', userId: ctx.user.id, reinstall: false })}
<a class="mp-btn-sm mp-btn-link mp-btn-settings" href="${href}">${icon('gear', 13)} Settings</a>${menu}</div>
${s.owner_name && s.owner_id !== ctx.user.id ? `<p class="mp-srv-owner">Owner: ${esc(s.owner_name)}</p>` : ''}
</article>`;
}

function activityList(items) {
  if (!items.length) return empty('No activity yet.');
  return `<ul class="mp-activity">${items.map((a) => `<li><span class="mp-activity-msg">${esc(a.message)}</span>
<time datetime="${f.iso(a.created_at)}" title="${f.iso(a.created_at)}">${f.relative(a.created_at)}</time></li>`).join('')}</ul>`;
}

function profileCard(user, extra = {}) {
  return `<dl class="mp-dl">
<dt>Username</dt><dd>${esc(user.username)}</dd><dt>Email</dt><dd>${esc(user.email)}</dd><dt>Role</dt><dd>${esc(user.role)}</dd>
<dt>Member since</dt><dd>${f.date(user.createdAt)}</dd>
<dt>Last sign-in</dt><dd>${user.lastLoginAt ? `<time datetime="${f.iso(user.lastLoginAt)}">${f.relative(user.lastLoginAt)}</time>` : 'Never'}</dd>
${extra.sessions != null ? `<dt>Active sessions</dt><dd>${extra.sessions}</dd>` : ''}</dl>`;
}

function overview({ ctx, list, flash, showAll = false }) {
  const admin = ctx.user.role === 'admin';
  const body = list.length
    ? `<div class="mp-srv-grid">${list.map((s) => serverCard(s, { ...ctx, back: showAll ? '/dashboard?all=1' : '/dashboard' })).join('\n')}</div>`
    : `<div class="mp-panel mp-empty-box"><p class="mp-empty">No servers found.</p></div>`;
  const tools = admin ? `<div class="mp-dash-tools"><a class="mp-switch${showAll ? ' is-on' : ''}" href="${showAll ? '/dashboard' : '/dashboard?all=1'}" role="switch" aria-checked="${showAll}"><span class="mp-switch-label">${showAll ? 'Showing all servers' : 'Showing your servers'}</span><span class="mp-switch-track"><span class="mp-switch-knob"></span></span></a>
<a class="mp-btn-primary" href="/admin/servers/new">${icon('plus', 14)} Create Server</a></div>` : '';
  const hero = `<header class="mp-dash-header mp-dash-header-row"><div><h1>Dashboard</h1><p class="mp-sub">Manage your game servers.</p></div>${tools}</header>`;
  return shell({ title: 'Dashboard', active: 'overview', user: ctx.user, csrf: ctx.csrfToken, flash, body, hero });
}

function activityPage({ ctx, items, page, pages, flash }) {
  const nav = pages > 1 ? `<nav class="mp-pager">${page > 1 ? `<a href="?page=${page - 1}">Previous</a>` : ''}<span>Page ${page} of ${pages}</span>${page < pages ? `<a href="?page=${page + 1}">Next</a>` : ''}</nav>` : '';
  return shell({ title: 'Activity', sub: 'Everything that happened on your account and servers.', active: 'activity', user: ctx.user, csrf: ctx.csrfToken, flash, body: `<section class="mp-panel">${activityList(items)}${nav}</section>` });
}

const profilePage = ({ ctx, sessions, serverCount, flash }) => shell({ title: 'Profile', sub: 'Your account details.', active: 'profile', user: ctx.user, csrf: ctx.csrfToken, flash,
  body: `<section class="mp-panel"><h2>Your profile</h2>${profileCard(ctx.user, { sessions })}
<dl class="mp-dl"><dt>Servers</dt><dd>${serverCount}</dd></dl><p><a href="/dashboard/settings">Edit in account settings</a></p></section>` });

function dfield({ id, name, label, type = 'text', value = '', error, autocomplete = 'off', rule = 'required', match }) {
  return `<div class="mp-field${error ? ' has-error' : ''}"><label for="${id}">${esc(label)}</label>
<div class="mp-input-wrap"><input id="${id}" name="${name}" type="${type}" value="${esc(value)}" autocomplete="${autocomplete}" data-rule="${rule}"${match ? ` data-match="${match}"` : ''} required aria-describedby="${id}-err">
${type === 'password' ? `<button type="button" class="mp-toggle" data-toggle-password="${id}" aria-label="Show password" aria-pressed="false"><span class="mp-eye-on">${icon('eye', 16)}</span><span class="mp-eye-off">${icon('eyeOff', 16)}</span></button>` : ''}</div>
<p class="mp-error" id="${id}-err"${error ? '' : ' hidden'}>${esc(error || '')}</p></div>`;
}

function deviceLabel(ua = '') {
  const browser = /Edg\//.test(ua) ? 'Edge' : /Firefox\//.test(ua) ? 'Firefox' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  const os = /Windows/.test(ua) ? 'Windows' : /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Mac OS/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : 'Unknown OS';
  return `${browser} on ${os}`;
}

function settingsPage({ ctx, sessions, errors = {}, values = {}, flash }) {
  const pe = errors.profile || {}, we = errors.password || {};
  const csrf = `<input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}">`;
  const rows = sessions.map((s) => {
    const current = s.id === ctx.session.id;
    return `<li><div><strong>${esc(deviceLabel(s.user_agent))}</strong>${current ? ' <span class="mp-badge mp-badge-online">this device</span>' : ''}
<div class="mp-muted">${esc(s.ip || 'unknown IP')} · active <time datetime="${f.iso(s.last_seen_at)}">${f.relative(s.last_seen_at)}</time></div></div>
${current ? '' : `<form method="post" action="/dashboard/settings/sessions/revoke">${csrf}<input type="hidden" name="session_id" value="${esc(s.id)}"><button class="mp-btn-sm" type="submit">Sign out</button></form>`}</li>`;
  }).join('');
  const colours = [['accent', 'Accent', '#8b5cf6'], ['bg', 'Background', '#07050f'], ['surface', 'Surface', '#120d24'], ['sidebar', 'Sidebar', '#0d0919']]
    .map(([k, l, v]) => `<label class="mp-colour"><span>${l}</span><input type="color" data-colour="${k}" value="${v}"></label>`).join('');
  const body = `
<section class="mp-panel mp-acct"><h2>My panel colours</h2>
<p class="mp-muted">Personal colours for your account in this browser. Other users and the administrator theme are unaffected.</p>
<div class="mp-colours">${colours}</div>
<div class="mp-form-actions"><button type="button" class="mp-button mp-btn-inline" data-colour-save>Save colours</button><button type="button" class="mp-btn-sm" data-colour-reset>Use panel defaults</button></div></section>
<div class="mp-grid-2 mp-acct">
<div><h2 class="mp-sect">Update Password</h2><section class="mp-panel">
<form method="post" action="/dashboard/settings/password" class="mp-form" novalidate data-validate>${csrf}
${dfield({ id: 'w-current', name: 'current_password', label: 'Current password', type: 'password', error: we.current_password, autocomplete: 'current-password' })}
${dfield({ id: 'w-new', name: 'password', label: 'New password', type: 'password', error: we.password, autocomplete: 'new-password', rule: 'password' })}
<p class="mp-hint">Your new password should be at least 10 characters in length and unique to this website.</p>
${dfield({ id: 'w-confirm', name: 'confirm', label: 'Confirm new password', type: 'password', error: we.confirm, autocomplete: 'new-password', rule: 'confirm', match: 'w-new' })}
<button type="submit" class="mp-button mp-btn-inline">Update Password</button></form></section></div>
<div><h2 class="mp-sect">Update Email Address</h2><section class="mp-panel">
<form method="post" action="/dashboard/settings/profile" class="mp-form" novalidate data-validate>${csrf}<input type="hidden" name="username" value="${esc(ctx.user.username)}">
${dfield({ id: 'p-email', name: 'email', label: 'Email', type: 'email', value: values.email ?? ctx.user.email, error: pe.email || pe.username, autocomplete: 'email', rule: 'email' })}
${dfield({ id: 'p-current', name: 'current_password', label: 'Confirm password', type: 'password', error: pe.current_password, autocomplete: 'current-password' })}
<button type="submit" class="mp-button mp-btn-inline">Update Email</button></form></section></div>
</div>
<h2 class="mp-sect mp-acct">Two-Step Verification</h2>
<section class="mp-panel mp-acct mp-half"><p class="mp-muted">You do not currently have two-step verification enabled on your account. Click the button below to begin configuring it.</p>
<button type="button" class="mp-button mp-btn-inline" disabled title="Two-step verification has not been built yet">Enable Two-Step</button>
<p class="mp-muted mp-note">Not available yet: this needs a login-flow change that is planned as its own module.</p></section>
<section class="mp-panel"><div class="mp-panel-head"><h2>Active sessions</h2>
${sessions.length > 1 ? `<form method="post" action="/dashboard/settings/sessions/revoke-others">${csrf}<button class="mp-btn-sm" type="submit">Sign out all other devices</button></form>` : ''}</div>
<ul class="mp-sessions">${rows}</ul></section>`;
  return shell({ title: 'Account settings', sub: 'Manage your profile and account security.', active: 'settings', user: ctx.user, csrf: ctx.csrfToken, flash, body });
}

module.exports = { liveTag, capacityPanel, cap, overview, activityPage, profilePage, settingsPage, shell, badge, meter, empty, actionButtons, activityList };
