'use strict';
// Secondary server pages (activity, users, network) and honest "not built yet" pages for modules that do not exist.
const { esc } = require('../views/layout');
const { icon } = require('../views/icons');
const f = require('./format');
const access = require('./services/access');
const servers = require('./services/servers');
const { shell, empty, activityList } = require('./views');
const startup = require('./services/startup');
const runtimeConfig = require('../runtime/config');

const srv = (s, acc) => ({ row: s, identifier: s.identifier, kind: s.kind, canConsole: acc.has('console.view'), canFiles: acc.has('files.view') });
const NOT_BUILT = {
  'server-properties': 'Server Properties', players: 'Players Manager', worlds: 'World Manager', 'world-viewer': 'World Viewer', versions: 'Versions Manager',
  plugins: 'Plugins Manager', databases: 'Databases', schedules: 'Schedules', backups: 'Backups'
};

const notBuilt = (name) => `<section class="mp-panel mp-empty-box"><div class="mp-soon">${icon('rocket', 26)}</div><h2>${esc(name)} is not built yet</h2>
<p class="mp-muted">This module is not part of the panel yet, so nothing is shown here instead of showing made-up data. It will appear in this place once it is built.</p></section>`;

/** Server-scoped placeholder for a sidebar entry that has no backend yet. */
const serverNotBuilt = ({ ctx, server, access: acc, slug }) => shell({ title: NOT_BUILT[slug], sub: server.name, active: slug, server: srv(server, acc), user: ctx.user, csrf: ctx.csrfToken, body: notBuilt(NOT_BUILT[slug]) });
/** Account-tab placeholder (API credentials, SSH keys). */
const accountNotBuilt = ({ ctx, name, active }) => shell({ title: name, sub: 'Manage your profile and account security.', active, user: ctx.user, csrf: ctx.csrfToken, body: notBuilt(name) });

const serverActivity = ({ ctx, server, access: acc, items }) => shell({ title: 'Activity', sub: server.name, active: 'activity-server', server: srv(server, acc), user: ctx.user, csrf: ctx.csrfToken,
  body: `<section class="mp-panel">${activityList(items)}</section>` });


/** Startup page (Pterodactyl style): start command, the installed runtime and the variables that build the command. */
function serverStartup({ ctx, server: s, access: acc, errors = {}, values = {}, flash }) {
  const admin = ctx.user.role === 'admin', bot = s.kind === 'bot', canEdit = acc.role === 'owner' || acc.role === 'admin';
  const fields = startup.schemaOf(s), cur = { ...startup.valuesOf(s), ...values };
  const cmd = startup.commandOf(s, runtimeConfig.defaultCommand), custom = startup.isCustom(s);
  const ver = startup.versions(), rt = bot ? servers.RUNTIMES[s.runtime] : null;
  const verText = bot ? ver[s.runtime] : null;
  const dis = canEdit ? '' : ' disabled';
  const err = (k) => `<p class="mp-error"${errors[k] ? '' : ' hidden'}>${esc(errors[k] || '')}</p>`;
  const card = (f) => f.bool
    ? `<div class="mp-startup-var"><div class="mp-startup-var-head"><strong>${esc(f.label)}</strong><code>${f.key}</code></div>
<label class="mp-check"><input type="checkbox" name="${f.key}" value="1"${cur[f.key] === '1' ? ' checked' : ''}${dis}> Enabled</label><p class="mp-hint">${esc(f.desc)}</p></div>`
    : `<div class="mp-startup-var${errors[f.key] ? ' has-error' : ''}"><div class="mp-startup-var-head"><strong>${esc(f.label)}</strong><code>${f.key}</code></div>
<div class="mp-input-wrap"><input name="${f.key}" type="text" value="${esc(cur[f.key])}" autocomplete="off" spellcheck="false" placeholder="${esc(f.def || '')}"${dis}></div><p class="mp-hint">${esc(f.desc)}</p>${err(f.key)}</div>`;
  const runtimeBox = bot
    ? `<section class="mp-panel"><h2>Runtime</h2><dl class="mp-dl"><dt>Language</dt><dd>${esc(rt?.label || s.runtime)}</dd>
<dt>Installed version</dt><dd>${verText ? `<code>${esc(verText)}</code>` : '<span class="mp-muted">Not found on this machine</span>'}</dd>
<dt>Recommended</dt><dd>${s.runtime === 'nodejs' ? 'Node.js 22 (LTS). Node 21 is end-of-life.' : 'Python 3.10 or newer.'}</dd></dl>
<p class="mp-muted">The runtime is installed on the machine and shared by all bots. Only the administrator can change its version.</p></section>`
    : `<section class="mp-panel"><h2>Server software</h2><dl class="mp-dl"><dt>Software</dt><dd>${esc(s.software)} ${esc(s.version)}</dd><dt>Java</dt><dd>Installed on the machine</dd></dl></section>`;
  const cmdBox = `<section class="mp-panel"><h2>Startup command</h2><pre class="mp-startup-cmd"><code>${esc(cmd)}</code></pre>
${custom ? '<p class="mp-hint">An administrator set a custom command. Saving the variables below replaces it with the standard one.</p>' : ''}
${admin ? `<div class="mp-field${errors.command ? ' has-error' : ''}"><label for="st-command">Custom command <span class="mp-muted">(administrators only)</span></label><div class="mp-input-wrap"><input id="st-command" name="command" type="text" value="${esc(values.command !== undefined ? values.command : (s.start_command || ''))}" autocomplete="off" spellcheck="false" placeholder="${bot ? esc(startup.buildCommand(s.runtime, cur)) : 'Leave empty for the stock Paper command'}"></div>
<p class="mp-hint">${bot ? 'Leave it as it is to use the variables below.' : 'Placeholders: <code>{{HEAP_MB}}</code> <code>{{XMS_MB}}</code> <code>{{RAM_MB}}</code> <code>{{CPU_CORES_INT}}</code>. Empty or "default" = stock command.'}</p>${err('command')}</div>` : ''}</section>`;
  const vars = fields.length ? `<section class="mp-panel"><h2>Variables</h2><div class="mp-startup-grid">${fields.map(card).join('')}</div></section>` : '';
  const save = canEdit || admin ? `<div class="mp-form-actions"><button type="submit" class="mp-button mp-btn-inline">${icon('rocket', 14)} Save startup</button><span class="mp-muted">Changes apply the next time the server starts.</span></div>` : '<p class="mp-muted">You can view the startup settings. Only the owner can change them.</p>';
  const body = `<form method="post" action="/dashboard/servers/${esc(s.identifier)}/startup" class="mp-form" novalidate><input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}">${cmdBox}${runtimeBox}${vars}${save}</form>`;
  return shell({ title: 'Startup', sub: s.name, active: 'startup', server: srv(s, acc), user: ctx.user, csrf: ctx.csrfToken, flash, body, styles: ['/css/admin.css'] });
}

const PERM = { 'control.start': 'Start', 'control.stop': 'Stop', 'control.restart': 'Restart', 'console.view': 'View console', 'console.send': 'Send commands', 'files.view': 'Browse files', 'files.write': 'Manage files' };

function serverUsers({ ctx, server, access: acc, owner, shared }) {
  const rows = [`<tr><td><strong>${esc(owner.username)}</strong></td><td>${esc(owner.email)}</td><td><span class="mp-badge mp-badge-online">Owner</span></td></tr>`,
    ...shared.map((u) => `<tr><td><strong>${esc(u.username)}</strong></td><td>${esc(u.email)}</td><td>${u.permissions.length ? esc(u.permissions.map((p) => PERM[p] || p).join(', ')) : '<span class="mp-muted">View only</span>'}</td></tr>`)].join('');
  const note = ctx.user.role === 'admin' || acc.role === 'owner' ? '<p class="mp-muted">Access is granted with <code>npm run grant-access</code>.</p>' : '';
  return shell({ title: 'Users', sub: server.name, active: 'users', server: srv(server, acc), user: ctx.user, csrf: ctx.csrfToken,
    body: `<section class="mp-panel"><div class="mp-table-wrap"><table class="mp-table"><thead><tr><th>User</th><th>Email</th><th>Access</th></tr></thead><tbody>${rows}</tbody></table></div>${note}</section>` });
}

function serverNetwork({ ctx, server: s, access: acc }) {
  const admin = ctx.user.role === 'admin';
  const kv = (k, v) => `<dt>${k}</dt><dd>${v}</dd>`;
  const body = `<section class="mp-panel"><h2>Connection</h2><dl class="mp-dl">
${kv('Server address', s.address ? `<code>${esc(s.address)}</code> <button type="button" class="mp-btn-sm" data-copy="${esc(s.address)}">Copy</button>` : '<span class="mp-muted">Not set</span>')}
${kv('Node', s.node_id ? esc(s.node_name) : '<span class="mp-muted">Unassigned</span>')}
${s.node_id && s.node_location ? kv('Location', esc(s.node_location)) : ''}
${s.node_id && admin ? kv('Node address', `<code>${esc(s.node_fqdn)}</code>`) : ''}
${kv('Last report', s.metrics_at ? f.relative(s.metrics_at) : 'Never')}</dl></section>`;
  return shell({ title: 'Network', sub: s.name, active: 'network', server: srv(s, acc), user: ctx.user, csrf: ctx.csrfToken, body });
}

module.exports = { NOT_BUILT, serverStartup, serverNotBuilt, accountNotBuilt, serverActivity, serverUsers, serverNetwork };
