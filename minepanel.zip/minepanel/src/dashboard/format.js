'use strict';
const mb = (v) => (v >= 1024 ? `${+(v / 1024).toFixed(v % 1024 ? 1 : 0)} GB` : `${Math.round(v)} MB`);
/** "512 B", "1.5 KB", "23.4 MB", "1.02 GB" – network sizes (1024 based, like the rest of the panel). null -> "—". */
function bytes(n) {
  if (n == null || !Number.isFinite(n)) return '—';
  if (n < 1024) return `${Math.round(n)} B`;
  const u = ['KB', 'MB', 'GB', 'TB']; let i = -1, v = n;
  do { v /= 1024; i++; } while (v >= 1024 && i < u.length - 1);
  return `${v.toFixed(v >= 100 ? 0 : v >= 10 ? 1 : 2)} ${u[i]}`;
}
const rate = (n) => (n == null || !Number.isFinite(n) ? '—' : `${bytes(n)}/s`);
const pct = (used, limit) => (limit > 0 ? Math.min(100, Math.round((used / limit) * 100)) : 0);

function relative(ts, now = Date.now()) {
  if (!ts) return 'Never';
  const s = Math.max(0, Math.round((now - ts) / 1000));
  if (s < 45) return 'just now';
  const units = [[60, 'min'], [3600, 'hour'], [86400, 'day'], [2592000, 'month'], [31536000, 'year']];
  let out = `${Math.round(s / 60)} min`;
  for (let i = 0; i < units.length; i++) {
    if (s >= units[i][0]) out = `${Math.round(s / units[i][0])} ${units[i][1]}${Math.round(s / units[i][0]) === 1 ? '' : 's'}`;
  }
  return `${out} ago`;
}
const cores = (cpuPct) => { const c = +(cpuPct / 100).toFixed(2); return `${c} ${c === 1 ? 'core' : 'cores'}`; };
/** "3 d 4 h", "2 h 15 min", "5 min" – elapsed time since ts (used for uptime). */
function duration(ts, now = Date.now()) {
  if (!ts) return '—';
  const m = Math.max(0, Math.floor((now - ts) / 60000)), d = Math.floor(m / 1440), h = Math.floor((m % 1440) / 60);
  if (d) return `${d} d ${h} h`;
  if (h) return `${h} h ${m % 60} min`;
  return m < 1 ? 'under a minute' : `${m} min`;
}
/** "2h 05m 09s" - exact elapsed time since ts (the banner uptime; public/js/dashboard.js keeps it ticking). */
function clock(ts, now = Date.now()) {
  if (!ts) return '—';
  const t = Math.max(0, Math.floor((now - ts) / 1000)), d = Math.floor(t / 86400), h = Math.floor((t % 86400) / 3600), m = Math.floor((t % 3600) / 60), sec = t % 60;
  const p = (n) => String(n).padStart(2, '0');
  return d ? `${d}d ${p(h)}h ${p(m)}m` : h ? `${h}h ${p(m)}m ${p(sec)}s` : `${m}m ${p(sec)}s`;
}
const date = (ts) => (ts ? new Date(ts).toISOString().slice(0, 10) : '—');
const iso = (ts) => (ts ? new Date(ts).toISOString() : '');

/** Shapes raw aggregate numbers into display values; shared by the page and the JSON API. */
function describe(s) {
  return {
    total: s.total, online: s.online, offline: s.offline, changing: s.changing,
    ram: { used: s.ram_used, limit: s.ram_limit, pct: pct(s.ram_used, s.ram_limit), text: `${mb(s.ram_used)} / ${mb(s.ram_limit)}` },
    cpu: { used: s.cpu_used / 100, limit: s.cpu_limit / 100, pct: pct(s.cpu_used, s.cpu_limit),
      text: `${+(s.cpu_used / 100).toFixed(2)} / ${+(s.cpu_limit / 100).toFixed(2)} cores` },
    disk: { used: s.disk_used, limit: s.disk_limit, pct: pct(s.disk_used, s.disk_limit), text: `${mb(s.disk_used)} / ${mb(s.disk_limit)}` },
    players: { online: s.players_online, max: s.players_max, text: `${s.players_online} / ${s.players_max}` }
  };
}

/** "2.1%" / "37%": share of the limit that is used (one decimal below 10%, so a quiet server does not read as 0%). */
const pctText = (used, limit) => { if (!(limit > 0)) return '0%'; const v = Math.min(100, (used / limit) * 100); return `${v < 10 ? +v.toFixed(1) : Math.round(v)}%`; };

/** Public JSON/display shape of one server row (joined with its node). Never exposes internal ids or the owner. */
function describeServer(s, { admin = false } = {}) {
  const live = s.status === 'online', measured = live && s.net_rx_bytes != null && s.net_tx_bytes != null;
  const free = (used, limit) => mb(Math.max(0, limit - used));
  return {
    identifier: s.identifier, name: s.name, status: s.status, task: s.task || null, software: s.software, version: s.version, address: s.address,
    players: { online: s.players_online, max: s.players_max },
    ram: { used: s.ram_used_mb, limit: s.ram_limit_mb, pct: pct(s.ram_used_mb, s.ram_limit_mb), allocated: mb(s.ram_limit_mb), text: `${mb(s.ram_used_mb)} / ${mb(s.ram_limit_mb)}`,
      pctText: pctText(s.ram_used_mb, s.ram_limit_mb), freeText: free(s.ram_used_mb, s.ram_limit_mb), usedText: mb(s.ram_used_mb) },
    cpu: { used: s.cpu_used_pct, limit: s.cpu_limit_pct, pct: pct(s.cpu_used_pct, s.cpu_limit_pct), allocated: cores(s.cpu_limit_pct),
      text: `${+(s.cpu_used_pct / 100).toFixed(2)} / ${cores(s.cpu_limit_pct)}`, pctText: pctText(s.cpu_used_pct, s.cpu_limit_pct), limitText: cores(s.cpu_limit_pct), usedText: `${+s.cpu_used_pct.toFixed(1)}% of one core` },
    disk: { used: s.disk_used_mb, limit: s.disk_limit_mb, pct: pct(s.disk_used_mb, s.disk_limit_mb), allocated: mb(s.disk_limit_mb), text: `${mb(s.disk_used_mb)} / ${mb(s.disk_limit_mb)}`,
      pctText: pctText(s.disk_used_mb, s.disk_limit_mb), freeText: free(s.disk_used_mb, s.disk_limit_mb), usedText: mb(s.disk_used_mb) },
    // Measured by the runtime from the kernel's TCP counters of the server's port; "available: false" when the server is not running or the host cannot measure it.
    net: { available: measured, note: measured ? 'TCP traffic on the server port, counted since the last start' : live ? 'Not available on this host: the runtime needs the ss tool (iproute2) to measure it' : 'The server is offline',
      rx: { bytes: measured ? s.net_rx_bytes : null, bps: measured ? s.net_rx_bps : null, total: measured ? bytes(s.net_rx_bytes) : '—', rate: measured ? rate(s.net_rx_bps) : '—' },
      tx: { bytes: measured ? s.net_tx_bytes : null, bps: measured ? s.net_tx_bps : null, total: measured ? bytes(s.net_tx_bytes) : '—', rate: measured ? rate(s.net_tx_bps) : '—' } },
    node: s.node_id ? { name: s.node_name, location: s.node_location, status: s.node_status, ...(admin ? { fqdn: s.node_fqdn } : {}) } : null,
    startedAt: live ? iso(s.started_at) : null, metricsAt: iso(s.metrics_at), createdAt: iso(s.created_at), updatedAt: iso(s.updated_at)
  };
}

module.exports = { bytes, rate, pctText, mb, pct, cores, duration, clock, relative, date, iso, describe, describeServer };
