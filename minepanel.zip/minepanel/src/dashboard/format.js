'use strict';
const mb = (v) => (v >= 1024 ? `${+(v / 1024).toFixed(v % 1024 ? 1 : 0)} GB` : `${Math.round(v)} MB`);
const pct = (used, limit) => (limit > 0 ? Math.min(100, Math.round((used / limit) * 100)) : 0);

function relative(ts, now = Date.now()) {
  if (!ts) return 'Never';
  const s = Math.max(0, Math.round((now - ts) / 1000));
  if (s < 45) return 'just now';
  const units = [[60, 'min'], [3600, 'hour'], [86400, 'day'], [2592000, 'month'], [31536000, 'year']];
  let out = `${Math.round(s / 60)} min`;
  for (let i = 0; i < units.length; i++) {
    if (s >= units[i][0]) out = `${Math.round(s / units[i][0])} ${units[i][1]}${Math.round(s / units[i][0]) === 1 ? '' : 's'}`;
  }
  return `${out} ago`;
}
const cores = (cpuPct) => { const c = +(cpuPct / 100).toFixed(2); return `${c} ${c === 1 ? 'core' : 'cores'}`; };
/** "3 d 4 h", "2 h 15 min", "5 min" – elapsed time since ts (used for uptime). */
function duration(ts, now = Date.now()) {
  if (!ts) return '—';
  const m = Math.max(0, Math.floor((now - ts) / 60000)), d = Math.floor(m / 1440), h = Math.floor((m % 1440) / 60);
  if (d) return `${d} d ${h} h`;
  if (h) return `${h} h ${m % 60} min`;
  return m < 1 ? 'under a minute' : `${m} min`;
}
const date = (ts) => (ts ? new Date(ts).toISOString().slice(0, 10) : '—');
const iso = (ts) => (ts ? new Date(ts).toISOString() : '');

/** Shapes raw aggregate numbers into display values; shared by the page and the JSON API. */
function describe(s) {
  return {
    total: s.total, online: s.online, offline: s.offline, changing: s.changing,
    ram: { used: s.ram_used, limit: s.ram_limit, pct: pct(s.ram_used, s.ram_limit), text: `${mb(s.ram_used)} / ${mb(s.ram_limit)}` },
    cpu: { used: s.cpu_used / 100, limit: s.cpu_limit / 100, pct: pct(s.cpu_used, s.cpu_limit),
      text: `${+(s.cpu_used / 100).toFixed(2)} / ${+(s.cpu_limit / 100).toFixed(2)} cores` },
    disk: { used: s.disk_used, limit: s.disk_limit, pct: pct(s.disk_used, s.disk_limit), text: `${mb(s.disk_used)} / ${mb(s.disk_limit)}` },
    players: { online: s.players_online, max: s.players_max, text: `${s.players_online} / ${s.players_max}` }
  };
}

/** Public JSON/display shape of one server row (joined with its node). Never exposes internal ids or the owner. */
function describeServer(s, { admin = false } = {}) {
  const live = s.status === 'online';
  return {
    identifier: s.identifier, name: s.name, status: s.status, software: s.software, version: s.version, address: s.address,
    players: { online: s.players_online, max: s.players_max },
    ram: { used: s.ram_used_mb, limit: s.ram_limit_mb, pct: pct(s.ram_used_mb, s.ram_limit_mb), allocated: mb(s.ram_limit_mb), text: `${mb(s.ram_used_mb)} / ${mb(s.ram_limit_mb)}` },
    cpu: { used: s.cpu_used_pct, limit: s.cpu_limit_pct, pct: pct(s.cpu_used_pct, s.cpu_limit_pct), allocated: cores(s.cpu_limit_pct),
      text: `${+(s.cpu_used_pct / 100).toFixed(2)} / ${cores(s.cpu_limit_pct)}` },
    disk: { used: s.disk_used_mb, limit: s.disk_limit_mb, pct: pct(s.disk_used_mb, s.disk_limit_mb), allocated: mb(s.disk_limit_mb), text: `${mb(s.disk_used_mb)} / ${mb(s.disk_limit_mb)}` },
    node: s.node_id ? { name: s.node_name, location: s.node_location, status: s.node_status, ...(admin ? { fqdn: s.node_fqdn } : {}) } : null,
    startedAt: live ? iso(s.started_at) : null, metricsAt: iso(s.metrics_at), createdAt: iso(s.created_at), updatedAt: iso(s.updated_at)
  };
}

module.exports = { mb, pct, cores, duration, relative, date, iso, describe, describeServer };
