'use strict';
// Account security pages: set up two-step verification, show backup codes, and the settings cards (2FA + Discord).
const { esc } = require('../views/layout');
const { icon } = require('../views/icons');
const config = require('../config');
const settings = require('../services/settings');
const twofactor = require('../services/twofactor');
const oauth = require('../services/oauth');
const totp = require('../lib/totp');
const qr = require('../lib/qr');

const csrfField = (ctx) => `<input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}">`;
const group4 = (s) => s.replace(/(.{4})/g, '$1 ').trim();
const passwordField = (id = 'sec-pw') => `<div class="mp-field"><label for="${id}">Confirm with your password</label><div class="mp-input-wrap"><input id="${id}" name="current_password" type="password" autocomplete="current-password" required></div></div>`;

/** The two cards on the Account settings page. */
function settingsCards(ctx) {
  const on = twofactor.isEnabled(ctx.user.id), left = on ? twofactor.backupLeft(ctx.user.id) : 0;
  const tfa = on
    ? `<section class="mp-panel mp-acct mp-half mp-sec-card"><p><span class="mp-badge mp-badge-online">enabled</span> Your account asks for a code from your authenticator app when you sign in. <span class="mp-muted">${left} backup code${left === 1 ? '' : 's'} left.</span></p>
<details class="mp-fold"><summary class="mp-btn-sm">${icon('key', 13)} <span>New backup codes</span></summary>
<form method="post" action="/dashboard/settings/2fa/backup-codes" class="mp-form mp-fold-body">${csrfField(ctx)}<p class="mp-muted">This replaces all old backup codes.</p>${passwordField('sec-pw-a')}<button type="submit" class="mp-button mp-btn-inline">Make new backup codes</button></form></details>
<details class="mp-fold"><summary class="mp-btn-sm mp-btn-stop">${icon('x', 13)} <span>Turn off two-step</span></summary>
<form method="post" action="/dashboard/settings/2fa/disable" class="mp-form mp-fold-body">${csrfField(ctx)}<p class="mp-muted">Your account will be protected by the password only.</p>${passwordField('sec-pw-b')}<button type="submit" class="mp-button mp-button-danger mp-btn-inline">Turn off</button></form></details></section>`
    : `<section class="mp-panel mp-acct mp-half mp-sec-card"><p class="mp-muted">You do not currently have two-step verification enabled on your account. Add an authenticator app (Google Authenticator, Authy, Microsoft Authenticator ...) so a stolen password alone cannot open your account.</p>
<a class="mp-button mp-btn-inline mp-button-link" href="/dashboard/settings/2fa">${icon('smartphone', 15)} <span>Enable Two-Step</span></a></section>`;

  let dis;
  if (!config.discord.enabled) dis = '<section class="mp-panel mp-acct mp-half mp-sec-card"><p class="mp-muted">Discord login is not set up on this panel yet. The administrator needs to add <code>DISCORD_CLIENT_ID</code> and <code>DISCORD_CLIENT_SECRET</code> to the <code>.env</code> file.</p></section>';
  else {
    const l = oauth.linkedFor('discord', ctx.user.id);
    dis = l
      ? `<section class="mp-panel mp-acct mp-half mp-sec-card"><p>${icon('discord', 16)} Linked to Discord${l.handle ? ` as <strong>${esc(l.handle)}</strong>` : ''}. You can use <em>Continue with Discord</em> on the sign-in page.</p>
<form method="post" action="/dashboard/settings/discord/unlink">${csrfField(ctx)}<button type="submit" class="mp-btn-sm mp-btn-stop">${icon('x', 13)} <span>Unlink Discord</span></button></form></section>`
      : `<section class="mp-panel mp-acct mp-half mp-sec-card"><p class="mp-muted">Link your Discord account to sign in with one tap. Only accounts you link here can sign in this way.</p>
<a class="mp-button mp-button-discord mp-btn-inline mp-button-link" href="/auth/discord?link=1">${icon('discord', 15)} <span>Link Discord</span></a></section>`;
  }
  return `<h2 class="mp-sect mp-acct">Two-Step Verification</h2>${tfa}<h2 class="mp-sect mp-acct">Discord</h2>${dis}`;
}

function setupPage({ ctx, secret, error }) {
  const { shell } = require('./views');
  const uri = totp.otpauthUri({ secret, account: ctx.user.email, issuer: settings.brand() });
  const body = `<section class="mp-panel mp-acct mp-setup">
<ol class="mp-steps">
<li><strong>Install an authenticator app</strong><span class="mp-muted"> such as Google Authenticator, Authy or Microsoft Authenticator.</span></li>
<li><strong>Add this account.</strong><span class="mp-muted"> Scan the code, or on this phone tap the button.</span></li></ol>
<div class="mp-qr-wrap">${qr.svg(uri, { label: 'Authenticator setup QR code' })}</div>
<p class="mp-center"><a class="mp-button mp-btn-inline mp-button-link" href="${esc(uri)}">${icon('smartphone', 15)} <span>Open in authenticator app</span></a></p>
<p class="mp-muted mp-center">Can't scan? Type this key in the app (time based):</p>
<p class="mp-center"><code class="mp-secret" data-secret>${esc(group4(secret))}</code> <button type="button" class="mp-icon-btn" data-copy="${esc(secret)}" aria-label="Copy key">${icon('copy', 14)}</button></p>
<form method="post" action="/dashboard/settings/2fa/enable" class="mp-form" novalidate>${csrfField(ctx)}
<ol class="mp-steps" start="3"><li><strong>Enter the 6-digit code</strong><span class="mp-muted"> the app shows now.</span></li></ol>
<div class="mp-field${error ? ' has-error' : ''}"><label for="tf-code">Authentication code</label><div class="mp-input-wrap"><input id="tf-code" class="mp-code-input" name="code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="7" pattern="[0-9 ]*" autofocus required></div><p class="mp-error"${error ? '' : ' hidden'}>${esc(error || '')}</p></div>
<div class="mp-form-actions"><button type="submit" class="mp-button mp-btn-inline">Turn on two-step</button><a class="mp-btn-sm" href="/dashboard/settings">Cancel</a></div></form></section>`;
  return shell({ title: 'Enable two-step verification', sub: 'Protect your account with an authenticator app.', active: 'settings', user: ctx.user, csrf: ctx.csrfToken, body });
}

function backupPage({ ctx, codes, fresh }) {
  const { shell } = require('./views');
  const body = `<section class="mp-panel mp-acct mp-setup">
<p>${fresh ? '<strong>Two-step verification is on.</strong> ' : ''}Save these backup codes somewhere safe. Each one works <strong>once</strong> if you lose your phone. <strong>They are shown only now.</strong></p>
<ul class="mp-backup" data-backup>${codes.map((c) => `<li><code>${esc(c)}</code></li>`).join('')}</ul>
<div class="mp-form-actions"><button type="button" class="mp-button mp-btn-inline" data-copy="${esc(codes.join('\n'))}">${icon('copy', 14)} <span>Copy all</span></button><a class="mp-btn-sm" href="/dashboard/settings">Done</a></div></section>`;
  return shell({ title: 'Backup codes', sub: 'Keep these safe.', active: 'settings', user: ctx.user, csrf: ctx.csrfToken, body });
}

module.exports = { settingsCards, setupPage, backupPage };
