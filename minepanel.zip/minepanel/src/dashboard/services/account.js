'use strict';
require('../migrations'); // ensure dashboard tables exist before preparing statements
const db = require('../../db');
const v = require('../../lib/validate');
const { hashPassword, verifyPassword } = require('../../lib/crypto');
const users = require('../../services/users');
const sessions = require('../../services/sessions');
const activity = require('./activity');

const q = {
  updateProfile: db.prepare('UPDATE users SET username = ?, email = ?, updated_at = ? WHERE id = ?'),
  sessions: db.prepare('SELECT id, created_at, last_seen_at, ip, user_agent, remember FROM sessions WHERE user_id = ? AND expires_at > ? ORDER BY last_seen_at DESC'),
  delOthers: db.prepare('DELETE FROM sessions WHERE user_id = ? AND id != ?'),
  delOne: db.prepare('DELETE FROM sessions WHERE user_id = ? AND id = ?'),
  countSessions: db.prepare('SELECT COUNT(*) AS n FROM sessions WHERE user_id = ? AND expires_at > ?')
};

async function updateProfile(user, { username, email, current_password: currentPassword }, ip) {
  const values = { username: String(username ?? '').trim(), email: String(email ?? '').trim() };
  const errors = v.collect({ username: v.username(values.username), email: v.email(values.email) });
  if (!currentPassword) errors.current_password = 'Enter your current password to confirm.';
  if (Object.keys(errors).length) return { errors, values };

  const row = users.findById(user.id);
  const changed = values.username !== row.username || values.email.toLowerCase() !== row.email;
  if (!changed) return { values, info: 'No changes to save.' };
  if (!(await verifyPassword(String(currentPassword), row.password_hash))) return { errors: { current_password: 'Incorrect password.' }, values };

  const byName = users.findByUsername(values.username), byMail = users.findByEmail(values.email);
  if (byName && byName.id !== user.id) errors.username = 'That username is already taken.';
  if (byMail && byMail.id !== user.id) errors.email = 'An account with that email already exists.';
  if (Object.keys(errors).length) return { errors, values };

  try { q.updateProfile.run(values.username, values.email.toLowerCase(), Date.now(), user.id); }
  catch (err) {
    const f = users.uniqueViolation(err);
    if (!f) throw err;
    return { errors: { [f]: f === 'email' ? 'An account with that email already exists.' : 'That username is already taken.' }, values };
  }
  activity.record({ userId: user.id, type: 'account.profile', message: 'Profile details updated', ip });
  return { ok: 'Profile updated.' };
}

async function changePassword(user, session, { current_password: current, password, confirm }, ip) {
  const errors = v.collect({ password: v.password(password), confirm: v.confirm(confirm, password) });
  if (!current) errors.current_password = 'Enter your current password.';
  if (Object.keys(errors).length) return { errors };
  const row = users.findById(user.id);
  if (!(await verifyPassword(String(current), row.password_hash))) return { errors: { current_password: 'Incorrect password.' } };
  if (String(password) === String(current)) return { errors: { password: 'Choose a password different from your current one.' } };

  users.setPassword(user.id, await hashPassword(String(password)));
  const others = q.delOthers.run(user.id, session.id).changes; // keep this device, sign out the rest
  activity.record({ userId: user.id, type: 'account.password', message: `Password changed${others ? `; ${others} other session${others === 1 ? '' : 's'} signed out` : ''}`, ip });
  return { ok: 'Password changed.' };
}

const listSessions = (userId) => q.sessions.all(userId, Date.now());
const countSessions = (userId) => q.countSessions.get(userId, Date.now()).n;

function revokeSession(user, currentSessionId, targetId) {
  if (targetId === currentSessionId) return { ok: false, message: 'Use Sign out to end your current session.' };
  const n = q.delOne.run(user.id, String(targetId)).changes;
  if (n) activity.record({ userId: user.id, type: 'account.session', message: 'Signed out another device' });
  return n ? { ok: true, message: 'Device signed out.' } : { ok: false, message: 'Session not found.' };
}

function revokeOthers(user, currentSessionId) {
  const n = q.delOthers.run(user.id, currentSessionId).changes;
  if (n) activity.record({ userId: user.id, type: 'account.session', message: `Signed out ${n} other device${n === 1 ? '' : 's'}` });
  return n;
}

module.exports = { updateProfile, changePassword, listSessions, countSessions, revokeSession, revokeOthers };
