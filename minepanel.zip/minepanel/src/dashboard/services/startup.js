'use strict';
// Startup (like Pterodactyl's Startup tab): the start command of a server and the variables that build it.
//   * Bots (Node.js / Python): variables MAIN_FILE, NODE_ARGS / PY_ARGS and AUTO_INSTALL. Saving them rebuilds the start command.
//   * Minecraft servers: the stock command is shown; only administrators can replace it.
// Administrators can also type their own start command for any server ("custom"); saving the variables again replaces it.
const { execFileSync } = require('node:child_process');
require('../migrations');
const db = require('../../db');
const servers = require('./servers');

const ENTRY_RE = /^(?!.*\.\.)[A-Za-z0-9_][A-Za-z0-9_./-]{0,59}$/;
const FLAG = '-{1,2}[A-Za-z0-9][A-Za-z0-9_.=:/,-]*';
const ARGS_RE = new RegExp(`^(${FLAG})( +${FLAG})*$`);

const SCHEMA = {
  nodejs: [
    { key: 'MAIN_FILE', label: 'Main file', def: 'index.js', desc: 'The file Node.js runs, inside the bot folder (e.g. index.js, bot.js, src/main.js).' },
    { key: 'NODE_ARGS', label: 'Node.js arguments', def: '', optional: true, desc: 'Optional flags put before the main file, e.g. --max-old-space-size=256.' },
    { key: 'AUTO_INSTALL', label: 'Install packages on start', def: '1', bool: true, desc: 'Runs "npm install" before every start when package.json exists.' }
  ],
  python: [
    { key: 'MAIN_FILE', label: 'Main file', def: 'main.py', desc: 'The file Python runs, inside the bot folder (e.g. main.py, bot.py).' },
    { key: 'PY_ARGS', label: 'Python arguments', def: '', optional: true, desc: 'Optional flags put before the main file, e.g. -X dev.' },
    { key: 'AUTO_INSTALL', label: 'Install requirements on start', def: '1', bool: true, desc: 'Runs "pip install -r requirements.txt" before every start when that file exists.' }
  ]
};
const ARGS_KEY = { nodejs: 'NODE_ARGS', python: 'PY_ARGS' };
const schemaOf = (server) => (server.kind === 'bot' ? SCHEMA[server.runtime] || [] : []);

/** The start command that the variables of a bot produce. */
function buildCommand(runtime, v) {
  const args = (v[ARGS_KEY[runtime]] || '').trim();
  return [runtime === 'python' ? 'python3 -u' : 'node', args, v.MAIN_FILE].filter(Boolean).join(' ');
}

/** Current values: stored ones, else what an existing command already says (bots created before this page), else the defaults. */
function valuesOf(server) {
  const fields = schemaOf(server), out = Object.fromEntries(fields.map((f) => [f.key, f.def]));
  let stored = {};
  try { stored = JSON.parse(server.startup_vars || '{}') || {}; } catch { /* ignore */ }
  if (!server.startup_vars && server.start_command) {
    const last = server.start_command.trim().split(/\s+/).pop();
    if (ENTRY_RE.test(last)) out.MAIN_FILE = last;
  }
  for (const f of fields) if (typeof stored[f.key] === 'string') out[f.key] = stored[f.key];
  return out;
}

const isCustom = (server) => server.kind === 'bot' && !!server.start_command && server.start_command !== buildCommand(server.runtime, valuesOf(server));

/** Command that really runs (what the Startup page shows). */
const commandOf = (server, defaultCommand) => server.start_command || (server.kind === 'bot' ? buildCommand(server.runtime, valuesOf(server)) : defaultCommand);

/**
 * Saves the variables (and, administrators only, a custom command). Returns { ok: true, server } or { ok: false, errors }.
 * `input` = raw form fields. Unknown fields are ignored.
 */
function save(server, input, { admin = false } = {}) {
  const errors = {}, fields = schemaOf(server), vals = {};
  for (const f of fields) {
    const raw = String(input[f.key] ?? '').trim();
    if (f.bool) { vals[f.key] = input[f.key] === '1' || input[f.key] === 'on' || input[f.key] === 'true' ? '1' : '0'; continue; }
    if (f.key === 'MAIN_FILE') { if (!ENTRY_RE.test(raw)) errors.MAIN_FILE = 'Use a file name like index.js (letters, numbers, dots, dashes, underscores, slashes; no "..").'; }
    else if (raw && (raw.length > 200 || !ARGS_RE.test(raw))) errors[f.key] = 'Use flags only, separated by spaces, e.g. --max-old-space-size=256.';
    vals[f.key] = raw;
  }
  let command = server.kind === 'bot' ? null : undefined;
  const typed = admin && input.command !== undefined ? String(input.command).trim() : null;
  if (typed !== null) {
    if (typed.length > 1000 || /[\r\n]/.test(typed)) errors.command = 'Use one line of up to 1000 characters.';
    else if (server.kind !== 'bot' && (typed === '' || typed === 'default')) command = null;           // back to the stock command
    else command = typed === 'default' ? null : typed;
  }
  if (Object.keys(errors).length) return { ok: false, errors, values: { ...vals, command: typed ?? '' } };
  const now = Date.now();
  if (server.kind === 'bot') {
    const generated = buildCommand(server.runtime, vals);
    const keepCustom = typed !== null && typed !== '' && typed !== 'default' && typed !== generated;
    const finalCommand = keepCustom ? typed : generated;
    db.prepare('UPDATE servers SET startup_vars = ?, start_command = ?, updated_at = ? WHERE id = ?').run(JSON.stringify(vals), finalCommand, now, server.id);
  } else if (command !== undefined) {
    db.prepare('UPDATE servers SET start_command = ?, updated_at = ? WHERE id = ?').run(command, now, server.id);
  }
  return { ok: true, server: db.prepare('SELECT * FROM servers WHERE id = ?').get(server.id) };
}

// Installed runtime versions (read from the machine, cached for a minute).
let cache = { at: 0, v: null };
function versions() {
  if (cache.v && Date.now() - cache.at < 60000) return cache.v;
  const ask = (bin, args) => { try { return execFileSync(bin, args, { encoding: 'utf8', timeout: 3000, stdio: ['ignore', 'pipe', 'pipe'] }).trim().replace(/^Python\s+/i, ''); } catch { return null; } };
  cache = { at: Date.now(), v: { nodejs: ask('node', ['-v']), python: ask('python3', ['--version']) }, };
  return cache.v;
}

module.exports = { SCHEMA, ENTRY_RE, schemaOf, buildCommand, valuesOf, isCustom, commandOf, save, versions };
