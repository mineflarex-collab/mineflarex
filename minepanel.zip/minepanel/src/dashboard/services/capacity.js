'use strict';
// VPS capacity. There is no limit on the NUMBER of servers: the only limit is the machine. Servers may use up to
// 90% of the VPS RAM, CPU and disk. A resource counts as full when either
//   * the limits given to all servers add up to 90% of it, or
//   * the VPS is really using 90% of it right now.
// Once any resource is full the admin gets a warning and no more servers can be created until the VPS is upgraded
// (or servers are removed).
//
// Environment overrides (containers often report the host's hardware): VPS_RAM_MB, VPS_CPU_CORES, VPS_DISK_MB, VPS_LIMIT_PCT.
require('../migrations');
const fs = require('node:fs');
const os = require('node:os');
const db = require('../../db');
const runtimeConfig = require('../../runtime/config');

const MB = 1024 * 1024;
const env = process.env;
const num = (v) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : null);
const limitPct = () => Math.min(100, num(env.VPS_LIMIT_PCT) || 90);

/** Nearest folder that exists (the servers folder is only created when the first server starts). */
function existingDir(dir) {
  let d = dir;
  while (d && !fs.existsSync(d)) { const up = require('node:path').dirname(d); if (up === d) break; d = up; }
  return d || '/';
}

function ramAvailableMb() {
  try {
    const m = /MemAvailable:\s+(\d+) kB/.exec(fs.readFileSync('/proc/meminfo', 'utf8'));
    if (m) return Number(m[1]) / 1024;
  } catch { /* not Linux */ }
  return os.freemem() / MB;
}

/** The machine: totals and what is really in use right now. */
function probeHost() {
  const cores = num(env.VPS_CPU_CORES) || os.cpus().length || 1;
  const ramTotal = num(env.VPS_RAM_MB) || os.totalmem() / MB;
  let diskTotal = num(env.VPS_DISK_MB), diskUsed = 0;
  try {
    const st = fs.statfsSync(existingDir(runtimeConfig.dataDir));
    const total = (st.blocks * st.bsize) / MB;
    diskUsed = total - (st.bavail * st.bsize) / MB;
    diskTotal = diskTotal || total;
  } catch { /* statfs unavailable */ }
  return {
    ram: { total: ramTotal, used: Math.max(0, os.totalmem() / MB - ramAvailableMb()) },     // real usage, even if VPS_RAM_MB overrides the total
    cpu: { total: cores * 100, used: Math.min(cores, os.loadavg()[0]) * 100 },       // 1-minute load average; 0 on Windows
    disk: { total: diskTotal || 0, used: Math.max(0, diskUsed) }
  };
}
let probe = probeHost;
/** Tests replace the machine with a fake one. Pass nothing to restore the real one. */
const setProbe = (fn) => { probe = fn || probeHost; };

const q = () => db.prepare('SELECT COALESCE(SUM(ram_limit_mb), 0) AS ram, COALESCE(SUM(cpu_limit_pct), 0) AS cpu, COALESCE(SUM(disk_limit_mb), 0) AS disk, COUNT(*) AS servers FROM servers').get();

const META = {
  ram: { label: 'RAM', fmt: (v) => (v >= 1024 ? `${+(v / 1024).toFixed(1)} GB` : `${Math.round(v)} MB`) },
  cpu: { label: 'CPU', fmt: (v) => { const c = +(v / 100).toFixed(2); return `${c} ${c === 1 ? 'core' : 'cores'}`; } },
  disk: { label: 'Disk', fmt: (v) => (v >= 1024 ? `${+(v / 1024).toFixed(1)} GB` : `${Math.round(v)} MB`) }
};
const pctOf = (v, total) => (total > 0 ? (v / total) * 100 : 0);

/** Where the VPS stands now. `extra` = limits of a server that is about to be created ({ ram, cpu, disk }). */
function status(extra = {}) {
  const host = probe(), alloc = q(), max = limitPct();
  const resources = Object.keys(META).map((key) => {
    const total = host[key].total, allocated = alloc[key] + (extra[key] || 0), used = host[key].used;
    const allocPct = pctOf(allocated, total), usedPct = pctOf(used, total), pct = Math.max(allocPct, usedPct);
    return { key, label: META[key].label, total, allocated, used, allocPct, usedPct, pct, budget: (total * max) / 100,
      full: pct >= max, totalText: META[key].fmt(total), allocatedText: META[key].fmt(allocated), usedText: META[key].fmt(used) };
  });
  return { limitPct: max, servers: alloc.servers, resources, full: resources.some((r) => r.full), fullResources: resources.filter((r) => r.full) };
}

/** Admin-facing warning for the centre of the screen, or null while there is room. */
function warning() {
  const s = status();
  if (!s.full) return null;
  const list = s.fullResources.map((r) => `${r.label} ${Math.floor(r.pct)}%`).join(', ');
  return { title: 'VPS is full', lines: [`Servers are using ${s.limitPct}% or more of this VPS (${list}).`, 'Do not create any more servers. Upgrade your VPS to add more.'], status: s };
}

/** { ok: true } or { ok: false, message } for a server with these limits. */
function canCreate({ ram = 0, cpu = 0, disk = 0 } = {}) {
  const now = status();
  if (now.full) return { ok: false, message: warning().lines.join(' ') };
  const after = status({ ram, cpu, disk }).resources.filter((r) => r.pct > now.limitPct);
  if (after.length) {
    return { ok: false, message: `This server would take ${after.map((r) => r.label).join(', ')} above ${now.limitPct}% of the VPS. Lower its limits, or upgrade your VPS.` };
  }
  return { ok: true };
}

/**
 * { ok: true } or { ok: false, message } when an existing server's limits change from `old` to `next` ({ ram, cpu, disk }).
 * Lowering a limit is always allowed (even on a full VPS); raising one must keep that resource at or below the VPS limit.
 */
function canResize(old, next) {
  const delta = {}, grow = [];
  for (const k of Object.keys(META)) { delta[k] = (next[k] || 0) - (old[k] || 0); if (delta[k] > 0) grow.push(k); }
  if (!grow.length) return { ok: true };
  const over = status(delta).resources.filter((r) => grow.includes(r.key) && r.pct > limitPct());
  if (over.length) return { ok: false, message: `These limits would take ${over.map((r) => r.label).join(', ')} above ${limitPct()}% of the VPS. Lower them, or upgrade your VPS.` };
  return { ok: true };
}

module.exports = { status, warning, canCreate, canResize, setProbe, limitPct };
