'use strict';
// VPS capacity, the Pterodactyl way: a server's RAM / CPU / disk limits are only a CEILING, not space that is kept
// for it. A server with a 4 GB limit that really uses 600 MB only takes 600 MB of the VPS, so many servers fit and
// the admin does not have to split the VPS up in advance.
//   * What counts is what the VPS REALLY uses right now. A resource is full at 90% real usage (VPS_LIMIT_PCT).
//   * When any resource is full the admin gets a warning and no more servers can be created until the VPS is
//     upgraded (or servers are removed / stopped).
//   * One server may not ask for more RAM or disk than the whole VPS has.
//   * Optional, like Pterodactyl's "overallocate": VPS_OVERALLOC_PCT=N also caps the SUM of the RAM and disk limits at
//     (100+N)% of the VPS. Unset (default) = no cap on the sum.
//
// Environment overrides (containers often report the host's hardware): VPS_RAM_MB, VPS_CPU_CORES, VPS_DISK_MB, VPS_LIMIT_PCT.
require('../migrations');
const fs = require('node:fs');
const os = require('node:os');
const db = require('../../db');
const runtimeConfig = require('../../runtime/config');

const MB = 1024 * 1024;
const env = process.env;
const num = (v) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : null);
const limitPct = () => Math.min(100, num(env.VPS_LIMIT_PCT) || 90);

/** Nearest folder that exists (the servers folder is only created when the first server starts). */
function existingDir(dir) {
  let d = dir;
  while (d && !fs.existsSync(d)) { const up = require('node:path').dirname(d); if (up === d) break; d = up; }
  return d || '/';
}

function ramAvailableMb() {
  try {
    const m = /MemAvailable:\s+(\d+) kB/.exec(fs.readFileSync('/proc/meminfo', 'utf8'));
    if (m) return Number(m[1]) / 1024;
  } catch { /* not Linux */ }
  return os.freemem() / MB;
}

// Real CPU use, averaged over the last minute from the kernel's own CPU counters (the load average spikes
// to "100%" for a moment whenever a Minecraft server starts, which used to mark the VPS as full).
let lastTimes = null; const cpuSamples = [];
function sampleCpu() {
  const t = os.cpus().reduce((a, c) => { const x = Object.values(c.times); a.total += x.reduce((p, n) => p + n, 0); a.idle += c.times.idle; return a; }, { total: 0, idle: 0 });
  if (lastTimes && t.total > lastTimes.total) {
    cpuSamples.push(1 - (t.idle - lastTimes.idle) / (t.total - lastTimes.total));
    if (cpuSamples.length > 12) cpuSamples.shift();
  }
  lastTimes = t;
}
function cpuBusyFraction() {
  sampleCpu();
  if (cpuSamples.length) return Math.min(1, Math.max(0, cpuSamples.reduce((a, b) => a + b, 0) / cpuSamples.length));
  return Math.min(1, os.loadavg()[1] / (os.cpus().length || 1));        // first minute after start: 5-minute load average
}
if (process.env.NODE_ENV !== 'test') { sampleCpu(); setInterval(sampleCpu, 5000).unref(); }

/** The machine: totals and what is really in use right now. */
function probeHost() {
  const cores = num(env.VPS_CPU_CORES) || os.cpus().length || 1;
  const ramTotal = num(env.VPS_RAM_MB) || os.totalmem() / MB;
  let diskTotal = num(env.VPS_DISK_MB), diskUsed = 0;
  try {
    const st = fs.statfsSync(existingDir(runtimeConfig.dataDir));
    const total = (st.blocks * st.bsize) / MB;
    diskUsed = total - (st.bavail * st.bsize) / MB;
    diskTotal = diskTotal || total;
  } catch { /* statfs unavailable */ }
  return {
    ram: { total: ramTotal, used: Math.max(0, os.totalmem() / MB - ramAvailableMb()) },     // real usage, even if VPS_RAM_MB overrides the total
    cpu: { total: cores * 100, used: cpuBusyFraction() * (os.cpus().length || 1) * 100 },       // busy cores really in use (even if VPS_CPU_CORES overrides the total)
    disk: { total: diskTotal || 0, used: Math.max(0, diskUsed) }
  };
}
let probe = probeHost;
/** Tests replace the machine with a fake one. Pass nothing to restore the real one. */
const setProbe = (fn) => { probe = fn || probeHost; };

const q = () => db.prepare('SELECT COALESCE(SUM(ram_limit_mb), 0) AS ram, COALESCE(SUM(cpu_limit_pct), 0) AS cpu, COALESCE(SUM(disk_limit_mb), 0) AS disk, COUNT(*) AS servers FROM servers').get();

const META = {
  ram: { label: 'RAM', fmt: (v) => (v >= 1024 ? `${+(v / 1024).toFixed(1)} GB` : `${Math.round(v)} MB`) },
  cpu: { label: 'CPU', fmt: (v) => { const c = +(v / 100).toFixed(2); return `${c} ${c === 1 ? 'core' : 'cores'}`; } },
  disk: { label: 'Disk', fmt: (v) => (v >= 1024 ? `${+(v / 1024).toFixed(1)} GB` : `${Math.round(v)} MB`) }
};
const pctOf = (v, total) => (total > 0 ? (v / total) * 100 : 0);

/** Where the VPS stands now. Real usage decides "full"; `allocated` (limits given to servers) is shown for information. */
function status() {
  const host = probe(), alloc = q(), max = limitPct();
  const resources = Object.keys(META).map((key) => {
    const total = host[key].total, allocated = alloc[key], used = host[key].used;
    const allocPct = pctOf(allocated, total), usedPct = pctOf(used, total), pct = usedPct;
    return { key, label: META[key].label, total, allocated, used, allocPct, usedPct, pct, budget: (total * max) / 100, free: Math.max(0, (total * max) / 100 - used),
      full: usedPct >= max, totalText: META[key].fmt(total), allocatedText: META[key].fmt(allocated), usedText: META[key].fmt(used) };
  });
  return { limitPct: max, servers: alloc.servers, resources, full: resources.some((r) => r.full), fullResources: resources.filter((r) => r.full) };
}

/** Admin-facing warning for the centre of the screen, or null while there is room. */
function warning() {
  const s = status();
  if (!s.full) return null;
  const list = s.fullResources.map((r) => `${r.label} ${Math.floor(r.pct)}%`).join(', ');
  return { title: 'VPS is full', lines: [`Servers are using ${s.limitPct}% or more of this VPS (${list}).`, 'Do not create any more servers. Upgrade your VPS to add more.'], status: s };
}

const overallocPct = () => (env.VPS_OVERALLOC_PCT != null && env.VPS_OVERALLOC_PCT !== '' && Number(env.VPS_OVERALLOC_PCT) >= 0 ? Number(env.VPS_OVERALLOC_PCT) : null);

/** Resources whose new limit (`want`, with `add` more promised in total) does not make sense for this VPS. */
function tooBig(now, want, add = want) {
  const oa = overallocPct();
  return now.resources.filter((r) => {
    if (r.key === 'cpu') return false;                                    // CPU is a ceiling: 100 = at most one core
    const w = want[r.key] || 0;
    return w > r.total || (oa != null && r.allocated + (add[r.key] || 0) > r.total * (1 + oa / 100));
  });
}

/** { ok: true } or { ok: false, message } for a server with these limits. */
function canCreate({ ram = 0, cpu = 0, disk = 0 } = {}) {
  const now = status();
  if (now.full) return { ok: false, message: warning().lines.join(' ') };
  const over = tooBig(now, { ram, cpu, disk });
  if (over.length) return { ok: false, message: `This server asks for more ${over.map((r) => r.label).join(', ')} than the whole VPS has${overallocPct() != null ? ' (or is allowed to promise)' : ''}. Lower its limits, or upgrade your VPS.` };
  return { ok: true };
}

/**
 * { ok: true } or { ok: false, message } when an existing server's limits change from `old` to `next` ({ ram, cpu, disk }).
 * Lowering a limit is always allowed (even on a full VPS); raising one needs a VPS that is not full.
 */
function canResize(old, next) {
  const delta = {}, grow = [];
  for (const k of Object.keys(META)) { delta[k] = (next[k] || 0) - (old[k] || 0); if (delta[k] > 0) grow.push(k); }
  if (!grow.length) return { ok: true };
  const now = status();
  const full = now.resources.filter((r) => grow.includes(r.key) && r.full);
  if (full.length) return { ok: false, message: `${full.map((r) => r.label).join(', ')} is full on this VPS (${now.limitPct}% in use), so limits cannot be raised. Lower them, or upgrade your VPS.` };
  const over = tooBig(now, next, delta).filter((r) => grow.includes(r.key));
  if (over.length) return { ok: false, message: `These limits ask for more ${over.map((r) => r.label).join(', ')} than the whole VPS has${overallocPct() != null ? ' (or is allowed to promise)' : ''}. Lower them, or upgrade your VPS.` };
  return { ok: true };
}

module.exports = { status, warning, canCreate, canResize, setProbe, limitPct };
