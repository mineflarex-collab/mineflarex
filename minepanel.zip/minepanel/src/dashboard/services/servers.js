'use strict';
require('../migrations'); // ensure dashboard tables exist before preparing statements
const crypto = require('node:crypto');
const db = require('../../db');
const activity = require('./activity');
const access = require('./access');
const { usesServerJar } = require('../../runtime/jar');
const runtimeConfig = require('../../runtime/config');

// Server rows joined with their node (node columns are NULL while a server is unassigned).
const SELECT = `SELECT s.*, n.name AS node_name, n.location AS node_location, n.status AS node_status, n.fqdn AS node_fqdn
                FROM servers s LEFT JOIN nodes n ON n.id = s.node_id`;

// A server is visible to its owner and to users it was shared with. Bind the user id twice.
const VISIBLE = '(s.owner_id = ? OR s.id IN (SELECT server_id FROM server_access WHERE user_id = ?))';

const q = {
  insert: db.prepare(`INSERT INTO servers (identifier, owner_id, node_id, name, software, version, address, ram_limit_mb, cpu_limit_pct, disk_limit_mb, players_max, start_command, kind, runtime, created_at, updated_at)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`),
  byKind: db.prepare(`SELECT s.*, n.name AS node_name, n.location AS node_location, n.status AS node_status, n.fqdn AS node_fqdn, u.username AS owner_name
                      FROM servers s LEFT JOIN nodes n ON n.id = s.node_id LEFT JOIN users u ON u.id = s.owner_id
                      WHERE s.kind = ? AND (? = '' OR s.name LIKE ? ESCAPE '\\' OR s.identifier LIKE ? ESCAPE '\\' OR u.username LIKE ? ESCAPE '\\')
                      ORDER BY (s.status = 'online') DESC, s.name COLLATE NOCASE LIMIT ?`),
  countByKind: db.prepare('SELECT COUNT(*) AS n FROM servers WHERE kind = ?'),
  detail: db.prepare(`${SELECT} WHERE ${VISIBLE} AND s.identifier = ?`),
  visible: db.prepare(`${SELECT} WHERE ${VISIBLE} ORDER BY s.name COLLATE NOCASE LIMIT ?`),
  commands: db.prepare('SELECT * FROM server_commands WHERE server_id = ? ORDER BY id DESC LIMIT ?'),
  nodeFacets: db.prepare(`SELECT DISTINCT n.id, n.name FROM servers s JOIN nodes n ON n.id = s.node_id WHERE ${VISIBLE} ORDER BY n.name COLLATE NOCASE`),
  softwareFacets: db.prepare(`SELECT DISTINCT s.software FROM servers s WHERE ${VISIBLE} ORDER BY s.software COLLATE NOCASE`),
  unassigned: db.prepare(`SELECT 1 FROM servers s WHERE ${VISIBLE} AND s.node_id IS NULL LIMIT 1`),
  assignNode: db.prepare('UPDATE servers SET node_id = ?, updated_at = ? WHERE id = ?'),
  setResources: db.prepare('UPDATE servers SET ram_limit_mb = ?, cpu_limit_pct = ?, disk_limit_mb = ?, address = ?, players_max = COALESCE(?, players_max), updated_at = ? WHERE id = ?'),
  role: db.prepare('SELECT role FROM users WHERE id = ?'),
  all: db.prepare(`SELECT s.*, n.name AS node_name, n.location AS node_location, n.status AS node_status, n.fqdn AS node_fqdn, u.username AS owner_name
                   FROM servers s LEFT JOIN nodes n ON n.id = s.node_id LEFT JOIN users u ON u.id = s.owner_id
                   ORDER BY (s.status = 'online') DESC, s.name COLLATE NOCASE LIMIT ?`),
  detailAny: db.prepare(`${SELECT} WHERE s.identifier = ?`),
  byId: db.prepare('SELECT * FROM servers WHERE id = ?'),
  owned: db.prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?'),
  list: db.prepare(`${SELECT} WHERE s.owner_id = ? ORDER BY (s.status = 'online') DESC, s.name COLLATE NOCASE LIMIT ?`),
  pending: db.prepare("SELECT 1 FROM server_commands WHERE server_id = ? AND status = 'pending'"),
  addCommand: db.prepare('INSERT INTO server_commands (server_id, user_id, command, created_at) VALUES (?, ?, ?, ?)'),
  setStatus: db.prepare('UPDATE servers SET status = ?, task = ?, updated_at = ? WHERE id = ?'),
  summary: db.prepare(`SELECT
      COUNT(*)                                                    AS total,
      COALESCE(SUM(status = 'online'), 0)                         AS online,
      COALESCE(SUM(status IN ('offline','crashed')), 0)           AS offline,
      COALESCE(SUM(status IN ('starting','stopping')), 0)         AS changing,
      COALESCE(SUM(ram_limit_mb), 0)                              AS ram_limit,
      COALESCE(SUM(CASE WHEN status = 'online' THEN ram_used_mb END), 0)  AS ram_used,
      COALESCE(SUM(cpu_limit_pct), 0)                             AS cpu_limit,
      COALESCE(SUM(CASE WHEN status = 'online' THEN cpu_used_pct END), 0) AS cpu_used,
      COALESCE(SUM(disk_limit_mb), 0)                             AS disk_limit,
      COALESCE(SUM(disk_used_mb), 0)                              AS disk_used,
      COALESCE(SUM(CASE WHEN status = 'online' THEN players_online END), 0) AS players_online,
      COALESCE(SUM(players_max), 0)                               AS players_max
    FROM servers WHERE owner_id = ?`)
};

// Which quick actions are valid in which state, and the transitional status they cause (`to` may be a function of the
// current status). `task` is the long-running job shown to the user instead of the plain status (see migration #7).
const TRANSITIONS = {
  start:     { from: ['offline', 'crashed'],            to: 'starting', label: 'Start' },
  stop:      { from: ['online', 'starting'],            to: 'stopping', label: 'Stop' },
  restart:   { from: ['online'],                        to: 'stopping', label: 'Restart' },
  // Reinstall: a running server is stopped first (status stopping); a stopped one keeps its status. The runtime
  // then replaces the server software and leaves the server offline.
  reinstall: { from: ['offline', 'crashed', 'online'],  to: (status) => (status === 'online' ? 'stopping' : status), label: 'Reinstall', task: 'reinstall' }
};
const allowedActions = (status) => Object.keys(TRANSITIONS).filter((a) => TRANSITIONS[a].from.includes(status));

/** Why a server cannot be reinstalled (null = it can). Only the stock Paper setup has software the panel can fetch again. */
function reinstallProblem(server) {
  if (server.kind === 'bot') return `${server.name} is a bot: there is no server software to reinstall.`;
  if (!usesServerJar(server.start_command || runtimeConfig.defaultCommand)) return `${server.name} uses a custom start command, so there is no server.jar the panel can reinstall.`;
  return null;
}

/** Short public identifier, e.g. "a3f91c2e" (8 hex chars, unique across the panel). */
const newIdentifier = () => crypto.randomBytes(4).toString('hex');
const IDENTIFIER_RE = /^[0-9a-f]{8}$/;

// Servers nest: 'mc' = MC Host (Paper), 'bot' = Bot Host (Python or Node.js, preinstalled on the machine).
const KINDS = ['mc', 'bot'];
const RUNTIMES = {
  python: { label: 'Python', command: (entry) => `python3 -u ${entry}`, defaultEntry: 'main.py' },
  nodejs: { label: 'Node.js', command: (entry) => `node ${entry}`, defaultEntry: 'index.js' }
};

function create({ ownerId, name, software = 'paper', version = 'latest', address = null, ramLimitMb = 2048, cpuLimitPct = 100, diskLimitMb = 10240, playersMax = 20, nodeId = null, startCommand = null, kind = 'mc', runtime = null }) {
  if (!KINDS.includes(kind)) throw new Error(`Unknown server kind "${kind}"`);
  if (kind === 'bot' && !RUNTIMES[runtime]) throw new Error('A bot needs a runtime (python or nodejs).');
  const now = Date.now();
  for (let attempt = 0; ; attempt++) {
    try {
      const r = q.insert.run(newIdentifier(), ownerId, nodeId, name.trim(), software, version, address, ramLimitMb, cpuLimitPct, diskLimitMb, playersMax, startCommand, kind, kind === 'bot' ? runtime : null, now, now);
      return q.byId.get(Number(r.lastInsertRowid));
    } catch (err) {
      // Astronomically unlikely identifier collision: retry with a new one. Any other error (e.g. duplicate name) propagates.
      if (!/servers\.identifier/.test(err.message) || attempt >= 5) throw err;
    }
  }
}

function assignNode(serverId, nodeId) { q.assignNode.run(nodeId, Date.now(), serverId); }

/** Admin edit: memory / CPU / disk limits and the public address (IP). playersMax = null keeps the current value. Returns the fresh row. */
function updateResources(serverId, { ramLimitMb, cpuLimitPct, diskLimitMb, address = null, playersMax = null }) {
  q.setResources.run(ramLimitMb, cpuLimitPct, diskLimitMb, address, playersMax, Date.now(), serverId);
  return q.byId.get(serverId);
}

const listForOwner = (ownerId, limit = 1000) => q.list.all(ownerId, limit);
/** Every server the user can see (own + shared), for live updates. */
const isAdmin = (userId) => q.role.get(userId)?.role === 'admin';
/** Every server the user can see (own + shared; administrators see all), for live updates. */
const listVisible = (userId, limit = 1000) => (isAdmin(userId) ? q.all.all(limit) : q.visible.all(userId, userId, limit));
/** All servers on the panel with their owner's username (administrators only: callers must check the role). */
const listAll = (limit = 1000) => q.all.all(limit);
/** Servers of one kind with their owner and node, newest-online first (administrators only: callers must check the role). */
const listByKind = (kind, search = '', limit = 500) => {
  const t = String(search).trim().slice(0, 100), like = `%${t.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
  return q.byKind.all(kind, t, like, like, like, limit);
};
const countByKind = (kind) => q.countByKind.get(kind).n;
const getForOwner = (ownerId, id) => q.owned.get(id, ownerId) || null;
const summaryFor = (ownerId) => q.summary.get(ownerId);

// ---------------------------------------------------------------------------------------------
// Server management list: search, filters, sorting, pagination, details
// ---------------------------------------------------------------------------------------------
const STATUSES = ['online', 'offline', 'starting', 'stopping', 'crashed'];
const PER_PAGE = 20;
// Whitelist: user input only ever selects a key here, it is never interpolated into SQL.
const SORTS = {
  name: 's.name COLLATE NOCASE', status: 's.status', ram: 's.ram_limit_mb', cpu: 's.cpu_limit_pct',
  disk: 's.disk_limit_mb', node: 'n.name COLLATE NOCASE', created: 's.created_at'
};

const one = (v) => (Array.isArray(v) ? v[0] : v);

/** Turns raw query-string values into a clean, safe filter object (unknown values fall back to defaults). */
function normalizeFilters(raw = {}) {
  const text = (v, max) => String(one(v) ?? '').trim().slice(0, max);
  const status = text(raw.status, 20).toLowerCase();
  const node = text(raw.node, 12).toLowerCase();
  const sort = text(raw.sort, 12).toLowerCase();
  return {
    q: text(raw.q, 100),
    status: STATUSES.includes(status) ? status : '',
    node: node === 'none' || /^\d{1,9}$/.test(node) ? node : '',
    software: text(raw.software, 40),
    sort: Object.hasOwn(SORTS, sort) ? sort : 'name',
    dir: text(raw.dir, 4).toLowerCase() === 'desc' ? 'desc' : 'asc',
    page: Math.max(1, parseInt(text(raw.page, 6), 10) || 1)
  };
}

const escLike = (v) => v.replace(/[\\%_]/g, (c) => `\\${c}`);

function buildWhere(ownerId, f, { skipStatus = false } = {}) {
  const where = [VISIBLE], args = [ownerId, ownerId];
  if (f.q) {
    const like = `%${escLike(f.q)}%`;
    const cols = ['s.name', 's.identifier', 's.address', 's.software', 's.version', 'n.name', 'n.location'];
    where.push(`(${cols.map((c) => `${c} LIKE ? ESCAPE '\\'`).join(' OR ')})`);
    args.push(...cols.map(() => like));
  }
  if (f.status && !skipStatus) { where.push('s.status = ?'); args.push(f.status); }
  if (f.node === 'none') where.push('s.node_id IS NULL');
  else if (f.node) { where.push('s.node_id = ?'); args.push(Number(f.node)); }
  if (f.software) { where.push('s.software = ? COLLATE NOCASE'); args.push(f.software); }
  return { sql: where.join(' AND '), args };
}

/** One page of the owner's servers matching the filters. Always scoped to ownerId. */
function search(ownerId, filters, perPage = PER_PAGE) {
  const f = normalizeFilters(filters);
  const { sql, args } = buildWhere(ownerId, f);
  const total = db.prepare(`SELECT COUNT(*) AS n FROM servers s LEFT JOIN nodes n ON n.id = s.node_id WHERE ${sql}`).get(...args).n;
  const pages = Math.max(1, Math.ceil(total / perPage));
  const page = Math.min(f.page, pages);
  const items = db.prepare(`${SELECT} WHERE ${sql} ORDER BY ${SORTS[f.sort]} ${f.dir === 'desc' ? 'DESC' : 'ASC'}, s.id LIMIT ? OFFSET ?`)
    .all(...args, perPage, (page - 1) * perPage);
  return { items, total, page, pages, perPage, filters: { ...f, page } };
}

/** Per-status counts for the filter chips; they follow the other active filters but ignore the status filter itself. */
function statusCounts(ownerId, filters) {
  const f = normalizeFilters(filters);
  const { sql, args } = buildWhere(ownerId, f, { skipStatus: true });
  const rows = db.prepare(`SELECT s.status, COUNT(*) AS n FROM servers s LEFT JOIN nodes n ON n.id = s.node_id WHERE ${sql} GROUP BY s.status`).all(...args);
  const counts = Object.fromEntries(STATUSES.map((s) => [s, 0]));
  let all = 0;
  for (const r of rows) { counts[r.status] = r.n; all += r.n; }
  return { all, ...counts };
}

/** Values for the filter drop-downs: only nodes/software the user actually has. */
function facets(ownerId) {
  return { nodes: q.nodeFacets.all(ownerId, ownerId), software: q.softwareFacets.all(ownerId, ownerId).map((r) => r.software), hasUnassigned: !!q.unassigned.get(ownerId, ownerId) };
}

/** Details lookup by public identifier; null for unknown identifiers and for other users' servers. */
function getByIdentifier(ownerId, identifier) {
  if (!IDENTIFIER_RE.test(String(identifier))) return null;
  return (isAdmin(ownerId) ? q.detailAny.get(String(identifier)) : q.detail.get(ownerId, ownerId, String(identifier))) || null;
}
const recentCommands = (serverId, limit = 10) => q.commands.all(serverId, limit);

// Destructive power actions must be explicitly confirmed (enforced here, so the UI and the JSON API behave the same).
const CONFIRM = new Set(['stop', 'restart', 'reinstall']);
const fail = (code, message, extra = {}) => ({ ok: false, code, message, ...extra });

/** Which of the quick actions this access level may use right now (permission AND current state AND not busy with a job). */
const allowedActionsFor = (acc, server) => {
  if (!acc || server.task) return [];
  return allowedActions(server.status).filter((a) => acc.can(a) && (a !== 'reinstall' || !reinstallProblem(server)));
};

/**
 * Power action requested by a user (start / stop / restart / reinstall). Checks, in order: action exists, server visible
 * to the user, permission, confirmation (stop/restart), valid state, no other command in progress.
 * The panel never fakes a result: it queues a command and moves the server into a transitional state;
 * the runtime (src/runtime) executes it and reports the real status back.
 * Result: { ok, code, message, ... } where code is ok | unknown_action | not_found | forbidden |
 * confirmation_required | invalid_state | busy.
 */
function requestCommand(user, serverId, action, ip, { confirmed = false } = {}) {
  const t = TRANSITIONS[action];
  if (!t) return fail('unknown_action', 'Unknown action.');
  const row = Number.isInteger(serverId) ? q.byId.get(serverId) : null;
  const acc = row ? access.forUser(user.id, row) : null;
  if (!row || !acc) return fail('not_found', 'Server not found.');
  if (!acc.can(action)) return fail('forbidden', `You do not have permission to ${action} ${row.name}.`);
  if (CONFIRM.has(action) && !confirmed) return fail('confirmation_required', `Please confirm that you want to ${action} ${row.name}.`, { identifier: row.identifier });

  let command, next;
  db.exec('BEGIN IMMEDIATE');
  try {
    const server = q.byId.get(row.id);            // re-read inside the write lock: the runtime may have changed it meanwhile
    if (server.task) {
      db.exec('ROLLBACK');
      return fail('busy', `${server.name} is being reinstalled. Please wait until it has finished.`);
    }
    if (!t.from.includes(server.status)) {
      db.exec('ROLLBACK');
      return fail('invalid_state', `${server.name} cannot be ${action === 'stop' ? 'stopped' : action + 'ed'} while it is ${server.status}.`);
    }
    const problem = action === 'reinstall' ? reinstallProblem(server) : null;
    if (problem) {
      db.exec('ROLLBACK');
      return fail('invalid_state', problem);
    }
    // One command at a time per server; the only exception is stopping a server that is still starting up.
    if (q.pending.get(server.id) && !(action === 'stop' && server.status === 'starting')) {
      db.exec('ROLLBACK');
      return fail('busy', `A command for ${server.name} is already in progress.`);
    }
    const r = q.addCommand.run(server.id, user.id, action, Date.now());
    command = { id: Number(r.lastInsertRowid), command: action, status: 'pending' };
    next = typeof t.to === 'function' ? t.to(server.status) : t.to;
    q.setStatus.run(next, t.task || null, Date.now(), server.id);
    db.exec('COMMIT');
  } catch (err) { db.exec('ROLLBACK'); throw err; }

  activity.record({ userId: row.owner_id, serverId: row.id, serverName: row.name, type: `server.${action}`,
    message: `${t.label} requested for ${row.name}${user.id === row.owner_id ? '' : ` by ${user.username}`}`, ip });
  return { ok: true, code: 'ok', message: `${t.label} command sent to ${row.name}.`, status: next, task: t.task || null, command, identifier: row.identifier };
}

module.exports = {
  KINDS, RUNTIMES, listByKind, countByKind,
  create, assignNode, updateResources, listForOwner, listVisible, listAll, isAdmin, getForOwner, summaryFor, requestCommand, allowedActions, allowedActionsFor, reinstallProblem, CONFIRM, TRANSITIONS,
  STATUSES, PER_PAGE, normalizeFilters, search, statusCounts, facets, getByIdentifier, recentCommands
};
