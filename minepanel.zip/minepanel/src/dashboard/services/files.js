'use strict';
// File manager: browse, search, create, rename and delete inside ONE server's directory on disk.
//
// The directory is the same one the runtime starts the game process in: <RUNTIME_DATA_DIR>/<identifier>/.
// Nothing is stored in the database and nothing is simulated: every call reads or changes the real files.
//
// Safety rules (all enforced here, so the web UI and the JSON API behave the same):
//  * Paths from the client are lists of names relative to the server directory. ".." is rejected outright
//    (never "collapsed"), NUL bytes are rejected, and every name is validated.
//  * Symlinks cannot be used to escape: a directory is only opened if its *real* path is inside the server
//    directory, and entries are always addressed through the real path of their parent. Symlinks themselves are
//    never followed when deleting (the link is removed, not its target) and never during search.
//  * The server directory itself can never be renamed or deleted.
//  * Errors never contain absolute host paths.
const fs = require('node:fs');
const fsp = fs.promises;
const path = require('node:path');
const runtime = require('../../runtime/config');
const crypto = require('node:crypto');
const { dirSizeBytes } = require('../../lib/dirsize');
const archive = require('../../lib/archive');

const MAX_ENTRIES = 5000;       // entries returned for one folder (the rest is reported as truncated)
const MAX_NAME_BYTES = 255;     // the limit of ext4/NTFS/APFS
const MAX_PATH_CHARS = 4096;
const MAX_DELETE = 100;         // items per delete request
const SEARCH = { maxResults: 200, maxDepth: 24, maxVisited: 100000, maxMs: 4000, maxConcurrent: 4 };
const MAX_EDIT_BYTES = 1024 * 1024;          // text files above this are download-only
const CHUNK_MAX = 64 * 1024 * 1024;          // one upload request carries at most this many bytes (Cloudflare caps a request at 100 MB)
const UPLOAD_MAX = (Number(process.env.UPLOAD_MAX_MB) || 2048) * 1024 * 1024;
const NOFOLLOW = fs.constants.O_NOFOLLOW || 0;
const IDENTIFIER_RE = /^[A-Za-z0-9_-]{1,64}$/;

const STATUS = { bad_path: 400, bad_query: 422, name_invalid: 422, too_many: 422, not_found: 404, too_large: 413, disk_full: 413, conflict: 409, not_text: 415, not_archive: 415, corrupt: 422, exists: 409, not_dir: 409, forbidden: 403, root_protected: 403, busy: 429 };
class FileError extends Error {
  constructor(code, message) { super(message); this.code = code; this.status = STATUS[code] || 500; }
}

const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });
const within = (root, p) => p === root || p.startsWith(root.endsWith(path.sep) ? root : root + path.sep);
const display = (segs) => `/${segs.join('/')}`;
let activeSearches = 0;

/** Translates operating-system errors into FileErrors with safe messages. Anything unexpected is rethrown (HTTP 500). */
function mapError(e) {
  if (e instanceof FileError) return e;
  switch (e && e.code) {
    case 'ENOENT': return new FileError('not_found', 'That file or folder does not exist (it may have been moved or deleted).');
    case 'ENOTDIR': return new FileError('not_dir', 'That is not a folder.');
    case 'EEXIST': case 'ENOTEMPTY': return new FileError('exists', 'Something with that name already exists here.');
    case 'EACCES': case 'EPERM': case 'EROFS': return new FileError('forbidden', 'The operating system refused this change (permissions or read-only storage).');
    case 'ENAMETOOLONG': return new FileError('name_invalid', `Names can be at most ${MAX_NAME_BYTES} bytes long.`);
    case 'ELOOP': return new FileError('forbidden', 'That location contains a symbolic-link loop.');
    default: return e;
  }
}
const guard = async (fn) => { try { return await fn(); } catch (e) { throw mapError(e); } };

/** "/plugins/Essentials/config.yml" -> ['plugins','Essentials','config.yml']. Empty / "/" -> []. */
function parseSegments(input) {
  const p = input == null || input === '' ? '/' : input;
  if (typeof p !== 'string' || p.length > MAX_PATH_CHARS || p.includes('\0')) throw new FileError('bad_path', 'That path is not valid.');
  const segs = p.split('/').filter((s) => s !== '' && s !== '.');
  for (const s of segs) {
    if (s === '..') throw new FileError('bad_path', 'That path is not valid.');
    if (process.platform === 'win32' && /[\\:]/.test(s)) throw new FileError('bad_path', 'That path is not valid.');
  }
  return segs;
}

/** Validates a single file or folder name typed by a user. */
function validateName(raw) {
  const bad = (m) => { throw new FileError('name_invalid', m); };
  if (typeof raw !== 'string' || raw === '') bad('Enter a name.');
  if (raw !== raw.trim()) bad('Names cannot start or end with a space.');
  if (raw === '.' || raw === '..') bad('That name is not allowed.');
  if (/[/\0]/.test(raw)) bad('Names cannot contain "/" or null characters.');
  if (/[\x00-\x1f\x7f]/.test(raw)) bad('Names cannot contain control characters.');
  if (process.platform === 'win32' && /[\\:*?"<>|]/.test(raw)) bad('Names cannot contain \\ : * ? " < > |');
  if (Buffer.byteLength(raw) > MAX_NAME_BYTES) bad(`Names can be at most ${MAX_NAME_BYTES} bytes long.`);
  return raw;
}

const rootOf = (server) => {
  if (!server || !IDENTIFIER_RE.test(String(server.identifier))) throw new FileError('not_found', 'Server not found.');
  return path.resolve(runtime.dataDir, String(server.identifier));
};

/** The server directory's real path. It is created on first use, exactly as the runtime would on start. */
async function openRoot(server) {
  const root = rootOf(server);
  await fsp.mkdir(root, { recursive: true });
  return fsp.realpath(root);
}

/**
 * Disk allocation of the server: refuses a change that would take the server folder above its disk limit.
 * `addBytes` = how much the change adds (a replaced file is passed as new size minus old size).
 */
async function ensureRoom(server, root, addBytes) {
  if (!(addBytes > 0) || !(server.disk_limit_mb > 0)) return;
  const limit = server.disk_limit_mb * 1048576, used = await dirSizeBytes(root);
  if (used + addBytes > limit) {
    const mb = (b) => `${Math.max(0, Math.round(b / 1048576))} MB`;
    throw new FileError('disk_full', `Not enough disk space: this server may use ${mb(limit)} and already uses ${mb(used)}. Delete some files first.`);
  }
}

/** Real path of a folder given by segments; it must exist, be a folder and lie inside the server directory. */
async function realDir(root, segs) {
  const real = await fsp.realpath(path.join(root, ...segs));
  if (!within(root, real)) throw new FileError('forbidden', 'That location is outside the server directory.');
  if (!(await fsp.stat(real)).isDirectory()) throw new FileError('not_dir', 'That is not a folder.');
  return real;
}

/** An existing entry (file, folder or link itself - never its target), addressed through its parent's real path. */
async function entryAt(root, segs) {
  if (!segs.length) throw new FileError('root_protected', 'The server\'s root folder cannot be renamed or deleted.');
  const parent = await realDir(root, segs.slice(0, -1));
  const abs = path.join(parent, segs[segs.length - 1]);
  return { parent, abs, name: segs[segs.length - 1], st: await fsp.lstat(abs) };
}

/** One row of a listing. Symlinks are reported as what they point to when that is inside the server directory, otherwise as "link". */
async function describe(root, dir, name) {
  const abs = path.join(dir, name), st = await fsp.lstat(abs);
  let type = st.isDirectory() ? 'dir' : st.isFile() ? 'file' : st.isSymbolicLink() ? 'link' : 'other', size = st.isFile() ? st.size : null, symlink = false;
  if (st.isSymbolicLink()) {
    symlink = true;
    try {
      const real = await fsp.realpath(abs);
      if (within(root, real)) {
        const t = await fsp.stat(real);
        type = t.isDirectory() ? 'dir' : t.isFile() ? 'file' : 'other';
        size = t.isFile() ? t.size : null;
      }
    } catch { /* broken link: stays "link" */ }
  }
  return { name, type, symlink, size, modified: Math.floor(st.mtimeMs) };
}

const byTypeThenName = (a, b) => ((a.type === 'dir') === (b.type === 'dir') ? collator.compare(a.name, b.name) || (a.name < b.name ? -1 : 1) : a.type === 'dir' ? -1 : 1);

/** Lists one folder. `rel` is "/a/b" style. */
function list(server, rel) {
  return guard(async () => {
    const root = await openRoot(server), segs = parseSegments(rel), dir = await realDir(root, segs);
    const dirents = await fsp.readdir(dir, { withFileTypes: true });
    dirents.sort((a, b) => (a.isDirectory() === b.isDirectory() ? collator.compare(a.name, b.name) : a.isDirectory() ? -1 : 1));
    const slice = dirents.slice(0, MAX_ENTRIES), entries = [];
    for (let i = 0; i < slice.length; i += 64) {
      const rows = await Promise.all(slice.slice(i, i + 64).map((d) => describe(root, dir, d.name).catch(() => null)));   // an entry that vanished meanwhile is skipped
      for (const r of rows) if (r) entries.push(r);
    }
    entries.sort(byTypeThenName);
    return { path: display(segs), parent: segs.length ? display(segs.slice(0, -1)) : null, entries, total: dirents.length, truncated: dirents.length > MAX_ENTRIES };
  });
}

/** Case-insensitive name search in a folder and everything below it (breadth first, so shallow matches come first). Symlinks are never followed. */
async function search(server, rel, query) {
  const q = typeof query === 'string' ? query.trim() : '';
  if (!q || q.length > 100 || q.includes('\0')) throw new FileError('bad_query', 'Enter 1 to 100 characters to search for.');
  if (activeSearches >= SEARCH.maxConcurrent) throw new FileError('busy', 'Several searches are running right now. Try again in a moment.');
  activeSearches++;
  try {
    return await guard(async () => {
      const root = await openRoot(server), segs = parseSegments(rel), start = await realDir(root, segs);
      const needle = q.toLowerCase(), deadline = Date.now() + SEARCH.maxMs, found = [];
      const queue = [{ dir: start, rel: segs, depth: 0 }];
      let visited = 0, reason = null;
      scan: for (let qi = 0; qi < queue.length; qi++) {
        const { dir, rel: r, depth } = queue[qi];
        let ents;
        try { ents = await fsp.readdir(dir, { withFileTypes: true }); } catch { continue; }   // unreadable or vanished folder: skip it
        ents.sort((a, b) => collator.compare(a.name, b.name));
        for (const ent of ents) {
          if (++visited > SEARCH.maxVisited) { reason = 'scanned'; break scan; }
          if (ent.name.toLowerCase().includes(needle)) {
            found.push({ dir, rel: r, name: ent.name });
            if (found.length >= SEARCH.maxResults) { reason = 'results'; break scan; }
          }
          if (ent.isDirectory() && depth < SEARCH.maxDepth) queue.push({ dir: path.join(dir, ent.name), rel: [...r, ent.name], depth: depth + 1 });
        }
        if (Date.now() > deadline) { reason = 'time'; break; }
      }
      const results = [];
      for (const h of found) {
        try { results.push({ ...(await describe(root, h.dir, h.name)), path: display([...h.rel, h.name]), parent: display(h.rel) }); } catch { /* vanished while searching */ }
      }
      return { query: q, path: display(segs), results, truncated: !!reason, reason, scanned: Math.min(visited, SEARCH.maxVisited) };
    });
  } finally { activeSearches--; }
}

/** Creates an empty file or a folder named `name` inside the folder `parentRel`. Never overwrites anything. */
function create(server, parentRel, name, type) {
  return guard(async () => {
    if (type !== 'file' && type !== 'folder') throw new FileError('name_invalid', 'Choose whether to create a file or a folder.');
    validateName(name);
    const root = await openRoot(server), segs = parseSegments(parentRel), dir = await realDir(root, segs), abs = path.join(dir, name);
    if (type === 'folder') await fsp.mkdir(abs, { mode: 0o755 });
    else await (await fsp.open(abs, 'wx', 0o644)).close();            // 'wx' = fail if it exists (also if it is a symlink)
    return { ...(await describe(root, dir, name)), path: display([...segs, name]) };
  });
}

/** Renames an entry inside its own folder (it cannot be moved elsewhere by renaming). */
function rename(server, rel, newName) {
  return guard(async () => {
    validateName(newName);
    const root = await openRoot(server), segs = parseSegments(rel), { parent, abs, name, st } = await entryAt(root, segs);
    const dest = path.join(parent, newName);
    if (newName === name) return { unchanged: true, ...(await describe(root, parent, name)), path: display(segs) };
    let existing = null;
    try { existing = await fsp.lstat(dest); } catch (e) { if (e.code !== 'ENOENT') throw e; }
    // A case-only rename on a case-insensitive filesystem points at the same inode: that is fine.
    if (existing && !(existing.ino === st.ino && existing.dev === st.dev && newName.toLowerCase() === name.toLowerCase())) {
      throw new FileError('exists', `"${newName}" already exists in this folder.`);
    }
    await fsp.rename(abs, dest);
    return { ...(await describe(root, parent, newName)), path: display([...segs.slice(0, -1), newName]) };
  });
}

/** Deletes files and folders (folders with everything inside). Links are removed, never followed. Reports every item separately. */
function remove(server, rels) {
  return guard(async () => {
    if (!Array.isArray(rels) || !rels.length) throw new FileError('bad_path', 'Nothing was selected.');
    if (rels.length > MAX_DELETE) throw new FileError('too_many', `You can delete at most ${MAX_DELETE} items at once.`);
    const root = await openRoot(server);
    const all = [...new Set(rels.map((r) => display(parseSegments(r))))];
    // Parsing first means one bad path rejects the whole request before anything is deleted.
    // A selected folder already covers everything selected inside it.
    const paths = all.filter((p) => !all.some((o) => o !== p && p.startsWith(o === '/' ? '/' : `${o}/`)));
    const results = [];
    for (const p of paths) {
      try {
        const { abs } = await entryAt(root, parseSegments(p));
        await fsp.rm(abs, { recursive: true, force: false, maxRetries: 2 });
        results.push({ path: p, ok: true });
      } catch (e) {
        const fe = mapError(e);
        if (!(fe instanceof FileError)) throw fe;
        results.push({ path: p, ok: false, code: fe.code, error: fe.message });
      }
    }
    return { results, deleted: results.filter((r) => r.ok).length, failed: results.filter((r) => !r.ok).length };
  });
}

const tmpName = (name) => `.${name}.mpupload`.slice(0, MAX_NAME_BYTES);

/** An existing regular file (a link is followed only if it stays inside the server directory). Returns its real path and size. */
async function resolveFile(root, segs) {
  const { abs, name } = await entryAt(root, segs);
  const real = await fsp.realpath(abs);
  if (!within(root, real)) throw new FileError('forbidden', 'That location is outside the server directory.');
  const st = await fsp.stat(real);
  if (!st.isFile()) throw new FileError('not_found', 'That is not a file.');
  return { real, size: st.size, name, modified: Math.floor(st.mtimeMs) };
}

/** For downloads: opens the file and hands back a read stream plus metadata. */
function openDownload(server, rel) {
  return guard(async () => {
    const root = await openRoot(server), f = await resolveFile(root, parseSegments(rel));
    const fh = await fsp.open(f.real, 'r');
    return { name: f.name, size: f.size, stream: fh.createReadStream({ autoClose: true }) };
  });
}

/** Reads a small text file for the editor. Binary files and big files are refused. */
function readText(server, rel) {
  return guard(async () => {
    const root = await openRoot(server), f = await resolveFile(root, parseSegments(rel));
    if (f.size > MAX_EDIT_BYTES) throw new FileError('too_large', 'This file is too big to edit in the browser (limit 1 MB). Download it instead.');
    const buf = await fsp.readFile(f.real);
    if (buf.subarray(0, 8192).includes(0)) throw new FileError('not_text', 'This looks like a binary file, so it cannot be edited as text.');
    return { path: display(parseSegments(rel)), name: f.name, size: f.size, modified: f.modified, content: buf.toString('utf8') };
  });
}

/** Saves edited text over an existing file (written to a temp file first, then swapped in, so a crash cannot leave half a file). */
function writeText(server, rel, content) {
  return guard(async () => {
    if (typeof content !== 'string') throw new FileError('bad_path', 'Nothing to save.');
    if (Buffer.byteLength(content) > MAX_EDIT_BYTES) throw new FileError('too_large', 'The file is too big to save from the browser (limit 1 MB).');
    const root = await openRoot(server), segs = parseSegments(rel), f = await resolveFile(root, segs);
    const tmp = path.join(path.dirname(f.real), tmpName(f.name));
    const mode = (await fsp.stat(f.real)).mode & 0o777;
    await ensureRoom(server, root, Buffer.byteLength(content) - f.size);
    await fsp.writeFile(tmp, content, { mode, flag: 'w' });
    await fsp.rename(tmp, f.real);
    return { ...(await describe(root, path.dirname(f.real), path.basename(f.real))), path: display(segs) };
  });
}

/**
 * Receives one chunk of an upload (the browser splits big files). Chunks are appended to a hidden temp file next to
 * the target; when the last one arrives it is renamed into place. Existing files are only replaced when `overwrite` is set.
 */
function receiveChunk(server, parentRel, name, { offset, total, overwrite }, input) {
  return guard(async () => {
    validateName(name);
    if (!Number.isSafeInteger(offset) || !Number.isSafeInteger(total) || offset < 0 || total < 0 || offset > total) throw new FileError('bad_path', 'Invalid upload range.');
    if (total > UPLOAD_MAX) throw new FileError('too_large', `Files can be at most ${Math.round(UPLOAD_MAX / 1048576)} MB.`);
    const root = await openRoot(server), segs = parseSegments(parentRel), dir = await realDir(root, segs);
    const dest = path.join(dir, name), tmp = path.join(dir, tmpName(name));
    if (!overwrite) { try { await fsp.lstat(dest); throw new FileError('exists', `"${name}" already exists in this folder.`); } catch (e) { if (e.code !== 'ENOENT') throw e; } }
    else { try { if ((await fsp.lstat(dest)).isDirectory()) throw new FileError('exists', `"${name}" is a folder.`); } catch (e) { if (e.code !== 'ENOENT') throw e; } }
    let fh;
    if (offset === 0) {          // reserve the room once, for the announced size (a replaced file frees its old size)
      const old = overwrite ? (await fsp.lstat(dest).catch(() => null))?.size || 0 : 0;
      await ensureRoom(server, root, total - old);
    }
    if (offset === 0) fh = await fsp.open(tmp, fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_TRUNC | NOFOLLOW, 0o644);
    else {
      const have = (await fsp.lstat(tmp).catch(() => null))?.size;
      if (have !== offset) throw new FileError('conflict', 'The upload got out of sync. Please upload the file again.');
      fh = await fsp.open(tmp, fs.constants.O_WRONLY | fs.constants.O_APPEND | NOFOLLOW);
    }
    let got = 0;
    try {
      for await (const part of input) {
        got += part.length;
        if (got > CHUNK_MAX || offset + got > total) throw new FileError('too_large', 'The upload is larger than announced.');
        await fh.write(part);
      }
    } finally { await fh.close(); }
    const done = offset + got === total;
    if (!done && got === 0) throw new FileError('bad_path', 'Empty upload chunk.');
    if (!done) return { done: false, received: offset + got };
    await fsp.rename(tmp, dest);
    return { done: true, received: total, entry: { ...(await describe(root, dir, name)), path: display([...segs, name]) } };
  });
}

/** Removes the half-written temp file of a cancelled upload. */
function cancelUpload(server, parentRel, name) {
  return guard(async () => {
    validateName(name);
    const root = await openRoot(server), dir = await realDir(root, parseSegments(parentRel));
    await fsp.rm(path.join(dir, tmpName(name)), { force: true });
    return { ok: true };
  });
}

// ---------------------------------------------------------------------------------------------------------------
// Unarchive. Extraction can take minutes (a 400 MB backup), longer than a proxy such as Cloudflare keeps a request
// open, so it runs as a background job: POST starts it (202), the page polls the status and can cancel.
// One job per server at a time, at most UNARCHIVE_MAX_ACTIVE on the whole panel. Jobs live in memory (a panel restart
// ends them; files already extracted stay) and the last result is kept for an hour so the page can show it.
const UNARCHIVE_MAX_ACTIVE = 2;
const UNARCHIVE_KEEP_MS = 60 * 60 * 1000;
const UNARCHIVE_DEFAULT_MAX = 64 * 1024 * 1024 * 1024;   // servers without a disk limit
const jobs = new Map();                                    // server id -> latest job

const snapshot = (j) => j && ({
  id: j.id, state: j.state, file: j.file, dest: j.dest, kind: j.kind, archiveBytes: j.archiveBytes,
  readBytes: Math.min(j.archiveBytes, j.state === 'done' ? j.archiveBytes : Number(j.progress.read ? j.progress.read() : 0) || 0),
  files: j.result ? j.result.files : 0, dirs: j.result ? j.result.dirs : 0, bytes: j.result ? j.result.bytes : 0,
  skipped: j.result ? j.result.skipped : 0, skippedSamples: j.result ? j.result.samples : [],
  error: j.error, errorCode: j.errorCode, cancelled: j.cancelRequested, startedAt: j.startedAt, finishedAt: j.finishedAt
});

/** Creates the destination folder chain (never through a link) and returns its segments after checking it is a real folder inside the server. */
async function ensureDest(root, segs) {
  let cur = root;
  for (const s of segs) {
    validateName(s);
    const next = path.join(cur, s);
    let st = null;
    try { st = await fsp.lstat(next); } catch (e) { if (e.code !== 'ENOENT') throw e; }
    if (!st) await fsp.mkdir(next, { mode: 0o755 });
    else if (!st.isDirectory()) throw new FileError('not_dir', `"${s}" already exists and is not a folder.`);
    cur = next;
  }
  return realDir(root, segs);
}

/** True when the entry is something the Unarchive action can open. */
const isArchiveName = (name) => !!archive.kindOf(name);

/**
 * Starts extracting the archive at `rel` into `intoRel` (default: the folder the archive is in; created when missing).
 * Returns the job snapshot at once. `onFinish(snapshot)` is called when it ends (done / failed / cancelled).
 */
function startUnarchive(server, rel, intoRel, onFinish) {
  return guard(async () => {
    const root = await openRoot(server), segs = parseSegments(rel), f = await resolveFile(root, segs);
    const kind = archive.kindOf(f.name);
    if (!kind) throw new FileError('not_archive', 'Only .zip, .tar, .tar.gz, .tgz and .gz files can be unarchived.');
    const running = jobs.get(server.id);
    if (running && running.state === 'running') throw new FileError('busy', 'An archive is already being extracted on this server. Wait for it to finish or cancel it.');
    if ([...jobs.values()].filter((j) => j.state === 'running').length >= UNARCHIVE_MAX_ACTIVE) throw new FileError('busy', 'The panel is busy extracting other archives. Try again in a minute.');
    const destSegs = intoRel == null || intoRel === '' ? segs.slice(0, -1) : parseSegments(intoRel);
    const dest = await ensureDest(root, destSegs);
    let maxBytes = UNARCHIVE_DEFAULT_MAX;
    if (server.disk_limit_mb > 0) {
      maxBytes = server.disk_limit_mb * 1048576 - (await dirSizeBytes(root));
      if (maxBytes <= 0) throw new FileError('disk_full', 'This server has no free disk space left. Delete some files first.');
    }
    const job = { id: crypto.randomBytes(8).toString('hex'), serverId: server.id, state: 'running', kind, file: display(segs), dest: display(destSegs), archiveBytes: f.size,
      progress: {}, result: null, error: null, errorCode: null, cancelRequested: false, startedAt: Date.now(), finishedAt: null };
    jobs.set(server.id, job);
    const finish = (state, err) => {
      job.state = state; job.finishedAt = Date.now();
      if (err) { job.error = err.message || String(err); job.errorCode = err.code || 'failed'; }
      const t = setTimeout(() => { if (jobs.get(server.id) === job) jobs.delete(server.id); }, UNARCHIVE_KEEP_MS); t.unref();
      try { if (onFinish) onFinish(snapshot(job)); } catch { /* logging must never break the job */ }
    };
    archive.extract({ kind, file: f.real, dest, name: f.name, maxBytes, cancelled: () => job.cancelRequested, progress: job.progress })
      .then((result) => { job.result = result; finish('done'); })
      .catch((e) => {
        const mapped = mapError(e);
        if (e instanceof archive.ArchiveError) { if (e.code === 'cancelled') return finish('cancelled', e); return finish('failed', e.code === 'disk_full' ? new FileError('disk_full', e.message) : e); }
        finish('failed', mapped instanceof FileError ? mapped : new Error('Extraction failed unexpectedly.'));
      });
    return snapshot(job);
  });
}

/** The latest extraction of this server (running, or finished within the last hour), or null. */
const unarchiveStatus = (server) => snapshot(jobs.get(server.id) || null);

/** Asks the running extraction to stop (files already written stay). */
function cancelUnarchive(server) {
  const j = jobs.get(server.id);
  if (!j || j.state !== 'running') throw new FileError('not_found', 'No extraction is running on this server.');
  j.cancelRequested = true;
  return snapshot(j);
}

module.exports = { openDownload, readText, writeText, receiveChunk, cancelUpload, MAX_EDIT_BYTES, CHUNK_MAX, FileError, list, search, create, rename, remove, validateName, parseSegments, rootOf, MAX_ENTRIES, MAX_DELETE, SEARCH, startUnarchive, unarchiveStatus, cancelUnarchive, isArchiveName };
