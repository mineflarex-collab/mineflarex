'use strict';
require('../migrations'); // ensure dashboard tables exist before preparing statements
const db = require('../../db');

const STATUSES = ['online', 'offline', 'maintenance'];
const q = {
  insert: db.prepare(`INSERT INTO nodes (name, location, fqdn, status, ram_total_mb, cpu_total_pct, disk_total_mb, created_at, updated_at)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`),
  byId: db.prepare('SELECT * FROM nodes WHERE id = ?'),
  byName: db.prepare('SELECT * FROM nodes WHERE name = ?'),
  list: db.prepare('SELECT * FROM nodes ORDER BY name COLLATE NOCASE'),
  setStatus: db.prepare('UPDATE nodes SET status = ?, updated_at = ? WHERE id = ?')
};

/** Registers a machine that runs servers. Throws on duplicate name (UNIQUE) or invalid status (CHECK). */
function create({ name, location = null, fqdn, status = 'online', ramTotalMb = 0, cpuTotalPct = 0, diskTotalMb = 0 }) {
  const now = Date.now();
  const r = q.insert.run(String(name).trim(), location, fqdn, status, ramTotalMb, cpuTotalPct, diskTotalMb, now, now);
  return q.byId.get(Number(r.lastInsertRowid));
}
const getById = (id) => q.byId.get(id) || null;
const findByName = (name) => q.byName.get(String(name).trim()) || null;
const list = () => q.list.all();
function setStatus(id, status) { q.setStatus.run(status, Date.now(), id); }

module.exports = { create, getById, findByName, list, setStatus, STATUSES };
