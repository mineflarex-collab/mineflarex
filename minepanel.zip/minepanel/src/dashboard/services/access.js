'use strict';
// Who may do what on a server. The owner has every permission; other users only what has been granted
// to them in server_access (a grant with no flags is view-only). Users with no relation to a server
// get null, which callers must treat exactly like "server does not exist".
require('../migrations'); // ensure dashboard tables exist before preparing statements
const db = require('../../db');

const PERMISSIONS = ['control.start', 'control.stop', 'control.restart', 'console.view', 'console.send', 'files.view', 'files.write'];
const ACTION_PERMISSION = { start: 'control.start', stop: 'control.stop', restart: 'control.restart', reinstall: 'control.reinstall' };
// Reinstall replaces the server software, so it is never delegated: only the owner and administrators have it
// (it is deliberately not in PERMISSIONS, which is what can be granted to other users).
const OWNER_ONLY = ['control.reinstall'];
const COLUMN = { 'control.start': 'can_start', 'control.stop': 'can_stop', 'control.restart': 'can_restart', 'console.view': 'can_console', 'console.send': 'can_command', 'files.view': 'can_files', 'files.write': 'can_files_write' };

const q = {
  get: db.prepare('SELECT * FROM server_access WHERE server_id = ? AND user_id = ?'),
  upsert: db.prepare(`INSERT INTO server_access (server_id, user_id, can_start, can_stop, can_restart, can_console, can_command, can_files, can_files_write, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                      ON CONFLICT (server_id, user_id) DO UPDATE SET can_start = excluded.can_start, can_stop = excluded.can_stop, can_restart = excluded.can_restart,
                      can_console = excluded.can_console, can_command = excluded.can_command, can_files = excluded.can_files, can_files_write = excluded.can_files_write`),
  del: db.prepare('DELETE FROM server_access WHERE server_id = ? AND user_id = ?'),
  list: db.prepare(`SELECT a.*, u.username, u.email FROM server_access a JOIN users u ON u.id = a.user_id WHERE a.server_id = ? ORDER BY u.username COLLATE NOCASE`)
};

// can(action): power actions (start/stop/restart). has(permission): any permission by name, e.g. 'console.view'.
const make = (role, perms) => ({ role, permissions: new Set(perms), can(action) { return this.permissions.has(ACTION_PERMISSION[action]); }, has(p) { return this.permissions.has(p); } });

/** The user's access to a server row ({ role: 'owner' | 'shared', permissions, can(action) }) or null. */
const roleOf = db.prepare('SELECT role, is_owner, servers_hidden FROM users WHERE id = ?');
function forUser(userId, server) {
  if (!server) return null;
  if (server.owner_id === userId) return make('owner', [...PERMISSIONS, ...OWNER_ONLY]);
  const who = roleOf.get(userId);   // panel administrators can operate every server, except those the main admin hid from them
  if (who?.role === 'admin' && (who.is_owner || !who.servers_hidden)) return make('admin', [...PERMISSIONS, ...OWNER_ONLY]);
  const r = q.get.get(server.id, userId);
  return r ? make('shared', PERMISSIONS.filter((p) => r[COLUMN[p]])) : null;
}

/** Grants (or replaces) access. permissions: subset of PERMISSIONS; an empty list grants view-only access.
 *  console.send implies console.view (you cannot type into a console you cannot see); files.write implies files.view. */
function grant({ serverId, userId, permissions = [] }) {
  if (permissions.includes('console.send') && !permissions.includes('console.view')) permissions = [...permissions, 'console.view'];
  if (permissions.includes('files.write') && !permissions.includes('files.view')) permissions = [...permissions, 'files.view'];   // you cannot change files you cannot see
  const bad = permissions.filter((p) => !PERMISSIONS.includes(p));
  if (bad.length) throw new Error(`Unknown permission: ${bad.join(', ')}`);
  const has = (p) => (permissions.includes(p) ? 1 : 0);
  q.upsert.run(serverId, userId, has('control.start'), has('control.stop'), has('control.restart'), has('console.view'), has('console.send'), has('files.view'), has('files.write'), Date.now());
}
const revoke = (serverId, userId) => q.del.run(serverId, userId).changes > 0;
const listFor = (serverId) => q.list.all(serverId).map((r) => ({ userId: r.user_id, username: r.username, email: r.email,
  permissions: PERMISSIONS.filter((p) => r[COLUMN[p]]) }));

module.exports = { PERMISSIONS, ACTION_PERMISSION, forUser, grant, revoke, listFor };
