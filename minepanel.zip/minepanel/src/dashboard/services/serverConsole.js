'use strict';
// Storage for the live console. The panel (web process) and the runtime (which owns the game processes) may be
// two different OS processes, so they talk through the database, like the power-command queue does:
//
//   runtime  --Writer.push()-->  console_lines  --poll-->  WebSocket hub  -->  browsers     (output)
//   browsers --WebSocket-->  console_input  --poll-->  runtime  -->  process stdin           (commands)
//
// console_lines ids only ever increase, so a client that reconnects simply asks for "everything after id N".
require('../migrations'); // ensure dashboard tables exist before preparing statements
const db = require('../../db');

const MAX_LINE = 4000;            // longer lines are cut (a runaway process must not fill the database)
const MAX_BUFFERED = 5000;        // writer buffer cap between flushes; beyond it the oldest lines are dropped (and counted)
const HISTORY_KEEP = 100;         // commands remembered per user and server

const q = {
  insertLine: db.prepare('INSERT INTO console_lines (server_id, ts, stream, line) VALUES (?, ?, ?, ?)'),
  tail: db.prepare('SELECT id, ts, stream, line FROM (SELECT * FROM console_lines WHERE server_id = ? ORDER BY id DESC LIMIT ?) ORDER BY id'),
  after: db.prepare('SELECT id, ts, stream, line FROM console_lines WHERE server_id = ? AND id > ? ORDER BY id LIMIT ?'),
  before: db.prepare('SELECT id, ts, stream, line FROM (SELECT * FROM console_lines WHERE server_id = ? AND id < ? ORDER BY id DESC LIMIT ?) ORDER BY id'),
  lastId: db.prepare('SELECT COALESCE(MAX(id), 0) AS id FROM console_lines WHERE server_id = ?'),
  prune: db.prepare(`DELETE FROM console_lines WHERE server_id = ? AND id <= COALESCE((SELECT id FROM console_lines WHERE server_id = ? ORDER BY id DESC LIMIT 1 OFFSET ?), 0)`),
  status: db.prepare('SELECT status FROM servers WHERE id = ?'),

  addInput: db.prepare('INSERT INTO console_input (server_id, user_id, username, command, created_at) VALUES (?, ?, ?, ?, ?)'),
  pendingInput: db.prepare("SELECT * FROM console_input WHERE status = 'pending' ORDER BY id LIMIT ?"),
  markInput: db.prepare("UPDATE console_input SET status = ?, error = ?, handled_at = ? WHERE id = ? AND status = 'pending'"),
  staleInput: db.prepare("SELECT * FROM console_input WHERE status = 'pending' AND created_at < ?"),
  purgeInput: db.prepare("DELETE FROM console_input WHERE status != 'pending' AND created_at < ?"),

  history: db.prepare('SELECT id, command FROM console_history WHERE user_id = ? AND server_id = ? ORDER BY id DESC LIMIT ?'),
  lastCmd: db.prepare('SELECT command FROM console_history WHERE user_id = ? AND server_id = ? ORDER BY id DESC LIMIT 1'),
  addHistory: db.prepare('INSERT INTO console_history (user_id, server_id, command, created_at) VALUES (?, ?, ?, ?)'),
  trimHistory: db.prepare(`DELETE FROM console_history WHERE user_id = ? AND server_id = ? AND id <= COALESCE((SELECT id FROM console_history WHERE user_id = ? AND server_id = ? ORDER BY id DESC LIMIT 1 OFFSET ?), 0)`)
};

const clean = (s) => String(s).replace(/\r$/, '').replace(/\u0000/g, '').slice(0, MAX_LINE);
const STREAMS = new Set(['out', 'err', 'in', 'sys']);

/** Buffered writer used by the runtime: many log lines become one transaction every `flushMs`
 *  (a commit per line would be far too slow when a server prints thousands of lines). */
class Writer {
  constructor({ flushMs = 100, keep = 5000, onError = () => {} } = {}) {
    this.flushMs = flushMs; this.keep = keep; this.onError = onError;
    this.buf = []; this.dropped = new Map(); this.sincePrune = new Map(); this.timer = null;
  }

  push(serverId, stream, line) {
    if (!STREAMS.has(stream)) stream = 'out';
    if (this.buf.length >= MAX_BUFFERED) {
      const old = this.buf.shift();
      this.dropped.set(old.serverId, (this.dropped.get(old.serverId) || 0) + 1);
    }
    this.buf.push({ serverId, ts: Date.now(), stream, line: clean(line) });
    if (!this.timer) { this.timer = setTimeout(() => this.flush(), this.flushMs); this.timer.unref?.(); }
  }

  /** Writes everything buffered. Safe to call at any time (also on shutdown). */
  flush() {
    clearTimeout(this.timer); this.timer = null;
    if (!this.buf.length && !this.dropped.size) return;
    const rows = this.buf; this.buf = [];
    for (const [serverId, n] of this.dropped) rows.push({ serverId, ts: Date.now(), stream: 'sys', line: `[minePanel] ${n} console line${n === 1 ? ' was' : 's were'} dropped (output too fast)` });
    this.dropped.clear();
    const touched = new Set();
    db.exec('BEGIN');
    try {
      for (const r of rows) {
        try { q.insertLine.run(r.serverId, r.ts, r.stream, r.line); touched.add(r.serverId); this.sincePrune.set(r.serverId, (this.sincePrune.get(r.serverId) || 0) + 1); }
        catch (err) { if (!/FOREIGN KEY/i.test(err.message)) this.onError(err); }       // a deleted server is not an error
      }
      for (const id of touched) {
        if (this.sincePrune.get(id) >= Math.max(200, Math.floor(this.keep / 5))) { q.prune.run(id, id, this.keep); this.sincePrune.set(id, 0); }
      }
      db.exec('COMMIT');
    } catch (err) { try { db.exec('ROLLBACK'); } catch { /* none open */ } this.onError(err); }
  }
}

const wire = (r) => r;
/** Last `limit` lines (oldest first). */
const tail = (serverId, limit = 500) => q.tail.all(serverId, limit).map(wire);
/** Lines with id > afterId (oldest first). */
const after = (serverId, afterId, limit = 1000) => q.after.all(serverId, afterId, limit).map(wire);
/** Up to `limit` lines older than beforeId (oldest first) – for scrolling back. */
const before = (serverId, beforeId, limit = 200) => q.before.all(serverId, beforeId, limit).map(wire);
const lastId = (serverId) => q.lastId.get(serverId).id;
const serverStatus = (serverId) => q.status.get(serverId)?.status ?? null;
/** Immediate single-line write (for the web process; the runtime uses Writer). */
function appendNow(serverId, stream, line) { try { q.insertLine.run(serverId, Date.now(), STREAMS.has(stream) ? stream : 'out', clean(line)); } catch { /* server deleted */ } }

// ---- commands waiting for the runtime ---------------------------------------------------------
function enqueueInput({ serverId, user, command }) {
  return Number(q.addInput.run(serverId, user.id, user.username, command, Date.now()).lastInsertRowid);
}
const pendingInput = (limit = 50) => q.pendingInput.all(limit);
/** Returns true only for the caller that actually moved the row out of 'pending' (web and runtime may race). */
const markInput = (id, status, error = null) => q.markInput.run(status, error, Date.now(), id).changes > 0;
/** Marks commands nobody picked up within `olderThanMs` as failed and returns them (the runtime is down or stuck). */
function failStale(olderThanMs) {
  const rows = q.staleInput.all(Date.now() - olderThanMs);
  return rows.filter((r) => markInput(r.id, 'failed', 'The server runtime did not respond'));
}
const purgeInput = (olderThanMs = 24 * 3600 * 1000) => q.purgeInput.run(Date.now() - olderThanMs);

// ---- per-user command history -----------------------------------------------------------------
/** Oldest first, so the client can walk it with the arrow keys. */
const history = (userId, serverId, limit = HISTORY_KEEP) => q.history.all(userId, serverId, limit).reverse().map((r) => r.command);
function addHistory(userId, serverId, command) {
  if (q.lastCmd.get(userId, serverId)?.command === command) return;             // repeating the same command is not a new entry
  q.addHistory.run(userId, serverId, command, Date.now());
  q.trimHistory.run(userId, serverId, userId, serverId, HISTORY_KEEP);
}

module.exports = { Writer, tail, after, before, lastId, serverStatus, appendNow, enqueueInput, pendingInput, markInput, failStale, purgeInput, history, addHistory, MAX_LINE, HISTORY_KEEP };
