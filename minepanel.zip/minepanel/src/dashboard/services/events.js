'use strict';
// Real-time status stream (Server-Sent Events). Every open connection watches the servers its user can see;
// a shared timer reads them from the database and pushes only what changed. Because it reads the database
// (not an in-process event bus), it also sees changes made by a runtime running as a separate process.
const servers = require('./servers');
const f = require('../format');

const TICK_MS = 1000, HEARTBEAT_EVERY = 15, MAX_PER_USER = 8, MAX_LIFETIME_MS = 5 * 60 * 1000;
const clients = new Set();
let timer = null, ticks = 0;

function write(c, event, data) {
  if (c.res.destroyed || c.res.writableEnded) return false;
  try { c.res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); return true; } catch { return false; }
}

function tick() {
  ticks += 1;
  const byUser = new Map();
  for (const c of clients) {
    if (Date.now() - c.since > MAX_LIFETIME_MS) { c.close(); continue; }    // forces EventSource to reconnect (and re-authenticate)
    if (!byUser.has(c.user.id)) byUser.set(c.user.id, []);
    byUser.get(c.user.id).push(c);
  }
  for (const [userId, list] of byUser) {
    let rows;
    try { rows = servers.listVisible(userId); } catch { continue; }
    const admin = list[0].user.role === 'admin';
    const described = rows.map((s) => f.describeServer(s, { admin }));
    for (const c of list) {
      const changed = [];
      for (const d of described) {
        const json = JSON.stringify(d);
        if (c.last.get(d.identifier) !== json) { c.last.set(d.identifier, json); changed.push(d); }
      }
      if (changed.length) write(c, 'update', changed);
      else if (ticks % HEARTBEAT_EVERY === 0 && !c.res.destroyed) { try { c.res.write(': ping\n\n'); } catch { /* closed */ } }
    }
  }
  if (!clients.size) { clearInterval(timer); timer = null; }
}

const count = (userId) => [...clients].filter((c) => c.user.id === userId).length;

/** Registers a connection; sends the initial snapshot (identifier + status of every visible server). */
function add(user, res) {
  const c = { user, res, since: Date.now(), last: new Map(), close() { clients.delete(c); try { res.end(); } catch { /* closed */ } } };
  const rows = servers.listVisible(user.id), admin = user.role === 'admin';
  for (const s of rows) { const d = f.describeServer(s, { admin }); c.last.set(d.identifier, JSON.stringify(d)); }
  clients.add(c);
  write(c, 'snapshot', rows.map((s) => ({ identifier: s.identifier, status: s.status })));
  if (!timer) { timer = setInterval(tick, TICK_MS); timer.unref(); }
  return c;
}
const remove = (c) => clients.delete(c);
const closeAll = () => { for (const c of [...clients]) c.close(); };

module.exports = { add, remove, count, closeAll, MAX_PER_USER };
