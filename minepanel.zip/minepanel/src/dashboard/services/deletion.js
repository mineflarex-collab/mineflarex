'use strict';
// Deleting a server from the admin panel, three ways:
//   delete  - the server must already be stopped. Removes the database record and erases its files.
//   safe    - stops the server gracefully first (waits for it), then MOVES its files to <data dir>/../deleted/ (nothing is erased,
//             an administrator can restore the folder by hand), then removes the database record. If it will not stop, nothing is deleted.
//   force   - kills the process at once (no waiting for a clean stop), erases the files and removes the record, whatever state the server is in.
require('../migrations');
const fs = require('node:fs');
const path = require('node:path');
const db = require('../../db');
const runtimeConfig = require('../../runtime/config');
const servers = require('./servers');
const activity = require('./activity');

const MODES = { delete: 'Delete', safe: 'Safe delete', force: 'Force delete' };
const IDENTIFIER_RE = /^[A-Za-z0-9_-]{1,64}$/;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const q = {
  status: db.prepare('SELECT status, task FROM servers WHERE id = ?'),
  remove: db.prepare('DELETE FROM servers WHERE id = ?')   // commands, console, access, backups... go with it (ON DELETE CASCADE)
};
class DeleteError extends Error {}

const isStopped = (s) => s === 'offline' || s === 'crashed';
const dirOf = (server) => {
  if (!IDENTIFIER_RE.test(String(server.identifier))) throw new DeleteError('This server has an invalid identifier, its folder was left alone.');
  const root = path.resolve(runtimeConfig.dataDir), dir = path.resolve(root, String(server.identifier));
  if (path.dirname(dir) !== root) throw new DeleteError('The server folder is outside the data directory, it was left alone.');
  return dir;
};
const trashDir = () => path.join(path.dirname(path.resolve(runtimeConfig.dataDir)), 'deleted');

/** Waits until the server reports offline / crashed. Returns true if it did, false on timeout. */
async function waitStopped(serverId, ms) {
  const end = Date.now() + ms;
  for (;;) {
    const row = q.status.get(serverId);
    if (!row || isStopped(row.status)) return true;
    if (Date.now() >= end) return false;
    await sleep(250);
  }
}

function eraseFiles(dir) { fs.rmSync(dir, { recursive: true, force: true, maxRetries: 3, retryDelay: 150 }); }
function moveToTrash(dir, server) {
  if (!fs.existsSync(dir)) return null;
  const dest = path.join(trashDir(), `${server.identifier}-${new Date().toISOString().replace(/[:.]/g, '-')}`);
  fs.mkdirSync(trashDir(), { recursive: true });
  try { fs.renameSync(dir, dest); } catch (err) {
    if (err.code !== 'EXDEV') throw err;                            // another disk: copy, then erase the original
    fs.cpSync(dir, dest, { recursive: true }); eraseFiles(dir);
  }
  return dest;
}

/**
 * @param {{user: object, server: object, mode: 'delete'|'safe'|'force', ip?: string, stopWaitMs?: number, killWaitMs?: number}} o
 * @returns {Promise<{ok: true, message: string}>} or throws DeleteError (nothing was deleted)
 */
async function deleteServer({ user, server, mode, ip = null, stopWaitMs = runtimeConfig.stopTimeoutMs + 15000, killWaitMs = 20000 }) {
  if (!MODES[mode]) throw new DeleteError('Unknown delete option.');
  const dir = dirOf(server);
  const row = q.status.get(server.id);
  if (!row) throw new DeleteError('Server not found.');

  if (mode === 'delete') {
    if (!isStopped(row.status)) throw new DeleteError(`${server.name} is ${row.status}. Stop it first, or use Safe delete / Force delete.`);
    if (row.task) throw new DeleteError(`${server.name} is busy (${row.task}). Wait for it to finish, or use Force delete.`);
  }

  if (mode === 'safe') {
    if (row.task) throw new DeleteError(`${server.name} is busy (${row.task}). Wait for it to finish first.`);
    if (!isStopped(row.status)) {
      if (row.status !== 'stopping') servers.requestCommand(user, server.id, 'stop', ip, { confirmed: true });
      if (!(await waitStopped(server.id, stopWaitMs))) throw new DeleteError(`${server.name} did not stop in time, so nothing was deleted. Try again, or use Force delete.`);
    }
  }

  if (mode === 'force' && !isStopped(row.status)) {
    servers.requestForce(user, server.id, 'force_stop', ip);
    await waitStopped(server.id, killWaitMs);                       // if the runtime is down nothing runs; if it is slow, its next poll kills a process whose server row is gone
  }

  let where = null;
  try {
    if (mode === 'safe') where = moveToTrash(dir, server); else eraseFiles(dir);
  } catch (err) { throw new DeleteError(`The files of ${server.name} could not be ${mode === 'safe' ? 'moved' : 'removed'} (${err.code || err.message}), so the server was kept.`); }

  q.remove.run(server.id);
  activity.record({ userId: server.owner_id, serverId: null, serverName: server.name, type: 'server.deleted',
    message: `${server.name} (${server.identifier}) was deleted by ${user.username} (${MODES[mode].toLowerCase()})${where ? `; files kept in ${where}` : ''}`, ip });
  return { ok: true, message: mode === 'safe' && where ? `"${server.name}" was deleted. Its files were moved to ${where}.` : `"${server.name}" was deleted.` };
}

module.exports = { deleteServer, DeleteError, MODES };
