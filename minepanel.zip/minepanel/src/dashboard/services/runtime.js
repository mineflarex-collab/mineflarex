'use strict';
// Interface for the process that actually runs Minecraft servers (agent / daemon / future server-management module).
// The dashboard only reads what is reported here.
require('../migrations'); // ensure dashboard tables exist before preparing statements
const db = require('../../db');
const activity = require('./activity');

const q = {
  byId: db.prepare('SELECT * FROM servers WHERE id = ?'),
  update: db.prepare(`UPDATE servers SET status = ?, cpu_used_pct = ?, ram_used_mb = ?, disk_used_mb = ?, players_online = ?,
                      started_at = ?, metrics_at = ?, updated_at = ? WHERE id = ?`),
  pending: db.prepare("SELECT * FROM server_commands WHERE status = 'pending' ORDER BY id"),
  getCmd: db.prepare('SELECT * FROM server_commands WHERE id = ?'),
  finish: db.prepare('UPDATE server_commands SET status = ?, error = ?, completed_at = ? WHERE id = ?'),
  setStatus: db.prepare('UPDATE servers SET status = ?, updated_at = ? WHERE id = ?')
};

const LABEL = { online: 'is now online', offline: 'is now offline', crashed: 'crashed', starting: 'is starting', stopping: 'is stopping' };

/** Report live state/metrics for a server. Records an activity entry when the status changes. */
function reportStatus(serverId, { status, cpuUsedPct = 0, ramUsedMb = 0, diskUsedMb = 0, playersOnline = 0 }) {
  const s = q.byId.get(serverId);
  if (!s) throw new Error(`Unknown server ${serverId}`);
  const now = Date.now(), live = status === 'online';
  const startedAt = live ? (s.status === 'online' && s.started_at ? s.started_at : now) : null;
  q.update.run(status, live ? cpuUsedPct : 0, live ? ramUsedMb : 0, diskUsedMb, live ? playersOnline : 0, startedAt, now, now, serverId);
  if (status !== s.status) {
    activity.record({ userId: s.owner_id, serverId, serverName: s.name, type: 'server.status', message: `${s.name} ${LABEL[status] || status}` });
  }
}

const pendingCommands = () => q.pending.all();

/** Mark a queued command finished. On failure the server is put into `status` (the real state the runtime observed; defaults to crashed/online) and the error is logged. */
function completeCommand(commandId, { ok = true, error = null, status = null } = {}) {
  const c = q.getCmd.get(commandId);
  if (!c || c.status !== 'pending') return false;
  q.finish.run(ok ? 'done' : 'failed', error, Date.now(), commandId);
  if (!ok) {
    const s = q.byId.get(c.server_id);
    if (s) {
      q.setStatus.run(status || (c.command === 'start' ? 'crashed' : 'online'), Date.now(), s.id);
      activity.record({ userId: s.owner_id, serverId: s.id, serverName: s.name, type: 'server.error',
        message: `${c.command} failed for ${s.name}${error ? `: ${error}` : ''}` });
    }
  }
  return true;
}

module.exports = { reportStatus, pendingCommands, completeCommand };
