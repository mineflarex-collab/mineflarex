'use strict';
// Interface for the process that actually runs Minecraft servers (agent / daemon / future server-management module).
// The dashboard only reads what is reported here.
require('../migrations'); // ensure dashboard tables exist before preparing statements
const db = require('../../db');
const activity = require('./activity');

const q = {
  byId: db.prepare('SELECT * FROM servers WHERE id = ?'),
  update: db.prepare(`UPDATE servers SET status = ?, cpu_used_pct = ?, ram_used_mb = ?, disk_used_mb = ?, players_online = ?,
                      started_at = ?, metrics_at = ?, updated_at = ?, net_rx_bytes = ?, net_tx_bytes = ?, net_rx_bps = ?, net_tx_bps = ? WHERE id = ?`),
  pending: db.prepare("SELECT * FROM server_commands WHERE status = 'pending' ORDER BY id"),
  getCmd: db.prepare('SELECT * FROM server_commands WHERE id = ?'),
  finish: db.prepare('UPDATE server_commands SET status = ?, error = ?, completed_at = ? WHERE id = ?'),
  setStatus: db.prepare('UPDATE servers SET status = ?, updated_at = ? WHERE id = ?'),
  clearTask: db.prepare('UPDATE servers SET task = NULL, updated_at = ? WHERE id = ? AND task IS NOT NULL')
};

const LABEL = { online: 'is now online', offline: 'is now offline', crashed: 'crashed', starting: 'is starting', stopping: 'is stopping' };

/** Report live state/metrics for a server. Records an activity entry when the status changes. */
function reportStatus(serverId, { status, cpuUsedPct = 0, ramUsedMb = 0, diskUsedMb = 0, playersOnline = 0, netRxBytes = null, netTxBytes = null, netRxBps = null, netTxBps = null }) {
  const s = q.byId.get(serverId);
  if (!s) throw new Error(`Unknown server ${serverId}`);
  const now = Date.now(), live = status === 'online';
  const startedAt = live ? (s.status === 'online' && s.started_at ? s.started_at : now) : null;
  const net = (v) => (live && Number.isFinite(v) ? Math.max(0, Math.round(v)) : null);   // NULL = not measured (offline, or the host cannot measure it)
  q.update.run(status, live ? cpuUsedPct : 0, live ? ramUsedMb : 0, diskUsedMb, live ? playersOnline : 0, startedAt, now, now, net(netRxBytes), net(netTxBytes), net(netRxBps), net(netTxBps), serverId);
  if (status !== s.status) {
    activity.record({ userId: s.owner_id, serverId, serverName: s.name, type: 'server.status', message: `${s.name} ${LABEL[status] || status}` });
  }
}

const pendingCommands = () => q.pending.all();

const w = {
  warn: db.prepare('UPDATE servers SET usage_warning = ? WHERE id = ? AND COALESCE(usage_warning, \'\') != COALESCE(?, \'\')'),
  suspend: db.prepare('UPDATE servers SET suspended = 1, suspended_reason = ?, suspended_at = ?, usage_warning = NULL, updated_at = ? WHERE id = ?'),
  unsuspend: db.prepare('UPDATE servers SET suspended = 0, suspended_reason = NULL, suspended_at = NULL, usage_warning = NULL, updated_at = ? WHERE id = ?')
};
/** Yellow warning text shown on the server pages (null clears it). */
function setUsageWarning(serverId, text) { w.warn.run(text || null, serverId, text || null); }
/** Suspend: the server stays offline and cannot be started until an admin unsuspends it. */
function suspendServer(serverId, reason, { by = null } = {}) {
  const s = q.byId.get(serverId); if (!s) return false;
  w.suspend.run(reason, Date.now(), Date.now(), serverId);
  activity.record({ userId: s.owner_id, serverId, serverName: s.name, type: 'server.suspended', message: `${s.name} was suspended${by ? ` by ${by}` : ' automatically'}: ${reason}` });
  return true;
}
function unsuspendServer(serverId, { by = null } = {}) {
  const s = q.byId.get(serverId); if (!s) return false;
  w.unsuspend.run(Date.now(), serverId);
  activity.record({ userId: s.owner_id, serverId, serverName: s.name, type: 'server.unsuspended', message: `${s.name} was unsuspended${by ? ` by ${by}` : ''}` });
  return true;
}

/** Mark a queued command finished. On failure the server is put into `status` (the real state the runtime observed; defaults to crashed/online) and the error is logged. */
function completeCommand(commandId, { ok = true, error = null, status = null } = {}) {
  const c = q.getCmd.get(commandId);
  if (!c || c.status !== 'pending') return false;
  q.finish.run(ok ? 'done' : 'failed', error, Date.now(), commandId);
  q.clearTask.run(Date.now(), c.server_id);                      // the job is over either way: buttons come back
  if (ok && c.command === 'reinstall') {
    const s = q.byId.get(c.server_id);
    if (s) activity.record({ userId: s.owner_id, serverId: s.id, serverName: s.name, type: 'server.reinstalled', message: `${s.name} was reinstalled` });
  }
  if (!ok) {
    const s = q.byId.get(c.server_id);
    if (s) {
      q.setStatus.run(status || (c.command === 'start' ? 'crashed' : c.command === 'reinstall' ? 'offline' : 'online'), Date.now(), s.id);
      activity.record({ userId: s.owner_id, serverId: s.id, serverName: s.name, type: 'server.error',
        message: `${c.command} failed for ${s.name}${error ? `: ${error}` : ''}` });
    }
  }
  return true;
}

module.exports = { reportStatus, pendingCommands, completeCommand, setUsageWarning, suspendServer, unsuspendServer };
