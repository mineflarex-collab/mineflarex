'use strict';
require('../migrations'); // ensure dashboard tables exist before preparing statements
const db = require('../../db');

const q = {
  insert: db.prepare('INSERT INTO activity_log (user_id, server_id, server_name, type, message, ip, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'),
  page: db.prepare('SELECT * FROM activity_log WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?'),
  count: db.prepare('SELECT COUNT(*) AS n FROM activity_log WHERE user_id = ?'),
  forServer: db.prepare('SELECT * FROM activity_log WHERE server_id = ? ORDER BY created_at DESC, id DESC LIMIT ?')
};

/** Writes one audit/activity entry for a user. type examples: server.start, account.password */
function record({ userId, serverId = null, serverName = null, type, message, ip = null }) {
  q.insert.run(userId, serverId, serverName, type, message, ip, Date.now());
}
const recent = (userId, limit = 10, offset = 0) => q.page.all(userId, limit, offset);
const count = (userId) => q.count.get(userId).n;
/** Caller must already have verified the user may see this server. */
const forServer = (serverId, limit = 10) => q.forServer.all(serverId, limit);

module.exports = { record, recent, count, forServer };
