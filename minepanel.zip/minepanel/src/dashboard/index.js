'use strict';
require('./migrations'); // creates/updates dashboard tables on first load
const routes = require('./routes');
const admin = require('./admin');
const adminPanel = require('./adminPanel');
const fileManager = require('./files');
module.exports = (router) => { routes(router); admin(router); adminPanel(router); fileManager(router); };
