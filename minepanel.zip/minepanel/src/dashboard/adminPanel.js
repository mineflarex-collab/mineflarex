'use strict';
// Admin panel (administrators only). Left sidebar: Users, Servers (Bot Host / MC Host) and Settings (panel name + logo).
//
//   GET  /admin                                overview: totals, VPS meters, crashed servers, latest activity
//   GET  /admin/users                  users: search, add, make admin / user, enable / disable
//   GET  /admin/servers/mc                     MC Host: Minecraft (Paper) servers      (create: /admin/servers/new?kind=mc)
//   GET  /admin/servers/bots                   Bot Host: Python / Node.js bots          (create: /admin/servers/new?kind=bot)
//   GET  /admin/settings                       panel name + logo
//   POST /admin/settings/name                  { name } or { reset: 1 }
//   POST /admin/settings/logo                  raw image bytes (application/octet-stream, X-CSRF-Token header)
//   POST /admin/settings/logo/reset            back to the default logo
//   GET  /brand/logo                           the uploaded logo (public: the login page shows it too)
const { requireAdmin } = require('../middleware/auth');
const { rateLimit } = require('../lib/rateLimit');
const { HttpError } = require('../lib/http');
const { hashPassword } = require('../lib/crypto');
const validate = require('../lib/validate');
const { esc } = require('../views/layout');
const { icon } = require('../views/icons');
const users = require('../services/users');
const settings = require('../services/settings');
const servers = require('./services/servers');
const activity = require('./services/activity');
const capacity = require('./services/capacity');
const f = require('./format');
const { shell, badge, actionButtons, capacityPanel, liveTag } = require('./views');

const STATUSES = ['online', 'offline', 'crashed'];
const page = (ctx, o) => shell({ admin: true, user: ctx.user, csrf: ctx.csrfToken, styles: ['/css/admin.css'], ...o });
const hidden = (ctx) => `<input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}">`;
const searchBox = (action, q, placeholder) => `<form method="get" action="${action}" class="mp-admin-search" role="search">
<div class="mp-input-wrap has-icon"><span class="mp-input-icon">${icon('search', 16)}</span><input type="search" name="q" value="${esc(q)}" placeholder="${esc(placeholder)}" maxlength="100" autocomplete="off" aria-label="${esc(placeholder)}"></div>
<button type="submit" class="mp-btn-sm">Search</button></form>`;
const when = (ts) => (ts ? `<time datetime="${f.iso(ts)}" title="${f.iso(ts)}">${f.relative(ts)}</time>` : '<span class="mp-muted">Never</span>');
const table = (head, rows, emptyText) => (rows.length
  ? `<div class="mp-table-wrap"><table class="mp-table"><thead><tr>${head.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`
  : `<p class="mp-empty">${esc(emptyText)}</p>`);

/** The live numbers of one server row (also sent by /api/admin/usage so the page can refresh them). */
function usageOf(s) {
  const on = s.status === 'online';
  return {
    identifier: s.identifier, badge: badge(s),
    ram: `${on ? `${f.mb(s.ram_used_mb)} / ` : ''}${f.mb(s.ram_limit_mb)}`,
    cpu: `${on ? `${Math.round(s.cpu_used_pct)}% / ` : ''}${f.cores(s.cpu_limit_pct)}`,
    disk: `${f.mb(s.disk_used_mb || 0)} / ${f.mb(s.disk_limit_mb)}`,
    players: `${s.players_online} / ${s.players_max}`
  };
}
const liveCell = (s, field, text) => `<td data-srv="${esc(s.identifier)}" data-f="${field}">${text}</td>`;

// ---------------------------------------------------------------------------------------------
// Users
// ---------------------------------------------------------------------------------------------
function usersPage({ ctx, q = '', list, errors = {}, values = {}, flash, addOpen = false }) {
  const v = { username: '', email: '', role: 'user', ...values };
  const fld = (name, label, { type = 'text', ac = 'off' } = {}) => `<div class="mp-field${errors[name] ? ' has-error' : ''}"><label for="u-${name}">${label}</label>
<div class="mp-input-wrap"><input id="u-${name}" name="${name}" type="${type}" value="${type === 'password' ? '' : esc(v[name])}" autocomplete="${ac}"></div>
<p class="mp-error"${errors[name] ? '' : ' hidden'}>${esc(errors[name] || '')}</p></div>`;
  const add = `<details class="mp-panel mp-admin-add"${addOpen ? ' open' : ''}><summary class="mp-btn-primary">${icon('plus', 14)} Add user</summary>
<form method="post" action="/admin/users" class="mp-form" novalidate>${hidden(ctx)}
<div class="mp-grid-2"><div>${fld('username', 'Username', { ac: 'off' })}${fld('email', 'Email', { type: 'email', ac: 'off' })}</div>
<div>${fld('password', 'Password', { type: 'password', ac: 'new-password' })}
<div class="mp-field"><label for="u-role">Role</label><div class="mp-input-wrap"><select id="u-role" name="role" class="mp-select"><option value="user"${v.role === 'user' ? ' selected' : ''}>User</option><option value="admin"${v.role === 'admin' ? ' selected' : ''}>Administrator</option></select></div></div></div></div>
<div class="mp-form-actions"><button type="submit" class="mp-button mp-btn-inline">${icon('plus', 14)} Create user</button></div></form></details>`;

  const act = (u, path, field, value, label, cls = '') => `<form method="post" action="/admin/users/${u.id}/${path}" class="mp-actions">${hidden(ctx)}<input type="hidden" name="${field}" value="${value}"><button type="submit" class="mp-btn-sm ${cls}">${label}</button></form>`;
  const rows = list.map((u) => {
    const me = u.id === ctx.user.id;
    const name = [u.first_name, u.last_name].filter(Boolean).join(' ');
    return `<tr><td><a href="/admin/users/${u.id}/edit"><strong>${esc(u.username)}</strong></a>${me ? ' <span class="mp-muted">(you)</span>' : ''}${name ? `<div class="mp-muted">${esc(name)}</div>` : ''}</td>
<td>${esc(u.email)}</td>
<td><span class="mp-badge mp-badge-${u.role === 'admin' ? 'starting' : 'offline'}">${u.role === 'admin' ? 'Admin' : 'User'}</span></td>
<td><span class="mp-badge mp-badge-${u.is_active ? 'online' : 'crashed'}">${u.is_active ? 'Active' : 'Disabled'}</span></td>
<td>${u.server_count}</td><td>${when(u.last_login_at)}</td>
<td><div class="mp-actions"><a class="mp-btn-sm mp-btn-link" href="/admin/users/${u.id}/edit" aria-label="Edit ${esc(u.username)}">${icon('edit', 13)} Edit</a>${me ? '' : `${act(u, 'role', 'role', u.role === 'admin' ? 'user' : 'admin', u.role === 'admin' ? 'Make user' : 'Make admin')}${act(u, 'active', 'active', u.is_active ? '0' : '1', u.is_active ? 'Disable' : 'Enable', u.is_active ? 'mp-btn-stop' : 'mp-btn-start')}`}</div></td></tr>`;
  });
  const body = `<div class="mp-admin-bar">${searchBox('/admin/users', q, 'Search users…')}</div>${add}
<section class="mp-panel">${table(['User', 'Email', 'Role', 'Status', 'Servers', 'Last sign-in', 'Actions'], rows, q ? 'No users match your search.' : 'No users yet.')}<p class="mp-muted mp-count">${list.length} user${list.length === 1 ? '' : 's'}</p></section>`;
  return page(ctx, { title: 'Users', sub: 'Manage accounts and roles.', active: 'admin-users', flash, body });
}


function editUserPage({ ctx, u, errors = {}, values = {}, flash }) {
  const me = u.id === ctx.user.id;
  const v = { username: u.username, email: u.email, first: u.first_name || '', last: u.last_name || '', role: u.role, active: u.is_active ? '1' : '0', ...values };
  const owned = servers.listAll().filter((s) => s.owner_id === u.id);
  const fld = (name, label, { type = 'text', ac = 'off', hint = '' } = {}) => `<div class="mp-field${errors[name] ? ' has-error' : ''}"><label for="e-${name}">${label}</label>
<div class="mp-input-wrap"><input id="e-${name}" name="${name}" type="${type}" value="${type === 'password' ? '' : esc(v[name])}" autocomplete="${ac}"></div>${hint ? `<p class="mp-hint">${hint}</p>` : ''}
<p class="mp-error"${errors[name] ? '' : ' hidden'}>${esc(errors[name] || '')}</p></div>`;
  const sel = (name, label, opts, hint) => `<div class="mp-field${errors[name] ? ' has-error' : ''}"><label for="e-${name}">${label}</label><div class="mp-input-wrap"><select id="e-${name}" name="${name}" class="mp-select"${me ? ' disabled' : ''}>${opts.map(([val, text]) => `<option value="${val}"${v[name] === val ? ' selected' : ''}>${text}</option>`).join('')}</select></div><p class="mp-hint">${me ? 'You cannot change your own role or status.' : hint}</p><p class="mp-error"${errors[name] ? '' : ' hidden'}>${esc(errors[name] || '')}</p></div>`;
  const srvRows = owned.map((s) => `<tr><td><a href="/dashboard/servers/${esc(s.identifier)}"><strong>${esc(s.name)}</strong></a></td><td><code>${esc(s.identifier)}</code></td><td>${s.kind === 'bot' ? 'Bot Host' : 'MC Host'}</td><td>${badge(s)}</td><td><a class="mp-icon-btn" href="/admin/servers/${esc(s.identifier)}/edit" aria-label="Edit ${esc(s.name)}">${icon('edit', 14)}</a></td></tr>`);
  const canDelete = !me && !owned.length;
  const del = me ? '<p class="mp-muted">You cannot delete your own account.</p>'
    : owned.length ? `<p class="mp-muted">This user owns ${owned.length} server${owned.length === 1 ? '' : 's'}. Delete or reassign them first, then the account can be deleted.</p>`
      : `<details class="mp-danger"><summary class="mp-btn-sm mp-btn-stop">${icon('trash', 14)} Delete user</summary>
<form method="post" action="/admin/users/${u.id}/delete" class="mp-form">${hidden(ctx)}<p><strong>Are you sure?</strong> The account <code>${esc(u.username)}</code> and its sessions are removed for good. This cannot be undone.</p>
<button type="submit" class="mp-btn-sm mp-btn-stop">Yes, delete ${esc(u.username)}</button></form></details>`;
  void canDelete;
  const body = `<form method="post" action="/admin/users/${u.id}" class="mp-form" novalidate>${hidden(ctx)}
<div class="mp-grid-2">
<section class="mp-panel"><h2>Identity</h2>${fld('email', 'Email', { type: 'email' })}${fld('username', 'Username')}${fld('first', 'First name')}${fld('last', 'Last name')}</section>
<section class="mp-panel"><h2>Password</h2>${fld('password', 'Password', { type: 'password', ac: 'new-password', hint: 'Leaving this blank keeps the current password. Set a new one here to reset it for the user.' })}
<h2>Permissions</h2>${sel('role', 'Administrator', [['user', 'No'], ['admin', 'Yes']], 'Setting this to Yes gives the user full administrative access to the panel.')}${sel('active', 'Status', [['1', 'Active'], ['0', 'Disabled']], 'A disabled user cannot sign in.')}</section>
</div>
<section class="mp-panel mp-user-foot"><div>${del.includes('<form') ? '' : del}</div><div class="mp-form-actions"><a class="mp-btn-sm" href="/admin/users">Cancel</a> <button type="submit" class="mp-button mp-btn-inline">${icon('edit', 14)} Update user</button></div></section></form>
${del.includes('<form') ? `<section class="mp-panel"><h2>Delete user</h2>${del}</section>` : ''}
<section class="mp-panel"><h2>Associated servers (${owned.length})</h2>${table(['Server', 'Identifier', 'Type', 'Status', ''], srvRows, 'This user has no servers yet.')}</section>`;
  return page(ctx, { title: u.username, sub: [u.first_name, u.last_name].filter(Boolean).join(' ') || 'Manage user details.', active: 'admin-users', flash, body });
}

// ---------------------------------------------------------------------------------------------
// Overview: numbers at a glance, the VPS meters, servers that need attention, latest activity
// ---------------------------------------------------------------------------------------------
function overviewPage({ ctx, flash }) {
  const all = servers.listAll(), people = users.listAll();
  const online = all.filter((s) => s.status === 'online'), crashed = all.filter((s) => s.status === 'crashed');
  const players = online.reduce((n, s) => n + (s.players_online || 0), 0);
  const stat = (label, value, sub, href, tone = '') => `<a class="mp-stat${tone ? ` is-${tone}` : ''}" href="${href}"><span class="mp-stat-label">${label}</span><strong class="mp-stat-value">${value}</strong><span class="mp-muted">${sub}</span></a>`;
  const stats = `<div class="mp-stats">${[
    stat('Users', people.length, `${people.filter((u) => u.role === 'admin').length} admin · ${people.filter((u) => !u.is_active).length} disabled`, '/admin/users'),
    stat('MC servers', servers.countByKind('mc'), `${online.filter((s) => s.kind === 'mc').length} online`, '/admin/servers/mc'),
    stat('Bots', servers.countByKind('bot'), `${online.filter((s) => s.kind === 'bot').length} online`, '/admin/servers/bots'),
    stat('Online now', online.length, `of ${all.length} server${all.length === 1 ? '' : 's'}`, '/admin/servers/mc?status=online', online.length ? 'good' : ''),
    stat('Players', players, 'connected right now', '/admin/servers/mc?status=online'),
    stat('Crashed', crashed.length, crashed.length ? 'need a look' : 'all fine', '/admin/servers/mc?status=crashed', crashed.length ? 'bad' : '')
  ].join('')}</div>`;
  const attention = crashed.length
    ? `<section class="mp-panel"><h2>Needs attention</h2>${table(['Server', 'Owner', 'Status', ''], crashed.map((s) => `<tr><td><strong>${esc(s.name)}</strong><div class="mp-muted"><code>#${servers.numberOf(s)}</code></div></td><td>${esc(s.owner_name || '—')}</td><td>${badge(s)}</td><td><a class="mp-btn-sm" href="/dashboard/servers/${esc(s.identifier)}/console">Console</a></td></tr>`), '')}</section>` : '';
  const items = activity.recentAll(10);
  const feed = items.length
    ? `<ul class="mp-activity">${items.map((a) => `<li><span class="mp-activity-msg"><strong>${esc(a.username || '—')}</strong> · ${esc(a.message)}</span>${when(a.created_at)}</li>`).join('')}</ul>`
    : '<p class="mp-empty">No activity yet.</p>';
  const quick = `<div class="mp-quick"><a class="mp-btn-primary" href="/admin/servers/new?kind=mc">${icon('plus', 14)} MC server</a><a class="mp-btn-primary" href="/admin/servers/new?kind=bot">${icon('plus', 14)} Bot</a><a class="mp-btn-sm" href="/admin/users">${icon('users', 14)} Users</a><a class="mp-btn-sm" href="/admin/settings">${icon('gear', 14)} Settings</a></div>`;
  return page(ctx, { title: 'Overview', sub: 'How your panel and VPS are doing.', active: 'admin-overview', flash, body: `${quick}${stats}${capacityPanel()}${attention}<section class="mp-panel"><h2>Latest activity</h2>${feed}</section>`, scripts: ['/js/admin-live.js'] });
}

// ---------------------------------------------------------------------------------------------
// Servers: MC Host / Bot Host
// ---------------------------------------------------------------------------------------------
function serversPage({ ctx, kind, q = '', status = '', list, flash }) {
  const bot = kind === 'bot';
  const back = (bot ? '/admin/servers/bots' : '/admin/servers/mc') + (q ? `?q=${encodeURIComponent(q)}` : '');   // where the power buttons return to
  const link = (s) => `<a href="/dashboard/servers/${esc(s.identifier)}"><strong>${esc(s.name)}</strong></a><div class="mp-muted"><code>#${servers.numberOf(s)}</code> · <code>${esc(s.identifier)}</code></div>`;
  const u = usageOf;
  const rows = list.map((s) => `<tr><td>${link(s)}</td><td>${esc(s.owner_name || '—')}</td>
<td>${bot ? esc(servers.RUNTIMES[s.runtime]?.label || s.runtime || '—') : `${esc(s.software)} ${esc(s.version)}`}</td>
${liveCell(s, 'badge', u(s).badge)}${liveCell(s, 'ram', u(s).ram)}${liveCell(s, 'cpu', u(s).cpu)}${liveCell(s, 'disk', u(s).disk)}${bot ? '' : liveCell(s, 'players', u(s).players)}
<td>${s.address ? `<code>${esc(s.address)}</code>` : '<span class="mp-muted">Not set</span>'}${s.expires_at ? `<div class="mp-muted">Valid till ${servers.formatDate(s.expires_at)}</div>` : ''}${s.suspended ? '<div><span class="mp-badge mp-badge-crashed">suspended</span></div>' : ''}</td>
<td><div class="mp-row-actions">${actionButtons(s, { csrf: ctx.csrfToken, back, userId: ctx.user.id })}</div></td>
<td><div class="mp-actions"><a class="mp-icon-btn" href="/admin/servers/${esc(s.identifier)}/edit" title="Edit resources, IP and validity" aria-label="Edit ${esc(s.name)}">${icon('edit', 14)}</a><a class="mp-icon-btn" href="/dashboard/servers/${esc(s.identifier)}/startup" title="Startup command and variables" aria-label="Startup of ${esc(s.name)}">${icon('rocket', 14)}</a></div></td>
<td><div class="mp-actions"><a class="mp-btn-sm mp-btn-link" href="/admin/servers/${esc(s.identifier)}/extend" title="Upgrade validity time">${icon('calendar', 13)} Upgrade</a><form method="post" action="/admin/servers/${esc(s.identifier)}/${s.suspended ? 'unsuspend' : 'suspend'}"><input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}"><input type="hidden" name="back" value="${esc(back)}"><button type="submit" class="mp-btn-sm${s.suspended ? ' mp-btn-start' : ' mp-btn-stop'}">${s.suspended ? 'Unsuspend' : 'Suspend'}</button></form></div></td></tr>`);
  const head = ['Name', 'Owner', bot ? 'Runtime' : 'Software', 'Status', 'Memory', 'CPU', 'Disk', ...(bot ? [] : ['Players']), 'IP', 'Actions', 'Edit', 'Time / Suspend'];
  const cap = capacity.status(), full = cap.full, makeLabel = bot ? 'Create Bot' : 'Create MC Server';
  const create = full
    ? `<span class="mp-btn-primary is-disabled" aria-disabled="true" title="The VPS is full. Upgrade your VPS first.">${icon('plus', 14)} ${makeLabel}</span>`
    : `<a class="mp-btn-primary" href="/admin/servers/new?kind=${kind}">${icon('plus', 14)} ${makeLabel}</a>`;
  const note = bot
    ? 'Bots run on <strong>Python</strong> or <strong>Node.js</strong>. Both are already installed, so you only pick one when you create the bot.'
    : 'Minecraft servers run <strong>Paper</strong>.';
  const base = bot ? '/admin/servers/bots' : '/admin/servers/mc', qs = q ? `&q=${encodeURIComponent(q)}` : '';
  const chips = `<nav class="mp-chips" aria-label="Filter by status">${[['', 'All'], ['online', 'Online'], ['offline', 'Offline'], ['crashed', 'Crashed']].map(([k, l]) => `<a class="mp-chip${status === k ? ' is-on' : ''}" href="${base}${k || q ? `?${k ? `status=${k}` : ''}${qs}`.replace('?&', '?') : ''}">${l}</a>`).join('')}</nav>`;
  const body = `${capacityPanel(cap)}<div class="mp-admin-bar">${searchBox(base, q, bot ? 'Search bots…' : 'Search MC servers…')}${create}</div>${chips}
<section class="mp-panel"><div class="mp-admin-note-row"><p class="mp-muted mp-admin-note">${note}</p>${liveTag()}</div>${table(head, rows, q ? 'Nothing matches your search.' : bot ? 'No bots yet.' : 'No MC servers yet.')}<p class="mp-muted mp-count">${list.length} ${bot ? 'bot' : 'server'}${list.length === 1 ? '' : 's'}${status ? ` · ${esc(status)}` : ''}</p></section>`;
  return page(ctx, { title: bot ? 'Bot Host' : 'MC Host', sub: bot ? 'Python and Node.js bots.' : 'Minecraft servers running Paper.', active: bot ? 'admin-bots' : 'admin-mc', flash, body, scripts: ['/js/admin-live.js'] });
}

// ---------------------------------------------------------------------------------------------
// Settings: panel name + logo
// ---------------------------------------------------------------------------------------------
function settingsPage({ ctx, errors = {}, values = {}, flash }) {
  const name = values.name ?? settings.brand();
  const custom = settings.hasCustomLogo();
  const nameForm = `<section class="mp-panel mp-acct"><h2>Panel name</h2><p class="mp-muted">Shown in the top bar, on the login page and in the browser tab.</p>
<form method="post" action="/admin/settings/name" class="mp-form" novalidate>${hidden(ctx)}
<div class="mp-field${errors.name ? ' has-error' : ''}"><label for="s-name">Name</label><div class="mp-input-wrap"><input id="s-name" name="name" type="text" value="${esc(name)}" maxlength="${settings.NAME_MAX}" autocomplete="off"></div>
<p class="mp-error"${errors.name ? '' : ' hidden'}>${esc(errors.name || '')}</p></div>
<div class="mp-form-actions"><button type="submit" class="mp-button mp-btn-inline">Save name</button><button type="submit" name="reset" value="1" class="mp-btn-sm" formnovalidate>Use default</button></div></form></section>`;
  const logoForm = `<section class="mp-panel mp-acct"><h2>Logo</h2><p class="mp-muted">PNG, JPG, WebP or GIF, up to 1 MB. A square image looks best.</p>
<div class="mp-logo-edit"><img class="mp-logo-preview" src="${esc(settings.logoUrl())}" width="84" height="84" alt="Current logo" data-logo-preview>
<div class="mp-logo-controls"><input type="file" id="s-logo" accept="image/png,image/jpeg,image/webp,image/gif" data-logo-file aria-label="Choose a logo image">
<div class="mp-form-actions"><button type="button" class="mp-button mp-btn-inline" data-logo-upload data-csrf="${esc(ctx.csrfToken)}" disabled>${icon('arrowUp', 14)} Upload logo</button>
${custom ? `<form method="post" action="/admin/settings/logo/reset" class="mp-actions">${hidden(ctx)}<button type="submit" class="mp-btn-sm">Use default logo</button></form>` : ''}</div>
<p class="mp-hint" data-logo-status role="status"></p><noscript><p class="mp-hint">JavaScript is needed to upload a logo.</p></noscript></div></div></section>`;
  return page(ctx, { title: 'Settings', sub: 'Panel name and logo.', active: 'admin-settings', flash, body: `<div class="mp-grid-2">${nameForm}${logoForm}</div>`, scripts: ['/js/admin.js'] });
}

/** Reads a request body into a Buffer, refusing anything over `limit` bytes. */
function readBuffer(req, limit) {
  return new Promise((resolve, reject) => {
    if (Number(req.headers['content-length']) > limit) return reject(new HttpError(413, 'The logo must be 1 MB or smaller.'));
    const chunks = []; let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new HttpError(413, 'The logo must be 1 MB or smaller.')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

module.exports = function register(router) {
  const log = (ctx, userId, type, message) => activity.record({ userId, type, message, ip: ctx.ip });
  const writeLimit = rateLimit({ name: 'admin-write', windowMs: 60 * 1000, max: 60 });

  // ---- users
  const showUsers = (ctx) => ctx.html(200, usersPage({ ctx, q: String(ctx.query.q ?? '').slice(0, 100), list: users.listAll(ctx.query.q), flash: ctx.takeFlash() }));
  router.get('/admin', requireAdmin, (ctx) => ctx.html(200, overviewPage({ ctx, flash: ctx.takeFlash() })));
  router.get('/admin/users', requireAdmin, showUsers);

  // Live numbers for the admin pages: the three VPS meters and every server's usage (admin only).
  router.get('/api/admin/usage', requireAdmin, (ctx) => {
    const st = capacity.status();
    ctx.res.setHeader('Cache-Control', 'no-store');
    return ctx.json(200, {
      full: st.full, limitPct: st.limitPct,
      vps: Object.fromEntries(st.resources.map((r) => [r.key, { pct: Math.round(r.usedPct), text: `${r.usedText} of ${r.totalText} in use`, sub: `${r.allocatedText} limit given to servers (a ceiling, only what they use is taken)`, full: r.full }])),
      servers: servers.listAll().map(usageOf)
    });
  });

  router.post('/admin/users', requireAdmin, rateLimit({ name: 'admin-user-create', windowMs: 60 * 60 * 1000, max: 60 }), async (ctx) => {
    const b = ctx.body;
    const values = { username: String(b.username ?? '').trim(), email: String(b.email ?? '').trim(), role: b.role === 'admin' ? 'admin' : 'user' };
    const errors = validate.collect({ username: validate.username(values.username), email: validate.email(values.email), password: validate.password(b.password) });
    const fail = (e) => ctx.html(422, usersPage({ ctx, list: users.listAll(), errors: e, values, addOpen: true, flash: { type: 'error', message: 'Please fix the highlighted fields.' } }));
    if (Object.keys(errors).length) return fail(errors);
    try {
      const u = users.create({ username: values.username, email: values.email, passwordHash: await hashPassword(String(b.password)), role: values.role });
      log(ctx, u.id, 'account.created', `Your account was created by ${ctx.user.username}`);
      ctx.flash('success', `User "${u.username}" created.`);
      return ctx.redirect('/admin/users');
    } catch (err) {
      const field = users.uniqueViolation(err);
      if (!field) throw err;
      return fail({ [field]: field === 'email' ? 'That email is already registered.' : 'That username is taken.' });
    }
  });

  // Role / status changes. Never on yourself, and the last active administrator is always kept.
  const target = (ctx) => {
    const u = users.findById(Number(ctx.params.id));
    if (!u) throw new HttpError(404, 'User not found.');
    if (u.id === ctx.user.id) throw new HttpError(400, 'You cannot change your own role or status.');
    return u;
  };
  router.post('/admin/users/:id/role', requireAdmin, writeLimit, (ctx) => {
    const u = target(ctx), role = ctx.body.role === 'admin' ? 'admin' : 'user';
    if (u.role === 'admin' && role === 'user' && u.is_active && users.countActiveAdmins() <= 1) throw new HttpError(400, 'There must be at least one active administrator.');
    users.setRole(u.id, role);
    log(ctx, u.id, 'account.role', `Your role was changed to ${role} by ${ctx.user.username}`);
    ctx.flash('success', `${u.username} is now ${role === 'admin' ? 'an administrator' : 'a regular user'}.`);
    return ctx.redirect('/admin/users');
  });
  router.post('/admin/users/:id/active', requireAdmin, writeLimit, (ctx) => {
    const u = target(ctx), active = ctx.body.active === '1';
    if (!active && u.role === 'admin' && users.countActiveAdmins() <= 1) throw new HttpError(400, 'There must be at least one active administrator.');
    users.setActive(u.id, active);
    ctx.flash('success', `${u.username} was ${active ? 'enabled' : 'disabled'}.`);
    return ctx.redirect('/admin/users');
  });

  // Edit user: username, email, role, status and (optionally) a new password.
  const editTarget = (ctx) => { const u = users.findById(Number(ctx.params.id)); if (!u) throw new HttpError(404, 'User not found.'); return u; };
  router.get('/admin/users/:id/edit', requireAdmin, (ctx) => ctx.html(200, editUserPage({ ctx, u: editTarget(ctx), flash: ctx.takeFlash() })));
  router.post('/admin/users/:id', requireAdmin, writeLimit, async (ctx) => {
    const u = editTarget(ctx), b = ctx.body, me = u.id === ctx.user.id;
    const values = { username: String(b.username ?? '').trim(), email: String(b.email ?? '').trim(), first: String(b.first ?? '').trim(), last: String(b.last ?? '').trim(),
      role: me ? u.role : (b.role === 'admin' ? 'admin' : 'user'), active: me ? (u.is_active ? '1' : '0') : (b.active === '0' ? '0' : '1') };
    const checks = { username: validate.username(values.username), email: validate.email(values.email), first: validate.optionalName(values.first), last: validate.optionalName(values.last) };
    if (b.password) checks.password = validate.password(b.password);
    const errors = validate.collect(checks);
    const fail = (e) => ctx.html(422, editUserPage({ ctx, u, errors: e, values, flash: { type: 'error', message: 'Please fix the highlighted fields.' } }));
    if (Object.keys(errors).length) return fail(errors);
    const active = values.active === '1', demoting = u.role === 'admin' && (values.role !== 'admin' || !active) && u.is_active;
    if (demoting && users.countActiveAdmins() <= 1) return fail({ role: 'There must be at least one active administrator.' });
    try {
      users.update(u.id, { username: values.username, email: values.email, role: values.role, firstName: values.first, lastName: values.last });
      if (!me) users.setActive(u.id, active);
      if (b.password) users.setPassword(u.id, await hashPassword(String(b.password)));
    } catch (err) {
      const field = users.uniqueViolation(err);
      if (!field) throw err;
      return fail({ [field]: field === 'email' ? 'That email is already registered.' : 'That username is taken.' });
    }
    if (values.role !== u.role) log(ctx, u.id, 'account.role', `Your role was changed to ${values.role} by ${ctx.user.username}`);
    ctx.flash('success', `User "${values.username}" updated.`);
    return ctx.redirect('/admin/users');
  });

  router.post('/admin/users/:id/delete', requireAdmin, writeLimit, (ctx) => {
    const u = editTarget(ctx);
    if (u.id === ctx.user.id) throw new HttpError(400, 'You cannot delete your own account.');
    if (servers.listAll().some((s) => s.owner_id === u.id)) throw new HttpError(400, 'This user still owns servers. Delete or reassign them first.');
    if (u.role === 'admin' && u.is_active && users.countActiveAdmins() <= 1) throw new HttpError(400, 'There must be at least one active administrator.');
    users.remove(u.id);
    ctx.flash('success', `User "${u.username}" was deleted.`);
    return ctx.redirect('/admin/users');
  });

  // ---- servers nest
  router.get('/admin/servers', requireAdmin, (ctx) => ctx.redirect('/admin/servers/mc'));
  for (const [path, kind] of [['/admin/servers/mc', 'mc'], ['/admin/servers/bots', 'bot']]) {
    router.get(path, requireAdmin, (ctx) => ctx.html(200, serversPage({ ctx, kind, q: String(ctx.query.q ?? '').slice(0, 100), status: STATUSES.includes(ctx.query.status) ? ctx.query.status : '', list: servers.listByKind(kind, ctx.query.q).filter((s) => !STATUSES.includes(ctx.query.status) || s.status === ctx.query.status), flash: ctx.takeFlash() })));
  }

  // ---- settings
  router.get('/admin/settings', requireAdmin, (ctx) => ctx.html(200, settingsPage({ ctx, flash: ctx.takeFlash() })));

  router.post('/admin/settings/name', requireAdmin, writeLimit, (ctx) => {
    if (ctx.body.reset) { settings.resetBrand(); ctx.flash('success', 'Panel name reset to the default.'); return ctx.redirect('/admin/settings'); }
    const name = String(ctx.body.name ?? '').trim(), err = settings.validateName(name);
    if (err) return ctx.html(422, settingsPage({ ctx, errors: { name: err }, values: { name }, flash: { type: 'error', message: 'Please fix the highlighted field.' } }));
    settings.setBrand(name);
    ctx.flash('success', 'Panel name saved.');
    return ctx.redirect('/admin/settings');
  });

  router.post('/admin/settings/logo', requireAdmin, writeLimit, async (ctx) => {
    if (!String(ctx.req.headers['content-type'] || '').startsWith('application/octet-stream')) return ctx.json(415, { error: 'Send the image as raw bytes.' });
    const buf = await readBuffer(ctx.req, settings.LOGO_MAX_BYTES);
    const err = settings.setLogo(buf);
    if (err) return ctx.json(422, { error: err });
    ctx.flash('success', 'Logo updated.');
    return ctx.json(200, { ok: true, url: settings.logoUrl() });
  });
  router.post('/admin/settings/logo/reset', requireAdmin, writeLimit, (ctx) => {
    settings.resetLogo();
    ctx.flash('success', 'Logo reset to the default.');
    return ctx.redirect('/admin/settings');
  });

  // The uploaded logo. Public on purpose: the sign-in page shows it before anybody is logged in.
  router.get('/brand/logo', (ctx) => {
    const logo = settings.getLogo();
    if (!logo) return ctx.redirect('/img/logo.png', 302);
    ctx.res.setHeader('Cache-Control', 'public, max-age=86400');
    ctx.res.writeHead(200, { 'Content-Type': logo.mime, 'Content-Length': logo.data.length });
    return ctx.res.end(ctx.req.method === 'HEAD' ? undefined : logo.data);
  });
};
