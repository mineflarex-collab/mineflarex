'use strict';
// Admin panel (administrators only). Left sidebar: Users, Servers (Bot Host / MC Host) and Settings (panel name + logo).
//
//   GET  /admin, /admin/users                  users: search, add, make admin / user, enable / disable
//   GET  /admin/servers/mc                     MC Host: Minecraft (Paper) servers      (create: /admin/servers/new?kind=mc)
//   GET  /admin/servers/bots                   Bot Host: Python / Node.js bots          (create: /admin/servers/new?kind=bot)
//   GET  /admin/settings                       panel name + logo
//   POST /admin/settings/name                  { name } or { reset: 1 }
//   POST /admin/settings/logo                  raw image bytes (application/octet-stream, X-CSRF-Token header)
//   POST /admin/settings/logo/reset            back to the default logo
//   GET  /brand/logo                           the uploaded logo (public: the login page shows it too)
const { requireAdmin } = require('../middleware/auth');
const { rateLimit } = require('../lib/rateLimit');
const { HttpError } = require('../lib/http');
const { hashPassword } = require('../lib/crypto');
const validate = require('../lib/validate');
const { esc } = require('../views/layout');
const { icon } = require('../views/icons');
const users = require('../services/users');
const settings = require('../services/settings');
const servers = require('./services/servers');
const activity = require('./services/activity');
const capacity = require('./services/capacity');
const f = require('./format');
const { shell, badge, actionButtons } = require('./views');

const page = (ctx, o) => shell({ admin: true, user: ctx.user, csrf: ctx.csrfToken, styles: ['/css/admin.css'], ...o });
const hidden = (ctx) => `<input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}">`;
const searchBox = (action, q, placeholder) => `<form method="get" action="${action}" class="mp-admin-search" role="search">
<div class="mp-input-wrap has-icon"><span class="mp-input-icon">${icon('search', 16)}</span><input type="search" name="q" value="${esc(q)}" placeholder="${esc(placeholder)}" maxlength="100" autocomplete="off" aria-label="${esc(placeholder)}"></div>
<button type="submit" class="mp-btn-sm">Search</button></form>`;
const when = (ts) => (ts ? `<time datetime="${f.iso(ts)}" title="${f.iso(ts)}">${f.relative(ts)}</time>` : '<span class="mp-muted">Never</span>');
const table = (head, rows, emptyText) => (rows.length
  ? `<div class="mp-table-wrap"><table class="mp-table"><thead><tr>${head.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`
  : `<p class="mp-empty">${esc(emptyText)}</p>`);

// ---------------------------------------------------------------------------------------------
// Users
// ---------------------------------------------------------------------------------------------
function usersPage({ ctx, q = '', list, errors = {}, values = {}, flash, addOpen = false }) {
  const v = { username: '', email: '', role: 'user', ...values };
  const fld = (name, label, { type = 'text', ac = 'off' } = {}) => `<div class="mp-field${errors[name] ? ' has-error' : ''}"><label for="u-${name}">${label}</label>
<div class="mp-input-wrap"><input id="u-${name}" name="${name}" type="${type}" value="${type === 'password' ? '' : esc(v[name])}" autocomplete="${ac}"></div>
<p class="mp-error"${errors[name] ? '' : ' hidden'}>${esc(errors[name] || '')}</p></div>`;
  const add = `<details class="mp-panel mp-admin-add"${addOpen ? ' open' : ''}><summary class="mp-btn-primary">${icon('plus', 14)} Add user</summary>
<form method="post" action="/admin/users" class="mp-form" novalidate>${hidden(ctx)}
<div class="mp-grid-2"><div>${fld('username', 'Username', { ac: 'off' })}${fld('email', 'Email', { type: 'email', ac: 'off' })}</div>
<div>${fld('password', 'Password', { type: 'password', ac: 'new-password' })}
<div class="mp-field"><label for="u-role">Role</label><div class="mp-input-wrap"><select id="u-role" name="role" class="mp-select"><option value="user"${v.role === 'user' ? ' selected' : ''}>User</option><option value="admin"${v.role === 'admin' ? ' selected' : ''}>Administrator</option></select></div></div></div></div>
<div class="mp-form-actions"><button type="submit" class="mp-button mp-btn-inline">${icon('plus', 14)} Create user</button></div></form></details>`;

  const act = (u, path, field, value, label, cls = '') => `<form method="post" action="/admin/users/${u.id}/${path}" class="mp-actions">${hidden(ctx)}<input type="hidden" name="${field}" value="${value}"><button type="submit" class="mp-btn-sm ${cls}">${label}</button></form>`;
  const rows = list.map((u) => {
    const me = u.id === ctx.user.id;
    const name = [u.first_name, u.last_name].filter(Boolean).join(' ');
    return `<tr><td><strong>${esc(u.username)}</strong>${me ? ' <span class="mp-muted">(you)</span>' : ''}${name ? `<div class="mp-muted">${esc(name)}</div>` : ''}</td>
<td>${esc(u.email)}</td>
<td><span class="mp-badge mp-badge-${u.role === 'admin' ? 'starting' : 'offline'}">${u.role === 'admin' ? 'Admin' : 'User'}</span></td>
<td><span class="mp-badge mp-badge-${u.is_active ? 'online' : 'crashed'}">${u.is_active ? 'Active' : 'Disabled'}</span></td>
<td>${u.server_count}</td><td>${when(u.last_login_at)}</td>
<td>${me ? '<span class="mp-muted">—</span>' : `<div class="mp-actions">${act(u, 'role', 'role', u.role === 'admin' ? 'user' : 'admin', u.role === 'admin' ? 'Make user' : 'Make admin')}${act(u, 'active', 'active', u.is_active ? '0' : '1', u.is_active ? 'Disable' : 'Enable', u.is_active ? 'mp-btn-stop' : 'mp-btn-start')}`}</div></td></tr>`;
  });
  const body = `<div class="mp-admin-bar">${searchBox('/admin/users', q, 'Search users…')}</div>${add}
<section class="mp-panel">${table(['User', 'Email', 'Role', 'Status', 'Servers', 'Last sign-in', 'Actions'], rows, q ? 'No users match your search.' : 'No users yet.')}<p class="mp-muted mp-count">${list.length} user${list.length === 1 ? '' : 's'}</p></section>`;
  return page(ctx, { title: 'Users', sub: 'Manage accounts and roles.', active: 'admin-users', flash, body });
}


function editUserPage({ ctx, u, errors = {}, values = {}, flash }) {
  const me = u.id === ctx.user.id, v = { username: u.username, email: u.email, role: u.role, active: u.is_active ? '1' : '0', ...values };
  const fld = (name, label, type = 'text', ac = 'off', hint = '') => `<div class="mp-field${errors[name] ? ' has-error' : ''}"><label for="e-${name}">${label}</label>
<div class="mp-input-wrap"><input id="e-${name}" name="${name}" type="${type}" value="${type === 'password' ? '' : esc(v[name])}" autocomplete="${ac}"></div>${hint ? `<p class="mp-hint">${hint}</p>` : ''}
<p class="mp-error"${errors[name] ? '' : ' hidden'}>${esc(errors[name] || '')}</p></div>`;
  const sel = (name, label, opts) => `<div class="mp-field${errors[name] ? ' has-error' : ''}"><label for="e-${name}">${label}</label><div class="mp-input-wrap"><select id="e-${name}" name="${name}" class="mp-select"${me ? ' disabled' : ''}>${opts.map(([val, text]) => `<option value="${val}"${v[name] === val ? ' selected' : ''}>${text}</option>`).join('')}</select></div>${me ? '<p class="mp-hint">You cannot change your own role or status.</p>' : ''}<p class="mp-error"${errors[name] ? '' : ' hidden'}>${esc(errors[name] || '')}</p></div>`;
  const body = `<section class="mp-panel"><form method="post" action="/admin/users/${u.id}" class="mp-form" novalidate>${hidden(ctx)}
<div class="mp-grid-2"><div>${fld('username', 'Username')}${fld('email', 'Email', 'email')}</div>
<div>${sel('role', 'Role', [['user', 'User'], ['admin', 'Administrator']])}${sel('active', 'Status', [['1', 'Active'], ['0', 'Disabled']])}${fld('password', 'New password', 'password', 'new-password', 'Leave empty to keep the current password.')}</div></div>
<div class="mp-form-actions"><button type="submit" class="mp-button mp-btn-inline">Save changes</button> <a class="mp-btn-sm" href="/admin/users">Cancel</a></div></form></section>`;
  return page(ctx, { title: 'Edit user', sub: `Account ${u.username}.`, active: 'admin-users', flash, body });
}

// ---------------------------------------------------------------------------------------------
// Servers: MC Host / Bot Host
// ---------------------------------------------------------------------------------------------
/** The three VPS meters: servers may use up to 90% of the machine, with no limit on how many servers that is. */
function capacityPanel(cap) {
  const row = (r) => `<div class="mp-resource${r.full ? ' is-full' : ''}"><div class="mp-resource-head"><span>${r.label}</span>
<span>${esc(r.allocatedText)} given to servers of ${esc(r.totalText)} · in use now ${Math.round(r.usedPct)}%</span></div>
<progress value="${Math.min(100, Math.round(r.pct))}" max="100" aria-label="${r.label} usage"></progress></div>`;
  return `<section class="mp-panel mp-capacity"><h2>VPS capacity</h2><p class="mp-muted">There is no limit on the number of servers. Together they may use up to ${cap.limitPct}% of the VPS RAM, CPU and disk.</p>${cap.resources.map(row).join('')}</section>`;
}

function serversPage({ ctx, kind, q = '', list, flash }) {
  const bot = kind === 'bot';
  const back = (bot ? '/admin/servers/bots' : '/admin/servers/mc') + (q ? `?q=${encodeURIComponent(q)}` : '');   // where the power buttons return to
  const link = (s) => `<a href="/dashboard/servers/${esc(s.identifier)}"><strong>${esc(s.name)}</strong></a><div class="mp-muted"><code>${esc(s.identifier)}</code></div>`;
  const rows = list.map((s) => `<tr><td>${link(s)}</td><td>${esc(s.owner_name || '—')}</td>
<td>${bot ? esc(servers.RUNTIMES[s.runtime]?.label || s.runtime || '—') : `${esc(s.software)} ${esc(s.version)}`}</td>
<td>${badge(s)}</td>
<td>${f.mb(s.ram_limit_mb)}</td><td>${f.cores ? esc(f.cores(s.cpu_limit_pct)) : s.cpu_limit_pct + '%'}</td><td>${f.mb(s.disk_limit_mb)}</td>
<td>${s.address ? `<code>${esc(s.address)}</code>` : '<span class="mp-muted">Not set</span>'}</td>
<td><div class="mp-row-actions">${actionButtons(s, { csrf: ctx.csrfToken, back, userId: ctx.user.id })}</div></td>
<td><a class="mp-icon-btn" href="/admin/servers/${esc(s.identifier)}/edit" title="Edit resources and IP" aria-label="Edit ${esc(s.name)}">${icon('edit', 14)}</a></td></tr>`);
  const head = ['Name', 'Owner', bot ? 'Runtime' : 'Software', 'Status', 'Memory', 'CPU', 'Disk', 'IP', 'Actions', 'Edit'];
  const cap = capacity.status(), full = cap.full, makeLabel = bot ? 'Create Bot' : 'Create MC Server';
  const create = full
    ? `<span class="mp-btn-primary is-disabled" aria-disabled="true" title="The VPS is full. Upgrade your VPS first.">${icon('plus', 14)} ${makeLabel}</span>`
    : `<a class="mp-btn-primary" href="/admin/servers/new?kind=${kind}">${icon('plus', 14)} ${makeLabel}</a>`;
  const note = bot
    ? 'Bots run on <strong>Python</strong> or <strong>Node.js</strong>. Both are already installed, so you only pick one when you create the bot.'
    : 'Minecraft servers run <strong>Paper</strong>.';
  const body = `${capacityPanel(cap)}<div class="mp-admin-bar">${searchBox(bot ? '/admin/servers/bots' : '/admin/servers/mc', q, bot ? 'Search bots…' : 'Search MC servers…')}${create}</div>
<section class="mp-panel"><p class="mp-muted mp-admin-note">${note}</p>${table(head, rows, q ? 'Nothing matches your search.' : bot ? 'No bots yet.' : 'No MC servers yet.')}<p class="mp-muted mp-count">${list.length} ${bot ? 'bot' : 'server'}${list.length === 1 ? '' : 's'}</p></section>`;
  return page(ctx, { title: bot ? 'Bot Host' : 'MC Host', sub: bot ? 'Python and Node.js bots.' : 'Minecraft servers running Paper.', active: bot ? 'admin-bots' : 'admin-mc', flash, body });
}

// ---------------------------------------------------------------------------------------------
// Settings: panel name + logo
// ---------------------------------------------------------------------------------------------
function settingsPage({ ctx, errors = {}, values = {}, flash }) {
  const name = values.name ?? settings.brand();
  const custom = settings.hasCustomLogo();
  const nameForm = `<section class="mp-panel mp-acct"><h2>Panel name</h2><p class="mp-muted">Shown in the top bar, on the login page and in the browser tab.</p>
<form method="post" action="/admin/settings/name" class="mp-form" novalidate>${hidden(ctx)}
<div class="mp-field${errors.name ? ' has-error' : ''}"><label for="s-name">Name</label><div class="mp-input-wrap"><input id="s-name" name="name" type="text" value="${esc(name)}" maxlength="${settings.NAME_MAX}" autocomplete="off"></div>
<p class="mp-error"${errors.name ? '' : ' hidden'}>${esc(errors.name || '')}</p></div>
<div class="mp-form-actions"><button type="submit" class="mp-button mp-btn-inline">Save name</button><button type="submit" name="reset" value="1" class="mp-btn-sm" formnovalidate>Use default</button></div></form></section>`;
  const logoForm = `<section class="mp-panel mp-acct"><h2>Logo</h2><p class="mp-muted">PNG, JPG, WebP or GIF, up to 1 MB. A square image looks best.</p>
<div class="mp-logo-edit"><img class="mp-logo-preview" src="${esc(settings.logoUrl())}" width="84" height="84" alt="Current logo" data-logo-preview>
<div class="mp-logo-controls"><input type="file" id="s-logo" accept="image/png,image/jpeg,image/webp,image/gif" data-logo-file aria-label="Choose a logo image">
<div class="mp-form-actions"><button type="button" class="mp-button mp-btn-inline" data-logo-upload data-csrf="${esc(ctx.csrfToken)}" disabled>${icon('arrowUp', 14)} Upload logo</button>
${custom ? `<form method="post" action="/admin/settings/logo/reset" class="mp-actions">${hidden(ctx)}<button type="submit" class="mp-btn-sm">Use default logo</button></form>` : ''}</div>
<p class="mp-hint" data-logo-status role="status"></p><noscript><p class="mp-hint">JavaScript is needed to upload a logo.</p></noscript></div></div></section>`;
  return page(ctx, { title: 'Settings', sub: 'Panel name and logo.', active: 'admin-settings', flash, body: `<div class="mp-grid-2">${nameForm}${logoForm}</div>`, scripts: ['/js/admin.js'] });
}

/** Reads a request body into a Buffer, refusing anything over `limit` bytes. */
function readBuffer(req, limit) {
  return new Promise((resolve, reject) => {
    if (Number(req.headers['content-length']) > limit) return reject(new HttpError(413, 'The logo must be 1 MB or smaller.'));
    const chunks = []; let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new HttpError(413, 'The logo must be 1 MB or smaller.')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

module.exports = function register(router) {
  const log = (ctx, userId, type, message) => activity.record({ userId, type, message, ip: ctx.ip });
  const writeLimit = rateLimit({ name: 'admin-write', windowMs: 60 * 1000, max: 60 });

  // ---- users
  const showUsers = (ctx) => ctx.html(200, usersPage({ ctx, q: String(ctx.query.q ?? '').slice(0, 100), list: users.listAll(ctx.query.q), flash: ctx.takeFlash() }));
  router.get('/admin', requireAdmin, showUsers);
  router.get('/admin/users', requireAdmin, showUsers);

  router.post('/admin/users', requireAdmin, rateLimit({ name: 'admin-user-create', windowMs: 60 * 60 * 1000, max: 60 }), async (ctx) => {
    const b = ctx.body;
    const values = { username: String(b.username ?? '').trim(), email: String(b.email ?? '').trim(), role: b.role === 'admin' ? 'admin' : 'user' };
    const errors = validate.collect({ username: validate.username(values.username), email: validate.email(values.email), password: validate.password(b.password) });
    const fail = (e) => ctx.html(422, usersPage({ ctx, list: users.listAll(), errors: e, values, addOpen: true, flash: { type: 'error', message: 'Please fix the highlighted fields.' } }));
    if (Object.keys(errors).length) return fail(errors);
    try {
      const u = users.create({ username: values.username, email: values.email, passwordHash: await hashPassword(String(b.password)), role: values.role });
      log(ctx, u.id, 'account.created', `Your account was created by ${ctx.user.username}`);
      ctx.flash('success', `User "${u.username}" created.`);
      return ctx.redirect('/admin/users');
    } catch (err) {
      const field = users.uniqueViolation(err);
      if (!field) throw err;
      return fail({ [field]: field === 'email' ? 'That email is already registered.' : 'That username is taken.' });
    }
  });

  // Role / status changes. Never on yourself, and the last active administrator is always kept.
  const target = (ctx) => {
    const u = users.findById(Number(ctx.params.id));
    if (!u) throw new HttpError(404, 'User not found.');
    if (u.id === ctx.user.id) throw new HttpError(400, 'You cannot change your own role or status.');
    return u;
  };
  router.post('/admin/users/:id/role', requireAdmin, writeLimit, (ctx) => {
    const u = target(ctx), role = ctx.body.role === 'admin' ? 'admin' : 'user';
    if (u.role === 'admin' && role === 'user' && u.is_active && users.countActiveAdmins() <= 1) throw new HttpError(400, 'There must be at least one active administrator.');
    users.setRole(u.id, role);
    log(ctx, u.id, 'account.role', `Your role was changed to ${role} by ${ctx.user.username}`);
    ctx.flash('success', `${u.username} is now ${role === 'admin' ? 'an administrator' : 'a regular user'}.`);
    return ctx.redirect('/admin/users');
  });
  router.post('/admin/users/:id/active', requireAdmin, writeLimit, (ctx) => {
    const u = target(ctx), active = ctx.body.active === '1';
    if (!active && u.role === 'admin' && users.countActiveAdmins() <= 1) throw new HttpError(400, 'There must be at least one active administrator.');
    users.setActive(u.id, active);
    ctx.flash('success', `${u.username} was ${active ? 'enabled' : 'disabled'}.`);
    return ctx.redirect('/admin/users');
  });

  // Edit user: username, email, role, status and (optionally) a new password.
  const editTarget = (ctx) => { const u = users.findById(Number(ctx.params.id)); if (!u) throw new HttpError(404, 'User not found.'); return u; };
  router.get('/admin/users/:id/edit', requireAdmin, (ctx) => ctx.html(200, editUserPage({ ctx, u: editTarget(ctx), flash: ctx.takeFlash() })));
  router.post('/admin/users/:id', requireAdmin, writeLimit, async (ctx) => {
    const u = editTarget(ctx), b = ctx.body, me = u.id === ctx.user.id;
    const values = { username: String(b.username ?? '').trim(), email: String(b.email ?? '').trim(),
      role: me ? u.role : (b.role === 'admin' ? 'admin' : 'user'), active: me ? (u.is_active ? '1' : '0') : (b.active === '0' ? '0' : '1') };
    const checks = { username: validate.username(values.username), email: validate.email(values.email) };
    if (b.password) checks.password = validate.password(b.password);
    const errors = validate.collect(checks);
    const fail = (e) => ctx.html(422, editUserPage({ ctx, u, errors: e, values, flash: { type: 'error', message: 'Please fix the highlighted fields.' } }));
    if (Object.keys(errors).length) return fail(errors);
    const active = values.active === '1', demoting = u.role === 'admin' && (values.role !== 'admin' || !active) && u.is_active;
    if (demoting && users.countActiveAdmins() <= 1) return fail({ role: 'There must be at least one active administrator.' });
    try {
      users.update(u.id, { username: values.username, email: values.email, role: values.role });
      if (!me) users.setActive(u.id, active);
      if (b.password) users.setPassword(u.id, await hashPassword(String(b.password)));
    } catch (err) {
      const field = users.uniqueViolation(err);
      if (!field) throw err;
      return fail({ [field]: field === 'email' ? 'That email is already registered.' : 'That username is taken.' });
    }
    if (values.role !== u.role) log(ctx, u.id, 'account.role', `Your role was changed to ${values.role} by ${ctx.user.username}`);
    ctx.flash('success', `User "${values.username}" updated.`);
    return ctx.redirect('/admin/users');
  });

  // ---- servers nest
  router.get('/admin/servers', requireAdmin, (ctx) => ctx.redirect('/admin/servers/mc'));
  for (const [path, kind] of [['/admin/servers/mc', 'mc'], ['/admin/servers/bots', 'bot']]) {
    router.get(path, requireAdmin, (ctx) => ctx.html(200, serversPage({ ctx, kind, q: String(ctx.query.q ?? '').slice(0, 100), list: servers.listByKind(kind, ctx.query.q), flash: ctx.takeFlash() })));
  }

  // ---- settings
  router.get('/admin/settings', requireAdmin, (ctx) => ctx.html(200, settingsPage({ ctx, flash: ctx.takeFlash() })));

  router.post('/admin/settings/name', requireAdmin, writeLimit, (ctx) => {
    if (ctx.body.reset) { settings.resetBrand(); ctx.flash('success', 'Panel name reset to the default.'); return ctx.redirect('/admin/settings'); }
    const name = String(ctx.body.name ?? '').trim(), err = settings.validateName(name);
    if (err) return ctx.html(422, settingsPage({ ctx, errors: { name: err }, values: { name }, flash: { type: 'error', message: 'Please fix the highlighted field.' } }));
    settings.setBrand(name);
    ctx.flash('success', 'Panel name saved.');
    return ctx.redirect('/admin/settings');
  });

  router.post('/admin/settings/logo', requireAdmin, writeLimit, async (ctx) => {
    if (!String(ctx.req.headers['content-type'] || '').startsWith('application/octet-stream')) return ctx.json(415, { error: 'Send the image as raw bytes.' });
    const buf = await readBuffer(ctx.req, settings.LOGO_MAX_BYTES);
    const err = settings.setLogo(buf);
    if (err) return ctx.json(422, { error: err });
    ctx.flash('success', 'Logo updated.');
    return ctx.json(200, { ok: true, url: settings.logoUrl() });
  });
  router.post('/admin/settings/logo/reset', requireAdmin, writeLimit, (ctx) => {
    settings.resetLogo();
    ctx.flash('success', 'Logo reset to the default.');
    return ctx.redirect('/admin/settings');
  });

  // The uploaded logo. Public on purpose: the sign-in page shows it before anybody is logged in.
  router.get('/brand/logo', (ctx) => {
    const logo = settings.getLogo();
    if (!logo) return ctx.redirect('/img/logo.png', 302);
    ctx.res.setHeader('Cache-Control', 'public, max-age=86400');
    ctx.res.writeHead(200, { 'Content-Type': logo.mime, 'Content-Length': logo.data.length });
    return ctx.res.end(ctx.req.method === 'HEAD' ? undefined : logo.data);
  });
};
