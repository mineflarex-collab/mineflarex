'use strict';
// Server management list + server details page. Markup only (.mp-* classes); no inline styles/scripts (CSP).
const { esc } = require('../views/layout');
const { icon } = require('../views/icons');
const f = require('./format');
const servers = require('./services/servers');
const access = require('./services/access');
const { shell, badge, meter, empty, actionButtons, activityList } = require('./views');

const BASE = '/dashboard/servers';
const PERM_LABEL = { 'control.start': 'Start', 'control.stop': 'Stop', 'control.restart': 'Restart', 'control.reinstall': 'Reinstall', 'console.view': 'View console', 'console.send': 'Send commands' };
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

/** Query string for a filter state (defaults are omitted so URLs stay short). */
function query(filters, over = {}) {
  const x = { ...filters, ...over }, p = new URLSearchParams();
  if (x.q) p.set('q', x.q);
  if (x.status) p.set('status', x.status);
  if (x.node) p.set('node', x.node);
  if (x.software) p.set('software', x.software);
  if (x.sort !== 'name' || x.dir !== 'asc') { p.set('sort', x.sort); p.set('dir', x.dir); }
  if (x.page > 1) p.set('page', String(x.page));
  const s = p.toString();
  return s ? `?${s}` : '';
}
// Changing a filter or sort returns to page 1; pass { page } explicitly to move between pages.
const href = (filters, over = {}) => BASE + query(filters, { page: 1, ...over });
const isFiltered = (x) => !!(x.q || x.status || x.node || x.software);

const nodeBadge = (status) => `<span class="mp-badge mp-badge-${status === 'online' ? 'online' : status === 'offline' ? 'crashed' : 'maintenance'}">${esc(status)}</span>`;

function sortHeader(label, key, filters) {
  const active = filters.sort === key;
  const dir = active && filters.dir === 'asc' ? 'desc' : 'asc';
  const aria = active ? ` aria-sort="${filters.dir === 'asc' ? 'ascending' : 'descending'}"` : '';
  return `<th scope="col"${aria}><a class="mp-sort${active ? ' is-active' : ''}" href="${esc(href(filters, { sort: key, dir }))}">${label}${active ? (filters.dir === 'asc' ? ' &#9650;' : ' &#9660;') : ''}</a></th>`;
}

function statusChips(counts, filters) {
  const chips = [['', 'All', counts.all], ...servers.STATUSES.map((s) => [s, cap(s), counts[s]])];
  return `<nav class="mp-chips" aria-label="Filter by status">${chips.map(([val, label, n]) =>
    `<a class="mp-chip${filters.status === val ? ' is-active' : ''}" href="${esc(href(filters, { status: val }))}"${filters.status === val ? ' aria-current="true"' : ''}>${label} <span>${n}</span></a>`).join('')}</nav>`;
}

function filterForm(filters, facets) {
  const opt = (value, label, current) => `<option value="${esc(value)}"${String(current) === String(value) ? ' selected' : ''}>${esc(label)}</option>`;
  const nodes = [opt('', 'All nodes', filters.node), ...(facets.hasUnassigned || filters.node === 'none' ? [opt('none', 'Unassigned', filters.node)] : []),
    ...facets.nodes.map((n) => opt(n.id, n.name, filters.node))].join('');
  const software = [opt('', 'All software', filters.software), ...facets.software.map((x) => opt(x, x, filters.software))].join('');
  return `<form method="get" action="${BASE}" class="mp-filters" role="search" data-autosubmit>
<label class="mp-sr" for="srv-q">Search servers</label>
<input id="srv-q" class="mp-search" type="search" name="q" value="${esc(filters.q)}" placeholder="Search name, identifier, address, node&hellip;" maxlength="100" autocomplete="off">
<label class="mp-sr" for="srv-node">Node</label><select id="srv-node" name="node">${nodes}</select>
<label class="mp-sr" for="srv-sw">Software</label><select id="srv-sw" name="software">${software}</select>
${filters.status ? `<input type="hidden" name="status" value="${esc(filters.status)}">` : ''}
${filters.sort !== 'name' || filters.dir !== 'asc' ? `<input type="hidden" name="sort" value="${esc(filters.sort)}"><input type="hidden" name="dir" value="${esc(filters.dir)}">` : ''}
<button type="submit" class="mp-btn-sm">Search</button>
${isFiltered(filters) ? `<a class="mp-btn-sm mp-btn-link" href="${BASE}">Clear</a>` : ''}
</form>`;
}

function resourceCell(label, allocated, used, limit, usedText, live) {
  return `<strong>${esc(allocated)}</strong>${live ? `${meter(used, limit, label)}<div class="mp-muted">${esc(usedText)} in use</div>` : '<div class="mp-muted">Not running</div>'}`;
}

function row(s, ctx, back) {
  const live = s.status === 'online', d = f.describeServer(s, { admin: ctx.user.role === 'admin' });
  const shared = s.owner_id !== ctx.user.id;
  const nodeCell = s.node_id
    ? `<strong>${esc(s.node_name)}</strong>${s.node_location ? `<div class="mp-muted">${esc(s.node_location)}</div>` : ''}${s.node_status !== 'online' ? nodeBadge(s.node_status) : ''}`
    : '<span class="mp-muted">Unassigned</span>';
  return `<tr>
<td><a href="${BASE}/${esc(s.identifier)}"><strong>${esc(s.name)}</strong></a>${shared ? ' <span class="mp-badge">shared</span>' : ''}<div class="mp-muted">${esc(s.software)} ${esc(s.version)}${s.address ? ` &middot; ${esc(s.address)}` : ''}</div></td>
<td><code>${esc(s.identifier)}</code> <button type="button" class="mp-btn-sm" data-copy="${esc(s.identifier)}">Copy</button></td>
<td>${badge(s)}</td>
<td>${resourceCell('RAM', d.ram.allocated, s.ram_used_mb, s.ram_limit_mb, f.mb(s.ram_used_mb), live)}</td>
<td>${resourceCell('CPU', d.cpu.allocated, s.cpu_used_pct, s.cpu_limit_pct, f.cores(s.cpu_used_pct), live)}</td>
<td><strong>${esc(d.disk.allocated)}</strong>${meter(s.disk_used_mb, s.disk_limit_mb, 'Disk')}<div class="mp-muted">${esc(f.mb(s.disk_used_mb))} used</div></td>
<td>${nodeCell}</td>
<td><div class="mp-row-actions">${actionButtons(s, { csrf: ctx.csrfToken, back, userId: ctx.user.id })}<a class="mp-btn-sm mp-btn-link" href="${BASE}/${esc(s.identifier)}">Details</a></div></td></tr>`;
}

function pager(result) {
  if (result.pages <= 1) return '';
  const { filters: x, page, pages } = result;
  return `<nav class="mp-pager" aria-label="Pagination">${page > 1 ? `<a href="${esc(href(x, { page: page - 1 }))}">Previous</a>` : ''}<span>Page ${page} of ${pages}</span>${page < pages ? `<a href="${esc(href(x, { page: page + 1 }))}">Next</a>` : ''}</nav>`;
}

function list({ ctx, flash, result, counts, facets }) {
  const x = result.filters, back = BASE + query(x);
  let table;
  if (!result.total) {
    table = isFiltered(x)
      ? `<p class="mp-empty">No servers match your search or filters. <a href="${BASE}">Clear filters</a></p>`
      : empty('No servers are assigned to your account yet.');
  } else {
    const head = `<tr>${sortHeader('Server', 'name', x)}<th scope="col">Identifier</th>${sortHeader('Status', 'status', x)}${sortHeader('RAM', 'ram', x)}${sortHeader('CPU', 'cpu', x)}${sortHeader('Disk', 'disk', x)}${sortHeader('Node', 'node', x)}<th scope="col">Actions</th></tr>`;
    table = `<div class="mp-table-wrap"><table class="mp-table mp-servers"><thead>${head}</thead><tbody>\n${result.items.map((s) => row(s, ctx, back)).join('\n')}</tbody></table></div>`;
  }
  const from = result.total ? (result.page - 1) * result.perPage + 1 : 0, to = Math.min(result.total, result.page * result.perPage);
  const summary = result.total ? `<p class="mp-muted mp-count">Showing ${from}&ndash;${to} of ${result.total} server${result.total === 1 ? '' : 's'}</p>` : '';
  const body = `<section class="mp-panel">${statusChips(counts, x)}${filterForm(x, facets)}${summary}${table}${pager(result)}</section>`;
  return shell({ title: 'Servers', active: 'servers', user: ctx.user, csrf: ctx.csrfToken, flash, body });
}

const kv = (rows) => `<dl class="mp-dl">${rows.map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}</dl>`;
const when = (ts) => (ts ? `<time datetime="${f.iso(ts)}" title="${f.iso(ts)}">${f.relative(ts)}</time>` : 'Never');

function resourceRow(label, key, r) {
  return `<div class="mp-resource"><div class="mp-resource-head"><span>${label} <span class="mp-muted">(allocated ${esc(r.allocated)})</span></span><span data-live="${key}.text">${esc(r.text)}</span></div>
<progress value="${r.used}" max="${r.limit || 1}" data-live-progress="${key}" aria-label="${label}"></progress></div>`;
}

function detail({ ctx, flash, server: s, access: acc, commands, activityItems }) {
  const admin = ctx.user.role === 'admin', d = f.describeServer(s, { admin }), back = `${BASE}/${s.identifier}`;
  const pending = commands.find((c) => c.status === 'pending');
  const acts = servers.allowedActionsFor(acc, s);

  const overview = kv([
    ['Name', esc(s.name)],
    ['Number', `<code>#${servers.numberOf(s)}</code>`],
    ['Identifier', `<code>${esc(s.identifier)}</code> <button type="button" class="mp-btn-sm" data-copy="${esc(s.identifier)}">Copy</button>`],
    ['Status', `${badge(s)}${pending ? ` <span class="mp-muted">${esc(pending.command)} ${s.task ? 'in progress' : 'waiting for the server runtime'}</span>` : ''}`],
    ['Address', s.address ? `<code>${esc(s.address)}</code> <button type="button" class="mp-btn-sm" data-copy="${esc(s.address)}">Copy</button>` : '<span class="mp-muted">Not set</span>'],
    ...(s.kind === 'bot'
      ? [['Type', 'Bot Host'], ['Runtime', esc(servers.RUNTIMES[s.runtime]?.label || s.runtime || '—')], ['Start command', `<code>${esc(s.start_command || '—')}</code>`]]
      : [['Type', 'MC Host'], ['Software', `${esc(s.software)} ${esc(s.version)}`], ['Players', `<span data-live="players">${s.players_online} / ${s.players_max}</span>`]]),
    ['Uptime', s.status === 'online' ? `<span data-live="uptime">${esc(f.duration(s.started_at))}</span>` : '<span class="mp-muted">Not running</span>'],
    ['Your access', acc.role === 'owner' ? 'Owner' : acc.permissions.size ? `Shared with you: ${[...acc.permissions].map((p) => PERM_LABEL[p] || p).join(', ')}` : 'Shared with you: view only'],
    ['Created', f.date(s.created_at)],
    ['Last report', when(s.metrics_at)]
  ]);

  const resources = `${resourceRow('Memory', 'ram', d.ram)}${resourceRow('CPU', 'cpu', d.cpu)}${resourceRow('Disk', 'disk', d.disk)}
<p class="mp-muted">Allocation is what your server is limited to; usage is reported by the server runtime.</p>`;

  const node = s.node_id
    ? kv([['Name', esc(s.node_name)], ['Location', s.node_location ? esc(s.node_location) : '<span class="mp-muted">Not set</span>'], ['Status', nodeBadge(s.node_status)],
      ...(admin ? [['Address', `<code>${esc(s.node_fqdn)}</code>`]] : [])])
    : '<p class="mp-empty">This server is not assigned to a node yet.</p>';

  const actions = s.task ? '<p class="mp-muted" data-live-note>This server is being reinstalled. The buttons come back when it has finished.</p>'
    : acts.length ? actionButtons(s, { csrf: ctx.csrfToken, back, userId: ctx.user.id })
      : `<p class="mp-muted">${acc.role !== 'owner' && !acc.permissions.size ? 'You have view-only access to this server.' : `No actions are available while the server is ${esc(s.status)}.`}</p>`;

  const cmdRows = commands.length
    ? `<div class="mp-table-wrap"><table class="mp-table"><thead><tr><th>Command</th><th>Status</th><th>Requested</th><th>Details</th></tr></thead><tbody>${commands.map((c) =>
      `<tr><td>${esc(cap(c.command))}</td><td><span class="mp-badge mp-badge-${c.status === 'done' ? 'online' : c.status === 'failed' ? 'crashed' : 'starting'}">${esc(c.status)}</span></td><td>${when(c.created_at)}</td><td>${c.error ? esc(c.error) : '<span class="mp-muted">—</span>'}</td></tr>`).join('')}</tbody></table></div>`
    : empty('No commands have been sent to this server yet.');

  const body = `<div data-server-live="${esc(s.identifier)}">
<div class="mp-grid">
<section class="mp-panel"><h2>Overview</h2>${overview}</section>
<section class="mp-panel"><h2>Resources</h2>${resources}</section>
<section class="mp-panel"><h2>Node</h2>${node}</section>
<section class="mp-panel"><h2>Actions</h2>${actions}${acc.has('console.view') ? `<p><a class="mp-button mp-button-secondary mp-btn-inline" href="${BASE}/${esc(s.identifier)}/console">Open console</a></p>` : ''}</section>
</div>
<section class="mp-panel"><h2>Command history</h2>${cmdRows}</section>
<section class="mp-panel"><h2>Recent activity</h2>${activityList(activityItems)}</section>
</div>`;
  return shell({ title: s.name, sub: s.kind === 'bot' ? `Bot · ${servers.RUNTIMES[s.runtime]?.label || s.runtime}` : `${s.software} ${s.version}`, active: 'details', server: { identifier: s.identifier, kind: s.kind, canConsole: acc.has('console.view'), canFiles: acc.has('files.view') }, user: ctx.user, csrf: ctx.csrfToken, flash, body });
}

const CONFIRM_COPY = {
  stop: { title: 'Stop server?', verb: 'Stop', text: 'The server will shut down and every connected player will be disconnected.' },
  restart: { title: 'Restart server?', verb: 'Restart', text: 'The server will shut down and start again. Every connected player will be disconnected while it restarts.' },
  reinstall: { title: 'Reinstall server?', verb: 'Reinstall', text: 'The server software (server.jar) is downloaded again and replaced with a fresh copy. A running server is stopped first, and it stays stopped until you press Start. Your worlds, plugins and settings are kept.' }
};

/** "Are you sure?" page for stop/restart. The POST it submits carries confirm=1, which the service requires. */
function confirm({ ctx, server: s, action, back }) {
  const c = CONFIRM_COPY[action];
  const body = `<section class="mp-panel mp-confirm"><h2>${c.title}</h2>
<p><strong>${esc(s.name)}</strong> <code>${esc(s.identifier)}</code></p>
<p>${c.text}</p>
${action === 'reinstall' ? `<p class="mp-muted">Software: ${esc(cap(s.software))} ${esc(s.version)}${String(s.version).toLowerCase() === 'latest' ? ' (the newest release will be downloaded)' : ''}</p>` : ''}
<p class="mp-muted">${s.players_online ? `${s.players_online} player${s.players_online === 1 ? ' is' : 's are'} online right now.` : 'No players are online right now.'}</p>
<form method="post" action="/dashboard/servers/action" class="mp-confirm-actions">
<input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}"><input type="hidden" name="server_id" value="${s.id}">
<input type="hidden" name="action" value="${action}"><input type="hidden" name="confirm" value="1"><input type="hidden" name="back" value="${esc(back)}">
<button type="submit" class="mp-button mp-button-danger">Yes, ${action} server</button>
<a class="mp-btn-sm mp-btn-link" href="${esc(back)}">Cancel</a></form></section>`;
  return shell({ title: c.title, active: 'servers', user: ctx.user, csrf: ctx.csrfToken, body });
}

const ONLINE = new Set(['online', 'starting']);
const ACT_ICON = { start: icon('play', 12), stop: icon('stop', 12), restart: icon('restart', 13), reinstall: icon('download', 13) };
const gib = (mbv) => `${+(mbv / 1024).toFixed(mbv % 1024 ? 1 : 0)} GiB`;

/** Start / Restart / Stop (+ Reinstall for Minecraft servers the panel can reinstall), as in the console header; actions that are not allowed right now are shown disabled. */
function powerBar(s, ctx, back) {
  const acc = access.forUser(ctx.user.id, s), allowed = new Set(servers.allowedActionsFor(acc, s));
  const shown = ['start', 'restart', 'stop', ...(acc.can('reinstall') && !servers.reinstallProblem(s) ? ['reinstall'] : [])];
  return shown.map((a) => {
    const label = `${ACT_ICON[a]} <span>${servers.TRANSITIONS[a].label}</span>`;
    if (!allowed.has(a)) return `<span class="mp-btn-sm mp-btn-${a} is-disabled" aria-disabled="true">${label}</span>`;
    if (servers.CONFIRM.has(a)) return `<a class="mp-btn-sm mp-btn-${a}" href="${BASE}/${esc(s.identifier)}/confirm/${a}?back=${encodeURIComponent(back)}">${label}</a>`;
    return `<form method="post" action="/dashboard/servers/action" class="mp-inline"><input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}"><input type="hidden" name="server_id" value="${s.id}"><input type="hidden" name="back" value="${esc(back)}"><button type="submit" name="action" value="${a}" class="mp-btn-sm mp-btn-${a}">${label}</button></form>`;
  }).join('');
}

/** Live console page. Everything dynamic happens in public/js/console.js over the WebSocket. */
function consolePage({ ctx, server: s, access: acc }) {
  const canSend = acc.has('console.send'), live = s.status === 'online', admin = ctx.user.role === 'admin';
  const d = f.describeServer(s, { admin }), me = `${BASE}/${s.identifier}`;
  const enabled = canSend && ONLINE.has(s.status);
  // One resource card: used / limit, percentage, bar and two detail lines. data-live-online = only updated while the server runs (offline shows "—").
  const on = ' data-live-online';
  const res = (ico, label, key, r, { liveOnly = true, left, right }) => {
    const show = live || !liveOnly;
    return `<div class="mp-res" data-res="${key}"><div class="mp-res-head"><span>${icon(ico, 14)} ${label}</span><span class="mp-res-pct" data-live="${key}.pctText"${liveOnly ? on : ''}>${show ? esc(r.pctText) : '—'}</span></div>
<div class="mp-res-val" data-live="${key}.text"${liveOnly ? on : ''}>${show ? esc(r.text) : '—'}</div><progress value="${show ? r.used : 0}" max="${r.limit || 1}" data-live-progress="${key}"${liveOnly ? on : ''} aria-label="${label}"></progress>
<div class="mp-res-sub"><span>${left}</span><span>${right(show)}</span></div></div>`;
  };
  const sub = (key, field, show, liveOnly = true) => `<b data-live="${key}.${field}"${liveOnly ? on : ''}>${show ? esc(d[key][field]) : '—'}</b>`;
  const row = (k, v) => `<div class="mp-kv-row"><span>${k}</span><span>${v}</span></div>`;
  const tile = (ico, label, value, hint) => `<div class="mp-mini">${icon(ico, 15)}<span>${label}</span>${value}<small>${hint}</small></div>`;
  const netTile = (ico, label, dir) => tile(ico, label, `<b data-live="net.${dir}.total"${on}>${live && d.net.available ? esc(d.net[dir].total) : '—'}</b>`,
    live ? `Now: <span data-live="net.${dir}.rate"${on}>${d.net.available ? esc(d.net[dir].rate) : '—'}</span>` : 'Server is offline');
  const port = servers.portOf(s.address);
  // Force controls under the console: admins get Suspend + the three force actions, users only the force actions their permissions allow.
  const forceBtns = ['stop', 'start', 'restart'].filter((a) => acc.can(a)).map((a) => `<form method="post" action="${me}/force/${a}" class="mp-inline"><input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}"><button type="submit" class="mp-btn-sm mp-btn-force">Force ${a}</button></form>`).join('');
  const suspendBtn = admin ? `<form method="post" action="/admin/servers/${esc(s.identifier)}/${s.suspended ? 'unsuspend' : 'suspend'}" class="mp-inline"><input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}"><input type="hidden" name="back" value="${me}/console"><button type="submit" class="mp-btn-sm">${s.suspended ? 'Unsuspend server' : 'Suspend server'}</button></form>` : '';
  const force = forceBtns || suspendBtn ? `<section class="mp-panel mp-force-card"><div class="mp-panel-head"><h2>Force</h2></div>
<p class="mp-muted">Force stop / start / restart kill the process immediately (the world is not saved) and also clear a stuck process, whatever status is shown. Use them when the normal buttons do not work.${admin ? ' Suspend stops the server and blocks it from starting.' : ''}</p>
<div class="mp-actions mp-force">${suspendBtn}${forceBtns}</div></section>
` : '';
  const hero = `<section class="mp-banner">
<img class="mp-srv-icon mp-srv-icon-lg" src="/img/server-icon.svg" width="52" height="52" alt="">
<div class="mp-banner-id"><small>Minecraft</small><h1>${esc(s.name)}</h1><span class="mp-banner-meta"><span>Minecraft</span><span>${esc(cap(s.software))} ${esc(s.version)}</span>${icon('globe', 13)}<span class=\"mp-uptime\" title=\"Uptime\">${icon('activity', 13)} Uptime: ${live && s.started_at ? `<b data-uptime-since=\"${Number(s.started_at)}\">${esc(f.clock(s.started_at))}</b>` : '<b>Offline</b>'}</span></span></div>
<div class="mp-banner-right"><span class="mp-console-conn" data-console-conn data-state="connecting" role="status">Connecting&hellip;</span>
<div class="mp-banner-actions">${powerBar(s, ctx, `${me}/console`)}</div></div>
</section>`;
  // Order (top to bottom, also on phones): Console -> Resources -> picture -> Network (Players, received, sent) -> Connection.
  // On wide screens Resources + picture sit beside the console, Network + Connection below it (see console.css).
  const body = `<div class="mp-console-layout mp-cl" data-server-live="${esc(s.identifier)}">
<section class="mp-panel mp-console" data-console="${esc(s.identifier)}" data-can-send="${canSend ? '1' : '0'}" data-status="${esc(s.status)}" data-conn="connecting">
<div class="mp-console-bar">
<span class="mp-console-title">${icon('terminal', 16)} Console</span>
<div class="mp-console-tools">
<button type="button" class="mp-auto" data-console-autoscroll aria-pressed="true">Auto scroll</button>
<button type="button" class="mp-icon-btn" data-console-clear title="Clears your view only; the server's log is not touched" aria-label="Clear console">${icon('trash', 15)}</button>
<button type="button" class="mp-icon-btn" data-console-download aria-label="Download console output">${icon('download', 15)}</button>
</div></div>
<div class="mp-console-wrap">
<div class="mp-console-out" data-console-out role="log" aria-label="Server console output" aria-live="off" tabindex="0"></div>
<div class="mp-spinner" aria-hidden="true"></div>
<button type="button" class="mp-console-jump" data-console-jump hidden>&darr; New output</button>
</div>
<form class="mp-console-form" data-console-form autocomplete="off">
<label class="mp-sr" for="console-cmd">Console command</label>
<span class="mp-console-prompt" aria-hidden="true">&rsaquo;</span>
<input id="console-cmd" class="mp-console-input" data-console-input type="text" maxlength="1000" spellcheck="false" autocapitalize="off" autocorrect="off" autocomplete="off"
 placeholder="${canSend ? (ONLINE.has(s.status) ? 'Type a command and press Enter (↑ ↓ for history)' : 'Start the server to send commands') : 'You can watch the console but not send commands'}"${enabled ? '' : ' disabled'}>
<button type="submit" class="mp-send" data-console-send${enabled ? '' : ' disabled'}>Send ${icon('arrowUp', 13)}</button>
</form>
<p class="mp-muted mp-console-note" data-console-note></p>
<noscript><p class="mp-empty">The live console needs JavaScript.</p></noscript>
</section>
${force}
<div class="mp-cl-top">
<section class="mp-panel mp-side-card mp-resources" aria-labelledby="res-title"><div class="mp-panel-head"><h2 id="res-title">Resources</h2><span class="mp-muted mp-live-tag">${live ? 'Live' : 'Waiting'}</span></div>
${res('cpu', 'CPU', 'cpu', d.cpu, { left: `Limit <b>${esc(d.cpu.limitText)}</b> (${s.cpu_limit_pct}%)`, right: (show) => `Using ${sub('cpu', 'usedText', show)}` })}
${res('ram', 'Memory', 'ram', d.ram, { left: `Limit <b>${esc(gib(s.ram_limit_mb))}</b>`, right: (show) => `${sub('ram', 'freeText', show)} free` })}
${res('hdd', 'Storage', 'disk', d.disk, { liveOnly: false, left: `Limit <b>${esc(gib(s.disk_limit_mb))}</b>`, right: (show) => `${sub('disk', 'freeText', show, false)} free` })}
</section>
<div class="mp-art"><img src="/img/herobrine-art.png" alt="" width="1200" height="778"></div>
</div>

<section class="mp-panel mp-network" aria-labelledby="net-title"><div class="mp-panel-head"><h2 id="net-title">Network</h2><span class="mp-muted mp-live-tag">${live ? 'Live' : 'Waiting'}</span></div>
<div class="mp-mini-grid">
${tile('users', 'Players', `<b data-live="players"${on}>${live ? `${s.players_online} / ${s.players_max}` : '—'}</b>`, live ? 'Online now' : 'Status query unavailable')}
${netTile('arrowDown', 'Network received', 'rx')}
${netTile('arrowUp', 'Network sent', 'tx')}
</div>
<p class="mp-muted mp-net-note" data-live="net.note">${esc(d.net.note)}</p>
</section>

<section class="mp-panel mp-side-card mp-connection" aria-labelledby="conn-title"><h2 id="conn-title">Connection</h2>
<div class="mp-kv-addr"><span class="mp-muted">Server address</span><div>${s.address ? `<code>${esc(s.address)}</code><button type="button" class="mp-icon-btn" data-copy="${esc(s.address)}" aria-label="Copy address">${icon('copy', 14)}</button>` : '<span class="mp-muted">Not set</span>'}</div></div>
<div class="mp-kv">${row('Status', esc(cap(s.status)))}${row('Port', port ? `<code>${port}</code>` : '—')}${row('Uptime', live ? `<span data-live="uptime">${esc(f.duration(s.started_at))}</span>` : '—')}${row('Node', s.node_id ? esc(s.node_name) : 'Unassigned')}${row('Runtime', `Minecraft ${esc(s.version)}`)}${row('Software', esc(cap(s.software)))}${row('Max players', esc(String(s.players_max)))}${row('Created', esc(f.date(s.created_at)))}</div></section>
</div>`;
  return shell({ title: `${s.name} console`, active: 'console', server: { identifier: s.identifier, kind: s.kind, canConsole: true, canFiles: acc.has('files.view') }, user: ctx.user, csrf: ctx.csrfToken, body, hero, styles: ['/css/console.css'], scripts: ['/js/console.js'] });
}

module.exports = { list, detail, confirm, consolePage };
