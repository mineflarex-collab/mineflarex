'use strict';
// Dashboard-owned schema. Tracked in its own table so the auth migrations (src/db.js) stay untouched.
// Append new migrations to the end; never edit old ones.
const crypto = require('node:crypto');
const db = require('../db');

db.exec('CREATE TABLE IF NOT EXISTS dashboard_migrations (id INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL)');

const MIGRATIONS = [`
  CREATE TABLE servers (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name           TEXT NOT NULL COLLATE NOCASE,
    software       TEXT NOT NULL DEFAULT 'paper',
    version        TEXT NOT NULL DEFAULT 'latest',
    address        TEXT,                       -- public host:port shown to the owner
    status         TEXT NOT NULL DEFAULT 'offline'
                   CHECK (status IN ('offline','starting','online','stopping','crashed')),
    ram_limit_mb   INTEGER NOT NULL DEFAULT 2048,
    cpu_limit_pct  INTEGER NOT NULL DEFAULT 100,   -- 100 = one core
    disk_limit_mb  INTEGER NOT NULL DEFAULT 10240,
    ram_used_mb    INTEGER NOT NULL DEFAULT 0,
    cpu_used_pct   REAL    NOT NULL DEFAULT 0,
    disk_used_mb   INTEGER NOT NULL DEFAULT 0,
    players_online INTEGER NOT NULL DEFAULT 0,
    players_max    INTEGER NOT NULL DEFAULT 20,
    started_at     INTEGER,
    metrics_at     INTEGER,                    -- last time the runtime reported
    created_at     INTEGER NOT NULL,
    updated_at     INTEGER NOT NULL,
    UNIQUE (owner_id, name)
  );
  CREATE INDEX idx_servers_owner ON servers(owner_id);

  CREATE TABLE server_commands (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    server_id    INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
    user_id      INTEGER REFERENCES users(id) ON DELETE SET NULL,
    command      TEXT NOT NULL CHECK (command IN ('start','stop','restart')),
    status       TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','done','failed')),
    error        TEXT,
    created_at   INTEGER NOT NULL,
    completed_at INTEGER
  );
  CREATE INDEX idx_commands_server ON server_commands(server_id, status);

  CREATE TABLE activity_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    server_id   INTEGER REFERENCES servers(id) ON DELETE SET NULL,
    server_name TEXT,                          -- snapshot, survives server deletion
    type        TEXT NOT NULL,
    message     TEXT NOT NULL,
    ip          TEXT,
    created_at  INTEGER NOT NULL
  );
  CREATE INDEX idx_activity_user ON activity_log(user_id, created_at DESC);
`,

// 2: nodes + server identifiers (server management list)
(conn) => {
  conn.exec(`
    CREATE TABLE nodes (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      name          TEXT NOT NULL UNIQUE COLLATE NOCASE,
      location      TEXT,
      fqdn          TEXT NOT NULL,               -- hostname / IP of the machine (shown to admins only)
      status        TEXT NOT NULL DEFAULT 'online' CHECK (status IN ('online','offline','maintenance')),
      ram_total_mb  INTEGER NOT NULL DEFAULT 0,
      cpu_total_pct INTEGER NOT NULL DEFAULT 0,
      disk_total_mb INTEGER NOT NULL DEFAULT 0,
      created_at    INTEGER NOT NULL,
      updated_at    INTEGER NOT NULL
    );
    -- SQLite cannot add NOT NULL columns without a default, so uniqueness is enforced by the index
    -- and non-null by services/servers.js (existing rows are backfilled below).
    ALTER TABLE servers ADD COLUMN identifier TEXT;
    ALTER TABLE servers ADD COLUMN node_id INTEGER REFERENCES nodes(id) ON DELETE SET NULL;
  `);
  const used = new Set(), set = conn.prepare('UPDATE servers SET identifier = ? WHERE id = ?');
  for (const { id } of conn.prepare('SELECT id FROM servers').all()) {
    let ident; do { ident = crypto.randomBytes(4).toString('hex'); } while (used.has(ident));
    used.add(ident); set.run(ident, id);
  }
  conn.exec(`
    CREATE UNIQUE INDEX idx_servers_identifier ON servers(identifier);
    CREATE INDEX idx_servers_node ON servers(node_id);
  `);
},

// 3: per-server access grants (collaborators) + the command the runtime launches
`
  ALTER TABLE servers ADD COLUMN start_command TEXT;      -- NULL = runtime default (see src/runtime)
  CREATE TABLE server_access (
    server_id   INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    can_start   INTEGER NOT NULL DEFAULT 0,
    can_stop    INTEGER NOT NULL DEFAULT 0,
    can_restart INTEGER NOT NULL DEFAULT 0,
    created_at  INTEGER NOT NULL,
    PRIMARY KEY (server_id, user_id)
  );                                                       -- no permission flags = view-only access
  CREATE INDEX idx_access_user ON server_access(user_id);
`,

// 4: live console (log lines the runtime captures, commands waiting to be written to the process, per-user command history)
`
  ALTER TABLE server_access ADD COLUMN can_console INTEGER NOT NULL DEFAULT 0;   -- may watch the console
  ALTER TABLE server_access ADD COLUMN can_command INTEGER NOT NULL DEFAULT 0;   -- may type commands into it

  CREATE TABLE console_lines (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,       -- monotonically increasing: clients resume from the last id they saw
    server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
    ts        INTEGER NOT NULL,
    stream    TEXT NOT NULL,                           -- out | err | in (a command someone sent) | sys (panel/runtime notice)
    line      TEXT NOT NULL
  );
  CREATE INDEX idx_console_lines_server ON console_lines(server_id, id);

  CREATE TABLE console_input (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    server_id  INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
    user_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    username   TEXT NOT NULL,
    command    TEXT NOT NULL,
    status     TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','sent','failed')),
    error      TEXT,
    created_at INTEGER NOT NULL,
    handled_at INTEGER
  );
  CREATE INDEX idx_console_input_status ON console_input(status, id);

  CREATE TABLE console_history (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    server_id  INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
    command    TEXT NOT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX idx_console_history ON console_history(user_id, server_id, id);
`,

// 5: file manager permissions (browse/search, and change = create/rename/delete)
`
  ALTER TABLE server_access ADD COLUMN can_files INTEGER NOT NULL DEFAULT 0;         -- may browse and search the server's files
  ALTER TABLE server_access ADD COLUMN can_files_write INTEGER NOT NULL DEFAULT 0;   -- may create, rename and delete files and folders
`,

// 6: Servers nest -> MC Host (kind 'mc', Paper) and Bot Host (kind 'bot', Python / Node.js preinstalled)
`
  ALTER TABLE servers ADD COLUMN kind TEXT NOT NULL DEFAULT 'mc' CHECK (kind IN ('mc','bot'));
  ALTER TABLE servers ADD COLUMN runtime TEXT;            -- bots only: 'python' | 'nodejs' (NULL for Minecraft servers)
  CREATE INDEX idx_servers_kind ON servers(kind);
`,

// 7: Reinstall. `servers.task` marks a long-running job the runtime is doing (NULL = none) so the panel can show
// "Reinstalling" and hide the other buttons; server_commands gets the new 'reinstall' command (its CHECK list
// cannot be altered in SQLite, so the table is rebuilt - nothing references it, existing rows are copied).
(conn) => {
  conn.exec(`
    ALTER TABLE servers ADD COLUMN task TEXT CHECK (task IS NULL OR task IN ('reinstall'));

    CREATE TABLE server_commands_new (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      server_id    INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
      user_id      INTEGER REFERENCES users(id) ON DELETE SET NULL,
      command      TEXT NOT NULL CHECK (command IN ('start','stop','restart','reinstall')),
      status       TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','done','failed')),
      error        TEXT,
      created_at   INTEGER NOT NULL,
      completed_at INTEGER
    );
    INSERT INTO server_commands_new (id, server_id, user_id, command, status, error, created_at, completed_at)
      SELECT id, server_id, user_id, command, status, error, created_at, completed_at FROM server_commands;
    DROP TABLE server_commands;
    ALTER TABLE server_commands_new RENAME TO server_commands;
    CREATE INDEX idx_commands_server ON server_commands(server_id, status);
  `);
}];

const applied = new Set(db.prepare('SELECT id FROM dashboard_migrations').all().map((r) => r.id));
MIGRATIONS.forEach((sql, i) => {
  const id = i + 1;
  if (applied.has(id)) return;
  db.exec('BEGIN');
  try {
    if (typeof sql === 'function') sql(db); else db.exec(sql);
    db.prepare('INSERT INTO dashboard_migrations (id, applied_at) VALUES (?, ?)').run(id, Date.now());
    db.exec('COMMIT');
  } catch (err) { db.exec('ROLLBACK'); throw err; }
});
