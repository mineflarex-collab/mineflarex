'use strict';
// File manager routes: the page and its JSON API. All data comes from src/dashboard/services/files.js (the real server directory).
//
//   GET  /dashboard/servers/:identifier/files                     page (path and search live in ?path= and ?q=)
//   GET  /api/dashboard/servers/:identifier/files?path=/a/b       list a folder
//   GET  /api/dashboard/servers/:identifier/files/search?q=&path= search a folder and everything below it
//   POST /api/dashboard/servers/:identifier/files/create          { path: "/parent", name, type: "file"|"folder" }
//   POST /api/dashboard/servers/:identifier/files/rename          { path: "/a/old", name: "new" }
//   POST /api/dashboard/servers/:identifier/files/delete          { paths: ["/a/x", ...], confirm: true }   (no confirm -> 428)
//   GET  /api/dashboard/servers/:identifier/files/download?path=/a/x     download one file
//   GET  /api/dashboard/servers/:identifier/files/content?path=/a/x      read a small text file (editor)
//   POST /api/dashboard/servers/:identifier/files/save                   { path, content }  save the editor
//   POST /api/dashboard/servers/:identifier/files/upload?path=/dir&name=f&offset=0&total=N[&overwrite=1]   raw chunk (application/octet-stream)
//   POST /api/dashboard/servers/:identifier/files/upload/cancel          { path: "/dir", name }
//   POST /api/dashboard/servers/:identifier/files/unarchive              { path: "/a/backup.tar.gz", into?: "/folder" }  -> 202 + job (background)
//   GET  /api/dashboard/servers/:identifier/files/unarchive              status of the latest extraction ({ job: null } when none)
//   POST /api/dashboard/servers/:identifier/files/unarchive/cancel       stop the running extraction
//
// Viewing needs the files.view permission, changing needs files.write. Owners and administrators have both; anyone
// without a relation to the server gets 404 (same as a missing server). Mutations also need the X-CSRF-Token header.
const { requireAuth } = require('../middleware/auth');
const { rateLimit } = require('../lib/rateLimit');
const { HttpError } = require('../lib/http');
const servers = require('./services/servers');
const access = require('./services/access');
const activity = require('./services/activity');
const files = require('./services/files');
const fileViews = require('./fileViews');

const short = (s, n = 160) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);

module.exports = function register(router) {
  /** Finds the server and checks the permission. Unrelated users get 404, missing permission 403. */
  const open = (ctx, permission) => {
    const server = servers.getByIdentifier(ctx.user.id, ctx.params.identifier);
    if (!server) throw new HttpError(404, 'Server not found.');
    const acc = access.forUser(ctx.user.id, server);
    if (!acc || !acc.has(permission)) {
      throw new HttpError(403, permission === 'files.write' ? 'You do not have permission to change files on this server.' : 'You do not have access to this server\'s files.');
    }
    return { server, acc };
  };
  // File errors become JSON { error, code } with a fitting status; anything else is a real bug (500).
  const api = (fn) => async (ctx) => {
    try { return await fn(ctx); } catch (e) {
      if (e instanceof files.FileError) return ctx.json(e.status, { error: e.message, code: e.code });
      throw e;
    }
  };
  const log = (ctx, server, type, message) => activity.record({ userId: server.owner_id, serverId: server.id, serverName: server.name, type, message: short(`${ctx.user.username} ${message}`), ip: ctx.ip });
  const base = '/api/dashboard/servers/:identifier/files';
  const readLimit = rateLimit({ name: 'files-read', windowMs: 60 * 1000, max: 300 });
  const searchLimit = rateLimit({ name: 'files-search', windowMs: 60 * 1000, max: 40 });
  const writeLimit = rateLimit({ name: 'files-write', windowMs: 60 * 1000, max: 120 });

  router.get('/dashboard/servers/:identifier/files', requireAuth, (ctx) => {
    const { server, acc } = open(ctx, 'files.view');
    ctx.html(200, fileViews.page({ ctx, server, access: acc }));
  });

  router.get(base, requireAuth, readLimit, api(async (ctx) => {
    const { acc, server } = open(ctx, 'files.view');
    const r = await files.list(server, ctx.query.path);
    return ctx.json(200, { ...r, canWrite: acc.has('files.write') });
  }));

  router.get(`${base}/search`, requireAuth, searchLimit, api(async (ctx) => {
    const { server } = open(ctx, 'files.view');
    return ctx.json(200, await files.search(server, ctx.query.path, ctx.query.q));
  }));

  router.get(`${base}/download`, requireAuth, readLimit, async (ctx) => {
    const { server } = open(ctx, 'files.view');
    let f;
    try { f = await files.openDownload(server, ctx.query.path); } catch (e) {
      if (e instanceof files.FileError) throw new HttpError(e.status, e.message);
      throw e;
    }
    log(ctx, server, 'file.download', `downloaded ${short(String(ctx.query.path))} from ${server.name}`);
    const ascii = f.name.replace(/[^\x20-\x7e]|["\\]/g, '_');
    ctx.res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': f.size, 'X-Content-Type-Options': 'nosniff',
      'Content-Disposition': `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(f.name)}` });
    await new Promise((resolve) => { f.stream.on('error', () => { ctx.res.destroy(); resolve(); }); ctx.res.on('close', () => { f.stream.destroy(); resolve(); }); f.stream.pipe(ctx.res); });
  });

  router.get(`${base}/content`, requireAuth, readLimit, api(async (ctx) => {
    const { server, acc } = open(ctx, 'files.view');
    return ctx.json(200, { ...(await files.readText(server, ctx.query.path)), canWrite: acc.has('files.write') });
  }));

  router.post(`${base}/save`, requireAuth, writeLimit, api(async (ctx) => {
    const { server } = open(ctx, 'files.write');
    const r = await files.writeText(server, typeof ctx.body.path === 'string' ? ctx.body.path : '', ctx.body.content);
    log(ctx, server, 'file.edit', `edited ${r.path} on ${server.name}`);
    return ctx.json(200, { ok: true, entry: r });
  }));

  const uploadLimit = rateLimit({ name: 'files-upload', windowMs: 60 * 1000, max: 600 });
  router.post(`${base}/upload`, requireAuth, uploadLimit, api(async (ctx) => {
    const { server } = open(ctx, 'files.write');
    const q = ctx.query, num = (v) => (/^\d{1,15}$/.test(String(v)) ? Number(v) : NaN);
    const r = await files.receiveChunk(server, q.path, q.name, { offset: num(q.offset), total: num(q.total), overwrite: q.overwrite === '1' }, ctx.req);
    if (r.done) log(ctx, server, 'file.upload', `uploaded ${r.entry.path} (${r.received} bytes) to ${server.name}`);
    return ctx.json(r.done ? 201 : 200, { ok: true, ...r });
  }));

  router.post(`${base}/upload/cancel`, requireAuth, writeLimit, api(async (ctx) => {
    const { server } = open(ctx, 'files.write');
    return ctx.json(200, await files.cancelUpload(server, ctx.body.path, ctx.body.name));
  }));

  // Unarchive (.zip, .tar, .tar.gz, .tgz, .gz): runs in the background; the page polls GET .../unarchive.
  const unarchiveLimit = rateLimit({ name: 'files-unarchive', windowMs: 60 * 1000, max: 60 });
  router.post(`${base}/unarchive`, requireAuth, unarchiveLimit, api(async (ctx) => {
    const { server } = open(ctx, 'files.write');
    const from = typeof ctx.body.path === 'string' ? ctx.body.path : '';
    const into = typeof ctx.body.into === 'string' ? ctx.body.into : null;
    const job = await files.startUnarchive(server, from, into, (j) => {
      if (j.state === 'done') log(ctx, server, 'file.unarchive', `extracted ${j.file} into ${j.dest} on ${server.name} (${j.files} files)`);
      else log(ctx, server, 'file.unarchive', `${j.state === 'cancelled' ? 'cancelled extracting' : 'could not extract'} ${j.file} on ${server.name}`);
    });
    return ctx.json(202, { ok: true, job });
  }));
  router.get(`${base}/unarchive`, requireAuth, readLimit, api(async (ctx) => {
    const { server } = open(ctx, 'files.view');
    return ctx.json(200, { job: files.unarchiveStatus(server) });
  }));
  router.post(`${base}/unarchive/cancel`, requireAuth, writeLimit, api(async (ctx) => {
    const { server } = open(ctx, 'files.write');
    return ctx.json(200, { ok: true, job: files.cancelUnarchive(server) });
  }));

  router.post(`${base}/create`, requireAuth, writeLimit, api(async (ctx) => {
    const { server } = open(ctx, 'files.write');
    const r = await files.create(server, ctx.body.path, ctx.body.name, ctx.body.type);
    log(ctx, server, 'file.create', `created ${r.type === 'dir' ? 'folder' : 'file'} ${r.path} on ${server.name}`);
    return ctx.json(201, { ok: true, entry: r });
  }));

  router.post(`${base}/rename`, requireAuth, writeLimit, api(async (ctx) => {
    const { server } = open(ctx, 'files.write');
    const from = typeof ctx.body.path === 'string' ? ctx.body.path : '';
    const r = await files.rename(server, from, ctx.body.name);
    if (!r.unchanged) log(ctx, server, 'file.rename', `renamed ${from} to ${r.name} on ${server.name}`);
    return ctx.json(200, { ok: true, entry: r });
  }));

  router.post(`${base}/delete`, requireAuth, writeLimit, api(async (ctx) => {
    const { server } = open(ctx, 'files.write');
    const confirmed = ctx.body.confirm === true || ctx.body.confirm === 'true' || ctx.body.confirm === '1';
    if (!confirmed) return ctx.json(428, { error: 'Deleting needs confirmation.', code: 'confirmation_required' });
    const paths = Array.isArray(ctx.body.paths) ? ctx.body.paths : typeof ctx.body.path === 'string' ? [ctx.body.path] : [];
    const r = await files.remove(server, paths.map(String));
    for (const x of r.results) if (x.ok) log(ctx, server, 'file.delete', `deleted ${x.path} on ${server.name}`);
    // 200 when everything went through, 207 when only some items could be deleted (each item says why).
    return ctx.json(r.failed ? 207 : 200, { ok: r.failed === 0, ...r });
  }));
};
