'use strict';
// Admin-only "Create Server" page (the same thing `npm run add-server` does, from the browser).
//   /admin/servers/new?kind=mc    MC Host  -> a Paper server
//   /admin/servers/new?kind=bot   Bot Host -> a Python or Node.js bot (the runtimes are already installed)
const { requireAdmin } = require('../middleware/auth');
const { rateLimit } = require('../lib/rateLimit');
const { HttpError } = require('../lib/http');
const { esc } = require('../views/layout');
const { icon } = require('../views/icons');
const users = require('../services/users');
const servers = require('./services/servers');
const capacity = require('./services/capacity');
const activity = require('./services/activity');
const runtimeSvc = require('./services/runtime');
const f = require('./format');
const { shell, capacityPanel } = require('./views');

const ENTRY_RE = /^(?!.*\.\.)[A-Za-z0-9_][A-Za-z0-9_./-]{0,59}$/;     // a file inside the bot's folder: no "..", no leading "/" or "-"
const kindOf = (v) => (String(v) === 'bot' ? 'bot' : 'mc');

function page({ ctx, kind, errors = {}, values = {}, flash }) {
  const bot = kind === 'bot';
  const v = { valid: '', name: '', owner: ctx.user.username, version: 'latest', address: '', ram: bot ? '512' : '2048', cpu: '100', disk: bot ? '2048' : '10240', players: '20', runtime: 'python', entry: '', ...values };
  const fld = (name, label, { type = 'text', hint = '' } = {}) => `<div class="mp-field${errors[name] ? ' has-error' : ''}"><label for="c-${name}">${label}</label>
<div class="mp-input-wrap"><input id="c-${name}" name="${name}" type="${type}" value="${esc(v[name])}" autocomplete="off"${type === 'number' ? ' min="1"' : ''}></div>
${hint ? `<p class="mp-hint">${hint}</p>` : ''}<p class="mp-error"${errors[name] ? '' : ' hidden'}>${esc(errors[name] || '')}</p></div>`;

  const runtimeField = `<div class="mp-field${errors.runtime ? ' has-error' : ''}"><label for="c-runtime">Runtime</label>
<div class="mp-input-wrap"><select id="c-runtime" name="runtime" class="mp-select">${Object.entries(servers.RUNTIMES).map(([k, r]) => `<option value="${k}"${v.runtime === k ? ' selected' : ''}>${r.label}</option>`).join('')}</select></div>
<p class="mp-hint">Python and Node.js are already installed, there is nothing to set up.</p><p class="mp-error"${errors.runtime ? '' : ' hidden'}>${esc(errors.runtime || '')}</p></div>`;
  const softwareField = `<div class="mp-field"><label for="c-software">Software</label><div class="mp-input-wrap"><input id="c-software" type="text" value="Paper" disabled></div>
<input type="hidden" name="software" value="paper"><p class="mp-hint">MC Host runs Paper.</p></div>`;

  const left = bot
    ? `${fld('name', 'Server name')}${fld('owner', 'Owner', { hint: 'Email or username of an existing account.' })}${runtimeField}${fld('entry', 'Start file', { hint: `Optional. Defaults to <code>${servers.RUNTIMES.python.defaultEntry}</code> (Python) or <code>${servers.RUNTIMES.nodejs.defaultEntry}</code> (Node.js).` })}`
    : `${fld('name', 'Server name')}${fld('owner', 'Owner', { hint: 'Email or username of an existing account.' })}${softwareField}${fld('version', 'Version')}`;
  const right = bot
    ? `${fld('ram', 'Memory limit (MB)', { type: 'number' })}${fld('cpu', 'CPU limit (%, 100 = one core)', { type: 'number' })}${fld('disk', 'Disk limit (MB)', { type: 'number' })}`
    : `${fld('address', 'Server address', { hint: `Optional. Leave empty and the server gets <code>${esc(servers.publicHost())}:${servers.nextPort()}</code> by itself (the port goes +1 for each new server; <code>0000</code> means this VPS has no public IPv4). You can edit it later with the pencil.` })}${fld('ram', 'Memory limit (MB)', { type: 'number' })}${fld('cpu', 'CPU limit (%, 100 = one core)', { type: 'number' })}${fld('disk', 'Disk limit (MB)', { type: 'number' })}`;
  const validity = fld('valid', 'Validity (valid until)', { hint: 'Optional. Date as <code>dd/mm/yyyy</code>, e.g. <code>20/12/2026</code>. The server is suspended automatically after this day. Leave empty for no expiry.' });
  const extra = `<div class="mp-grid-2"><div>${bot ? '' : fld('players', 'Max players', { type: 'number' })}${validity}</div></div>`;
  const full = !!capacity.warning();
  const label = bot ? 'Create Bot' : 'Create MC Server';
  const back = bot ? '/admin/servers/bots' : '/admin/servers/mc';
  const body = `${capacityPanel()}<section class="mp-panel mp-acct mp-create"><form method="post" action="/admin/servers" class="mp-form" novalidate>
<input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}"><input type="hidden" name="kind" value="${kind}">
<div class="mp-grid-2"><div>${left}</div><div>${right}</div></div>
${extra}
<div class="mp-form-actions"><button type="submit" class="mp-button mp-btn-inline"${full ? ' disabled title="The VPS is full. Upgrade your VPS first."' : ''}>${icon('plus', 14)} ${label}</button><a class="mp-btn-sm mp-btn-link" href="${back}">Cancel</a></div>
</form></section>`;
  return shell({ title: bot ? 'Create Bot' : 'Create Server', sub: bot ? 'Add a bot to Bot Host.' : 'Add a Minecraft server to MC Host.', active: bot ? 'admin-bots' : 'admin-mc', admin: true, user: ctx.user, csrf: ctx.csrfToken, flash, body, styles: ['/css/admin.css'], scripts: ['/js/admin-live.js'] });
}

/** Pencil page: change a server's memory / CPU / disk limits and its IP (public address). */
const PRESETS = { '7d': ['+7 days', { days: 7 }], '15d': ['+15 days', { days: 15 }], '1m': ['+1 month', { months: 1 }], '3m': ['+3 months', { months: 3 }], '6m': ['+6 months', { months: 6 }], '1y': ['+1 year', { years: 1 }] };

/** Admin > Upgrade time: add days / months / years to a server's validity, or set an exact date. */
function extendPage({ ctx, server, errors = {}, values = {}, flash }) {
  const bot = server.kind === 'bot', left = server.expires_at ? f.remaining(server.expires_at) : null;
  const cur = server.expires_at
    ? `<div class="mp-validity${server.expires_at < Date.now() ? ' is-expired' : servers.daysLeft(server.expires_at) <= 7 ? ' is-soon' : ''}" data-expires="${server.expires_at}">${icon('calendar', 15)}<span class="mp-validity-left" data-validity-left>${esc(left)}</span><span class="mp-validity-right">Expires <strong>${servers.formatDate(server.expires_at)}</strong></span></div>`
    : '<p class="mp-muted">This server has no expiry date yet. Pick a time below to give it one (counted from today).</p>';
  const form = (inner) => `<form method="post" action="/admin/servers/${esc(server.identifier)}/extend" class="mp-form" novalidate><input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}">${inner}</form>`;
  const presets = form(`<div class="mp-actions">${Object.entries(PRESETS).map(([k, [label]]) => `<button type="submit" name="preset" value="${k}" class="mp-btn-sm">${label}</button>`).join('')}</div>`);
  const custom = form(`<div class="mp-grid-2"><div><div class="mp-field${errors.amount ? ' has-error' : ''}"><label for="x-amount">Add time</label><div class="mp-input-wrap"><input id="x-amount" name="amount" type="number" min="1" max="3650" value="${esc(values.amount || '')}" placeholder="e.g. 20" autocomplete="off"></div><p class="mp-error"${errors.amount ? '' : ' hidden'}>${esc(errors.amount || '')}</p></div></div>
<div><div class="mp-field"><label for="x-unit">Unit</label><div class="mp-input-wrap"><select id="x-unit" name="unit" class="mp-select"><option value="d">Days</option><option value="m"${values.unit === 'm' ? ' selected' : ''}>Months</option><option value="y"${values.unit === 'y' ? ' selected' : ''}>Years</option></select></div></div></div></div>
<div class="mp-form-actions"><button type="submit" class="mp-button mp-btn-inline">${icon('plus', 14)} Add time</button></div>`);
  const exact = form(`<div class="mp-field${errors.date ? ' has-error' : ''}"><label for="x-date">Set exact date</label><div class="mp-input-wrap"><input id="x-date" name="date" type="text" value="${esc(values.date || '')}" placeholder="dd/mm/yyyy, e.g. 20/12/2026" autocomplete="off"></div><p class="mp-hint">Leave it for a fixed date. This replaces the current date (it can also shorten it).</p><p class="mp-error"${errors.date ? '' : ' hidden'}>${esc(errors.date || '')}</p></div>
<div class="mp-form-actions"><button type="submit" class="mp-button mp-btn-inline">Set date</button> <button type="submit" name="clear" value="1" class="mp-btn-sm">Remove expiry</button></div>`);
  const body = `<section class="mp-panel"><p class="mp-muted"><strong>${esc(server.name)}</strong> · <code>${esc(server.identifier)}</code></p>${cur}
<h2>Quick upgrade</h2>${presets}<h2>Custom time</h2>${custom}<h2>Exact date</h2>${exact}
<p><a class="mp-btn-sm" href="${bot ? '/admin/servers/bots' : '/admin/servers/mc'}">Back</a></p></section>`;
  return shell({ title: 'Upgrade time', sub: `Validity of ${server.name}.`, active: bot ? 'admin-bots' : 'admin-mc', admin: true, user: ctx.user, csrf: ctx.csrfToken, flash, body, styles: ['/css/admin.css'] });
}

function editPage({ ctx, server, errors = {}, values = {}, flash }) {
  const bot = server.kind === 'bot';
  const v = { ram: String(server.ram_limit_mb), cpu: String(server.cpu_limit_pct), disk: String(server.disk_limit_mb), address: server.address || '', players: String(server.players_max), ...values };
  const fld = (name, label, { type = 'text', hint = '' } = {}) => `<div class="mp-field${errors[name] ? ' has-error' : ''}"><label for="e-${name}">${label}</label>
<div class="mp-input-wrap"><input id="e-${name}" name="${name}" type="${type}" value="${esc(v[name])}" autocomplete="off"${type === 'number' ? ' min="1"' : ''}></div>
${hint ? `<p class="mp-hint">${hint}</p>` : ''}<p class="mp-error"${errors[name] ? '' : ' hidden'}>${esc(errors[name] || '')}</p></div>`;
  const back = bot ? '/admin/servers/bots' : '/admin/servers/mc';
  const live = server.status !== 'offline' && server.status !== 'crashed';
  const body = `<section class="mp-panel mp-acct mp-create"><p class="mp-muted"><strong>${esc(server.name)}</strong> · <code>#${servers.numberOf(server)}</code> · <code>${esc(server.identifier)}</code>${live ? '<br>This server is running: new limits apply the next time it starts.' : ''}</p>
<div class="mp-actions mp-manage-tabs"><span class="mp-btn-sm is-on">Build &amp; limits</span><a class="mp-btn-sm mp-btn-link" href="/dashboard/servers/${esc(server.identifier)}/startup">${icon('rocket', 13)} Startup</a><a class="mp-btn-sm mp-btn-link" href="/dashboard/servers/${esc(server.identifier)}/console">Console</a><a class="mp-btn-sm mp-btn-link" href="/dashboard/servers/${esc(server.identifier)}/files">Files</a><a class="mp-btn-sm mp-btn-link" href="/dashboard/servers/${esc(server.identifier)}">Open as owner</a></div>
<form method="post" action="/admin/servers/${esc(server.identifier)}/edit" class="mp-form" novalidate>
<input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}">
<div class="mp-grid-2"><div>${fld('ram', 'Memory limit (MB)', { type: 'number' })}${fld('cpu', 'CPU limit (%, 100 = one core)', { type: 'number' })}${fld('disk', 'Disk limit (MB)', { type: 'number' })}</div>
<div>${fld('address', 'IP / address', { hint: 'Optional, e.g. 203.0.113.10:25565 or play.example.com:25565. Leave empty to clear.' })}${bot ? '' : fld('players', 'Max players', { type: 'number' })}</div></div>
<div class="mp-form-actions"><button type="submit" class="mp-button mp-btn-inline">${icon('edit', 14)} Save changes</button><a class="mp-btn-sm mp-btn-link" href="${back}">Cancel</a></div>
</form>
<p class="mp-muted">Validity: ${server.expires_at ? `until <strong>${servers.formatDate(server.expires_at)}</strong> (${esc(f.remaining(server.expires_at))} left)` : 'no expiry'} · <a class="mp-btn-sm mp-btn-link" href="/admin/servers/${esc(server.identifier)}/extend">Upgrade time</a></p>
<form method="post" action="/admin/servers/${esc(server.identifier)}/${server.suspended ? 'unsuspend' : 'suspend'}" class="mp-form"><input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}">
<p class="mp-muted">${server.suspended ? `Suspended: ${esc(server.suspended_reason || 'by an administrator')}.` : 'Suspending stops the server and blocks it from starting. Servers are also suspended automatically when RAM, CPU or disk stays at 90%+ for too long.'}</p>
<button type="submit" class="mp-btn-sm">${server.suspended ? 'Unsuspend server' : 'Suspend server'}</button></form></section>`;
  return shell({ title: 'Edit server', sub: `Resources and IP for ${server.name}.`, active: bot ? 'admin-bots' : 'admin-mc', admin: true, user: ctx.user, csrf: ctx.csrfToken, flash, body, styles: ['/css/admin.css'] });
}

const int = (raw, min, max) => { const n = Number(raw); return Number.isInteger(n) && n >= min && n <= max ? n : null; };

const backTo = (ctx, s) => (/^(\/admin\/servers\/(mc|bots)(\?[\w=&%.-]*)?|\/dashboard\/servers\/[\w-]+\/console)$/.test(String(ctx.body.back || '')) ? ctx.body.back : `/admin/servers/${s.identifier}/edit`);

module.exports = function register(router) {
  const findServer = (ctx) => {
    const s = servers.getByIdentifier(ctx.user.id, ctx.params.identifier);   // administrators resolve every server
    if (!s) throw new HttpError(404, 'Server not found.');
    return s;
  };
  router.get('/admin/servers/:identifier/edit', requireAdmin, (ctx) => ctx.html(200, editPage({ ctx, server: findServer(ctx), flash: ctx.takeFlash() })));

  router.get('/admin/servers/:identifier/extend', requireAdmin, (ctx) => ctx.html(200, extendPage({ ctx, server: findServer(ctx), flash: ctx.takeFlash() })));
  router.post('/admin/servers/:identifier/extend', requireAdmin, rateLimit({ name: 'server-extend', windowMs: 60 * 1000, max: 60 }), (ctx) => {
    const s = findServer(ctx), b = ctx.body, now = Date.now();
    const bad = (errors, values) => ctx.html(422, extendPage({ ctx, server: s, errors, values, flash: { type: 'error', message: 'Please fix the highlighted field.' } }));
    let next, what;
    if (b.clear) { next = null; what = 'Expiry removed'; }
    else if (b.preset && PRESETS[b.preset]) { next = servers.extendFrom(s.expires_at, PRESETS[b.preset][1], now); what = PRESETS[b.preset][0].replace('+', 'Added '); }
    else if (String(b.date || '').trim()) {
      next = servers.parseDate(b.date);
      if (!next) return bad({ date: 'Use dd/mm/yyyy, for example 20/12/2026.' }, { date: String(b.date) });
      what = `Valid until set to ${servers.formatDate(next)}`;
    } else {
      const n = Number(b.amount), unit = { d: 'days', m: 'months', y: 'years' }[b.unit];
      if (!Number.isInteger(n) || n < 1 || n > 3650 || !unit) return bad({ amount: 'Enter a whole number from 1 to 3650.' }, { amount: String(b.amount ?? ''), unit: b.unit });
      next = servers.extendFrom(s.expires_at, { [unit]: n }, now); what = `Added ${n} ${n === 1 ? unit.slice(0, -1) : unit}`;
    }
    servers.setExpiry(s.id, next);
    if ((!next || next > now) && s.suspended && /^Validity expired/.test(s.suspended_reason || '')) runtimeSvc.unsuspendServer(s.id, { by: ctx.user.username });   // renewed
    activity.record({ userId: s.owner_id, serverId: s.id, serverName: s.name, type: 'server.validity', message: `${what} for ${s.name} by ${ctx.user.username}${next ? ` (now valid until ${servers.formatDate(next)})` : ''}`, ip: ctx.ip });
    ctx.flash('success', `${what}.${next ? ` Valid until ${servers.formatDate(next)}.` : ''}`);
    return ctx.redirect(`/admin/servers/${s.identifier}/extend`);
  });

  router.post('/admin/servers/:identifier/suspend', requireAdmin, rateLimit({ name: 'server-suspend', windowMs: 60 * 1000, max: 60 }), async (ctx) => {
    const s = findServer(ctx), entry = runtimeSvc;
    entry.suspendServer(s.id, 'Suspended by an administrator.', { by: ctx.user.username });
    if (s.status === 'online' || s.status === 'starting') servers.requestCommand(ctx.user, s.id, 'stop', ctx.ip, { confirmed: true });
    ctx.flash('success', `"${s.name}" suspended.`);
    return ctx.redirect(backTo(ctx, s));
  });
  router.post('/admin/servers/:identifier/unsuspend', requireAdmin, rateLimit({ name: 'server-unsuspend', windowMs: 60 * 1000, max: 60 }), (ctx) => {
    const s = findServer(ctx);
    runtimeSvc.unsuspendServer(s.id, { by: ctx.user.username });
    ctx.flash('success', `"${s.name}" unsuspended. It can be started again.`);
    return ctx.redirect(backTo(ctx, s));
  });

  router.post('/admin/servers/:identifier/edit', requireAdmin, rateLimit({ name: 'server-edit', windowMs: 60 * 1000, max: 60 }), (ctx) => {
    const server = findServer(ctx), b = ctx.body, errors = {}, bot = server.kind === 'bot';
    const values = Object.fromEntries(['ram', 'cpu', 'disk', 'address', 'players'].map((k) => [k, String(b[k] ?? '').trim()]));
    const ram = int(values.ram, 128, 1048576), cpu = int(values.cpu, 10, 6400), disk = int(values.disk, 128, 10485760);
    const players = bot ? null : int(values.players, 1, 10000);
    if (ram === null) errors.ram = 'Enter a whole number between 128 and 1048576.';
    if (cpu === null) errors.cpu = 'Enter a whole number between 10 and 6400.';
    if (disk === null) errors.disk = 'Enter a whole number between 128 and 10485760.';
    if (!bot && players === null) errors.players = 'Enter a whole number between 1 and 10000.';
    if (values.address && !/^[A-Za-z0-9_.:-]{1,100}$/.test(values.address)) errors.address = 'Use a host name or IP, optionally with :port.';
    const fail = (message) => ctx.html(422, editPage({ ctx, server, errors, values, flash: { type: 'error', message } }));
    if (Object.keys(errors).length) return fail('Please fix the highlighted fields.');
    const room = capacity.canResize({ ram: server.ram_limit_mb, cpu: server.cpu_limit_pct, disk: server.disk_limit_mb }, { ram, cpu, disk });
    if (!room.ok) return fail(room.message);
    const s = servers.updateResources(server.id, { ramLimitMb: ram, cpuLimitPct: cpu, diskLimitMb: disk, address: values.address || null, playersMax: players });
    activity.record({ userId: s.owner_id, serverId: s.id, serverName: s.name, type: 'server.updated',
      message: `Resources of ${s.name} were changed by ${ctx.user.username}: ${s.ram_limit_mb} MB RAM, ${s.cpu_limit_pct}% CPU, ${s.disk_limit_mb} MB disk${s.address ? `, address ${s.address}` : ''}`, ip: ctx.ip });
    ctx.flash('success', `"${s.name}" updated.`);
    return ctx.redirect(bot ? '/admin/servers/bots' : '/admin/servers/mc');
  });

  router.get('/admin/servers/new', requireAdmin, (ctx) => ctx.html(200, page({ ctx, kind: kindOf(ctx.query.kind), flash: ctx.takeFlash() })));

  router.post('/admin/servers', requireAdmin, rateLimit({ name: 'server-create', windowMs: 60 * 60 * 1000, max: 60 }), (ctx) => {
    const b = ctx.body, errors = {}, kind = kindOf(b.kind), bot = kind === 'bot';
    const values = Object.fromEntries(['name', 'owner', 'version', 'address', 'ram', 'cpu', 'disk', 'players', 'runtime', 'entry', 'valid'].map((k) => [k, String(b[k] ?? '').trim()]));
    const name = values.name;
    if (!name || name.length > 40) errors.name = 'Enter a name of up to 40 characters.';
    const owner = values.owner ? users.findByLogin(values.owner) : null;
    if (!owner) errors.owner = 'No account matches that email or username.';
    let startCommand = null;
    if (bot) {
      const rt = servers.RUNTIMES[values.runtime];
      if (!rt) errors.runtime = 'Choose Python or Node.js.';
      const entry = values.entry || (rt ? rt.defaultEntry : '');
      if (rt && !ENTRY_RE.test(entry)) errors.entry = 'Use a file name like main.py (letters, numbers, dots, dashes, underscores, slashes).';
      if (rt && !errors.entry) startCommand = rt.command(entry);
    } else {
      if (!/^[A-Za-z0-9_.+-]{1,30}$/.test(values.version)) errors.version = 'Use letters, numbers, dots, dashes or underscores.';
      if (values.address && !/^[A-Za-z0-9_.:-]{1,100}$/.test(values.address)) errors.address = 'Use a host name or IP, optionally with :port.';
    }
    const ram = int(values.ram, 128, 1048576), cpu = int(values.cpu, 10, 6400), disk = int(values.disk, 128, 10485760), players = bot ? 1 : int(values.players, 1, 10000);
    if (ram === null) errors.ram = 'Enter a whole number between 128 and 1048576.';
    if (cpu === null) errors.cpu = 'Enter a whole number between 10 and 6400.';
    if (disk === null) errors.disk = 'Enter a whole number between 128 and 10485760.';
    if (players === null) errors.players = 'Enter a whole number between 1 and 10000.';
    const expiresAt = values.valid ? servers.parseDate(values.valid) : null;
    if (values.valid && !expiresAt) errors.valid = 'Use dd/mm/yyyy, for example 20/12/2026.';
    if (Object.keys(errors).length) return ctx.html(422, page({ ctx, kind, errors, values, flash: { type: 'error', message: 'Please fix the highlighted fields.' } }));
    const room = capacity.canCreate({ ram, cpu, disk });      // servers are unlimited, the VPS is not: at most 90% of its RAM / CPU / disk
    if (!room.ok) return ctx.html(422, page({ ctx, kind, errors, values, flash: { type: 'error', message: room.message } }));
    try {
      const s = servers.create({ expiresAt, kind, ownerId: owner.id, name, ramLimitMb: ram, cpuLimitPct: cpu, diskLimitMb: disk, playersMax: players,
        ...(bot ? { runtime: values.runtime, software: servers.RUNTIMES[values.runtime].label, version: 'latest', startCommand }
          : { software: 'paper', version: values.version, address: values.address || null }) });
      activity.record({ userId: owner.id, serverId: s.id, serverName: s.name, type: 'server.created', message: `${bot ? 'Bot' : 'Server'} ${s.name} was added to your account (by ${ctx.user.username})` });
      ctx.flash('success', `${bot ? 'Bot' : 'Server'} "${s.name}" (#${servers.numberOf(s)}) created for ${owner.username}${s.address ? `, address ${s.address}` : ''}.`);
      return ctx.redirect(`/dashboard/servers/${s.identifier}`);
    } catch (err) {
      if (!/UNIQUE/.test(err.message)) throw err;
      errors.name = 'That user already has a server with this name.';
      return ctx.html(422, page({ ctx, kind, errors, values, flash: { type: 'error', message: 'Please fix the highlighted fields.' } }));
    }
  });
};
