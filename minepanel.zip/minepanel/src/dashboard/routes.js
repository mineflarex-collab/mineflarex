'use strict';
const { requireAuth, safeNext } = require('../middleware/auth');
const { rateLimit } = require('../lib/rateLimit');
const servers = require('./services/servers');
const activity = require('./services/activity');
const account = require('./services/account');
const f = require('./format');
const views = require('./views');
const serverViews = require('./serverViews');
const access = require('./services/access');
const events = require('./services/events');
const pages = require('./pages');
const startup = require('./services/startup');
const users = require('../services/users');
const { HttpError } = require('../lib/http');

const PER_PAGE = 25;
const hour = 60 * 60 * 1000;

module.exports = function register(router) {
  router.get('/dashboard', requireAuth, (ctx) => {
    const showAll = ctx.user.role === 'admin' && ctx.query.all === '1';
    ctx.html(200, views.overview({
      ctx, flash: ctx.takeFlash(), showAll,
      list: showAll ? servers.listAll(200) : servers.listForOwner(ctx.user.id, 50)
    }));
  });

  // Server management list: search + filters + sorting + pagination (all handled by the service, scoped to the signed-in user).
  router.get('/dashboard/servers', requireAuth, (ctx) => {
    const result = servers.search(ctx.user.id, ctx.query);
    ctx.html(200, serverViews.list({
      ctx, flash: ctx.takeFlash(), result,
      counts: servers.statusCounts(ctx.user.id, result.filters), facets: servers.facets(ctx.user.id)
    }));
  });

  // Server details page, addressed by the server's public identifier. Unknown identifiers and other users' servers are both 404.
  const findServer = (ctx) => {
    const s = servers.getByIdentifier(ctx.user.id, ctx.params.identifier);
    if (!s) throw new HttpError(404, 'Server not found.');
    return s;
  };
  router.get('/dashboard/servers/:identifier', requireAuth, (ctx) => {
    const server = findServer(ctx);
    ctx.html(200, serverViews.detail({
      ctx, flash: ctx.takeFlash(), server, access: access.forUser(ctx.user.id, server),
      commands: servers.recentCommands(server.id, 10), activityItems: activity.forServer(server.id, 10)
    }));
  });

  // Live console page (output + commands run over the WebSocket in src/dashboard/consoleSocket.js).
  router.get('/dashboard/servers/:identifier/console', requireAuth, (ctx) => {
    const server = findServer(ctx), acc = access.forUser(ctx.user.id, server);
    if (!acc.has('console.view')) throw new HttpError(403, 'You do not have access to this server\'s console.');
    ctx.html(200, serverViews.consolePage({ ctx, server, access: acc }));
  });

  // Secondary server pages. Entries without a backend render an honest "not built yet" page (never fake data).
  const withServer = (ctx) => { const server = findServer(ctx); return { ctx, server, access: access.forUser(ctx.user.id, server) }; };
  router.get('/dashboard/servers/:identifier/activity', requireAuth, (ctx) => { const v = withServer(ctx); ctx.html(200, pages.serverActivity({ ...v, items: activity.forServer(v.server.id, 50) })); });
  router.get('/dashboard/servers/:identifier/users', requireAuth, (ctx) => {
    const v = withServer(ctx);
    ctx.html(200, pages.serverUsers({ ...v, owner: users.findById(v.server.owner_id), shared: access.listFor(v.server.id) }));
  });
  router.get('/dashboard/servers/:identifier/network', requireAuth, (ctx) => ctx.html(200, pages.serverNetwork(withServer(ctx))));
  router.get('/dashboard/servers/:identifier/startup', requireAuth, (ctx) => ctx.html(200, pages.serverStartup({ ...withServer(ctx), flash: ctx.takeFlash() })));
  router.post('/dashboard/servers/:identifier/startup', requireAuth, rateLimit({ name: 'server-startup', windowMs: 60 * 1000, max: 30 }), (ctx) => {
    const v = withServer(ctx), s = v.server, admin = ctx.user.role === 'admin';
    if (!(v.access.role === 'owner' || v.access.role === 'admin')) throw new HttpError(403, 'Only the owner can change the startup settings.');
    const r = startup.save(s, ctx.body, { admin });
    if (!r.ok) return ctx.html(422, pages.serverStartup({ ...v, errors: r.errors, values: r.values, flash: { type: 'error', message: 'Please fix the highlighted fields.' } }));
    activity.record({ userId: s.owner_id, serverId: s.id, serverName: s.name, type: 'server.startup', message: `Startup settings of ${s.name} were changed by ${ctx.user.username}`, ip: ctx.ip });
    ctx.flash('success', `Startup saved. It applies the next time ${s.name} starts.`);
    return ctx.redirect(`/dashboard/servers/${s.identifier}/startup`);
  });
  for (const slug of Object.keys(pages.NOT_BUILT)) {
    router.get(`/dashboard/servers/:identifier/${slug}`, requireAuth, (ctx) => ctx.html(200, pages.serverNotBuilt({ ...withServer(ctx), slug })));
  }
  router.get('/dashboard/api-credentials', requireAuth, (ctx) => ctx.html(200, pages.accountNotBuilt({ ctx, name: 'API Credentials', active: 'api' })));
  router.get('/dashboard/ssh-keys', requireAuth, (ctx) => ctx.html(200, pages.accountNotBuilt({ ctx, name: 'SSH Keys', active: 'ssh' })));

  // JSON API for the same data (also polled by the details page for live usage numbers).
  router.get('/api/dashboard/servers', requireAuth, (ctx) => {
    const r = servers.search(ctx.user.id, ctx.query), admin = ctx.user.role === 'admin';
    ctx.json(200, {
      servers: r.items.map((s) => f.describeServer(s, { admin })),
      page: r.page, pages: r.pages, perPage: r.perPage, total: r.total, filters: r.filters,
      counts: servers.statusCounts(ctx.user.id, r.filters)
    });
  });
  router.get('/api/dashboard/servers/:identifier', requireAuth, (ctx) => {
    const s = findServer(ctx);
    const acc = access.forUser(ctx.user.id, s);
    ctx.json(200, {
      server: f.describeServer(s, { admin: ctx.user.role === 'admin' }),
      access: acc.role, permissions: [...acc.permissions], allowedActions: servers.allowedActionsFor(acc, s)
    });
  });

  // ---- Power controls -------------------------------------------------------------------------------
  // Confirmation page for destructive actions (works without JavaScript; the POST below re-checks everything).
  router.get('/dashboard/servers/:identifier/confirm/:action', requireAuth, (ctx) => {
    const server = findServer(ctx), action = ctx.params.action, acc = access.forUser(ctx.user.id, server);
    const back = safeNext(ctx.query.back) || `/dashboard/servers/${server.identifier}`;
    if (!servers.CONFIRM.has(action)) throw new HttpError(404, 'Page not found.');
    if (!servers.allowedActionsFor(acc, server).includes(action)) {
      const why = !acc.can(action) ? `You do not have permission to ${action} ${server.name}.`
        : server.task ? `${server.name} is being reinstalled. Please wait until it has finished.`
          : (action === 'reinstall' && servers.reinstallProblem(server)) || `${server.name} cannot be ${action === 'stop' ? 'stopped' : action + 'ed'} while it is ${server.status}.`;
      ctx.flash('error', why);
      return ctx.redirect(back);
    }
    return ctx.html(200, serverViews.confirm({ ctx, server, action, back }));
  });

  // JSON API: POST { "action": "start|stop|restart|reinstall", "confirm": true }  (stop/restart/reinstall need confirm: true).
  // Requires the session cookie and an X-CSRF-Token header (GET /api/dashboard/csrf).
  const HTTP = { ok: 202, unknown_action: 422, not_found: 404, forbidden: 403, confirmation_required: 428, invalid_state: 409, busy: 409, suspended: 403 };
  router.get('/api/dashboard/csrf', requireAuth, (ctx) => ctx.json(200, { token: ctx.csrfToken }));
  router.post('/api/dashboard/servers/:identifier/power', requireAuth, rateLimit({ name: 'server-action-api', windowMs: 60 * 1000, max: 30 }), (ctx) => {
    const s = findServer(ctx);
    const confirmed = ctx.body.confirm === true || ctx.body.confirm === 'true' || ctx.body.confirm === '1';
    const r = servers.requestCommand(ctx.user, s.id, String(ctx.body.action || ''), ctx.ip, { confirmed });
    if (!r.ok) return ctx.json(HTTP[r.code] || 400, { error: r.message, code: r.code });
    const fresh = servers.getByIdentifier(ctx.user.id, s.identifier);
    return ctx.json(HTTP.ok, { ok: true, code: 'ok', message: r.message, command: r.command,
      server: f.describeServer(fresh, { admin: ctx.user.role === 'admin' }) });
  });

  // Real-time status stream (Server-Sent Events): `snapshot` on connect, then `update` with changed servers.
  router.get('/api/dashboard/events', (ctx) => {
    if (!ctx.user) return ctx.json(401, { error: 'Authentication required.' });
    if (events.count(ctx.user.id) >= events.MAX_PER_USER) return ctx.json(429, { error: 'Too many open live connections.' });
    ctx.res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    ctx.res.write('retry: 3000\n\n');
    const client = events.add(ctx.user, ctx.res);
    return new Promise((resolve) => ctx.res.on('close', () => { events.remove(client); resolve(); }));
  });

  router.get('/dashboard/activity', requireAuth, (ctx) => {
    const total = activity.count(ctx.user.id), pages = Math.max(1, Math.ceil(total / PER_PAGE));
    const page = Math.min(pages, Math.max(1, parseInt(ctx.query.page, 10) || 1));
    ctx.html(200, views.activityPage({ ctx, flash: ctx.takeFlash(), page, pages, items: activity.recent(ctx.user.id, PER_PAGE, (page - 1) * PER_PAGE) }));
  });

  router.get('/dashboard/profile', requireAuth, (ctx) => ctx.html(200, views.profilePage({
    ctx, flash: ctx.takeFlash(), sessions: account.countSessions(ctx.user.id), serverCount: servers.summaryFor(ctx.user.id).total
  })));

  const settings = (ctx, extra = {}, status = 200) =>
    ctx.html(status, views.settingsPage({ ctx, sessions: account.listSessions(ctx.user.id), flash: extra.flash ?? ctx.takeFlash(), ...extra }));

  router.get('/dashboard/settings', requireAuth, (ctx) => settings(ctx));

  router.post('/dashboard/settings/profile', requireAuth, rateLimit({ name: 'profile', windowMs: hour, max: 20 }), async (ctx) => {
    const r = await account.updateProfile(ctx.user, ctx.body, ctx.ip);
    if (r.errors) return settings(ctx, { errors: { profile: r.errors }, values: r.values, flash: { type: 'error', message: 'Please fix the highlighted fields.' } }, 422);
    ctx.flash(r.ok ? 'success' : 'info', r.ok || r.info);
    return ctx.redirect('/dashboard/settings');
  });

  router.post('/dashboard/settings/password', requireAuth, rateLimit({ name: 'pwchange', windowMs: hour, max: 10 }), async (ctx) => {
    const r = await account.changePassword(ctx.user, ctx.session, ctx.body, ctx.ip);
    if (r.errors) return settings(ctx, { errors: { password: r.errors }, flash: { type: 'error', message: 'Password not changed. Please fix the highlighted fields.' } }, 422);
    ctx.flash('success', r.ok);
    return ctx.redirect('/dashboard/settings');
  });

  router.post('/dashboard/settings/sessions/revoke', requireAuth, (ctx) => {
    const r = account.revokeSession(ctx.user, ctx.session.id, String(ctx.body.session_id || ''));
    ctx.flash(r.ok ? 'success' : 'error', r.message);
    return ctx.redirect('/dashboard/settings');
  });

  router.post('/dashboard/settings/sessions/revoke-others', requireAuth, (ctx) => {
    const n = account.revokeOthers(ctx.user, ctx.session.id);
    ctx.flash('success', n ? `Signed out ${n} other device${n === 1 ? '' : 's'}.` : 'No other devices were signed in.');
    return ctx.redirect('/dashboard/settings');
  });

  // Power actions from the web UI (start / stop / restart / reinstall). Permission, confirmation and state are enforced in the service.
  router.post('/dashboard/servers/:identifier/force/:action', requireAuth, rateLimit({ name: 'server-force', windowMs: 60 * 1000, max: 20 }), (ctx) => {
    const server = findServer(ctx), acc = access.forUser(ctx.user.id, server), a = String(ctx.params.action);
    if (!['stop', 'start', 'restart'].includes(a)) throw new HttpError(404, 'Unknown action.');
    if (!acc.can(a)) throw new HttpError(403, `You do not have permission to ${a} this server.`);
    const r = servers.requestForce(ctx.user, server.id, `force_${a}`, ctx.ip);
    ctx.flash(r.ok ? 'success' : 'error', r.ok ? `${r.label} sent to "${server.name}".` : r.error);
    return ctx.redirect(`/dashboard/servers/${server.identifier}/console`);
  });
  router.post('/dashboard/servers/action', requireAuth, rateLimit({ name: 'server-action', windowMs: 60 * 1000, max: 30 }), (ctx) => {
    const back = safeNext(ctx.body.back) || '/dashboard';
    const confirmed = ctx.body.confirm === '1';
    const r = servers.requestCommand(ctx.user, Number(ctx.body.server_id), String(ctx.body.action || ''), ctx.ip, { confirmed });
    if (r.code === 'confirmation_required') return ctx.redirect(`/dashboard/servers/${r.identifier}/confirm/${encodeURIComponent(String(ctx.body.action))}?back=${encodeURIComponent(back)}`);
    ctx.flash(r.ok ? 'success' : 'error', r.message);
    return ctx.redirect(back);
  });

  // Polled by public/js/dashboard.js to keep numbers live.
  router.get('/api/dashboard/summary', requireAuth, (ctx) => ctx.json(200, {
    summary: f.describe(servers.summaryFor(ctx.user.id)),
    servers: servers.listVisible(ctx.user.id).map((s) => ({ id: s.id, status: s.status, task: s.task || null }))
  }));
};
