'use strict';
// File manager page. Markup only: the listing itself is drawn by public/js/files.js from the JSON API (names are
// untrusted - players and plugins create them - so the client only ever uses textContent / element nodes).
const { esc } = require('../views/layout');
const { icon } = require('../views/icons');
const { shell } = require('./views');
const { serverHead } = require('./serverViews');

function page({ ctx, server: s, access: acc }) {
  const canWrite = acc.has('files.write');
  const dialogField = `<div class="mp-field"><label for="files-name" data-files-label>Name</label><div class="mp-input-wrap"><input id="files-name" name="name" type="text" maxlength="255" autocomplete="off" spellcheck="false" autocapitalize="off" required data-files-name></div><p class="mp-error" data-files-error hidden></p></div>`;
  const back = `/dashboard/servers/${s.identifier}/files`;
  const tbtn = (attrs, ico, label, cls = '') => `<button type="button" class="mp-btn-sm mp-tool${cls}" ${attrs}>${icon(ico, 14)} <span>${label}</span></button>`;
  const body = `${serverHead(s, ctx, back)}
<section class="mp-files-head">
<div class="mp-files-buttons" role="toolbar" aria-label="File actions">
${tbtn('data-files-code', 'code', 'Code editor')}
${tbtn('data-files-refresh', 'restart', 'Refresh')}
${canWrite ? `${tbtn('data-files-new="folder"', 'folderPlus', 'New folder')}
${tbtn('data-files-upload', 'upload', 'Upload')}
<input type="file" multiple hidden data-files-input>
${tbtn('data-files-upload-folder', 'folderUp', 'Upload folder')}
<input type="file" webkitdirectory multiple hidden data-files-folder-input>
${tbtn('data-files-new="file"', 'filePlus', 'New file', ' mp-tool-primary')}` : ''}
</div>
</section>
<section class="mp-panel mp-files" data-files="${esc(s.identifier)}" data-can-write="${canWrite ? '1' : '0'}" data-status="${esc(s.status)}" data-csrf="${esc(ctx.csrfToken)}">
<div class="mp-files-bar">
<nav class="mp-crumbs" aria-label="Folder path" data-files-crumbs></nav>
<form class="mp-files-search" data-files-search role="search">${icon('search', 15)}<label class="mp-sr" for="files-q">Search files by name</label><input id="files-q" type="search" maxlength="100" placeholder="Search…" autocomplete="off" spellcheck="false" data-files-q><button type="button" class="mp-icon-btn mp-files-clear" data-files-clear aria-label="Clear search" hidden>${icon('x', 14)}</button></form>
</div>
<p class="mp-files-banner" data-files-banner hidden></p>
<div class="mp-files-uploads" data-files-uploads hidden><div class="mp-files-uploads-head"><strong data-files-uploads-title>Uploading</strong><span class="mp-muted">Keep this page open until finished</span></div><ul data-files-upload-list></ul></div>
${canWrite ? `<div class="mp-files-bulk" data-files-bulk hidden><span data-files-bulk-count></span><button type="button" class="mp-btn-sm" data-files-bulk-move>${icon('move', 13)} <span>Move selected</span></button><button type="button" class="mp-btn-sm mp-btn-stop" data-files-bulk-delete>${icon('trash', 13)} <span>Delete selected</span></button><button type="button" class="mp-btn-sm" data-files-bulk-clear>Clear selection</button></div>` : ''}
${canWrite ? `<div class="mp-files-uploads mp-unarch" data-unarch hidden role="status" aria-live="polite">
<div class="mp-files-uploads-head"><strong data-unarch-title>Unarchiving</strong><span class="mp-muted" data-unarch-hint>Runs on the server; you can leave this page</span></div>
<div class="mp-up"><span class="mp-up-ring" data-unarch-ring></span><div class="mp-up-info"><strong data-unarch-file></strong><span class="mp-muted" data-unarch-meta></span><progress class="mp-unarch-bar" data-unarch-bar value="0" max="100" aria-label="Extraction progress"></progress></div><span class="mp-up-pct" data-unarch-pct>0%</span>
<button type="button" class="mp-btn-sm mp-btn-stop" data-unarch-cancel>${icon('x', 13)} <span>Cancel</span></button><button type="button" class="mp-btn-sm" data-unarch-dismiss hidden>Close</button></div>
<p class="mp-muted mp-unarch-skipped" data-unarch-skipped hidden></p>
</div>` : ''}
<div class="mp-table-wrap mp-files-wrap" data-files-wrap aria-busy="true">
<table class="mp-table mp-files-table">
<thead><tr>${canWrite ? '<th class="mp-files-check"><input type="checkbox" data-files-all aria-label="Select all"></th>' : ''}<th>Name</th><th class="mp-files-size">Size</th><th class="mp-files-date">Last Modified</th><th class="mp-files-act"><span class="mp-sr">Actions</span></th></tr></thead>
<tbody data-files-body></tbody>
</table>
<p class="mp-empty mp-files-empty" data-files-empty hidden></p>
</div>
<p class="mp-muted mp-files-foot" data-files-foot role="status" aria-live="polite"></p>
<p class="mp-files-toast" data-files-toast role="status" aria-live="polite" hidden></p>
<div class="mp-files-drop" data-files-drop hidden>${icon('upload', 28)}<span>Drop files to upload</span></div>
<div class="mp-files-popup mp-files-rowmenu" role="menu" data-files-rowmenu hidden></div>
<noscript><p class="mp-empty">The file manager needs JavaScript.</p></noscript>
<template data-files-icons>
<span data-i="dir">${icon('folder', 18)}</span><span data-i="file">${icon('file', 18)}</span><span data-i="link">${icon('link', 18)}</span><span data-i="other">${icon('file', 18)}</span>
<span data-i="archive">${icon('archive', 14)}</span><span data-i="edit">${icon('edit', 14)}</span><span data-i="trash">${icon('trash', 14)}</span><span data-i="download">${icon('download', 14)}</span><span data-i="dots">${icon('dots', 16)}</span><span data-i="move">${icon('move', 14)}</span><span data-i="copy">${icon('copy', 14)}</span><span data-i="lock">${icon('lock', 14)}</span><span data-i="x">${icon('x', 14)}</span>
</template>
</section>
${canWrite ? `<dialog class="mp-dialog" data-files-dialog aria-labelledby="files-dialog-title">
<form method="dialog" data-files-dialog-form novalidate>
<h2 id="files-dialog-title" data-files-dialog-title>New file</h2>
<p class="mp-muted" data-files-dialog-hint></p>
${dialogField}
<div class="mp-dialog-actions"><button type="button" class="mp-btn-sm" data-files-dialog-cancel>Cancel</button><button type="submit" class="mp-button mp-btn-inline" data-files-dialog-ok>Create</button></div>
</form></dialog>
<dialog class="mp-dialog" data-unarch-dialog aria-labelledby="unarch-title">
<form method="dialog" data-unarch-form novalidate>
<h2 id="unarch-title">Unarchive</h2>
<p data-unarch-text></p>
<div class="mp-field"><label for="unarch-into">Extract into</label><div class="mp-input-wrap"><input id="unarch-into" type="text" maxlength="1000" autocomplete="off" spellcheck="false" autocapitalize="off" data-unarch-into></div><p class="mp-muted">A folder path inside this server, like <code>/</code> or <code>/world</code>. Missing folders are created.</p><p class="mp-error" data-unarch-error hidden></p></div>
<p class="mp-muted">Files with the same name are <strong>replaced</strong>. Links inside the archive are never created. Supports .zip, .tar, .tar.gz, .tgz and .gz.</p>
<p class="mp-muted mp-warn-text" data-unarch-online hidden>This server is running. Replacing files it is using (worlds, plugins, the server jar) can corrupt data or crash it. Stop the server first.</p>
<div class="mp-dialog-actions"><button type="button" class="mp-btn-sm" data-unarch-dialog-cancel>Cancel</button><button type="submit" class="mp-button mp-btn-inline" data-unarch-ok>Unarchive</button></div>
</form></dialog>
<dialog class="mp-dialog" data-files-move aria-labelledby="files-move-title">
<form method="dialog" data-files-move-form novalidate>
<h2 id="files-move-title" data-files-move-title>Move</h2>
<p class="mp-muted" data-files-move-hint></p>
<div class="mp-field"><label for="files-move-to" data-files-move-label>Destination folder</label><div class="mp-input-wrap"><input id="files-move-to" type="text" maxlength="1000" autocomplete="off" spellcheck="false" autocapitalize="off" data-files-move-to></div>
<p class="mp-muted">A folder inside this server, like <code>/</code> or <code>/plugins</code>. It must already exist.</p><p class="mp-error" data-files-move-error hidden></p></div>
<div class="mp-dialog-actions"><button type="button" class="mp-btn-sm" data-files-move-cancel>Cancel</button><button type="submit" class="mp-button mp-btn-inline" data-files-move-ok>Move</button></div>
</form></dialog>
<dialog class="mp-dialog" data-files-perm aria-labelledby="files-perm-title">
<form method="dialog" data-files-perm-form novalidate>
<h2 id="files-perm-title">Permissions</h2>
<p class="mp-muted" data-files-perm-hint></p>
<table class="mp-perm" aria-label="Unix permissions"><thead><tr><th></th><th>Read</th><th>Write</th><th>Execute</th></tr></thead><tbody>
${[['Owner', 'u'], ['Group', 'g'], ['Public', 'o']].map(([l, k]) => `<tr><th scope="row">${l}</th>${[['r', 4], ['w', 2], ['x', 1]].map(([n, v]) => `<td><input type="checkbox" data-perm="${k}${n}" data-bit="${v}" aria-label="${l} ${n === 'r' ? 'read' : n === 'w' ? 'write' : 'execute'}"></td>`).join('')}</tr>`).join('')}
</tbody></table>
<div class="mp-field"><label for="files-perm-mode">Mode</label><div class="mp-input-wrap"><input id="files-perm-mode" type="text" inputmode="numeric" maxlength="3" pattern="[0-7]{3}" autocomplete="off" data-perm-mode></div><p class="mp-error" data-files-perm-error hidden></p></div>
<div class="mp-dialog-actions"><button type="button" class="mp-btn-sm" data-files-perm-cancel>Cancel</button><button type="submit" class="mp-button mp-btn-inline" data-files-perm-ok>Save</button></div>
</form></dialog>
<dialog class="mp-dialog" data-files-confirm aria-labelledby="files-confirm-title">
<form method="dialog" data-files-confirm-form>
<h2 id="files-confirm-title">Delete permanently?</h2>
<p data-files-confirm-text></p>
<ul class="mp-dialog-list" data-files-confirm-list></ul>
<p class="mp-muted">This cannot be undone. Folders are deleted with everything inside them.</p>
<p class="mp-muted mp-warn-text" data-files-confirm-online hidden>This server is running. Deleting files it is using (worlds, plugins, the server jar) can corrupt data or crash it.</p>
<p class="mp-error" data-files-confirm-error hidden></p>
<div class="mp-dialog-actions"><button type="button" class="mp-btn-sm" data-files-confirm-cancel>Cancel</button><button type="submit" class="mp-button mp-button-danger mp-btn-inline" data-files-confirm-ok>Delete</button></div>
</form></dialog>` : ''}
<dialog class="mp-dialog mp-editor" data-files-editor aria-labelledby="files-editor-title">
<form method="dialog" data-files-editor-form>
<div class="mp-editor-head"><h2 id="files-editor-title" data-files-editor-title>Edit file</h2><span class="mp-muted" data-files-editor-meta></span></div>
<label class="mp-sr" for="files-editor-text">File contents</label><textarea id="files-editor-text" class="mp-editor-text" spellcheck="false" autocomplete="off" wrap="off" data-files-editor-text></textarea>
<p class="mp-error" data-files-editor-error hidden></p>
<div class="mp-dialog-actions"><span class="mp-muted mp-editor-hint">Ctrl+S to save</span><button type="button" class="mp-btn-sm" data-files-editor-close>Close</button>${canWrite ? '<button type="submit" class="mp-button mp-btn-inline" data-files-editor-save>Save</button>' : ''}</div>
</form></dialog>`;
  return shell({ title: 'Files', sub: `${s.name} · server directory`, active: 'files', server: { identifier: s.identifier, kind: s.kind, canConsole: acc.has('console.view'), canFiles: true },
    user: ctx.user, csrf: ctx.csrfToken, body, styles: ['/css/files.css'], scripts: ['/js/files.js'] });
}

module.exports = { page };
