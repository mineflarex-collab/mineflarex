'use strict';
// File manager page. Markup only: the listing itself is drawn by public/js/files.js from the JSON API (names are
// untrusted - players and plugins create them - so the client only ever uses textContent / element nodes).
const { esc } = require('../views/layout');
const { icon } = require('../views/icons');
const { shell } = require('./views');

function page({ ctx, server: s, access: acc }) {
  const canWrite = acc.has('files.write');
  const dialogField = `<div class="mp-field"><label for="files-name" data-files-label>Name</label><div class="mp-input-wrap"><input id="files-name" name="name" type="text" maxlength="255" autocomplete="off" spellcheck="false" autocapitalize="off" required data-files-name></div><p class="mp-error" data-files-error hidden></p></div>`;
  const body = `<section class="mp-files-head">
<div class="mp-files-title"><span class="mp-files-tile">${icon('folder', 20)}</span><p class="mp-muted">Manage your server files easily</p></div>
<div class="mp-files-buttons">
<button type="button" class="mp-btn-sm" data-files-refresh aria-label="Refresh">${icon('restart', 14)}</button>
${canWrite ? `<button type="button" class="mp-btn-sm" data-files-new="file">${icon('filePlus', 14)} <span>New File</span></button>
<button type="button" class="mp-btn-sm" data-files-upload>${icon('upload', 14)} <span>Upload</span></button>
<input type="file" multiple hidden data-files-input>
<div class="mp-files-dd"><button type="button" class="mp-button mp-btn-inline mp-files-create" data-files-create aria-haspopup="menu" aria-expanded="false">${icon('plus', 14)} <span>Create</span> ${icon('chevronDown', 14)}</button>
<div class="mp-files-popup" role="menu" data-files-create-menu hidden><button type="button" role="menuitem" data-files-new="folder">${icon('folderPlus', 14)} New Folder</button><button type="button" role="menuitem" data-files-new="file">${icon('filePlus', 14)} New File</button></div></div>` : ''}
 </div>
</section>
<section class="mp-panel mp-files" data-files="${esc(s.identifier)}" data-can-write="${canWrite ? '1' : '0'}" data-status="${esc(s.status)}" data-csrf="${esc(ctx.csrfToken)}">
<div class="mp-files-bar">
<nav class="mp-crumbs" aria-label="Folder path" data-files-crumbs></nav>
<form class="mp-files-search" data-files-search role="search">${icon('search', 15)}<label class="mp-sr" for="files-q">Search files by name</label><input id="files-q" type="search" maxlength="100" placeholder="Search…" autocomplete="off" spellcheck="false" data-files-q><button type="button" class="mp-icon-btn mp-files-clear" data-files-clear aria-label="Clear search" hidden>${icon('x', 14)}</button></form>
</div>
<p class="mp-files-banner" data-files-banner hidden></p>
<div class="mp-files-uploads" data-files-uploads hidden><div class="mp-files-uploads-head"><strong data-files-uploads-title>Uploading</strong><span class="mp-muted">Keep this page open until finished</span></div><ul data-files-upload-list></ul></div>
${canWrite ? `<div class="mp-files-bulk" data-files-bulk hidden><span data-files-bulk-count></span><button type="button" class="mp-btn-sm mp-btn-stop" data-files-bulk-delete>${icon('trash', 13)} <span>Delete selected</span></button><button type="button" class="mp-btn-sm" data-files-bulk-clear>Clear selection</button></div>` : ''}
<div class="mp-table-wrap mp-files-wrap" data-files-wrap aria-busy="true">
<table class="mp-table mp-files-table">
<thead><tr>${canWrite ? '<th class="mp-files-check"><input type="checkbox" data-files-all aria-label="Select all"></th>' : ''}<th>Name</th><th class="mp-files-size">Size</th><th class="mp-files-date">Last Modified</th><th class="mp-files-act"><span class="mp-sr">Actions</span></th></tr></thead>
<tbody data-files-body></tbody>
</table>
<p class="mp-empty mp-files-empty" data-files-empty hidden></p>
</div>
<p class="mp-muted mp-files-foot" data-files-foot role="status" aria-live="polite"></p>
<p class="mp-files-toast" data-files-toast role="status" aria-live="polite" hidden></p>
<div class="mp-files-drop" data-files-drop hidden>${icon('upload', 28)}<span>Drop files to upload</span></div>
<div class="mp-files-popup mp-files-rowmenu" role="menu" data-files-rowmenu hidden></div>
<noscript><p class="mp-empty">The file manager needs JavaScript.</p></noscript>
<template data-files-icons>
<span data-i="dir">${icon('folder', 18)}</span><span data-i="file">${icon('file', 18)}</span><span data-i="link">${icon('link', 18)}</span><span data-i="other">${icon('file', 18)}</span>
<span data-i="edit">${icon('edit', 14)}</span><span data-i="trash">${icon('trash', 14)}</span><span data-i="download">${icon('download', 14)}</span><span data-i="dots">${icon('dots', 16)}</span><span data-i="x">${icon('x', 14)}</span>
</template>
</section>
${canWrite ? `<dialog class="mp-dialog" data-files-dialog aria-labelledby="files-dialog-title">
<form method="dialog" data-files-dialog-form novalidate>
<h2 id="files-dialog-title" data-files-dialog-title>New file</h2>
<p class="mp-muted" data-files-dialog-hint></p>
${dialogField}
<div class="mp-dialog-actions"><button type="button" class="mp-btn-sm" data-files-dialog-cancel>Cancel</button><button type="submit" class="mp-button mp-btn-inline" data-files-dialog-ok>Create</button></div>
</form></dialog>
<dialog class="mp-dialog" data-files-confirm aria-labelledby="files-confirm-title">
<form method="dialog" data-files-confirm-form>
<h2 id="files-confirm-title">Delete permanently?</h2>
<p data-files-confirm-text></p>
<ul class="mp-dialog-list" data-files-confirm-list></ul>
<p class="mp-muted">This cannot be undone. Folders are deleted with everything inside them.</p>
<p class="mp-muted mp-warn-text" data-files-confirm-online hidden>This server is running. Deleting files it is using (worlds, plugins, the server jar) can corrupt data or crash it.</p>
<p class="mp-error" data-files-confirm-error hidden></p>
<div class="mp-dialog-actions"><button type="button" class="mp-btn-sm" data-files-confirm-cancel>Cancel</button><button type="submit" class="mp-button mp-button-danger mp-btn-inline" data-files-confirm-ok>Delete</button></div>
</form></dialog>` : ''}
<dialog class="mp-dialog mp-editor" data-files-editor aria-labelledby="files-editor-title">
<form method="dialog" data-files-editor-form>
<div class="mp-editor-head"><h2 id="files-editor-title" data-files-editor-title>Edit file</h2><span class="mp-muted" data-files-editor-meta></span></div>
<label class="mp-sr" for="files-editor-text">File contents</label><textarea id="files-editor-text" class="mp-editor-text" spellcheck="false" autocomplete="off" wrap="off" data-files-editor-text></textarea>
<p class="mp-error" data-files-editor-error hidden></p>
<div class="mp-dialog-actions"><span class="mp-muted mp-editor-hint">Ctrl+S to save</span><button type="button" class="mp-btn-sm" data-files-editor-close>Close</button>${canWrite ? '<button type="submit" class="mp-button mp-btn-inline" data-files-editor-save>Save</button>' : ''}</div>
</form></dialog>`;
  return shell({ title: 'Files', sub: `${s.name} · server directory`, active: 'files', server: { identifier: s.identifier, kind: s.kind, canConsole: acc.has('console.view'), canFiles: true },
    user: ctx.user, csrf: ctx.csrfToken, body, styles: ['/css/files.css'], scripts: ['/js/files.js'] });
}

module.exports = { page };
