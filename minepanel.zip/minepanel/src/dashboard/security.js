'use strict';
// Account security routes: two-step verification (authenticator app) and the Discord link.
//   GET  /dashboard/settings/2fa                  setup page (QR code + key)
//   POST /dashboard/settings/2fa/enable           { code }               -> shows the backup codes once
//   POST /dashboard/settings/2fa/disable          { current_password }
//   POST /dashboard/settings/2fa/backup-codes     { current_password }   -> new backup codes
//   POST /dashboard/settings/discord/unlink
const { requireAuth } = require('../middleware/auth');
const { rateLimit } = require('../lib/rateLimit');
const { verifyPassword } = require('../lib/crypto');
const users = require('../services/users');
const twofactor = require('../services/twofactor');
const oauth = require('../services/oauth');
const activity = require('./services/activity');
const sv = require('./securityViews');

module.exports = function register(router) {
  const hour = 60 * 60 * 1000;
  const log = (ctx, type, message) => activity.record({ userId: ctx.user.id, type, message, ip: ctx.ip });
  const passwordOk = async (ctx) => verifyPassword(String(ctx.body.current_password ?? ''), users.findById(ctx.user.id).password_hash);

  router.get('/dashboard/settings/2fa', requireAuth, (ctx) => {
    if (twofactor.isEnabled(ctx.user.id)) { ctx.flash('info', 'Two-step verification is already on.'); return ctx.redirect('/dashboard/settings'); }
    return ctx.html(200, sv.setupPage({ ctx, secret: twofactor.pendingSecret(ctx.user.id) || twofactor.beginSetup(ctx.user.id) }));
  });

  router.post('/dashboard/settings/2fa/enable', requireAuth, rateLimit({ name: '2fa-enable', windowMs: hour, max: 20 }), (ctx) => {
    if (twofactor.isEnabled(ctx.user.id)) return ctx.redirect('/dashboard/settings');
    const secret = twofactor.pendingSecret(ctx.user.id);
    if (!secret) return ctx.redirect('/dashboard/settings/2fa');
    const codes = twofactor.confirmSetup(ctx.user.id, ctx.body.code);
    if (!codes) return ctx.html(422, sv.setupPage({ ctx, secret, error: 'That code is not right. Make sure the time on your phone is automatic, then try the new code.' }));
    log(ctx, 'account.2fa_on', `${ctx.user.username} turned on two-step verification`);
    return ctx.html(200, sv.backupPage({ ctx, codes, fresh: true }));
  });

  router.post('/dashboard/settings/2fa/disable', requireAuth, rateLimit({ name: '2fa-disable', windowMs: hour, max: 10 }), async (ctx) => {
    if (!(await passwordOk(ctx))) { ctx.flash('error', 'Wrong password. Two-step verification is still on.'); return ctx.redirect('/dashboard/settings'); }
    twofactor.disable(ctx.user.id);
    log(ctx, 'account.2fa_off', `${ctx.user.username} turned off two-step verification`);
    ctx.flash('success', 'Two-step verification is off.');
    return ctx.redirect('/dashboard/settings');
  });

  router.post('/dashboard/settings/2fa/backup-codes', requireAuth, rateLimit({ name: '2fa-codes', windowMs: hour, max: 10 }), async (ctx) => {
    if (!twofactor.isEnabled(ctx.user.id)) return ctx.redirect('/dashboard/settings');
    if (!(await passwordOk(ctx))) { ctx.flash('error', 'Wrong password. Your backup codes were not changed.'); return ctx.redirect('/dashboard/settings'); }
    log(ctx, 'account.2fa_codes', `${ctx.user.username} made new backup codes`);
    return ctx.html(200, sv.backupPage({ ctx, codes: twofactor.newBackupCodes(ctx.user.id), fresh: false }));
  });

  router.post('/dashboard/settings/discord/unlink', requireAuth, (ctx) => {
    oauth.unlink('discord', ctx.user.id);
    log(ctx, 'account.discord_unlink', `${ctx.user.username} unlinked Discord`);
    ctx.flash('success', 'Discord was unlinked.');
    return ctx.redirect('/dashboard/settings');
  });
};
