'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const config = require('./config');

if (config.dbPath !== ':memory:') fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });
const db = new DatabaseSync(config.dbPath);
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');

// Append new migrations to the end; never edit old ones.
const MIGRATIONS = [`
  CREATE TABLE users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
    is_active     INTEGER NOT NULL DEFAULT 1,
    failed_logins INTEGER NOT NULL DEFAULT 0,
    locked_until  INTEGER,
    last_login_at INTEGER,
    created_at    INTEGER NOT NULL,
    updated_at    INTEGER NOT NULL
  );
  CREATE TABLE sessions (
    id           TEXT PRIMARY KEY,            -- sha256 of the cookie token
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at   INTEGER NOT NULL,
    last_seen_at INTEGER NOT NULL,
    expires_at   INTEGER NOT NULL,
    ttl_ms       INTEGER NOT NULL,
    remember     INTEGER NOT NULL DEFAULT 0,
    ip           TEXT,
    user_agent   TEXT
  );
  CREATE INDEX idx_sessions_user ON sessions(user_id);
  CREATE INDEX idx_sessions_expires ON sessions(expires_at);
  CREATE TABLE password_resets (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL UNIQUE,          -- sha256 of the emailed token
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    used_at    INTEGER,
    ip         TEXT
  );
  CREATE INDEX idx_resets_user ON password_resets(user_id);
`, `
  ALTER TABLE users ADD COLUMN first_name TEXT;
  ALTER TABLE users ADD COLUMN last_name TEXT;
`, `
  -- Admin > Settings: panel name and logo (the logo bytes live in panel_assets)
  CREATE TABLE panel_settings (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    updated_at INTEGER NOT NULL
  );
  CREATE TABLE panel_assets (
    name       TEXT PRIMARY KEY,
    mime       TEXT NOT NULL,
    data       BLOB NOT NULL,
    updated_at INTEGER NOT NULL
  );
`, `
  -- Main administrator: the first admin (the account created by the installer). Nobody else can change, demote, disable or delete it.
  ALTER TABLE users ADD COLUMN is_owner INTEGER NOT NULL DEFAULT 0;
  CREATE UNIQUE INDEX idx_users_owner ON users(is_owner) WHERE is_owner = 1;
  UPDATE users SET is_owner = 1 WHERE id = (SELECT MIN(id) FROM users WHERE role = 'admin');
`, `
  -- Admin privacy: the main admin can hide every other person's servers from a chosen admin (see Admin > Admin privacy).
  ALTER TABLE users ADD COLUMN servers_hidden INTEGER NOT NULL DEFAULT 0;
`, `
  -- Two-step verification (Google Authenticator / any TOTP app) and "Login with Discord"
  ALTER TABLE users ADD COLUMN totp_secret TEXT;                      -- AES-256-GCM sealed, never clear text
  ALTER TABLE users ADD COLUMN totp_enabled INTEGER NOT NULL DEFAULT 0;
  ALTER TABLE users ADD COLUMN totp_last_step INTEGER NOT NULL DEFAULT 0;   -- a code can be used only once
  CREATE TABLE totp_backup_codes (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code_hash TEXT NOT NULL,
    used_at   INTEGER
  );
  CREATE INDEX idx_backup_user ON totp_backup_codes(user_id);
  CREATE TABLE oauth_accounts (
    provider    TEXT NOT NULL,
    provider_id TEXT NOT NULL,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    handle      TEXT,
    created_at  INTEGER NOT NULL,
    PRIMARY KEY (provider, provider_id)
  );
  CREATE INDEX idx_oauth_user ON oauth_accounts(user_id);
`];

const version = db.prepare('PRAGMA user_version').get().user_version;
for (let i = version; i < MIGRATIONS.length; i++) {
  db.exec('BEGIN');
  try { db.exec(MIGRATIONS[i]); db.exec(`PRAGMA user_version = ${i + 1}`); db.exec('COMMIT'); }
  catch (err) { db.exec('ROLLBACK'); throw err; }
}

module.exports = db;
