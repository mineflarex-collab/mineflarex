'use strict';
// "Login with Discord": links a Discord account to an existing panel account. Signing in with Discord only works for
// accounts that were linked while signed in (Account settings), so nobody can take over an account by matching e-mails.
const crypto = require('node:crypto');
const db = require('../db');
const config = require('../config');
const { hmac, safeEqual } = require('../lib/crypto');

const q = {
  byProvider: db.prepare('SELECT * FROM oauth_accounts WHERE provider = ? AND provider_id = ?'),
  forUser: db.prepare('SELECT * FROM oauth_accounts WHERE provider = ? AND user_id = ?'),
  link: db.prepare('INSERT INTO oauth_accounts (provider, provider_id, user_id, handle, created_at) VALUES (?, ?, ?, ?, ?)'),
  unlink: db.prepare('DELETE FROM oauth_accounts WHERE provider = ? AND user_id = ?')
};
const find = (provider, id) => q.byProvider.get(provider, String(id)) || null;
const linkedFor = (provider, userId) => q.forUser.get(provider, userId) || null;
const link = (provider, id, userId, handle) => q.link.run(provider, String(id), userId, handle || null, Date.now());
const unlink = (provider, userId) => q.unlink.run(provider, userId);

// ---- state: signed, short-lived, bound to the browser by a cookie (CSRF protection of the OAuth flow)
const STATE_COOKIE = 'mp_oauth';
function makeState({ mode, userId = 0, next = '' }) {
  const nonce = crypto.randomBytes(16).toString('base64url');
  const payload = Buffer.from(JSON.stringify({ n: nonce, m: mode, u: userId, x: next, e: Date.now() + 10 * 60 * 1000 })).toString('base64url');
  return `${payload}.${hmac(config.secret, `oauth:${payload}`)}`;
}
function readState(raw) {
  const [payload, sig] = String(raw || '').split('.');
  if (!payload || !sig || !safeEqual(sig, hmac(config.secret, `oauth:${payload}`))) return null;
  try { const s = JSON.parse(Buffer.from(payload, 'base64url').toString()); return s.e > Date.now() ? s : null; } catch { return null; }
}

const redirectUri = () => `${config.baseUrl}/auth/discord/callback`;
const authorizeUrl = (state) => `https://discord.com/oauth2/authorize?${new URLSearchParams({
  client_id: config.discord.clientId, response_type: 'code', redirect_uri: redirectUri(), scope: 'identify', state, prompt: 'consent' })}`;

/** Exchanges the code and reads the Discord profile. Returns { id, handle } or throws. */
async function discordProfile(code) {
  const t = await fetch('https://discord.com/api/oauth2/token', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, signal: AbortSignal.timeout(10000),
    body: new URLSearchParams({ client_id: config.discord.clientId, client_secret: config.discord.clientSecret, grant_type: 'authorization_code', code: String(code), redirect_uri: redirectUri() })
  });
  if (!t.ok) throw new Error(`Discord token request failed (${t.status})`);
  const { access_token: token } = await t.json();
  const u = await fetch('https://discord.com/api/users/@me', { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(10000) });
  if (!u.ok) throw new Error(`Discord profile request failed (${u.status})`);
  const p = await u.json();
  if (!p || !/^\d{5,30}$/.test(String(p.id))) throw new Error('Discord returned no user id');
  return { id: String(p.id), handle: String(p.global_name || p.username || '').slice(0, 64) };
}

module.exports = { STATE_COOKIE, find, linkedFor, link, unlink, makeState, readState, authorizeUrl, discordProfile, redirectUri };
