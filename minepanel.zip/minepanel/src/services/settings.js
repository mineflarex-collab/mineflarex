'use strict';
// Panel-wide settings edited from Admin > Settings: the panel name and the logo.
// The name falls back to PANEL_NAME / the built-in default, the logo to /img/logo.png.
const db = require('../db');
const config = require('../config');

const q = {
  get: db.prepare('SELECT value FROM panel_settings WHERE key = ?'),
  set: db.prepare('INSERT INTO panel_settings (key, value, updated_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at'),
  del: db.prepare('DELETE FROM panel_settings WHERE key = ?'),
  asset: db.prepare('SELECT mime, data, updated_at FROM panel_assets WHERE name = ?'),
  assetMeta: db.prepare('SELECT updated_at FROM panel_assets WHERE name = ?'),
  putAsset: db.prepare('INSERT INTO panel_assets (name, mime, data, updated_at) VALUES (?, ?, ?, ?) ON CONFLICT(name) DO UPDATE SET mime = excluded.mime, data = excluded.data, updated_at = excluded.updated_at'),
  delAsset: db.prepare('DELETE FROM panel_assets WHERE name = ?')
};

const NAME_MAX = 32, LOGO_MAX_BYTES = 1024 * 1024;

const brand = () => q.get.get('name')?.value || config.brand;
const hasCustomLogo = () => !!q.assetMeta.get('logo');
/** URL of the logo; the version in the query string busts browser caches after a change. */
function logoUrl() {
  const m = q.assetMeta.get('logo');
  return m ? `/brand/logo?v=${m.updated_at}` : '/img/logo.png';
}

/** Returns an error message, or null when the name is acceptable. */
function validateName(v) {
  const n = String(v ?? '').trim();
  if (n.length < 2 || n.length > NAME_MAX) return `Use 2–${NAME_MAX} characters.`;
  if (/[\u0000-\u001f\u007f<>]/.test(n)) return 'Do not use control characters, < or >.';
  return null;
}
const setBrand = (name) => { q.set.run('name', String(name).trim(), Date.now()); };
const resetBrand = () => { q.del.run('name'); };

/** Identifies png / jpeg / webp / gif by their magic bytes (never trusts the declared type). SVG is refused on purpose. */
function sniffImage(buf) {
  if (buf.length > 12 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.length > 12 && buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') return 'image/webp';
  if (buf.length > 6 && /^GIF8[79]a$/.test(buf.toString('latin1', 0, 6))) return 'image/gif';
  return null;
}
/** Stores the logo. Returns null on success or an error message. */
function setLogo(buf) {
  if (!buf.length) return 'Choose an image file first.';
  if (buf.length > LOGO_MAX_BYTES) return 'The logo must be 1 MB or smaller.';
  const mime = sniffImage(buf);
  if (!mime) return 'Use a PNG, JPG, WebP or GIF image.';
  q.putAsset.run('logo', mime, buf, Date.now());
  return null;
}
const resetLogo = () => { q.delAsset.run('logo'); };
const getLogo = () => {
  const r = q.asset.get('logo');
  return r ? { mime: r.mime, data: Buffer.from(r.data), updatedAt: r.updated_at } : null;
};

module.exports = { brand, logoUrl, hasCustomLogo, validateName, setBrand, resetBrand, setLogo, resetLogo, getLogo, sniffImage, NAME_MAX, LOGO_MAX_BYTES };
