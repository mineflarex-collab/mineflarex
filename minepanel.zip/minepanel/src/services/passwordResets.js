'use strict';
const db = require('../db');
const config = require('../config');
const { randomToken, sha256 } = require('../lib/crypto');
const mailer = require('../lib/mailer');
const users = require('./users');
const sessions = require('./sessions');

const q = {
  latest: db.prepare('SELECT created_at FROM password_resets WHERE user_id = ? ORDER BY created_at DESC LIMIT 1'),
  clear: db.prepare('DELETE FROM password_resets WHERE user_id = ?'),
  insert: db.prepare('INSERT INTO password_resets (user_id, token_hash, created_at, expires_at, ip) VALUES (?, ?, ?, ?, ?)'),
  peek: db.prepare('SELECT user_id FROM password_resets WHERE token_hash = ? AND used_at IS NULL AND expires_at > ?'),
  consume: db.prepare('UPDATE password_resets SET used_at = ? WHERE token_hash = ? AND used_at IS NULL AND expires_at > ? RETURNING user_id'),
  purge: db.prepare('DELETE FROM password_resets WHERE expires_at <= ? OR used_at IS NOT NULL')
};

/** Creates and emails a reset link. Silent no-op for unknown/disabled accounts (caller shows a generic message). */
async function request(email, ip) {
  const user = users.findByEmail(email);
  if (!user || !user.is_active) return false;
  const last = q.latest.get(user.id);
  if (last && Date.now() - last.created_at < config.reset.cooldownMs) return false;
  const token = randomToken(32), now = Date.now();
  q.clear.run(user.id); // only the newest link is valid
  q.insert.run(user.id, sha256(token), now, now + config.reset.ttlMs, ip);
  const link = `${config.baseUrl}/reset-password?token=${token}`;
  await mailer.send({
    to: user.email,
    subject: 'Reset your minePanel password',
    text: `Hi ${user.username},\n\nUse the link below to choose a new password. It expires in ${Math.round(config.reset.ttlMs / 60000)} minutes and can be used once.\n\n${link}\n\nIf you didn't request this, you can ignore this email — your password won't change.\n`
  });
  return true;
}

const isValid = (token) => typeof token === 'string' && token.length >= 20 && token.length <= 100 && !!q.peek.get(sha256(token), Date.now());

/** Atomically burns the token, sets the new password hash and signs the user out everywhere. */
function consume(token, passwordHash) {
  if (typeof token !== 'string' || token.length > 100) return false;
  db.exec('BEGIN IMMEDIATE');
  try {
    const r = q.consume.get(Date.now(), sha256(token), Date.now());
    if (!r) { db.exec('ROLLBACK'); return false; }
    users.setPassword(r.user_id, passwordHash);
    q.clear.run(r.user_id);
    sessions.destroyAllForUser(r.user_id);
    db.exec('COMMIT');
    return true;
  } catch (err) { db.exec('ROLLBACK'); throw err; }
}

const purgeExpired = () => q.purge.run(Date.now());

module.exports = { request, isValid, consume, purgeExpired };
