'use strict';
// Two-step verification with an authenticator app (Google Authenticator, Authy, Microsoft Authenticator, ...).
const db = require('../db');
const totp = require('../lib/totp');
const config = require('../config');
const { sha256, hmac, safeEqual } = require('../lib/crypto');

const q = {
  row: db.prepare('SELECT id, totp_secret, totp_enabled, totp_last_step FROM users WHERE id = ?'),
  setSecret: db.prepare('UPDATE users SET totp_secret = ?, totp_enabled = 0, totp_last_step = 0 WHERE id = ?'),
  enable: db.prepare('UPDATE users SET totp_enabled = 1, totp_last_step = ? WHERE id = ?'),
  step: db.prepare('UPDATE users SET totp_last_step = ? WHERE id = ? AND totp_last_step < ?'),
  wipe: db.prepare('UPDATE users SET totp_secret = NULL, totp_enabled = 0, totp_last_step = 0 WHERE id = ?'),
  delCodes: db.prepare('DELETE FROM totp_backup_codes WHERE user_id = ?'),
  addCode: db.prepare('INSERT INTO totp_backup_codes (user_id, code_hash) VALUES (?, ?)'),
  useCode: db.prepare('UPDATE totp_backup_codes SET used_at = ? WHERE user_id = ? AND code_hash = ? AND used_at IS NULL'),
  left: db.prepare('SELECT COUNT(*) AS n FROM totp_backup_codes WHERE user_id = ? AND used_at IS NULL')
};

const isEnabled = (userId) => !!q.row.get(userId)?.totp_enabled;
const backupLeft = (userId) => q.left.get(userId).n;
const normCode = (c) => String(c ?? '').toLowerCase().replace(/[\s-]/g, '');

/** Starts (or restarts) setup: a fresh secret that only counts once a first code from the app is confirmed. */
function beginSetup(userId) {
  const secret = totp.newSecret();
  q.setSecret.run(totp.seal(secret), userId);
  return secret;
}
/** The secret of a setup that is not finished yet (so the page can be reloaded), or null. */
function pendingSecret(userId) {
  const r = q.row.get(userId);
  return r && r.totp_secret && !r.totp_enabled ? totp.open(r.totp_secret) : null;
}

function newBackupCodes(userId) {
  const codes = totp.backupCodes();
  db.exec('BEGIN');
  try { q.delCodes.run(userId); for (const c of codes) q.addCode.run(userId, sha256(normCode(c))); db.exec('COMMIT'); } catch (e) { db.exec('ROLLBACK'); throw e; }
  return codes;
}

/** Finishes setup when the code from the app is right. Returns the one-time backup codes, or null. */
function confirmSetup(userId, code) {
  const r = q.row.get(userId);
  if (!r || r.totp_enabled || !r.totp_secret) return null;
  const secret = totp.open(r.totp_secret), step = secret && totp.verify(secret, code);
  if (step === null || step === undefined || !secret) return null;
  q.enable.run(step, userId);
  return newBackupCodes(userId);
}

/** Login check: the 6-digit code (each one only once) or an unused backup code. Returns 'totp' | 'backup' | null. */
function check(userId, input) {
  const r = q.row.get(userId);
  if (!r || !r.totp_enabled) return null;
  const secret = totp.open(r.totp_secret);
  const step = secret ? totp.verify(secret, input) : null;
  if (step !== null) return q.step.run(step, userId, step).changes ? 'totp' : null;   // same step again = replay
  const c = normCode(input);
  if (/^[a-z0-9]{8}$/.test(c) && q.useCode.run(Date.now(), userId, sha256(c)).changes) return 'backup';
  return null;
}

function disable(userId) { q.wipe.run(userId); q.delCodes.run(userId); }

// ---- "password was right, code still needed": a signed 5-minute token in a cookie (it grants nothing by itself)
const PENDING_COOKIE = 'mp_2fa', PENDING_MS = 5 * 60 * 1000;
function makePending(userId, remember, next) {
  const payload = Buffer.from(JSON.stringify({ u: userId, r: remember ? 1 : 0, x: next || '', e: Date.now() + PENDING_MS })).toString('base64url');
  return `${payload}.${hmac(config.secret, `2fa:${payload}`)}`;
}
function readPending(raw) {
  const [payload, sig] = String(raw || '').split('.');
  if (!payload || !sig || !safeEqual(sig, hmac(config.secret, `2fa:${payload}`))) return null;
  try { const t = JSON.parse(Buffer.from(payload, 'base64url').toString()); return t.e > Date.now() ? { userId: t.u, remember: !!t.r, next: t.x || null } : null; } catch { return null; }
}

module.exports = { PENDING_COOKIE, PENDING_MS, makePending, readPending, isEnabled, backupLeft, beginSetup, pendingSecret, confirmSetup, check, disable, newBackupCodes };
