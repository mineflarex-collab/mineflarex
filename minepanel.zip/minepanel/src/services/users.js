'use strict';
const db = require('../db');
const config = require('../config');

const normEmail = (e) => String(e).trim().toLowerCase();
const row = (r) => r || null;

const q = {
  byId: db.prepare('SELECT * FROM users WHERE id = ?'),
  byEmail: db.prepare('SELECT * FROM users WHERE email = ?'),
  byUsername: db.prepare('SELECT * FROM users WHERE username = ?'),
  insert: db.prepare('INSERT INTO users (username, email, password_hash, role, created_at, updated_at, first_name, last_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'),
  fail: db.prepare(`UPDATE users SET failed_logins = failed_logins + 1,
      locked_until = CASE WHEN failed_logins + 1 >= ? THEN ? ELSE locked_until END WHERE id = ?`),
  ok: db.prepare('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = ? WHERE id = ?'),
  clearLock: db.prepare('UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id = ?'),
  setPassword: db.prepare('UPDATE users SET password_hash = ?, failed_logins = 0, locked_until = NULL, updated_at = ? WHERE id = ?'),
  setRole: db.prepare('UPDATE users SET role = ?, updated_at = ? WHERE id = ?')
};

const findById = (id) => row(q.byId.get(id));
const findByEmail = (e) => row(q.byEmail.get(normEmail(e)));
const findByUsername = (u) => row(q.byUsername.get(String(u).trim()));
const findByLogin = (id) => (String(id).includes('@') ? findByEmail(id) : findByUsername(id)) || null;

const MAIN_ADMIN = 'The main administrator account cannot be demoted, disabled or deleted.';
/** The first admin ever created (the installer's account) becomes the main administrator; later admins never do. */
const claimOwnerIfNone = (id) => { db.prepare('UPDATE users SET is_owner = 1 WHERE id = ? AND NOT EXISTS (SELECT 1 FROM users WHERE is_owner = 1)').run(id); };
const isOwner = (id) => { const u = findById(id); return !!(u && u.is_owner); };

const POLICY_KEY = 'new_admin_hide_servers';
/** Policy for admins created or promoted from now on: 1 = they cannot see or open other people's servers. */
const hideNewAdmins = () => db.prepare('SELECT value FROM panel_settings WHERE key = ?').get(POLICY_KEY)?.value === '1';
const setHideNewAdmins = (on) => { db.prepare('INSERT INTO panel_settings (key, value, updated_at) VALUES (?, ?, ?) ON CONFLICT (key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at').run(POLICY_KEY, on ? '1' : '0', Date.now()); };
const applyAdminPolicy = (id) => { if (hideNewAdmins()) db.prepare('UPDATE users SET servers_hidden = 1 WHERE id = ? AND is_owner = 0').run(id); };
/** Per-admin switch (the main admin is never restricted). */
const setServersHidden = (id, hidden) => {
  if (isOwner(id)) throw new Error('The main administrator always sees every server.');
  db.prepare("UPDATE users SET servers_hidden = ?, updated_at = ? WHERE id = ? AND role = 'admin'").run(hidden ? 1 : 0, Date.now(), id);
};
const listOtherAdmins = () => db.prepare("SELECT * FROM users WHERE role = 'admin' AND is_owner = 0 ORDER BY username COLLATE NOCASE").all();

function create({ username, email, passwordHash, role = 'user', firstName = null, lastName = null }) {
  const now = Date.now();
  const r = q.insert.run(String(username).trim(), normEmail(email), passwordHash, role, now, now, firstName || null, lastName || null);
  const created = Number(r.lastInsertRowid);
  if (role === 'admin') { claimOwnerIfNone(created); applyAdminPolicy(created); }
  return findById(created);
}

/** Returns which field collided ('email' | 'username') or null if err isn't a uniqueness error. */
function uniqueViolation(err) {
  const m = /UNIQUE constraint failed: users\.(\w+)/.exec(err?.message || '');
  return m ? m[1] : null;
}

const recordFailure = (id) => q.fail.run(config.lockout.maxAttempts, Date.now() + config.lockout.durationMs, id);
const recordSuccess = (id) => q.ok.run(Date.now(), id);
const clearLock = (id) => q.clearLock.run(id);
const setPassword = (id, hash) => q.setPassword.run(hash, Date.now(), id);
const setRole = (id, role) => {
  if (role !== 'admin' && isOwner(id)) throw new Error(MAIN_ADMIN);
  const was = findById(id)?.role;
  q.setRole.run(role, Date.now(), id);
  if (role === 'admin') { claimOwnerIfNone(id); if (was !== 'admin') applyAdminPolicy(id); }
  else db.prepare('UPDATE users SET servers_hidden = 0 WHERE id = ?').run(id);
};

/** Admin > Users: accounts with their server counts, newest first, optionally filtered by username / email. */
function listAll(search = '', limit = 500) {
  const t = String(search).trim().slice(0, 100), like = `%${t.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
  // prepared lazily: the servers table belongs to the dashboard migrations, which load after this module
  return db.prepare(`SELECT u.*, (SELECT COUNT(*) FROM servers s WHERE s.owner_id = u.id) AS server_count FROM users u
                     WHERE (? = '' OR u.username LIKE ? ESCAPE '\\' OR u.email LIKE ? ESCAPE '\\')
                     ORDER BY u.created_at DESC, u.id DESC LIMIT ?`).all(t, like, like, limit);
}
const setActive = (id, active) => { if (!active && isOwner(id)) throw new Error(MAIN_ADMIN); db.prepare('UPDATE users SET is_active = ?, updated_at = ? WHERE id = ?').run(active ? 1 : 0, Date.now(), id); };
const countActiveAdmins = () => db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND is_active = 1").get().n;

const publicUser = (u) => u && ({ id: u.id, username: u.username, email: u.email, role: u.role, is_owner: !!u.is_owner, firstName: u.first_name, lastName: u.last_name, createdAt: u.created_at, lastLoginAt: u.last_login_at });

/** Admin > Edit user: username, email and role in one statement (throws a UNIQUE error if taken). */
const update = (id, { username, email, role, firstName, lastName }) => {
  const cur = findById(id);
  if (cur.is_owner && role !== 'admin') throw new Error(MAIN_ADMIN);
  db.prepare('UPDATE users SET username = ?, email = ?, role = ?, first_name = ?, last_name = ?, updated_at = ? WHERE id = ?').run(String(username).trim(), normEmail(email), role,
    firstName === undefined ? cur.first_name : (firstName || null), lastName === undefined ? cur.last_name : (lastName || null), Date.now(), id);
};
/** Admin > Delete user (the caller makes sure the account owns no servers). */
const remove = (id) => { if (isOwner(id)) throw new Error(MAIN_ADMIN); db.prepare('DELETE FROM users WHERE id = ?').run(id); };

module.exports = { update, findById, findByEmail, findByUsername, findByLogin, create, uniqueViolation,
  remove, recordFailure, recordSuccess, clearLock, setPassword, setRole, publicUser, listAll, setActive, countActiveAdmins, isOwner,
  hideNewAdmins, setHideNewAdmins, setServersHidden, listOtherAdmins };
