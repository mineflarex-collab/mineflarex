'use strict';
const db = require('../db');
const config = require('../config');

const normEmail = (e) => String(e).trim().toLowerCase();
const row = (r) => r || null;

const q = {
  byId: db.prepare('SELECT * FROM users WHERE id = ?'),
  byEmail: db.prepare('SELECT * FROM users WHERE email = ?'),
  byUsername: db.prepare('SELECT * FROM users WHERE username = ?'),
  insert: db.prepare('INSERT INTO users (username, email, password_hash, role, created_at, updated_at, first_name, last_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'),
  fail: db.prepare(`UPDATE users SET failed_logins = failed_logins + 1,
      locked_until = CASE WHEN failed_logins + 1 >= ? THEN ? ELSE locked_until END WHERE id = ?`),
  ok: db.prepare('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = ? WHERE id = ?'),
  clearLock: db.prepare('UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id = ?'),
  setPassword: db.prepare('UPDATE users SET password_hash = ?, failed_logins = 0, locked_until = NULL, updated_at = ? WHERE id = ?'),
  setRole: db.prepare('UPDATE users SET role = ?, updated_at = ? WHERE id = ?')
};

const findById = (id) => row(q.byId.get(id));
const findByEmail = (e) => row(q.byEmail.get(normEmail(e)));
const findByUsername = (u) => row(q.byUsername.get(String(u).trim()));
const findByLogin = (id) => (String(id).includes('@') ? findByEmail(id) : findByUsername(id)) || null;

function create({ username, email, passwordHash, role = 'user', firstName = null, lastName = null }) {
  const now = Date.now();
  const r = q.insert.run(String(username).trim(), normEmail(email), passwordHash, role, now, now, firstName || null, lastName || null);
  return findById(Number(r.lastInsertRowid));
}

/** Returns which field collided ('email' | 'username') or null if err isn't a uniqueness error. */
function uniqueViolation(err) {
  const m = /UNIQUE constraint failed: users\.(\w+)/.exec(err?.message || '');
  return m ? m[1] : null;
}

const recordFailure = (id) => q.fail.run(config.lockout.maxAttempts, Date.now() + config.lockout.durationMs, id);
const recordSuccess = (id) => q.ok.run(Date.now(), id);
const clearLock = (id) => q.clearLock.run(id);
const setPassword = (id, hash) => q.setPassword.run(hash, Date.now(), id);
const setRole = (id, role) => q.setRole.run(role, Date.now(), id);

/** Admin > Users: accounts with their server counts, newest first, optionally filtered by username / email. */
function listAll(search = '', limit = 500) {
  const t = String(search).trim().slice(0, 100), like = `%${t.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
  // prepared lazily: the servers table belongs to the dashboard migrations, which load after this module
  return db.prepare(`SELECT u.*, (SELECT COUNT(*) FROM servers s WHERE s.owner_id = u.id) AS server_count FROM users u
                     WHERE (? = '' OR u.username LIKE ? ESCAPE '\\' OR u.email LIKE ? ESCAPE '\\')
                     ORDER BY u.created_at DESC, u.id DESC LIMIT ?`).all(t, like, like, limit);
}
const setActive = (id, active) => { db.prepare('UPDATE users SET is_active = ?, updated_at = ? WHERE id = ?').run(active ? 1 : 0, Date.now(), id); };
const countActiveAdmins = () => db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND is_active = 1").get().n;

const publicUser = (u) => u && ({ id: u.id, username: u.username, email: u.email, role: u.role, firstName: u.first_name, lastName: u.last_name, createdAt: u.created_at, lastLoginAt: u.last_login_at });

module.exports = { findById, findByEmail, findByUsername, findByLogin, create, uniqueViolation,
  recordFailure, recordSuccess, clearLock, setPassword, setRole, publicUser, listAll, setActive, countActiveAdmins };
