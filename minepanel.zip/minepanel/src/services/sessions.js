'use strict';
const db = require('../db');
const config = require('../config');
const { randomToken, sha256 } = require('../lib/crypto');
const { findById, publicUser } = require('./users');

const q = {
  insert: db.prepare(`INSERT INTO sessions (id, user_id, created_at, last_seen_at, expires_at, ttl_ms, remember, ip, user_agent)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`),
  get: db.prepare('SELECT * FROM sessions WHERE id = ?'),
  touch: db.prepare('UPDATE sessions SET last_seen_at = ?, expires_at = ? WHERE id = ?'),
  del: db.prepare('DELETE FROM sessions WHERE id = ?'),
  delUser: db.prepare('DELETE FROM sessions WHERE user_id = ?'),
  purge: db.prepare('DELETE FROM sessions WHERE expires_at <= ?')
};

/** Creates a session. Only the sha256 of the token is stored, so a DB leak can't be replayed. */
function create(userId, { remember = false, ip = null, userAgent = '' } = {}) {
  const token = randomToken(32), now = Date.now();
  const ttl = remember ? config.session.rememberMs : config.session.ttlMs;
  q.insert.run(sha256(token), userId, now, now, now + ttl, ttl, remember ? 1 : 0, ip, String(userAgent).slice(0, 255));
  return { token, ttl, remember };
}

/** Resolves a cookie token to { session, user } or null. Applies sliding expiry. */
function resolve(token) {
  if (typeof token !== 'string' || token.length < 20 || token.length > 100) return null;
  const id = sha256(token), s = q.get.get(id), now = Date.now();
  if (!s) return null;
  const user = s.expires_at > now ? findById(s.user_id) : null;
  if (!user || !user.is_active) { q.del.run(id); return null; }
  if (now - s.last_seen_at > config.session.touchEveryMs) q.touch.run(now, now + s.ttl_ms, id);
  return { session: { id, remember: !!s.remember, ttl: s.ttl_ms }, user: publicUser(user) };
}

const destroy = (token) => { if (typeof token === 'string' && token) q.del.run(sha256(token)); };
const destroyAllForUser = (userId) => q.delUser.run(userId);
const purgeExpired = () => q.purge.run(Date.now());

module.exports = { create, resolve, destroy, destroyAllForUser, purgeExpired };
