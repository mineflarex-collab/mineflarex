'use strict';
// Real network traffic of one game server: the bytes the kernel itself counted on the server's TCP connections.
//
// How: `ss -tin` lists every established TCP connection on the server's port together with the kernel's own
// per-connection counters (bytes_sent / bytes_received). Every sample adds up how much each connection grew since the
// previous sample, so the totals keep growing after players disconnect and the rate is real. Nothing is estimated.
// Limits (also written in the README): Minecraft Java Edition = TCP, so that is what is counted (UDP / Bedrock is
// not); traffic of a connection that opened and closed between two samples is missed (samples are a few seconds
// apart); totals count from the moment the server last started. When `ss` is missing (needs the iproute2 package and
// Linux), sample() returns null and the panel shows "not available" instead of a made-up number.
const { execFile } = require('node:child_process');

/** `ss -tin` output -> [{ key, sent, recv }] (one entry per connection; `recv` is null on kernels that do not report it). */
function parseSs(text) {
  const out = []; let cur = null;
  for (const raw of String(text).split('\n')) {
    if (!raw.trim()) continue;
    if (/^\s/.test(raw)) {                                    // detail line of the connection above
      if (!cur) continue;
      const s = /\bbytes_sent:(\d+)/.exec(raw), r = /\bbytes_received:(\d+)/.exec(raw);
      if (s) cur.sent = Number(s[1]);
      if (r) cur.recv = Number(r[1]);
      continue;
    }
    if (/^(State|Netid|Recv-Q)\b/i.test(raw)) { cur = null; continue; }   // header line
    const t = raw.trim().split(/\s+/);
    cur = t.length >= 2 ? { key: `${t[t.length - 2]}>${t[t.length - 1]}`, sent: 0, recv: null } : null;
    if (cur) out.push(cur);
  }
  return out.filter((c) => c.sent > 0 || c.recv !== null);
}

const defaultRun = (bin, port) => new Promise((resolve, reject) => {
  execFile(bin, ['-t', '-n', '-i', 'state', 'established', '(', 'sport', '=', `:${port}`, ')'], { timeout: 3000, maxBuffer: 8 * 1024 * 1024 }, (err, stdout) => (err ? reject(err) : resolve(stdout)));
});

class NetMeter {
  /** `run(bin, port)` can be replaced in tests; it must resolve the text `ss` prints. */
  constructor({ port, bin = 'ss', run = defaultRun, now = Date.now } = {}) {
    this.port = port; this.bin = bin; this.run = run; this.now = now;
    this.seen = new Map();            // connection key -> { sent, recv } at the previous sample
    this.rx = 0; this.tx = 0; this.at = null; this.broken = !port;
    this.rxBps = 0; this.txBps = 0;
  }

  /** Reads the counters once. Returns { rx, tx, rxBps, txBps } (bytes since the first sample / per second) or null when it cannot be measured. */
  async sample() {
    if (this.broken) return null;
    let text;
    try { text = await this.run(this.bin, this.port); } catch (e) {
      if (e && (e.code === 'ENOENT' || e.code === 'EACCES')) this.broken = true;   // no `ss` on this machine: stop trying
      return null;
    }
    const conns = parseSs(text), t = this.now(), next = new Map();
    let dRx = 0, dTx = 0;
    for (const c of conns) {
      const prev = this.seen.get(c.key) || { sent: 0, recv: 0 };
      if (c.sent >= prev.sent) dTx += c.sent - prev.sent; else dTx += c.sent;     // counter went back: it is a new connection with the same ends
      if (c.recv !== null) { if (c.recv >= prev.recv) dRx += c.recv - prev.recv; else dRx += c.recv; }
      next.set(c.key, { sent: c.sent, recv: c.recv ?? 0 });
    }
    this.seen = next;
    this.rx += dRx; this.tx += dTx;
    const dt = this.at == null ? 0 : (t - this.at) / 1000;
    this.rxBps = dt > 0 ? dRx / dt : 0; this.txBps = dt > 0 ? dTx / dt : 0;
    this.at = t;
    return { rx: this.rx, tx: this.tx, rxBps: Math.round(this.rxBps), txBps: Math.round(this.txBps) };
  }
}

module.exports = { NetMeter, parseSs };
