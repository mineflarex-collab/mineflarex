'use strict';
// Makes sure a server folder has its game jar before the process is spawned.
// Without this, a freshly created server has an empty folder and Java fails with
// "Unable to access jarfile server.jar".
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const API = process.env.PAPER_API || 'https://fill.papermc.io/v3/projects/paper';
const UA = { 'User-Agent': 'minePanel/1.0 (self-hosted panel)' };

async function getJson(url) {
  const res = await fetch(url, { headers: UA, signal: AbortSignal.timeout(30000) });
  if (!res.ok) throw new Error(`${url} -> HTTP ${res.status}`);
  return res.json();
}

/** Newest release version, e.g. "1.21.8" (skips pre-releases / snapshots). */
async function latestVersion() {
  const data = await getJson(API);
  const groups = Object.values(data.versions || {}).flat();
  const stable = groups.filter((v) => /^\d+(\.\d+){1,2}$/.test(v));
  const list = stable.length ? stable : groups;
  if (!list.length) throw new Error('Paper API returned no versions');
  const cmp = (a, b) => { const A = a.split('.').map(Number), B = b.split('.').map(Number); for (let i = 0; i < 3; i++) { const d = (A[i] || 0) - (B[i] || 0); if (d) return d; } return 0; };
  return list.sort(cmp).pop();
}

/** Does this start command run server.jar (i.e. is it the stock Java command)? */
function usesServerJar(command) { return !command || /(^|[\s/])server\.jar(\s|$)/.test(command); }

/**
 * Downloads server.jar into `dir` when it is missing. `say(line)` writes to the server console.
 * Throws with a readable message on failure.
 */
async function ensureServerJar({ dir, software, version, say }) {
  const jar = path.join(dir, 'server.jar');
  if (fs.existsSync(jar) && fs.statSync(jar).size > 0) return;
  const sw = String(software || 'paper').toLowerCase();
  if (sw !== 'paper') throw new Error(`server.jar is missing and auto-download only supports Paper (this server is "${software}"). Upload a server.jar in Files.`);

  let v = String(version || 'latest').trim();
  say(`[minePanel] server.jar not found - downloading Paper ${v}...`);
  if (!v || v.toLowerCase() === 'latest') v = await latestVersion();
  const build = await getJson(`${API}/versions/${encodeURIComponent(v)}/builds/latest`);
  const dl = build.downloads && (build.downloads['server:default'] || Object.values(build.downloads)[0]);
  if (!dl || !dl.url) throw new Error(`No download found for Paper ${v}`);
  say(`[minePanel] Downloading ${dl.name || 'paper.jar'} (build ${build.id})...`);

  const res = await fetch(dl.url, { headers: UA, signal: AbortSignal.timeout(5 * 60 * 1000) });
  if (!res.ok) throw new Error(`Download failed: HTTP ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  const want = dl.checksums && dl.checksums.sha256;
  if (want && crypto.createHash('sha256').update(buf).digest('hex') !== want) throw new Error('Downloaded jar failed checksum verification');
  const tmp = jar + '.part';
  fs.writeFileSync(tmp, buf);
  fs.renameSync(tmp, jar);
  say(`[minePanel] Downloaded server.jar (${(buf.length / 1048576).toFixed(1)} MB).`);
  const eula = path.join(dir, 'eula.txt');
  if (!fs.existsSync(eula)) { fs.writeFileSync(eula, 'eula=true\n'); say('[minePanel] eula.txt created (eula=true).'); }
}

module.exports = { ensureServerJar, usesServerJar };
