'use strict';
// Fast chunk loading / fast join for Paper servers.
//  - Paper's per-player chunk load/send rate is raised to CHUNK_RATE (default 90 chunks/s) and never above it.
//  - view-distance / simulation-distance are set once per server (a marker file stops us overwriting later edits in the panel).
// Everything is overridable with environment variables (see config below).
const fs = require('node:fs');
const path = require('node:path');

const num = (v, d) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : d);
const env = process.env;
const cfg = {
  enabled: env.RUNTIME_TUNING !== 'off',
  chunkRate: Math.min(90, num(env.RUNTIME_CHUNK_RATE, 90)),            // chunks/second per player (load + send), hard cap 90
  generateRate: Math.min(90, num(env.RUNTIME_CHUNK_GEN_RATE, 40)),     // brand-new chunks are CPU heavy: lower than load/send
  // Minecraft itself limits view-distance to 32 chunks (512 blocks); 16 chunks (256 blocks) is the fast default.
  viewDistance: Math.min(32, Math.max(2, num(env.RUNTIME_VIEW_DISTANCE, 16))),
  simulationDistance: Math.min(32, Math.max(2, num(env.RUNTIME_SIM_DISTANCE, 6)))
};

function setKeys(text, pairs) {
  for (const [key, value] of Object.entries(pairs)) {
    const re = new RegExp(`^${key.replace(/[.-]/g, '\\$&')}=.*$`, 'm');
    text = re.test(text) ? text.replace(re, `${key}=${value}`) : text + (text && !text.endsWith('\n') ? '\n' : '') + `${key}=${value}\n`;
  }
  return text;
}

/** server.properties: once per server. Returns true when it wrote something. */
function applyProperties(dir) {
  if (!cfg.enabled) return false;
  const marker = path.join(dir, '.minepanel-tuned');
  if (fs.existsSync(marker)) return false;
  const file = path.join(dir, 'server.properties');
  const text = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
  fs.writeFileSync(file, setKeys(text, {
    'view-distance': cfg.viewDistance,
    'simulation-distance': cfg.simulationDistance,
    'sync-chunk-writes': 'false',            // do not block the server thread on every chunk write
    'use-native-transport': 'true',
    'network-compression-threshold': 256
  }));
  fs.writeFileSync(marker, 'view-distance / simulation-distance were set once by minePanel. Edit them in Server Properties.\n');
  return true;
}

/** config/paper-global.yml: chunk load/send/generate rates. Only edits an existing file (Paper creates it on first start). */
function applyPaperRates(dir) {
  if (!cfg.enabled) return false;
  const file = path.join(dir, 'config', 'paper-global.yml');
  if (!fs.existsSync(file)) return false;
  const before = fs.readFileSync(file, 'utf8');
  let text = before;
  const want = { 'player-max-chunk-load-rate': cfg.chunkRate, 'player-max-chunk-send-rate': cfg.chunkRate, 'player-max-chunk-generate-rate': cfg.generateRate };
  for (const [key, value] of Object.entries(want)) {
    const re = new RegExp(`^(\\s*${key}:\\s*).*$`, 'm');
    if (re.test(text)) text = text.replace(re, `$1${value}.0`);
  }
  if (text === before) return false;
  fs.writeFileSync(file, text);
  return true;
}

module.exports = { applyProperties, applyPaperRates, tuning: cfg };
