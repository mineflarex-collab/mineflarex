'use strict';
// Plugin compatibility check, run before a Minecraft server starts.
//
// A plugin compiled for a newer Java than the one running the server makes Paper throw UnsupportedClassVersionError while it
// builds the plugin list. That is an Error (not an exception), so Paper stops loading plugins altogether and only the ones
// before the bad jar are loaded. Here such jars are moved to plugins/.unsupported/ before start (Paper does not look in
// sub-folders), so every compatible plugin loads normally. When Java is upgraded later, jars that now fit are moved back.
// Nothing is ever deleted and the console says exactly what was moved and why.
const fs = require('node:fs');
const fsp = fs.promises;
const path = require('node:path');
const zlib = require('node:zlib');
const { spawnSync } = require('node:child_process');
const { readZipDirectory } = require('../lib/archive');

const QUARANTINE = '.unsupported';
const MAX_CLASSES = 40;                    // besides the main/loader classes: enough to catch a plugin built for a newer Java
const javaCache = new Map();

/** Major version of the Java a command line starts ("java" / a path), or null when it cannot be told. */
function javaMajor(exe, env) {
  if (!exe || !/(^|[\\/])javaw?(\.exe)?$/i.test(exe)) return null;
  if (javaCache.has(exe)) return javaCache.get(exe);
  let major = null;
  try {
    const r = spawnSync(exe, ['-version'], { encoding: 'utf8', timeout: 8000, env });
    const m = /version "(\d+)(?:\.(\d+))?/.exec(`${r.stderr || ''}${r.stdout || ''}`);
    if (m) major = m[1] === '1' ? Number(m[2]) : Number(m[1]);
  } catch { /* unknown */ }
  if (major) javaCache.set(exe, major);
  return major || null;
}

async function readEntry(fh, e, limit) {
  const lh = Buffer.alloc(30); await fh.read(lh, 0, 30, e.lh);
  if (lh.readUInt32LE(0) !== 0x04034b50) return null;
  const start = e.lh + 30 + lh.readUInt16LE(26) + lh.readUInt16LE(28), n = Math.min(e.csize, e.method === 0 ? limit : Math.max(limit * 4, 256));
  const buf = Buffer.alloc(n); const { bytesRead } = await fh.read(buf, 0, n, start);
  const raw = buf.subarray(0, bytesRead);
  if (e.method === 0) return raw.subarray(0, limit);
  if (e.method !== 8) return null;
  try { return zlib.inflateRawSync(raw, { finishFlush: zlib.constants.Z_SYNC_FLUSH }).subarray(0, limit); } catch { return null; }
}

/** Highest class-file major version among the plugin's own classes, or 0 when the jar has none / cannot be read. */
async function highestClassMajor(file) {
  let fh;
  try {
    fh = await fsp.open(file, 'r');
    const entries = await readZipDirectory(fh, (await fh.stat()).size);
    const byName = new Map(entries.map((e) => [e.name, e]));
    const wanted = new Set();
    for (const yml of ['paper-plugin.yml', 'plugin.yml']) {           // the main and loader classes are what Paper loads first
      const e = byName.get(yml); if (!e || e.usize > 65536) continue;
      const buf = await readEntry(fh, e, 65536); if (!buf) continue;
      for (const m of buf.toString('utf8').matchAll(/^\s*(?:main|loader)\s*:\s*['"]?([\w.$]+)/gm)) wanted.add(`${m[1].replace(/\./g, '/')}.class`);
    }
    const others = entries.filter((e) => e.name.endsWith('.class') && !e.name.startsWith('META-INF/') && !e.name.endsWith('module-info.class') && !wanted.has(e.name)).slice(0, MAX_CLASSES);
    let top = 0;
    for (const e of [...[...wanted].map((n) => byName.get(n)).filter(Boolean), ...others]) {
      const head = await readEntry(fh, e, 8);
      if (head && head.length >= 8 && head.readUInt32BE(0) === 0xcafebabe) top = Math.max(top, head.readUInt16BE(6));
    }
    return top;
  } catch { return 0; } finally { if (fh) await fh.close().catch(() => {}); }
}

/**
 * Moves plugin jars this Java cannot run into plugins/.unsupported/ and brings back the ones that fit again.
 * `say(line)` writes to the server console. Never throws.
 */
async function sortPlugins({ dir, java, say }) {
  const result = { moved: [], restored: [] };
  try {
    if (!java) return result;
    const maxMajor = java + 44, plugins = path.join(dir, 'plugins'), parked = path.join(plugins, QUARANTINE);
    const jars = async (d) => { try { return (await fsp.readdir(d, { withFileTypes: true })).filter((x) => x.isFile() && /\.jar$/i.test(x.name)).map((x) => x.name); } catch { return []; } };
    for (const name of await jars(plugins)) {
      const major = await highestClassMajor(path.join(plugins, name));
      if (major <= maxMajor) continue;
      try {
        await fsp.mkdir(parked, { recursive: true });
        await fsp.rename(path.join(plugins, name), path.join(parked, name));
        result.moved.push(name);
        say(`[minePanel] Skipped plugin ${name}: it needs Java ${major - 44} but this server runs Java ${java}. Moved to plugins/${QUARANTINE}/ so the other plugins still load.`);
      } catch { /* leave it: the server will report it */ }
    }
    for (const name of await jars(parked)) {
      const major = await highestClassMajor(path.join(parked, name));
      if (major > maxMajor) continue;
      try {
        await fsp.access(path.join(plugins, name)).then(() => { throw new Error('exists'); }, () => {});
        await fsp.rename(path.join(parked, name), path.join(plugins, name));
        result.restored.push(name);
        say(`[minePanel] Plugin ${name} works with Java ${java} now: moved back to plugins/.`);
      } catch { /* a file with that name exists again: keep both */ }
    }
  } catch { /* never block a start */ }
  return result;
}

module.exports = { sortPlugins, highestClassMajor, javaMajor, QUARANTINE };
