'use strict';
// "Detached" servers: the game process does NOT belong to the panel process.
//
//   * it is started in its own session (setsid) through a tiny sh wrapper, with stdin = a FIFO and stdout/stderr = a log file
//   * the panel reads the log file (tail) and writes commands into the FIFO
//   * when the panel restarts (update, crash, `systemctl restart minepanel`) the game keeps running; the new panel process
//     "adopts" it again from <runDir>/<identifier>.json and continues reading the log where it stopped.
//
// Needs Linux + `mkfifo`. Anywhere else the supervisor falls back to normal child processes (they die with the panel).
// With systemd the unit also needs KillMode=process (see deploy/minepanel.service), otherwise systemd kills them itself.
const fs = require('node:fs');
const path = require('node:path');
const { spawn, execFileSync } = require('node:child_process');

const SCRIPT = [
  'P="$0"',
  'case "$1" in -bot) shift ;; *) shift; trap "" TERM ;; esac',      // Minecraft servers are stopped only by the panel, never by a stray SIGTERM
  'if [ -n "$MP_CGROUP_PROCS" ]; then echo $$ > "$MP_CGROUP_PROCS" || exit 126; fi',
  '"$@" <>"$P.in" >>"$P.out" 2>&1 &',
  'echo $! > "$P.pid"',
  'wait $!',
  'echo $? > "$P.exit"'
].join('\n');

/** Is this pid a live (non-zombie) process? Returns its /proc start time too (used to tell a recycled pid from ours). */
function procInfo(pid) {
  try {
    const stat = fs.readFileSync(`/proc/${pid}/stat`, 'utf8');
    const f = stat.slice(stat.lastIndexOf(')') + 2).split(' ');
    return { alive: f[0] !== 'Z' && f[0] !== 'X', start: f[19] };
  } catch { return { alive: false, start: null }; }
}

function supported() {
  if (process.platform !== 'linux') return false;
  try { execFileSync('mkfifo', ['--version'], { stdio: 'ignore' }); return true; } catch { return false; }
}

const readInt = (file) => { try { const n = parseInt(fs.readFileSync(file, 'utf8').trim(), 10); return Number.isFinite(n) ? n : null; } catch { return null; } };

/** Same surface the supervisor uses on a ChildProcess: pid, kill(signal), stdin.write / stdin.writable. */
class FileProc {
  constructor({ prefix, wrapperPid, wrapperStart, pid = null, offset = 0, onLine, onExit, tickMs = 100 }) {
    this.prefix = prefix; this.wrapperPid = wrapperPid; this.wrapperStart = wrapperStart; this.childPid = pid;
    this.offset = offset; this.onLine = onLine; this.onExitCb = onExit;
    this.partial = ''; this.ended = false; this.detached = false; this.inFd = null;
    this.stdin = { writable: true, write: (text) => this._write(text) };
    try { this.inFd = fs.openSync(`${prefix}.in`, fs.constants.O_RDWR | fs.constants.O_NONBLOCK); } catch { this.stdin.writable = false; }
    this.timer = setInterval(() => this._tick(), tickMs);
    setImmediate(() => this._tick());
  }

  /** The pid to measure: the real server process once the wrapper has written it, else the wrapper. */
  get pid() { return this.childPid || this.wrapperPid; }

  _write(text) {
    if (this.inFd == null) throw new Error('console closed');
    fs.writeSync(this.inFd, text);
  }

  _readOut() {
    let fd;
    try {
      fd = fs.openSync(`${this.prefix}.out`, 'r');
      const size = fs.fstatSync(fd).size;
      if (size < this.offset) this.offset = 0;                       // the file was truncated: start over
      while (this.offset < size) {
        const buf = Buffer.allocUnsafe(Math.min(size - this.offset, 1 << 20));
        const n = fs.readSync(fd, buf, 0, buf.length, this.offset);
        if (n <= 0) break;
        this.offset += n;
        this.partial += buf.toString('utf8', 0, n);
        let i;
        while ((i = this.partial.indexOf('\n')) >= 0) { const line = this.partial.slice(0, i).replace(/\r$/, ''); this.partial = this.partial.slice(i + 1); this.onLine(line); }
        if (this.partial.length > 65536) this.partial = this.partial.slice(-8192);
      }
    } catch { /* no file yet */ } finally { if (fd != null) try { fs.closeSync(fd); } catch { /* ignore */ } }
  }

  _tick() {
    if (this.ended || this.detached) return;
    if (!this.childPid) this.childPid = readInt(`${this.prefix}.pid`);
    this._readOut();
    const w = procInfo(this.wrapperPid), c = this.childPid ? procInfo(this.childPid) : { alive: false };
    const wrapperAlive = w.alive && (!this.wrapperStart || w.start === this.wrapperStart);
    if (wrapperAlive || c.alive) return;
    // finished: one last read, then work out how it ended
    this._readOut();
    if (this.partial) { this.onLine(this.partial); this.partial = ''; }
    const raw = readInt(`${this.prefix}.exit`);
    let code = raw, signal = null;
    if (raw == null || raw === 137) { code = null; signal = 'SIGKILL'; }        // no exit file: the whole group was killed
    this._finish(code, signal);
  }

  _finish(code, signal) {
    if (this.ended) return;
    this.ended = true; clearInterval(this.timer); this._closeFd();
    this.onExitCb(code, signal);
  }

  _closeFd() { if (this.inFd != null) { try { fs.closeSync(this.inFd); } catch { /* ignore */ } this.inFd = null; this.stdin.writable = false; } }

  /** SIGKILL takes the whole process group (wrapper + game + anything it started); other signals go to the game process only. */
  kill(signal = 'SIGTERM') {
    if (this.ended) return false;
    try {
      if (signal === 'SIGKILL') { try { process.kill(-this.wrapperPid, 'SIGKILL'); } catch { /* group gone */ } if (this.childPid) { try { process.kill(this.childPid, 'SIGKILL'); } catch { /* gone */ } } }
      else process.kill(this.childPid || this.wrapperPid, signal);
      return true;
    } catch { return false; }
  }

  /** What the next panel process needs to take over: where the log was read up to. */
  snapshot() { return { offset: this.offset - Buffer.byteLength(this.partial) }; }

  /** The panel is going away but the server keeps running: stop watching, touch nothing. */
  release() { this.detached = true; clearInterval(this.timer); this._closeFd(); }
}

/** Starts the wrapper (detached) and returns the handle. Throws when it cannot be spawned. */
function launch({ runDir, name, cwd, env, exe, args, bot, cgroupProcs, onLine, onExit, tickMs }) {
  fs.mkdirSync(runDir, { recursive: true });
  const prefix = path.join(runDir, name);
  for (const ext of ['pid', 'exit', 'out', 'json', 'in']) { try { fs.rmSync(`${prefix}.${ext}`, { force: true }); } catch { /* ignore */ } }
  execFileSync('mkfifo', ['-m', '600', `${prefix}.in`]);
  fs.writeFileSync(`${prefix}.out`, '');
  const childEnv = { ...env };
  if (cgroupProcs) childEnv.MP_CGROUP_PROCS = cgroupProcs;
  const proc = spawn('/bin/sh', ['-c', SCRIPT, prefix, bot ? '-bot' : '-srv', exe, ...args], { cwd, env: childEnv, stdio: 'ignore', detached: true });
  proc.on('error', () => {});
  proc.unref();
  const wrapperPid = proc.pid;
  if (!wrapperPid) throw new Error('could not start the process');
  const wrapperStart = procInfo(wrapperPid).start;
  return new FileProc({ prefix, wrapperPid, wrapperStart, onLine, onExit, tickMs });
}

/** Re-attaches to a server that a previous panel process started. Returns the handle, or null when it is not running any more. */
function adopt({ runDir, name, meta, onLine, onExit, tickMs }) {
  const prefix = path.join(runDir, name);
  if (!meta || !meta.wrapperPid) return null;
  const w = procInfo(meta.wrapperPid);
  const childPid = readInt(`${prefix}.pid`), c = childPid ? procInfo(childPid) : { alive: false };
  const mine = w.alive && (!meta.wrapperStart || w.start === meta.wrapperStart);
  if (!mine && !c.alive) return null;
  return new FileProc({ prefix, wrapperPid: meta.wrapperPid, wrapperStart: meta.wrapperStart, pid: childPid, offset: meta.offset || 0, onLine, onExit, tickMs });
}

const metaFile = (runDir, name) => path.join(runDir, `${name}.json`);
function readMeta(runDir, name) { try { return JSON.parse(fs.readFileSync(metaFile(runDir, name), 'utf8')); } catch { return null; } }
function writeMeta(runDir, name, meta) { try { fs.mkdirSync(runDir, { recursive: true }); const f = metaFile(runDir, name); fs.writeFileSync(`${f}.tmp`, JSON.stringify(meta)); fs.renameSync(`${f}.tmp`, f); } catch { /* best effort */ } }
function clearRun(runDir, name) { for (const ext of ['json', 'pid', 'exit', 'in', 'out', 'json.tmp']) { try { fs.rmSync(path.join(runDir, `${name}.${ext}`), { force: true }); } catch { /* ignore */ } } }

module.exports = { supported, launch, adopt, FileProc, readMeta, writeMeta, clearRun, procInfo };
