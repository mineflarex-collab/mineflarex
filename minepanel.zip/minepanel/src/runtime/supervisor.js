'use strict';
// The process supervisor ("runtime"): the part that actually runs servers.
//
//  * polls the command queue (server_commands) that the panel fills when a user presses Start / Stop / Restart
//  * spawns / stops / restarts a real OS process per server, in <dataDir>/<identifier>/
//  * reports the REAL status back (runtime.reportStatus): starting -> online when the console says the server
//    is ready, crashed when the process dies unexpectedly, offline after a normal stop
//  * samples real RAM / CPU usage of the process, disk usage of the server directory, and online players
//    (from join/leave lines in the console), and reports them every few seconds
//  * ENFORCES the limits each server was given (a server may use no more than its own RAM / CPU / disk):
//      RAM + CPU  hard limits through a Linux cgroup v2 per server (./limits.js). Without cgroups: a RAM watchdog
//                 (kills a server that stays above its RAM limit); CPU cannot be limited then.
//      disk       a watchdog measures the server folder (every few seconds when it is nearly full) and stops the
//                 server when it is over its disk limit; a server over its limit is not started; the File Manager
//                 refuses uploads/saves that would not fit.
//
//  * servers survive a panel restart: they run detached (./detached.js) and the next panel process adopts them again
//  * Stop / Restart act like Force stop / Force restart: the process is killed at once (no waiting for a slow graceful shutdown)
//
// Run exactly ONE supervisor per database (`npm run runtime`, or RUNTIME=embedded in the web process).
const fs = require('node:fs');
const path = require('node:path');
const { spawn, execFile } = require('node:child_process');
const { ensureServerJar, usesServerJar, applyPort } = require('./jar');
const { applyProperties, applyPaperRates } = require('./tuning');
const { sortPlugins, javaMajor } = require('./plugins');
const { portOf } = require('../dashboard/services/servers');
const { Cgroups } = require('./limits');
const { dirSizeBytes } = require('../lib/dirsize');
const db = require('../db');
require('../dashboard/migrations');
const runtime = require('../dashboard/services/runtime');
const consoleStore = require('../dashboard/services/serverConsole');
const baseConfig = require('./config');
const { hostMemory } = require('../lib/hostmem');
const { NetMeter } = require('./netmeter');
const detached = require('./detached');

const byId = db.prepare('SELECT * FROM servers WHERE id = ?');
const clearTask = db.prepare('UPDATE servers SET task = NULL, updated_at = ? WHERE id = ?');
const ENV_ALLOW = ['PATH', 'LANG', 'LC_ALL', 'TZ', 'JAVA_HOME', 'JAVA_TOOL_OPTIONS', 'TMPDIR', 'SystemRoot'];

/** Splits a command line into argv (supports single/double quotes; never uses a shell). */
function tokenize(cmd) {
  const out = []; let cur = '', quote = null, has = false;
  for (const ch of String(cmd)) {
    if (quote) { if (ch === quote) quote = null; else cur += ch; }
    else if (ch === '"' || ch === "'") { quote = ch; has = true; }
    else if (/\s/.test(ch)) { if (cur || has) { out.push(cur); cur = ''; has = false; } }
    else cur += ch;
  }
  if (quote) throw new Error('Unterminated quote in start command');
  if (cur || has) out.push(cur);
  if (!out.length) throw new Error('Start command is empty');
  return out;
}

function lineReader(stream, onLine) {
  let buf = ''; stream.setEncoding('utf8');
  stream.on('data', (d) => {
    buf += d; let i;
    while ((i = buf.indexOf('\n')) >= 0) { onLine(buf.slice(0, i).replace(/\r$/, '')); buf = buf.slice(i + 1); }
    if (buf.length > 8192) buf = buf.slice(-8192);
  });
}

const dirSizeMb = async (dir, cap) => Math.ceil((await dirSizeBytes(dir, cap)) / 1048576);

/** Real resource usage of a process: { cpu (% of one core), rssMb, sample } – /proc on Linux, `ps` elsewhere. */
async function procStats(pid, prev) {
  if (process.platform === 'linux') {
    const stat = fs.readFileSync(`/proc/${pid}/stat`, 'utf8');
    const f = stat.slice(stat.lastIndexOf(')') + 2).split(' ');
    const ticks = Number(f[11]) + Number(f[12]);                    // utime + stime (USER_HZ = 100)
    const m = /VmRSS:\s+(\d+) kB/.exec(fs.readFileSync(`/proc/${pid}/status`, 'utf8'));
    const now = Date.now(); let cpu = 0;
    if (prev) { const dt = (now - prev.t) / 1000; if (dt > 0) cpu = Math.max(0, ((ticks - prev.ticks) / 100) / dt * 100); }
    return { cpu, rssMb: m ? Number(m[1]) / 1024 : 0, sample: { ticks, t: now } };
  }
  const out = await new Promise((res, rej) => execFile('ps', ['-o', 'rss=,%cpu=', '-p', String(pid)], (e, so) => (e ? rej(e) : res(so))));
  const [rss, cpu] = out.trim().split(/\s+/).map(Number);
  return { cpu: cpu || 0, rssMb: (rss || 0) / 1024, sample: null };
}

const sleepRace = (promise, ms) => new Promise((resolve) => {
  const t = setTimeout(() => resolve(false), ms);
  promise.then(() => { clearTimeout(t); resolve(true); });
});

class Entry {
  constructor(server, dir) {
    this.server = server; this.dir = dir;
    this.state = 'starting';            // starting | online | stopping
    this.wasReady = false; this.stopRequested = false; this.quiet = false; this.done = false; this.timedOut = false;
    this.tail = []; this.players = new Set(); this.diskMb = server.disk_used_mb; this.diskAt = 0; this.cpuSample = null;
    this.limit = null;                  // { kind: 'ram' | 'disk', message } once the server broke one of its limits
    this.overRam = 0; this.cgroup = null; this.oomBase = 0;
    this.exited = new Promise((r) => { this._exited = r; });
    this.ready = new Promise((r) => { this._ready = r; });   // resolves { ok, error?, cancelled? }
  }
}

class Supervisor {
  constructor(opts = {}) {
    this.o = { ...baseConfig, ...opts };
    this.log = opts.log || (() => {});
    this.entries = new Map();      // server id -> Entry (a live process)
    this.inflight = new Map();     // server id -> { cmd, promise }
    this.claimed = new Set();      // command ids being executed
    this.timer = null; this.closing = false;
    // Live console: output of every process is written to the database (the panel streams it to browsers) and
    // commands typed in the panel arrive through the console_input queue.
    this.console = new consoleStore.Writer({ flushMs: this.o.consoleFlushMs, keep: this.o.consoleKeepLines, onError: (err) => this.log(`console write failed: ${err.message}`) });
    this.inputTimer = null;
    this.cg = this.o.cgroups ? new Cgroups({ root: this.o.cgroupRoot, selfCgroup: this.o.cgroupSelf, log: this.log }) : null;
    this.limitMode = 'software';   // 'cgroup' once hard RAM/CPU limits are active
    this.persist = !!this.o.persist && detached.supported();   // servers outlive the panel process
    this.runDir = this.o.runDir;
  }

  /** Reconciles what the database claims with reality (this process owns no servers yet), then starts polling. */
  start() {
    const queued = new Set(runtime.pendingCommands().map((c) => c.server_id));
    // A job (reinstall) that was running when the previous runtime died has no command left to finish it: clear the marker.
    for (const s of db.prepare('SELECT id FROM servers WHERE task IS NOT NULL').all()) if (!queued.has(s.id)) clearTask.run(Date.now(), s.id);
    if (this.cg) {
      const r = this.cg.setup();
      this.limitMode = r.ok ? 'cgroup' : 'software';
      this.log(r.ok ? 'limits: hard RAM/CPU limits per server (cgroup v2); disk is watched' : `limits: cgroups unavailable (${r.reason}): RAM is enforced by a watchdog, CPU is NOT limited; disk is watched`);
    } else this.log('limits: cgroups disabled: RAM is enforced by a watchdog, CPU is NOT limited; disk is watched');
    // Servers a previous panel process left running are taken over again (they were never stopped).
    const adopted = new Set();
    if (this.persist) for (const s of db.prepare('SELECT * FROM servers').all()) { try { if (this.adopt(s)) adopted.add(s.id); } catch (err) { this.log(`could not take over ${s.name}: ${err.message}`); } }
    for (const s of db.prepare("SELECT * FROM servers WHERE status NOT IN ('offline', 'crashed')").all()) {
      if (adopted.has(s.id)) continue;
      if (!queued.has(s.id)) this.report(s.id, 'offline');   // marked running, but no process exists -> say so
    }
    // Commands typed while no runtime was running must not be replayed now, minutes or hours later.
    for (const r of consoleStore.pendingInput(1000)) consoleStore.markInput(r.id, 'failed', 'The server runtime was not running');
    this.timer = setInterval(() => this.poll(), this.o.pollMs);
    this.inputTimer = setInterval(() => this.pollInput(), this.o.consoleInputMs);
    this.poll();
    this.log(`runtime started (data dir: ${this.o.dataDir}${this.persist ? `; servers keep running when the panel restarts, adopted ${adopted.size}` : ''})`);
  }

  /** What the next panel process needs to find a running server again. */
  saveMeta(e) {
    if (!e.persistent || !e.proc || e.done) return;
    let snap = { offset: 0 };
    try { snap = e.proc.snapshot(); } catch { /* keep 0 */ }
    detached.writeMeta(this.runDir, e.server.identifier, { wrapperPid: e.proc.wrapperPid, wrapperStart: e.proc.wrapperStart, offset: snap.offset, players: [...e.players], ready: !!e.wasReady,
      tokens: e.tokens, cgroup: e.cgroup, oomBase: e.oomBase, kind: e.server.kind, savedAt: Date.now() });
  }

  /** Takes over a server that is still running from an earlier panel process. Returns true when it is adopted. */
  adopt(server) {
    const name = server.identifier, meta = detached.readMeta(this.runDir, name);
    if (!meta) return false;
    const dir = path.join(this.o.dataDir, name), e = new Entry(server, dir);
    e.persistent = true; e.tokens = meta.tokens || []; e.cgroup = meta.cgroup || null; e.oomBase = meta.oomBase || 0; e.players = new Set(meta.players || []);
    if (e.cgroup && this.cg && this.cg.ok) { try { this.cg.apply(server); } catch (err) { this.log(`${server.name}: could not re-apply cgroup limits: ${err.message}`); } }
    const proc = detached.adopt({ runDir: this.runDir, name, meta, tickMs: 100, onLine: (l) => this.onLine(e, l, 'out'), onExit: (code, signal) => this.onExit(e, code, signal) });
    if (!proc) {                                                   // it ended while the panel was not running
      let code = null; try { const n = parseInt(fs.readFileSync(path.join(this.runDir, `${name}.exit`), 'utf8').trim(), 10); if (Number.isFinite(n)) code = n; } catch { /* no exit file: killed from outside, or the machine rebooted */ }
      this.console.push(server.id, 'sys', `[minePanel] The server process ended while the panel was restarting${code != null ? ` (exit code ${code})` : ''}.`);
      this.report(server.id, code == null || code === 0 || code === 143 ? 'offline' : 'crashed');
      detached.clearRun(this.runDir, name);
      return false;
    }
    e.proc = proc;
    this.entries.set(server.id, e);
    if (meta.ready) { e.state = 'online'; e.wasReady = true; e._ready({ ok: true }); }
    else {
      e.state = 'starting';
      if (server.kind === 'bot') e.botReadyTimer = setTimeout(() => this.markReady(e), this.o.botReadyMs);
      e.startTimer = setTimeout(() => { if (!e.wasReady && !e.done) { e.timedOut = true; proc.kill('SIGKILL'); } }, this.o.startTimeoutMs);
    }
    e.metricsTimer = setInterval(() => this.sample(e), this.o.metricsMs); e.metricsTimer.unref();
    dirSizeMb(dir).then((mb) => { e.diskMb = mb; e.diskAt = Date.now(); }).catch(() => {});
    this.console.push(server.id, 'sys', '[minePanel] The panel was restarted - the server kept running and is connected again.');
    this.report(server.id, e.wasReady ? 'online' : 'starting', { diskUsedMb: server.disk_used_mb, playersOnline: e.players.size });
    return true;
  }

  /**
   * The panel is shutting down. Detached servers (the default on Linux) keep running and are adopted by the next panel process;
   * other servers (and everything when RUNTIME_STOP_ON_EXIT=1) are stopped gracefully. Queued commands stay queued.
   */
  async shutdown() {
    this.closing = true; clearInterval(this.timer); clearInterval(this.inputTimer);
    const keep = [...this.entries.values()].filter((e) => e.persistent && !e.done && !this.o.stopOnExit);
    this.console.flush();                                                  // the last lines must not be lost
    for (const e of keep) { this.saveMeta(e); clearInterval(e.metricsTimer); clearTimeout(e.startTimer); clearTimeout(e.botReadyTimer); e.proc.release(); this.entries.delete(e.server.id); }
    await Promise.allSettled([...this.entries.values()].map((e) => this.stopEntry(e)));
    await Promise.allSettled([...this.inflight.values()].map((i) => i.promise));
    this.console.flush();
    if (keep.length && this.cg && this.cg.ok) this.cg.release();            // lets systemd start the next panel process in this cgroup
  }

  /** Writes commands queued by the panel to the console (stdin) of the running process. */
  pollInput() {
    if (this.closing) return;
    let rows;
    try { rows = consoleStore.pendingInput(50); } catch (err) { return this.log(`console input poll failed: ${err.message}`); }
    for (const r of rows) {
      const e = this.entries.get(r.server_id);
      let error = null;
      if (!e || e.done || e.state === 'stopping') error = 'The server is not running';
      else {
        try { if (!e.proc.stdin.writable) throw new Error('console closed'); e.proc.stdin.write(`${r.command}\n`); }
        catch (err) { error = `Could not write to the server console: ${err.message}`; }
      }
      if (!consoleStore.markInput(r.id, error ? 'failed' : 'sent', error)) continue;   // the panel already gave up on it
      if (error) this.console.push(r.server_id, 'sys', `[minePanel] Command not sent (${error.toLowerCase()}): ${r.command}`);
      else this.console.push(r.server_id, 'in', `${r.username}> ${r.command}`);
    }
  }

  report(serverId, status, x = {}) {
    const cur = byId.get(serverId); if (!cur) return;
    try {
      runtime.reportStatus(serverId, { status, diskUsedMb: x.diskUsedMb ?? cur.disk_used_mb, cpuUsedPct: x.cpuUsedPct ?? 0, ramUsedMb: x.ramUsedMb ?? 0, playersOnline: x.playersOnline ?? 0,
        netRxBytes: x.netRxBytes ?? null, netTxBytes: x.netTxBytes ?? null, netRxBps: x.netRxBps ?? null, netTxBps: x.netTxBps ?? null });
    } catch (err) { this.log(`report failed: ${err.message}`); }
  }

  /** Validity: a server whose valid-until day has passed is suspended (and stopped when it runs). Checked every 30 s. */
  expirySweep() {
    const now = Date.now();
    if (now - (this.lastExpiry || 0) < 30000) return;
    this.lastExpiry = now;
    for (const s of db.prepare('SELECT * FROM servers WHERE expires_at IS NOT NULL AND expires_at < ? AND suspended = 0').all(now)) {
      const d = new Date(s.expires_at), reason = `Validity expired on ${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
      this.console.push(s.id, 'sys', `[minePanel] ${reason}. Server suspended.`);
      try { runtime.suspendServer(s.id, reason); } catch (err) { this.log(`expiry suspend failed: ${err.message}`); continue; }
      const entry = this.entries.get(s.id);
      if (entry) this.stopEntry(entry);
    }
  }

  poll() {
    if (this.closing) return;
    try { this.expirySweep(); } catch (err) { this.log(`expiry check failed: ${err.message}`); }
    for (const [id, e] of this.entries) {                                          // a server deleted from the panel while its process lived: kill the orphan
      if (!e.done && !byId.get(id)) { e.stopRequested = true; e.quiet = true; try { e.proc.kill('SIGKILL'); } catch { /* gone */ } this.log(`server ${id} was deleted: process killed`); }
    }
    for (const cmd of runtime.pendingCommands()) {
      if (this.claimed.has(cmd.id)) continue;
      const busy = this.inflight.get(cmd.server_id), entry = this.entries.get(cmd.server_id);
      const preempt = cmd.command.startsWith('force_') || (cmd.command === 'stop' && entry && entry.state === 'starting');   // force actions always go through; a stop also cuts a boot short
      if (busy && !preempt) continue;                                                  // one command at a time per server
      this.claimed.add(cmd.id);
      const previous = busy ? busy.promise : null;
      const promise = this.execute(cmd, previous).catch((err) => {
        this.log(`command ${cmd.id} (${cmd.command}) failed: ${err.stack || err}`);
        try { runtime.completeCommand(cmd.id, { ok: false, error: err.message || String(err), status: this.entries.has(cmd.server_id) ? 'online' : 'crashed' }); } catch { /* ignore */ }
      }).finally(() => {
        this.claimed.delete(cmd.id);
        if (this.inflight.get(cmd.server_id)?.cmd.id === cmd.id) this.inflight.delete(cmd.server_id);
      });
      this.inflight.set(cmd.server_id, { cmd, promise });
    }
  }

  async execute(cmd, previous) {
    const server = byId.get(cmd.server_id);
    if (!server) return runtime.completeCommand(cmd.id, { ok: false, error: 'Server no longer exists' });
    const entry = this.entries.get(server.id);

    if (cmd.command === 'start') {
      if (entry) return this.finishStart(cmd, await entry.ready);          // already running / booting: report its outcome
      return this.finishStart(cmd, await this.launch(server));
    }
    if (cmd.command === 'stop') {
      if (entry) await this.quickStop(entry);                             // Stop acts like Force stop: no waiting for a slow graceful shutdown
      if (previous) await previous;                                       // let the cancelled start finish first
      if (!runtime.commandPending(cmd.id)) return;                        // a Kill (force stop) took over this stop
      this.report(server.id, 'offline');                                  // offline + command done NOW: Start must work immediately
      runtime.completeCommand(cmd.id);
      return this.measureDiskLater(server);                               // the slow folder walk happens afterwards
    }
    if (cmd.command.startsWith('force_')) return this.force(cmd, server, entry, previous);
    if (cmd.command === 'reinstall') return this.reinstall(cmd, server, entry);
    // restart (acts like Force restart): kill at once if running, then start again; status goes stopping -> starting -> online
    if (entry) await this.quickStop(entry, { restarting: true });
    if (!runtime.commandPending(cmd.id)) return;                         // a Kill (force stop) replaced this restart: stay offline
    return this.finishStart(cmd, await this.launch(byId.get(server.id)));
  }

  /** Measures the server folder in the background and stores only the disk figure (never touches the status). */
  measureDiskLater(server) {
    return dirSizeMb(path.join(this.o.dataDir, server.identifier)).then((mb) => runtime.setDiskUsed(server.id, mb)).catch(() => {});
  }

  /**
   * Reinstall: stop the server if it runs, download a fresh server.jar (verified, swapped in atomically, so a failed
   * download leaves the old jar in place), and leave the server offline. Worlds, plugins and configs are not touched.
   */
  async reinstall(cmd, server, entry) {
    const dir = path.join(this.o.dataDir, server.identifier), say = (l) => this.console.push(server.id, 'sys', l);
    const bot = server.kind === 'bot' || !usesServerJar(server.start_command || this.o.defaultCommand);
    if (bot) {                                                           // the panel refuses this up front; checked again because the row may have changed since
      const error = 'Nothing to reinstall: this server does not run the stock server.jar.';
      say(`[minePanel] ${error}`);
      return runtime.completeCommand(cmd.id, { ok: false, error, status: entry ? 'online' : 'offline' });
    }
    if (entry) await this.stopEntry(entry);                              // graceful stop; the exit reports 'offline'
    if (!runtime.commandPending(cmd.id)) return;
    say('[minePanel] Reinstalling server software (worlds, plugins and settings are kept)...');
    try {
      fs.mkdirSync(dir, { recursive: true });
      await ensureServerJar({ dir, software: server.software, version: server.version, say, force: true });
    } catch (err) {
      say(`[minePanel] Reinstall failed: ${err.message} The files on disk were not changed.`);
      this.report(server.id, 'offline', { diskUsedMb: await dirSizeMb(dir) });
      return runtime.completeCommand(cmd.id, { ok: false, error: err.message, status: 'offline' });
    }
    say('[minePanel] Reinstall finished. Press Start when you are ready.');
    this.report(server.id, 'offline', { diskUsedMb: await dirSizeMb(dir) });
    return runtime.completeCommand(cmd.id);
  }

  /** Admin force actions: SIGKILL now (plus anything left in the server's cgroup, e.g. an orphan of an earlier panel run), then optionally start again. */
  async force(cmd, server, entry, previous) {
    const say = (l) => this.console.push(server.id, 'sys', l), dir = path.join(this.o.dataDir, server.identifier);
    say(`[minePanel] ${cmd.command === 'force_stop' ? 'Force stop' : cmd.command === 'force_start' ? 'Force start' : 'Force restart'}: killing the process...`);
    if (entry && !entry.done) { entry.stopRequested = true; entry.quiet = true; try { entry.proc.kill('SIGKILL'); } catch { /* gone */ } await sleepRace(entry.exited, 8000); }
    if (previous) await sleepRace(previous, 8000);
    if (this.cg && this.cg.ok) this.cg.killServer(server.id);
    this.report(server.id, 'offline');
    if (cmd.command === 'force_stop') { runtime.completeCommand(cmd.id); return this.measureDiskLater(server); }
    return this.finishStart(cmd, await this.launch(byId.get(server.id)));
  }

  finishStart(cmd, r) {
    if (r.ok) return runtime.completeCommand(cmd.id);
    return runtime.completeCommand(cmd.id, { ok: false, error: r.error, status: r.cancelled || r.status === 'offline' ? 'offline' : 'crashed' });
  }

  /** Spawns the server process. Resolves when it is ready ({ ok: true }) or failed ({ ok: false, error }). */
  async launch(server) {
    { const fresh = byId.get(server.id); if (fresh && fresh.suspended) { const msg = `Server is suspended${fresh.suspended_reason ? `: ${fresh.suspended_reason}` : ''}. An administrator must unsuspend it first.`; this.console.push(server.id, 'sys', `[minePanel] ${msg}`); return { ok: false, error: msg, status: 'offline' }; } }
    // A server that is over its disk allocation is not started: it would only be stopped again by the watchdog.
    if (server.disk_used_mb >= server.disk_limit_mb * 0.9) {       // stored usage is close: measure for real
      const used = await dirSizeMb(path.join(this.o.dataDir, server.identifier));
      if (used > server.disk_limit_mb) {
        const msg = `Disk limit reached (${used} MB used of ${server.disk_limit_mb} MB). Delete some files in the File Manager, then start the server again.`;
        this.console.push(server.id, 'sys', `[minePanel] ${msg}`);
        return { ok: false, error: msg };
      }
    }
    // A new server has an empty folder: fetch server.jar first (Minecraft servers using the stock command only).
    if (server.kind !== 'bot' && usesServerJar(server.start_command || this.o.defaultCommand)) {
      const dir = path.join(this.o.dataDir, server.identifier);
      try {
        fs.mkdirSync(dir, { recursive: true });
        await ensureServerJar({ dir, software: server.software, version: server.version, say: (l) => this.console.push(server.id, 'sys', l) });
      } catch (err) {
        this.console.push(server.id, 'sys', `[minePanel] Could not prepare server.jar: ${err.message}`);
        return { ok: false, error: `Could not prepare server.jar: ${err.message}` };
      }
      // Plugins built for a newer Java than this server runs would stop Paper from loading ANY later plugin: park them, load the rest.
      try {
        const exe = tokenize(server.start_command || this.o.defaultCommand)[0];
        await sortPlugins({ dir, java: javaMajor(exe, { PATH: process.env.PATH, JAVA_HOME: process.env.JAVA_HOME }), say: (l) => this.console.push(server.id, 'sys', l) });
      } catch { /* never block a start */ }
    }
    if (server.kind === 'bot') {
      const r = await this.installPackages(server);          // Startup variable AUTO_INSTALL: npm install / pip install -r before the bot starts
      if (!r.ok) return r;
    }
    return this.spawnServer(server);
  }

  /** Runs `npm install` (Node.js) or `pip install -r requirements.txt` (Python) inside the bot folder. Skipped when disabled or when there is nothing to install. */
  async installPackages(server) {
    let vars = {};
    try { vars = JSON.parse(server.startup_vars || '{}') || {}; } catch { /* defaults */ }
    if (vars.AUTO_INSTALL === '0') return { ok: true };
    const dir = path.join(this.o.dataDir, server.identifier), say = (l) => this.console.push(server.id, 'sys', l);
    const job = server.runtime === 'nodejs' && fs.existsSync(path.join(dir, 'package.json')) ? { name: 'npm install', bin: 'npm', args: ['install', '--no-audit', '--no-fund'] }
      : server.runtime === 'python' && fs.existsSync(path.join(dir, 'requirements.txt')) ? { name: 'pip install -r requirements.txt', bin: 'python3', args: ['-m', 'pip', 'install', '--user', '--disable-pip-version-check', '-r', 'requirements.txt'] } : null;
    if (!job) return { ok: true };
    this.report(server.id, 'starting');
    say(`[minePanel] Installing packages: ${job.name}`);
    const env = { ...Object.fromEntries(ENV_ALLOW.filter((k) => process.env[k] != null).map((k) => [k, process.env[k]])), HOME: dir };
    const run = (args) => new Promise((resolve) => {
      let out = '', proc;
      try { proc = spawn(job.bin, args, { cwd: dir, env, stdio: ['ignore', 'pipe', 'pipe'] }); } catch (err) { return resolve({ code: -1, out: err.message }); }
      const timer = setTimeout(() => proc.kill('SIGKILL'), this.o.installTimeoutMs || 600000);
      const line = (l) => { out += `${l}\n`; say(l); };
      lineReader(proc.stdout, line); lineReader(proc.stderr, line);
      proc.on('error', (err) => { clearTimeout(timer); resolve({ code: -1, out: err.message }); });
      proc.on('close', (code) => { clearTimeout(timer); resolve({ code, out }); });
    });
    let r = await run(job.args);
    if (r.code !== 0 && /externally-managed-environment/.test(r.out)) r = await run([...job.args, '--break-system-packages']);   // Debian / Ubuntu Python
    if (r.code !== 0) {
      const error = `Package install failed (${job.name}). Fix it in the Console / Files, or turn off "Install packages on start" in Startup.`;
      say(`[minePanel] ${error}`);
      return { ok: false, error };
    }
    say('[minePanel] Packages installed.');
    return { ok: true };
  }

  spawnServer(server) {
    const dir = path.join(this.o.dataDir, server.identifier);
    const e = new Entry(server, dir);
    let tokens;
    try {
      fs.mkdirSync(dir, { recursive: true });
      if (server.kind !== 'bot' && usesServerJar(server.start_command || this.o.defaultCommand)) { applyPort(dir, portOf(server.address)); try { applyProperties(dir); applyPaperRates(dir); } catch { /* tuning is optional */ } }
      let heap = Math.max(64, Math.floor(server.ram_limit_mb * this.o.heapPct / 100));
      // The machine / hosting container can have less RAM than the panel allocation: never let the heap outgrow it,
      // or the kernel OOM-kills Java (SIGKILL) halfway through startup.
      const hm = hostMemory(), safe = Math.floor(Math.min(hm.limitMb, hm.availableMb + 200) * 0.7);
      if (safe >= 256 && heap > safe) {
        this.console.push(server.id, 'sys', `[minePanel] Heap lowered from ${heap} MB to ${safe} MB: this machine only has ${hm.limitMb} MB RAM (${hm.availableMb} MB free).`);
        heap = safe;
      }
      const cores = Math.max(1, Math.ceil(server.cpu_limit_pct / 100)), multi = cores >= 2;
      // One core: SerialGC (small, no extra threads). Two or more: G1 with the usual Minecraft tuning, and Xms = Xmx so the heap is not
      // grown step by step (slow, many GCs) while the world loads. The memory is only really used when the game touches it.
      const gc = multi ? '-XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200 -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5 -XX:SurvivorRatio=32 -XX:MaxTenuringThreshold=1' : '-XX:+UseSerialGC';
      const vars = { RAM_MB: server.ram_limit_mb, HEAP_MB: heap, XMS_MB: multi ? heap : Math.max(64, Math.min(heap, 512)), CPU_CORES: server.cpu_limit_pct / 100, CPU_CORES_INT: cores, DIR: dir, IDENTIFIER: server.identifier };
      tokens = tokenize(String(server.start_command || this.o.defaultCommand).replace(/\{\{GC_FLAGS\}\}/g, gc)).map((t) => t.replace(/\{\{(\w+)\}\}/g, (m, k) => (k in vars ? String(vars[k]) : m)));
    } catch (err) { this.console.push(server.id, 'sys', `[minePanel] Could not start: ${err.message}`); return Promise.resolve({ ok: false, error: err.message }); }
    e.tokens = tokens;
    if (this.o.netStats && server.kind !== 'bot') e.net = new NetMeter({ port: portOf(server.address), bin: this.o.ssBin });   // real traffic of the server's own port (bots have none)
    this.console.push(server.id, 'sys', '[minePanel] Starting server... (Made by MineFlareX)');
    this.console.push(server.id, 'sys', `[minePanel] Command: ${tokens.join(' ')}`);   // shows exactly which JVM flags are in use (e.g. to spot an old MaxMetaspaceSize cap)
    this.entries.set(server.id, e);
    this.report(server.id, 'starting');

    const env = Object.fromEntries(ENV_ALLOW.filter((k) => process.env[k] != null).map((k) => [k, process.env[k]]));   // never leak panel secrets to game processes
    let exe = tokens[0], args = tokens.slice(1), cgProcs = null;
    if (this.cg && this.cg.ok) {              // hard limits: the process starts inside the server's own cgroup
      try {
        const g = this.cg.apply(server);
        if (this.persist) cgProcs = g.procsFile;                                   // the detached wrapper moves itself into the group
        else ({ cmd: exe, args } = this.cg.wrap(tokens, g.procsFile));
        e.cgroup = g.dir; e.oomBase = this.cg.oomKills(g.dir);
      } catch (err) { this.log(`${server.name}: could not apply cgroup limits (${err.message}); using the software watchdog`); }
    }
    const bot = server.kind === 'bot';
    let proc;
    if (this.persist) {
      // Detached: the server is not a child of the panel. Output goes to a log file, commands through a FIFO (see detached.js), so a
      // restarted panel can pick it up again. Minecraft servers ignore a stray SIGTERM (the wrapper sets that); bots keep the normal one.
      try {
        e.persistent = true;
        proc = detached.launch({ runDir: this.runDir, name: server.identifier, cwd: dir, env: { ...env, HOME: dir }, exe, args, bot, cgroupProcs: cgProcs, tickMs: 50,
          onLine: (l) => this.onLine(e, l, 'out'), onExit: (code, signal) => this.onExit(e, code, signal) });
      } catch (err) {
        this.entries.delete(server.id); if (e.cgroup) this.cg.remove(e.cgroup);
        this.console.push(server.id, 'sys', `[minePanel] Could not start: ${err.message}`);
        return Promise.resolve({ ok: false, error: err.message });
      }
      e.proc = proc;
      this.saveMeta(e);
    } else {
      // `systemctl restart minepanel` (default KillMode) sends SIGTERM to every process of the service at once, which killed Java
      // (exit code 143) before the panel could save and stop it. A SIGTERM that is ignored before exec stays ignored in the
      // JVM (it does not install its own handler for an ignored signal), so Minecraft servers are now stopped ONLY by the panel
      // (console "stop", then SIGKILL as a last resort), never by the service manager. Bots keep the normal SIGTERM.
      if (!bot) { args = ['-c', 'trap "" TERM; exec "$@"', 'minepanel-sh', exe, ...args]; exe = 'sh'; }
      proc = spawn(exe, args, { cwd: dir, env: { ...env, HOME: dir }, stdio: ['pipe', 'pipe', 'pipe'] });
      e.proc = proc;
      proc.stdin.on('error', () => {});
      lineReader(proc.stdout, (l) => this.onLine(e, l, 'out'));
      lineReader(proc.stderr, (l) => this.onLine(e, l, 'err'));
      proc.on('error', (err) => this.onExit(e, null, null, err));
      proc.on('close', (code, signal) => this.onExit(e, code, signal));
    }
    // A bot has no "Done!" line to wait for: it counts as online once the process has stayed alive for a moment.
    if (server.kind === 'bot') e.botReadyTimer = setTimeout(() => this.markReady(e), this.o.botReadyMs);
    e.startTimer = setTimeout(() => { if (!e.wasReady && !e.done) { e.timedOut = true; proc.kill('SIGKILL'); } }, this.o.startTimeoutMs);
    e.metricsTimer = setInterval(() => this.sample(e), this.o.metricsMs); e.metricsTimer.unref();
    dirSizeMb(dir).then((mb) => { e.diskMb = mb; e.diskAt = Date.now(); });
    return e.ready;
  }

  onLine(e, line, stream = 'out') {
    this.console.push(e.server.id, stream, line);
    e.tail.push(line); if (e.tail.length > 15) e.tail.shift();
    let m;
    if ((m = /: (\w{1,16}) joined the game/.exec(line))) e.players.add(m[1]);
    else if ((m = /: (\w{1,16}) left the game/.exec(line))) e.players.delete(m[1]);
    if (e.state === 'starting' && this.o.readyRegex.test(line)) this.markReady(e);
  }

  /** The server finished starting: report it online and start sampling usage. */
  markReady(e) {
    if (e.done || e.state !== 'starting') return;
    e.state = 'online'; e.wasReady = true; clearTimeout(e.startTimer); clearTimeout(e.botReadyTimer); e.diskAt = 0;   // re-measure disk now: files were created during startup
    this.report(e.server.id, 'online', { diskUsedMb: e.diskMb });
    this.saveMeta(e);
    // First start: Paper has just created config/paper-global.yml. Cap/raise the chunk rates now; they apply from the next restart.
    try { if (e.server.kind !== 'bot' && applyPaperRates(path.join(this.o.dataDir, e.server.identifier))) this.console.push(e.server.id, 'sys', '[minePanel] Chunk loading tuned (90 chunks/s). Restart the server once to apply it.'); } catch { /* optional */ }
    this.sample(e);
    e._ready({ ok: true });
  }

  async sample(e) {
    if (e.done || (e.state !== 'online' && e.state !== 'starting')) return;
    let cpu = 0, rssMb = 0;
    try { const st = await procStats(e.proc.pid, e.cpuSample); cpu = st.cpu; rssMb = st.rssMb; e.cpuSample = st.sample; } catch { /* process just exited */ }
    const cur = byId.get(e.server.id) || e.server;                    // limits may have been changed by an admin meanwhile
    if (e.cgroup && (cur.ram_limit_mb !== e.server.ram_limit_mb || cur.cpu_limit_pct !== e.server.cpu_limit_pct)) {
      try { this.cg.apply(cur); } catch (err) { this.log(`${cur.name}: could not update cgroup limits: ${err.message}`); }
    }
    e.server = cur;
    this.saveMeta(e);
    const nearFull = e.diskMb >= cur.disk_limit_mb * 0.8;             // measure often when almost full, rarely otherwise
    if (Date.now() - e.diskAt > (nearFull ? this.o.diskHotMs : this.o.diskCheckMs)) { e.diskAt = Date.now(); try { e.diskMb = await dirSizeMb(e.dir); } catch { /* keep last value */ } }
    if (e.done || e.state === 'stopping') return;
    // Limit watchdog
    if (e.diskMb > cur.disk_limit_mb) return this.enforce(e, 'disk', `Disk limit reached (${e.diskMb} MB used of ${cur.disk_limit_mb} MB). The server is being stopped. Delete some files in the File Manager, then start it again.`);
    if (!e.cgroup) {                                                   // with a cgroup the kernel enforces RAM itself
      e.overRam = rssMb > cur.ram_limit_mb ? e.overRam + 1 : 0;
      if (e.overRam >= 2) return this.enforce(e, 'ram', `Server was killed because it used more RAM (${Math.round(rssMb)} MB) than its limit (${cur.ram_limit_mb} MB).`);
    }
    if (e.state !== 'online') return;
    if (this.checkUsage(e, cur, cpu, rssMb)) return;
    let net = null;
    if (e.net) { try { net = await e.net.sample(); } catch { net = null; } }
    if (e.done || e.state === 'stopping') return;
    this.report(e.server.id, 'online', { cpuUsedPct: Math.round(cpu * 10) / 10, ramUsedMb: Math.round(rssMb), diskUsedMb: e.diskMb, playersOnline: e.players.size,
      ...(net ? { netRxBytes: net.rx, netTxBytes: net.tx, netRxBps: net.rxBps, netTxBps: net.txBps } : {}) });
  }

  /**
   * Auto-suspend. Each of RAM / CPU / disk that stays at or above usagePct% is tracked; after usageWarnMs the server gets a
   * yellow warning (usage_warning), after usageSuspendMs it is suspended: stopped and blocked until an admin unsuspends it.
   * Returns true when the server is being suspended.
   */
  checkUsage(e, cur, cpu, rssMb) {
    const o = this.o, now = Date.now();
    const pct = { RAM: rssMb / cur.ram_limit_mb * 100, CPU: cpu / cur.cpu_limit_pct * 100, Disk: e.diskMb / cur.disk_limit_mb * 100 };
    e.hot = e.hot || {};
    for (const [k, v] of Object.entries(pct)) {
      if (v >= o.usagePct) e.hot[k] = e.hot[k] || { since: now, peak: v };
      else if (v < o.usagePct - 5) delete e.hot[k];
      if (e.hot[k]) e.hot[k].peak = Math.max(e.hot[k].peak, v);
    }
    const list = Object.entries(e.hot);
    if (!list.length) { try { runtime.setUsageWarning(e.server.id, null); } catch { /* ignore */ } return false; }
    const [worst, w] = list.sort((a, b) => a[1].since - b[1].since)[0];
    const hotFor = now - w.since;
    const names = list.map(([k, x]) => `${k} ${Math.round(x.peak)}%`).join(', ');
    if (hotFor >= o.usageSuspendMs) {
      const mins = Math.max(1, Math.round(hotFor / 60000));
      const reason = `${names} of its limit for ${mins}+ min`;
      this.console.push(e.server.id, 'sys', `[minePanel] Server suspended: ${reason}.`);
      this.log(`${e.server.name}: suspended (${reason})`);
      try { runtime.suspendServer(e.server.id, reason); } catch (err) { this.log(`suspend failed: ${err.message}`); return false; }
      this.stopEntry(e);
      return true;
    }
    if (hotFor >= o.usageWarnMs) {
      const left = Math.max(1, Math.ceil((o.usageSuspendMs - hotFor) / 60000));
      const text = `${names} - above ${o.usagePct}% of what this server is allowed. If it stays this high, the server will be suspended in about ${left} min.`;
      try { runtime.setUsageWarning(e.server.id, text); } catch { /* ignore */ }
    }
    return false;
  }

  /** A server broke one of its limits: RAM -> killed at once, disk -> stopped gracefully. It is then reported as crashed. */
  enforce(e, kind, message) {
    if (e.limit || e.done) return;
    e.limit = { kind, message };
    this.log(`${e.server.name}: ${message}`);
    if (kind === 'ram') e.proc.kill('SIGKILL');
    else this.stopEntry(e);
  }

  onExit(e, code, signal, err) {
    if (e.done) return;
    try { runtime.setUsageWarning(e.server.id, null); } catch { /* ignore */ }
    e.done = true; clearTimeout(e.startTimer); clearTimeout(e.botReadyTimer); clearInterval(e.metricsTimer);
    if (e.cgroup) {                          // did the kernel kill it for using more than its RAM limit?
      if (!e.limit && this.cg.oomKills(e.cgroup) > e.oomBase) e.limit = { kind: 'ram', message: `Server was killed because it used more than its RAM limit (${e.server.ram_limit_mb} MB).` };
      this.cg.remove(e.cgroup);              // also kills anything the server left running
    }
    this.console.push(e.server.id, 'sys', `[minePanel] Server process ended (${err ? err.message : signal ? `signal ${signal}` : `exit code ${code}`}).`);
    // Exit code 143 = 128 + SIGTERM: Java was told to stop by something OUTSIDE the panel's own stop command
    // (typically `systemctl restart|stop minepanel` signalling every process of the service, or the host stopping the container).
    // Paper handles SIGTERM like /stop (worlds are saved), so this is a stop, not a crash.
    const termed = !e.limit && !e.timedOut && (signal === 'SIGTERM' || code === 143);
    if (termed && !e.stopRequested) this.console.push(e.server.id, 'sys', '[minePanel] The server received SIGTERM from outside the panel (exit code 143) - e.g. the panel service was restarted or the host stopped it. This is a stop, not a crash. Press Start to run it again.');
    if (e.limit) this.console.push(e.server.id, 'sys', `[minePanel] ${e.limit.message}`);
    else if (signal === 'SIGKILL' && !e.stopRequested && !e.timedOut) {   // killed from outside the panel: almost always the host's OOM killer
      const hm = hostMemory();
      this.console.push(e.server.id, 'sys', `[minePanel] The server was killed from outside the panel - the machine ran out of RAM (machine limit ${hm.limitMb} MB, ${hm.availableMb} MB free). Give the server less RAM or free memory on the host.`);
    }
    if (this.entries.get(e.server.id) === e) { this.entries.delete(e.server.id); if (e.persistent) detached.clearRun(this.runDir, e.server.identifier); }   // (a newer start has its own files)
    e._exited({ code, signal });
    if (!e.wasReady) {
      if (e.limit) return e._ready({ ok: false, error: e.limit.message });                       // it never became ready: the command that launched it records the outcome
      if (e.stopRequested) return e._ready({ ok: false, cancelled: true, error: 'Cancelled by a stop request' });
      if (termed) return e._ready({ ok: false, cancelled: true, error: 'Stopped by SIGTERM while starting (panel service restarted?)' });
      let reason = err ? (err.code === 'ENOENT' ? `Could not run "${e.tokens[0]}" (not found)` : err.message)
        : e.persistent && code === 127 ? `Could not run "${e.tokens[0]}" (not found)`
        : e.timedOut ? `Server did not finish starting within ${Math.round(this.o.startTimeoutMs / 1000)}s`
          : `Process exited (${signal ? `signal ${signal}` : `code ${code}`}) before it was ready`;
      const tail = e.tail.slice(-3).join(' | ').slice(0, 300);
      if (tail) reason += `: ${tail}`;
      return e._ready({ ok: false, error: reason });
    }
    if (e.limit) { if (!e.quiet) this.report(e.server.id, 'crashed', { diskUsedMb: e.diskMb }); return; }
    if (e.stopRequested) { if (!e.quiet) this.report(e.server.id, 'offline', { diskUsedMb: e.diskMb }); return; }
    // Exited on its own: a clean exit (e.g. an operator typed /stop in game) is offline, anything else is a crash.
    this.report(e.server.id, code === 0 || termed ? 'offline' : 'crashed', { diskUsedMb: e.diskMb });
  }

  /**
   * The Stop / Restart buttons (for everybody): same effect as an administrator's Force stop / Force restart. A Minecraft server is killed
   * at once (a bot gets 2 s after SIGTERM), so nothing waits for a slow or hanging shutdown. RUNTIME_QUICK_STOP_GRACE_MS > 0 first sends the console "stop" command
   * and gives the server that many ms to save and exit before the kill.
   */
  async quickStop(e, { restarting = false } = {}) {
    if (e.done) return;
    const grace = this.o.quickStopGraceMs || 0, bot = e.server.kind === 'bot';
    e.stopRequested = true; e.quiet = restarting;
    if (e.state !== 'stopping') { this.console.push(e.server.id, 'sys', `[minePanel] ${restarting ? 'Restarting' : 'Stopping'} ${bot ? 'bot' : 'server'}...`); e.state = 'stopping'; this.report(e.server.id, 'stopping', { diskUsedMb: e.diskMb }); }
    if (bot) {                                                      // a bot only gets 2 s (or the grace time) to disconnect cleanly after SIGTERM
      try { e.proc.kill('SIGTERM'); } catch { /* gone */ }
      if (await sleepRace(e.exited, Math.max(grace, 2000))) return;
    } else if (grace > 0) {
      try { e.proc.stdin.write(`${this.o.stopCommand}\n`); } catch { /* already closing */ }
      if (await sleepRace(e.exited, grace)) return;
    }
    try { e.proc.kill('SIGKILL'); } catch { /* gone */ }
    if (!(await sleepRace(e.exited, 8000)) && this.cg && this.cg.ok) this.cg.killServer(e.server.id);   // something is holding on: take the whole group
  }

  /** Graceful stop: console command, then SIGKILL after the stop timeout (bots: SIGTERM first, then SIGKILL). */
  async stopEntry(e, { restarting = false } = {}) {
    if (e.done) return;
    e.stopRequested = true; e.quiet = restarting;
    const bot = e.server.kind === 'bot';
    if (e.state !== 'stopping') this.console.push(e.server.id, 'sys', bot ? '[minePanel] Stopping bot...' : `[minePanel] Stopping server (sending "${this.o.stopCommand}")...`);
    if (e.state !== 'stopping') { e.state = 'stopping'; this.report(e.server.id, 'stopping', { diskUsedMb: e.diskMb }); }
    if (bot) e.proc.kill('SIGTERM');                      // bots have no console "stop" command: ask the process to exit
    else { try { e.proc.stdin.write(`${this.o.stopCommand}\n`); } catch { /* already closing */ } }
    if (await sleepRace(e.exited, bot ? this.o.botStopTimeoutMs : this.o.stopTimeoutMs)) return;
    if (bot) {                                            // Minecraft servers ignore SIGTERM (see launch), so only bots get this extra step
      this.log(`${e.server.name}: did not stop in time, sending SIGTERM`);
      e.proc.kill('SIGTERM');
      if (await sleepRace(e.exited, this.o.killTimeoutMs)) return;
    }
    this.log(`${e.server.name}: still running, sending SIGKILL`);
    e.proc.kill('SIGKILL');
    await e.exited;
  }
}

module.exports = { Supervisor, tokenize };
