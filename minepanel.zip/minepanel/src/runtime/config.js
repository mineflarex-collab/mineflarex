'use strict';
// Runtime (process supervisor) settings. All overridable through environment variables.
const path = require('node:path');
require('../lib/env');
const env = process.env;
const dbPath = env.DB_PATH || path.join(__dirname, '..', '..', 'data', 'minepanel.db');
const num = (v, d) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : d);
const dataDir = env.RUNTIME_DATA_DIR || (dbPath === ':memory:' ? path.join(require('node:os').tmpdir(), 'minepanel-servers') : path.join(path.dirname(dbPath), 'servers'));

module.exports = {
  // Run the supervisor inside the web process (RUNTIME=embedded) instead of as `npm run runtime`.
  embedded: env.RUNTIME === 'embedded',
  // Each server lives in <dataDir>/<identifier>/ (that is its working directory).
  dataDir,
  // Servers keep running when the panel restarts (an update, a crash): they are started detached and the next panel process
  // adopts them again (src/runtime/detached.js). Linux only; RUNTIME_PERSIST=off gives the old behaviour (servers stop with the
  // panel). RUNTIME_STOP_ON_EXIT=1 keeps detached servers but still stops them when the panel is shut down on purpose.
  persist: env.RUNTIME_PERSIST ? !/^(off|0|false|no)$/i.test(env.RUNTIME_PERSIST) : env.NODE_ENV !== 'test',
  stopOnExit: /^(1|on|true|yes)$/i.test(env.RUNTIME_STOP_ON_EXIT || ''),
  runDir: env.RUNTIME_RUN_DIR || path.join(path.dirname(dataDir), 'run'),
  // Stop / Restart buttons act like Force stop / Force restart (the process is killed at once). A grace time above 0 first sends
  // the console "stop" command and waits that long for the world to be saved before the kill (0 = kill immediately).
  quickStopGraceMs: Number(env.RUNTIME_QUICK_STOP_GRACE_MS) > 0 ? Number(env.RUNTIME_QUICK_STOP_GRACE_MS) : 0,
  pollMs: num(env.RUNTIME_POLL_MS, 250),
  // Auto-suspend: RAM / CPU / disk at usagePct% or more -> yellow warning after usageWarnMs, suspended after usageSuspendMs
  // of staying that high (the clock restarts when usage drops back under usagePct - 5%).
  usagePct: Math.min(100, num(env.RUNTIME_USAGE_PCT, 90)),
  usageWarnMs: num(env.RUNTIME_USAGE_WARN_MS, 60 * 1000),
  usageSuspendMs: num(env.RUNTIME_USAGE_SUSPEND_MS, 10 * 60 * 1000),
  metricsMs: num(env.RUNTIME_METRICS_MS, 5000),
  startTimeoutMs: num(env.RUNTIME_START_TIMEOUT_MS, 15 * 60 * 1000),
  stopTimeoutMs: num(env.RUNTIME_STOP_TIMEOUT_MS, 60 * 1000),
  killTimeoutMs: num(env.RUNTIME_KILL_TIMEOUT_MS, 10 * 1000),
  // Live console: how often captured output is written to the database / queued commands are picked up,
  // and how many lines per server are kept for scrollback.
  consoleFlushMs: num(env.RUNTIME_CONSOLE_FLUSH_MS, 100),
  consoleInputMs: num(env.RUNTIME_CONSOLE_INPUT_MS, 100),
  consoleKeepLines: num(env.CONSOLE_KEEP_LINES, 5000),
  // Bot Server: a bot is "online" once its process has been alive this long; a bot gets this long to exit after SIGTERM.
  botReadyMs: num(env.RUNTIME_BOT_READY_MS, 2000),
  botStopTimeoutMs: num(env.RUNTIME_BOT_STOP_TIMEOUT_MS, 15 * 1000),
  stopCommand: env.RUNTIME_STOP_COMMAND || 'stop',
  // Resource limits. cgroups: hard RAM/CPU limits per server (Linux cgroup v2, needs Delegate=yes); RUNTIME_CGROUPS=off disables
  // them (also the default under NODE_ENV=test). Disk is always watched: every diskCheckMs, every diskHotMs once 80% full.
  cgroups: env.RUNTIME_CGROUPS ? !/^(off|0|false|no)$/i.test(env.RUNTIME_CGROUPS) : env.NODE_ENV !== 'test',
  cgroupRoot: undefined, cgroupSelf: undefined,
  // Network totals / rates come from `ss` (iproute2): RUNTIME_NETSTATS=off disables it, RUNTIME_SS_BIN points to another binary.
  netStats: !/^(off|0|false|no)$/i.test(env.RUNTIME_NETSTATS || ''),
  ssBin: env.RUNTIME_SS_BIN || 'ss',
  diskCheckMs: num(env.RUNTIME_DISK_CHECK_MS, 60 * 1000),
  diskHotMs: num(env.RUNTIME_DISK_HOT_MS, 5 * 1000),
  // {{HEAP_MB}} = this % of the server's RAM allocation. Java needs memory beyond the heap, so with the hard RAM limit
  // lower it (e.g. 80) if a server is killed for using too much RAM.
  heapPct: Math.min(95, num(env.RUNTIME_HEAP_PCT, 75)),
  // No -XX:MaxMetaspaceSize / -XX:ReservedCodeCacheSize caps on purpose: any number of plugins may be installed and the JVM
  // takes class/code memory only as it needs it (the server RAM limit still applies as the only ceiling).
  // Used when a server has no start_command. {{HEAP_MB}} = RUNTIME_HEAP_PCT % (default 75) of the RAM allocation.
  // -XX:ActiveProcessorCount: the JVM must size its GC/JIT threads by the CPU the server may use, not by the host's cores
  // (otherwise 10+ threads fight for one core and startup is very slow). {{GC_FLAGS}}: one core -> SerialGC (low memory); two or more
  // cores -> G1 with the usual Minecraft tuning, and -Xms = -Xmx so the heap is not grown step by step while the world loads.
  defaultCommand: env.RUNTIME_DEFAULT_COMMAND || 'java -Xms{{XMS_MB}}M -Xmx{{HEAP_MB}}M -XX:ActiveProcessorCount={{CPU_CORES_INT}} {{GC_FLAGS}} -XX:+DisableExplicitGC -Xshare:auto -Dfile.encoding=UTF-8 -jar server.jar nogui',
  // A console line matching this means the server finished starting.
  readyRegex: env.RUNTIME_READY_REGEX ? new RegExp(env.RUNTIME_READY_REGEX) : /Done \([\d.,]+s\)!|For help, type "help"/
};
