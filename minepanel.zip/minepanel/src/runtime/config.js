'use strict';
// Runtime (process supervisor) settings. All overridable through environment variables.
const path = require('node:path');
require('../lib/env');
const env = process.env;
const dbPath = env.DB_PATH || path.join(__dirname, '..', '..', 'data', 'minepanel.db');
const num = (v, d) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : d);

module.exports = {
  // Run the supervisor inside the web process (RUNTIME=embedded) instead of as `npm run runtime`.
  embedded: env.RUNTIME === 'embedded',
  // Each server lives in <dataDir>/<identifier>/ (that is its working directory).
  dataDir: env.RUNTIME_DATA_DIR || (dbPath === ':memory:' ? path.join(require('node:os').tmpdir(), 'minepanel-servers') : path.join(path.dirname(dbPath), 'servers')),
  pollMs: num(env.RUNTIME_POLL_MS, 1000),
  metricsMs: num(env.RUNTIME_METRICS_MS, 5000),
  startTimeoutMs: num(env.RUNTIME_START_TIMEOUT_MS, 5 * 60 * 1000),
  stopTimeoutMs: num(env.RUNTIME_STOP_TIMEOUT_MS, 60 * 1000),
  killTimeoutMs: num(env.RUNTIME_KILL_TIMEOUT_MS, 10 * 1000),
  // Live console: how often captured output is written to the database / queued commands are picked up,
  // and how many lines per server are kept for scrollback.
  consoleFlushMs: num(env.RUNTIME_CONSOLE_FLUSH_MS, 100),
  consoleInputMs: num(env.RUNTIME_CONSOLE_INPUT_MS, 100),
  consoleKeepLines: num(env.CONSOLE_KEEP_LINES, 5000),
  // Bot Host: a bot is "online" once its process has been alive this long; a bot gets this long to exit after SIGTERM.
  botReadyMs: num(env.RUNTIME_BOT_READY_MS, 2000),
  botStopTimeoutMs: num(env.RUNTIME_BOT_STOP_TIMEOUT_MS, 15 * 1000),
  stopCommand: env.RUNTIME_STOP_COMMAND || 'stop',
  // Resource limits. cgroups: hard RAM/CPU limits per server (Linux cgroup v2, needs Delegate=yes); RUNTIME_CGROUPS=off disables
  // them (also the default under NODE_ENV=test). Disk is always watched: every diskCheckMs, every diskHotMs once 80% full.
  cgroups: env.RUNTIME_CGROUPS ? !/^(off|0|false|no)$/i.test(env.RUNTIME_CGROUPS) : env.NODE_ENV !== 'test',
  cgroupRoot: undefined, cgroupSelf: undefined,
  diskCheckMs: num(env.RUNTIME_DISK_CHECK_MS, 60 * 1000),
  diskHotMs: num(env.RUNTIME_DISK_HOT_MS, 5 * 1000),
  // {{HEAP_MB}} = this % of the server's RAM allocation. Java needs memory beyond the heap, so with the hard RAM limit
  // lower it (e.g. 80) if a server is killed for using too much RAM.
  heapPct: Math.min(95, num(env.RUNTIME_HEAP_PCT, 75)),
  // Used when a server has no start_command. {{HEAP_MB}} = RUNTIME_HEAP_PCT % (default 75) of the RAM allocation.
  // -XX:ActiveProcessorCount: the JVM must size its GC/JIT threads by the CPU the server may use, not by the host's cores
  // (otherwise 10+ threads fight for one core and startup is very slow). SerialGC + small -Xms = low memory, fast boot.
  defaultCommand: env.RUNTIME_DEFAULT_COMMAND || 'java -Xms{{XMS_MB}}M -Xmx{{HEAP_MB}}M -XX:ActiveProcessorCount={{CPU_CORES_INT}} -XX:+UseSerialGC -XX:+DisableExplicitGC -XX:MaxMetaspaceSize=256M -XX:ReservedCodeCacheSize=64M -Xshare:auto -Dfile.encoding=UTF-8 -jar server.jar nogui',
  // A console line matching this means the server finished starting.
  readyRegex: env.RUNTIME_READY_REGEX ? new RegExp(env.RUNTIME_READY_REGEX) : /Done \([\d.,]+s\)!|For help, type "help"/
};
