'use strict';
// HARD resource limits for game processes: Linux cgroup v2.
//
//   RAM   memory.max        the kernel kills the server when it tries to use more than its RAM allocation (no swap escape)
//   CPU   cpu.max           the kernel throttles the server to its CPU allocation (100% = one core, 200% = two ...)
//   PIDs  pids.max          a fork bomb cannot take the whole VPS down
//
// Every server gets its own cgroup  <panel cgroup>/mp-srv-<id>  and its process is started inside it.
// Disk has no cgroup controller: the supervisor enforces it by watching the server folder (see supervisor.js).
//
// Needs a cgroup the panel may write to. With systemd that is `Delegate=yes` in minepanel.service (already in
// deploy/minepanel.service). When cgroups are not available (macOS, Windows, a container without delegation, a
// shell session) setup() returns { ok: false, reason } and the supervisor falls back to software checks.
const fs = require('node:fs');
const path = require('node:path');

const MB = 1024 * 1024;
const PREFIX = 'mp-srv-';
const PANEL_GROUP = 'mp-panel';
const PERIOD = 100000;                       // cpu.max period in microseconds

const write = (file, value) => fs.writeFileSync(file, String(value));
const tryWrite = (file, value) => { try { write(file, value); return true; } catch { return false; } };

class Cgroups {
  constructor({ root = '/sys/fs/cgroup', selfCgroup = '/proc/self/cgroup', pidsMax = Number(process.env.RUNTIME_PIDS_MAX) || 4096, log = () => {} } = {}) {
    this.root = root; this.selfCgroup = selfCgroup; this.pidsMax = pidsMax; this.log = log;
    this.base = null; this.ok = false; this.reason = 'not set up';
  }

  /** Prepares the panel's own cgroup so it can hand out limits. Returns { ok, reason? }. Safe to call twice. */
  setup() {
    if (this.ok) return { ok: true };
    const fail = (reason) => { this.ok = false; this.reason = reason; return { ok: false, reason }; };
    if (process.platform !== 'linux') return fail('not Linux');
    try {
      if (!fs.existsSync(path.join(this.root, 'cgroup.controllers'))) return fail('cgroup v2 is not mounted');
      const line = fs.readFileSync(this.selfCgroup, 'utf8').split('\n').find((l) => l.startsWith('0::'));
      if (!line) return fail('this system uses cgroup v1');
      let rel = line.slice(3).trim();
      if (path.basename(rel) === PANEL_GROUP) rel = path.dirname(rel);                 // already moved by an earlier setup()
      const base = path.join(this.root, rel);
      const avail = fs.readFileSync(path.join(base, 'cgroup.controllers'), 'utf8').split(/\s+/);
      for (const c of ['memory', 'cpu']) if (!avail.includes(c)) return fail(`the ${c} controller is not available in the panel's cgroup`);
      // cgroup v2 "no internal processes": controllers can only be enabled for children while this cgroup holds no
      // processes itself, so the panel moves into a child group first.
      const panel = path.join(base, PANEL_GROUP);
      fs.mkdirSync(panel, { recursive: true });
      write(path.join(panel, 'cgroup.procs'), process.pid);
      tryWrite(path.join(base, 'cgroup.subtree_control'), ['memory', 'cpu', 'pids'].filter((c) => avail.includes(c)).map((c) => `+${c}`).join(' '));
      const enabled = fs.readFileSync(path.join(base, 'cgroup.subtree_control'), 'utf8').split(/\s+/).map((c) => c.replace(/^\+/, ''));
      if (!enabled.includes('memory') || !enabled.includes('cpu')) return fail('could not enable the memory/cpu controllers (is Delegate=yes set in the systemd unit?)');
      this.base = base; this.ok = true; this.reason = '';
      this.sweep();
      return { ok: true };
    } catch (err) {
      return fail(err.code === 'EACCES' || err.code === 'EPERM' || err.code === 'EROFS' ? 'no permission to manage cgroups (add Delegate=yes to the systemd unit)' : err.message);
    }
  }

  /** Removes empty leftovers of a previous run. */
  sweep() {
    try { for (const n of fs.readdirSync(this.base)) if (n.startsWith(PREFIX)) { try { fs.rmdirSync(path.join(this.base, n)); } catch { /* still in use */ } } } catch { /* ignore */ }
  }

  /** Creates (or updates) the cgroup of a server with its limits. Returns { dir, procsFile }. */
  apply(server) {
    if (!this.ok) throw new Error('cgroups are not set up');
    const dir = path.join(this.base, `${PREFIX}${server.id}`);
    fs.mkdirSync(dir, { recursive: true });
    write(path.join(dir, 'memory.max'), Math.max(16, Math.floor(server.ram_limit_mb)) * MB);
    tryWrite(path.join(dir, 'memory.swap.max'), 0);                                    // swap would let a server exceed its RAM
    tryWrite(path.join(dir, 'memory.oom.group'), 1);                                   // an OOM kill takes the whole server (all its processes)
    write(path.join(dir, 'cpu.max'), `${Math.max(1000, Math.round(server.cpu_limit_pct * (PERIOD / 100)))} ${PERIOD}`);
    tryWrite(path.join(dir, 'pids.max'), this.pidsMax);
    return { dir, procsFile: path.join(dir, 'cgroup.procs') };
  }

  /** How many times the kernel OOM-killed this server (it exceeded its RAM limit). */
  oomKills(dir) {
    try { const m = /^oom_kill (\d+)/m.exec(fs.readFileSync(path.join(dir, 'memory.events'), 'utf8')); return m ? Number(m[1]) : 0; } catch { return 0; }
  }

  /** Kills anything still left in the group (orphaned children) and deletes it. */
  remove(dir) {
    if (!dir) return;
    tryWrite(path.join(dir, 'cgroup.kill'), 1);
    let tries = 0;
    const attempt = () => { try { fs.rmdirSync(dir); } catch (err) { if (err.code !== 'ENOENT' && ++tries < 10) setTimeout(attempt, 200).unref(); } };
    attempt();
  }

  /** Kills every process of one server's group (also orphans left by an earlier panel run) and removes the group. */
  killServer(id) { if (this.ok) this.remove(path.join(this.base, `${PREFIX}${id}`)); }

  /** The command to spawn: a tiny fixed shell wrapper moves itself into the cgroup, then exec()s the server (same pid, no race). */
  wrap(tokens, procsFile) {
    return { cmd: '/bin/sh', args: ['-c', 'echo $$ > "$0" || exit 126; exec "$@"', procsFile, ...tokens] };
  }
}

module.exports = { Cgroups, PREFIX };
