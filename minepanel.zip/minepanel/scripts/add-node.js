'use strict';
// Usage: npm run add-node -- <name> <fqdn> [--location "Frankfurt, DE"] [--ram MB] [--cpu PCT] [--disk MB] [--status online|offline|maintenance]
require('../src/dashboard'); // ensure tables exist
const nodes = require('../src/dashboard/services/nodes');

const [name, fqdn, ...rest] = process.argv.slice(2);
const opt = {};
for (let i = 0; i < rest.length; i += 2) opt[String(rest[i]).replace(/^--/, '')] = rest[i + 1];
if (!name || !fqdn) { console.error('Usage: npm run add-node -- <name> <fqdn> [--location TEXT] [--ram MB] [--cpu PCT] [--disk MB] [--status online|offline|maintenance]'); process.exit(1); }
if (opt.status && !nodes.STATUSES.includes(opt.status)) { console.error(`Status must be one of: ${nodes.STATUSES.join(', ')}`); process.exit(1); }

try {
  const n = nodes.create({ name, fqdn, location: opt.location || null, status: opt.status || 'online',
    ramTotalMb: +opt.ram || 0, cpuTotalPct: +opt.cpu || 0, diskTotalMb: +opt.disk || 0 });
  console.log(`Node #${n.id} "${n.name}" (${n.fqdn}) added.`);
} catch (e) {
  console.error(/UNIQUE/.test(e.message) ? 'A node with this name already exists.' : e.message); process.exit(1);
}
