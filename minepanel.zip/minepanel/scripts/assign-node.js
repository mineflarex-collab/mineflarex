'use strict';
// Usage: npm run assign-node -- <server-identifier> <node-name>      (use "none" to unassign)
require('../src/dashboard'); // ensure tables exist
const db = require('../src/db');
const nodes = require('../src/dashboard/services/nodes');
const servers = require('../src/dashboard/services/servers');

const [identifier, nodeName] = process.argv.slice(2);
if (!identifier || !nodeName) { console.error('Usage: npm run assign-node -- <server-identifier> <node-name | none>'); process.exit(1); }

const server = db.prepare('SELECT id, name FROM servers WHERE identifier = ?').get(identifier);
if (!server) { console.error(`No server with identifier ${identifier}`); process.exit(1); }
let node = null;
if (nodeName.toLowerCase() !== 'none') {
  node = nodes.findByName(nodeName);
  if (!node) { console.error(`No node named "${nodeName}". Create it with: npm run add-node`); process.exit(1); }
}
servers.assignNode(server.id, node ? node.id : null);
console.log(node ? `Server "${server.name}" (${identifier}) is now on node "${node.name}".` : `Server "${server.name}" (${identifier}) was unassigned from its node.`);
