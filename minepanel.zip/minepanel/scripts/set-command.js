'use strict';
// Usage: npm run set-command -- <server-identifier> "<command>"      (use "default" to restore the runtime default)
// Placeholders: {{RAM_MB}} {{HEAP_MB}} {{CPU_CORES}} {{DIR}} {{IDENTIFIER}}. The command runs without a shell, inside the server's directory.
require('../src/dashboard'); // ensure tables exist
const db = require('../src/db');
const { tokenize } = require('../src/runtime/supervisor');

const [identifier, command] = process.argv.slice(2);
if (!identifier || !command) { console.error('Usage: npm run set-command -- <server-identifier> "<command>" | default'); process.exit(1); }
const server = db.prepare('SELECT id, name FROM servers WHERE identifier = ?').get(identifier);
if (!server) { console.error(`No server with identifier ${identifier}`); process.exit(1); }
if (command !== 'default') { try { tokenize(command); } catch (e) { console.error(e.message); process.exit(1); } }
db.prepare('UPDATE servers SET start_command = ?, updated_at = ? WHERE id = ?').run(command === 'default' ? null : command, Date.now(), server.id);
console.log(`"${server.name}" will now start with: ${command === 'default' ? '(runtime default)' : command}`);
