'use strict';
// Usage: npm run grant-access -- <server-identifier> <user-email> <start,stop,restart,console,command,files,filewrite | view | none>
//   start,stop,restart  power permissions     console  watch the live console     command  type commands into it (implies console)
//   files  browse and search the server's files     filewrite  create, rename and delete files and folders (implies files)
//   view  view-only access (no console)       none  remove access
require('../src/dashboard'); // ensure tables exist
const db = require('../src/db');
const users = require('../src/services/users');
const access = require('../src/dashboard/services/access');

const [identifier, email, perms] = process.argv.slice(2);
if (!identifier || !email || !perms) { console.error('Usage: npm run grant-access -- <server-identifier> <user-email> <start,stop,restart,console,command,files,filewrite | view | none>'); process.exit(1); }
const server = db.prepare('SELECT id, name, owner_id FROM servers WHERE identifier = ?').get(identifier);
if (!server) { console.error(`No server with identifier ${identifier}`); process.exit(1); }
const user = users.findByEmail(email);
if (!user) { console.error(`No user with email ${email}`); process.exit(1); }
if (user.id === server.owner_id) { console.error('That user already owns this server.'); process.exit(1); }

if (perms === 'none') {
  console.log(access.revoke(server.id, user.id) ? `Removed ${user.username}'s access to "${server.name}".` : `${user.username} had no access to "${server.name}".`);
} else {
  const PERM = { start: 'control.start', stop: 'control.stop', restart: 'control.restart', console: 'console.view', command: 'console.send', files: 'files.view', filewrite: 'files.write' };
  const NAME = Object.fromEntries(Object.entries(PERM).map(([k, v]) => [v, k]));
  const names = perms === 'view' ? [] : perms.split(',').map((p) => p.trim());
  const unknown = names.filter((n) => !PERM[n]);
  if (unknown.length) { console.error(`Unknown permission: ${unknown.join(', ')}. Use any of: start, stop, restart, console, command, files, filewrite (or "view", "none").`); process.exit(1); }
  const list = names.map((n) => PERM[n]);
  try { access.grant({ serverId: server.id, userId: user.id, permissions: list }); }
  catch (e) { console.error(`${e.message}. Use any of: start, stop, restart, console, command, files, filewrite (or "view", "none").`); process.exit(1); }
  const have = access.forUser(user.id, server);
  console.log(`${user.username} now has ${list.length ? [...have.permissions].map((p) => NAME[p]).join(', ') : 'view-only'} access to "${server.name}".`);
}
