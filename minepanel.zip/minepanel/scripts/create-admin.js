'use strict';
// Usage: npm run create-admin -- <email> <username>      (password is prompted, input hidden)
//        ADMIN_PASSWORD=... npm run create-admin -- <email> <username>
const readline = require('node:readline');
const v = require('../src/lib/validate');
const { hashPassword } = require('../src/lib/crypto');
const users = require('../src/services/users');

function askHidden(prompt) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    rl._writeToOutput = (s) => { if (s.includes(prompt)) process.stdout.write(s); };
    rl.question(prompt, (a) => { rl.close(); process.stdout.write('\n'); resolve(a); });
  });
}

(async () => {
  const [email, username] = process.argv.slice(2);
  if (!email || !username) { console.error('Usage: npm run create-admin -- <email> <username>'); process.exit(1); }
  const password = process.env.ADMIN_PASSWORD || await askHidden('Password: ');
  const problem = v.email(email) || v.username(username) || v.password(password);
  if (problem) { console.error(problem); process.exit(1); }

  const existing = users.findByEmail(email);
  if (existing) {
    users.setRole(existing.id, 'admin');
    console.log(`Existing user "${existing.username}" promoted to admin (password unchanged).`);
    return;
  }
  if (users.findByUsername(username)) { console.error(`That username is taken: ${username}`); process.exit(1); }
  const u = users.create({ username, email, passwordHash: await hashPassword(password), role: 'admin' });
  console.log(`Admin created: ${u.username} <${u.email}>`);
})().catch((e) => { console.error(e.message); process.exit(1); });
