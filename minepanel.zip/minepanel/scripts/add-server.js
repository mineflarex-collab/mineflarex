'use strict';
// Bot Host:  npm run add-server -- <owner-email> <bot-name> --kind bot --runtime python|nodejs [--entry main.py]
// MC Host:   (default) a Paper server
// Usage: npm run add-server -- <owner-email> <server-name> [--ram 2048] [--cpu 100] [--disk 10240]
//        [--players 20] [--software paper] [--version 1.21.4] [--address host:port] [--node node-name] [--command "java -jar ..."]
require('../src/dashboard'); // ensure tables exist
const users = require('../src/services/users');
const servers = require('../src/dashboard/services/servers');
const nodes = require('../src/dashboard/services/nodes');
const activity = require('../src/dashboard/services/activity');

const [email, name, ...rest] = process.argv.slice(2);
const opt = {};
for (let i = 0; i < rest.length; i += 2) opt[String(rest[i]).replace(/^--/, '')] = rest[i + 1];
if (!email || !name) { console.error('Usage: npm run add-server -- <owner-email> <server-name> [--ram MB] [--cpu PCT] [--disk MB] [--players N] [--software X] [--version X] [--address host:port] [--node NAME] [--command CMD]'); process.exit(1); }

const owner = users.findByEmail(email);
if (!owner) { console.error(`No user with email ${email}`); process.exit(1); }
let node = null;
if (opt.node) {
  node = nodes.findByName(opt.node);
  if (!node) { console.error(`No node named "${opt.node}". Create it with: npm run add-node`); process.exit(1); }
}
const kind = opt.kind === 'bot' ? 'bot' : 'mc';
let runtime = null, command = opt.command || null;
if (kind === 'bot') {
  const rt = servers.RUNTIMES[opt.runtime];
  if (!rt) { console.error('A bot needs --runtime python or --runtime nodejs'); process.exit(1); }
  const entry = opt.entry || rt.defaultEntry;
  if (!/^(?!.*\.\.)[A-Za-z0-9_][A-Za-z0-9_./-]{0,59}$/.test(entry)) { console.error('Invalid --entry (use a file name like main.py)'); process.exit(1); }
  runtime = opt.runtime; command = command || rt.command(entry);
}
try {
  const s = servers.create({ kind, runtime, nodeId: node ? node.id : null, startCommand: command, ownerId: owner.id, name, software: kind === 'bot' ? servers.RUNTIMES[runtime].label : 'paper', version: kind === 'bot' ? 'latest' : opt.version, address: opt.address || null,
    ramLimitMb: +opt.ram || 2048, cpuLimitPct: +opt.cpu || 100, diskLimitMb: +opt.disk || 10240, playersMax: +opt.players || 20 });
  activity.record({ userId: owner.id, serverId: s.id, serverName: s.name, type: 'server.created', message: `Server ${s.name} was added to your account` });
  console.log(`Server "${s.name}" added for ${owner.username}. Identifier: ${s.identifier}${node ? `, node: ${node.name}` : ''}`);
} catch (e) {
  console.error(/UNIQUE/.test(e.message) ? 'That user already has a server with this name.' : e.message); process.exit(1);
}
