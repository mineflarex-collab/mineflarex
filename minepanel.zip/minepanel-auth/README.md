# minePanel – Authentication System

Zero npm dependencies. Needs **Node.js ≥ 22.13** (uses built-in `node:sqlite` and `crypto.scrypt`).

## Run
```bash
cp .env.example .env        # then export the vars (or use your process manager)
npm start                   # http://localhost:3000
npm run create-admin -- you@example.com yourname   # prompts for password
npm test                    # integration tests
```
Dev mode prints reset emails to the console (`MAIL_DRIVER=log`). For real delivery set `MAIL_DRIVER=smtp` + `SMTP_*` (STARTTLS/TLS supported; credentials are never sent unencrypted).

## Structure
```
server.js                 entry point
src/config.js             all settings (lockout, TTLs, password rules, CSP, landing pages)
src/db.js                 SQLite + versioned migrations (users, sessions, password_resets)
src/app.js                middleware order + error handling
src/lib/                  http (router/cookies/body), crypto (scrypt, tokens), validate, rateLimit, mailer (SMTP)
src/services/             users, sessions, passwordResets  (all DB logic)
src/middleware/auth.js    securityHeaders, CSRF, loadSession, requireAuth, requireRole, requireAdmin, guestOnly
src/routes/auth.js        /login /register /forgot-password /reset-password /logout
src/routes/protected.js   placeholder /account, /admin, /api/me  (replace with dashboard)
src/views/                markup only (.mp-* classes) – layout.js, pages.js
public/css/auth.css       neutral placeholder styles – swap for your theme
public/js/auth.js         client-side validation, show/hide password
```

## Protecting routes
```js
const { requireAuth, requireAdmin, requireRole } = require('../middleware/auth');
router.get('/servers', requireAuth, handler);
router.get('/admin/users', requireAdmin, handler);
router.post('/servers/create', requireRole('admin','user'), handler);
```
`ctx.user` = `{ id, username, email, role }`. Every POST form must include `<input type="hidden" name="_csrf" value="${ctx.csrfToken}">`.

## Security summary
- scrypt (N=2¹⁵) password hashing, per-user salt, automatic rehash on parameter change, constant-time compare, dummy hash for unknown users
- Sessions: 256-bit random token in HttpOnly/SameSite=Lax (Secure in production) cookie; only its SHA-256 is stored; new ID on every login; sliding expiry (12 h, or 30 d with "keep me signed in"); disabled users are signed out
- Logout is POST + CSRF and deletes the server-side session
- Reset: 256-bit single-use token (hash stored), 1 h expiry, only newest link valid, generic response (no account enumeration), reset signs out all devices
- Lockout after 5 failures (15 min) + per-IP rate limits on login/register/forgot/reset
- CSRF double-submit with HMAC-signed cookie + Origin check; CSP, X-Frame-Options, no-store, HSTS (prod); open-redirect-safe `next`
- Roles: `user` / `admin` (DB CHECK constraint). Create the first admin via the script; there is no self-service admin signup.

## File manager
Browse, search, create, rename, delete, **upload** (drag & drop, 32 MiB chunks so it passes Cloudflare's 100 MB limit; max size `UPLOAD_MAX_MB`, default 2048), **download** and **edit** text files (<= 1 MB, Ctrl+S). Theme: black + purple (`--accent:#8b5cf6` in `public/css/auth.css`).

## VPS + Cloudflare
See `deploy/DEPLOY.md` (installed from the MineFlareX menu: option [2] MINE PANEL, systemd service, Cloudflare Tunnel to `http://localhost:3000`, nginx alternative). `.env` is now loaded automatically.

## Production checklist
Set `NODE_ENV=production`, a strong `SESSION_SECRET`, `BASE_URL` (https), SMTP settings, and `TRUST_PROXY=true` only behind a trusted reverse proxy (TLS terminated there, `Host` forwarded). Back up `data/minepanel.db`. The rate limiter is in-memory (single process); use a shared store if you run multiple instances.

---

# Admin panel (`/admin`)

Administrators land here after signing in. The left sidebar has three entries:

| Sidebar | Page | What it does |
| --- | --- | --- |
| **Users** | `/admin/users` | Search accounts, add a user, make someone admin / user, enable / disable an account. You cannot change yourself, and the last active administrator is always kept. |
| **Servers → Bot Host** | `/admin/servers/bots` | Python and Node.js bots. Both runtimes are already installed on the machine, so creating a bot only asks for a runtime (and optionally a start file: `main.py` / `index.js` by default). |
| **Servers → MC Host** | `/admin/servers/mc` | Minecraft servers. The software is always **Paper**. |
| **Settings** | `/admin/settings` | Panel name and logo. Both are used in the top bar, the sign-in / register pages and the browser tab. |

* **Create**: `Create Bot` / `Create MC Server` on the two Servers pages (or `npm run add-server -- <email> <name> --kind bot --runtime python`).
* **Panel name**: 2-32 characters, stored in the database (`panel_settings`). "Use default" goes back to `PANEL_NAME` (or ZynexNode).
* **Logo**: PNG, JPG, WebP or GIF up to 1 MB, stored in the database (`panel_assets`) and served from `/brand/logo` (public, so the login page can show it). SVG is refused on purpose. The type is checked from the file's real bytes, not its name.
* **Bots at runtime**: a bot is `online` once its process has stayed alive for `RUNTIME_BOT_READY_MS` (default 2000), it is stopped with SIGTERM (then SIGKILL after `RUNTIME_BOT_STOP_TIMEOUT_MS`, default 15000), and a bot that exits straight away is reported as a failed start with the last console lines. Minecraft-only tools (Server Properties, Players, Worlds, Plugins...) are hidden for bots.
* **No Node option**: servers are no longer assigned to a node when they are created from the admin panel (the Node field and column are gone).
* **VPS capacity**: there is no limit on the number of servers, only on the machine. Together the servers may use up to **90%** of the VPS RAM, CPU and disk (`src/dashboard/services/capacity.js`). A resource counts as full when the limits given to all servers add up to 90% of it, or the VPS really uses 90% of it. Then every admin page shows a centred warning ("VPS is full ... Do not create any more servers. Upgrade your VPS to add more."), the Create buttons are disabled and creating a server is refused. A single new server that would push a resource past 90% is refused too. The Bot Host and MC Host pages show the three meters. Overrides for containers: `VPS_RAM_MB`, `VPS_CPU_CORES`, `VPS_DISK_MB`, `VPS_LIMIT_PCT` (default 90).
* Existing servers are Minecraft servers (`kind = 'mc'`): the migration needs no manual step.
* Code: `src/dashboard/adminPanel.js` (users, server lists, settings), `src/dashboard/admin.js` (create server), `src/services/settings.js` (name + logo), `public/js/admin.js`, `public/css/admin.css`. Tests: `tests/admin.test.js`.

# User Dashboard (`src/dashboard/`)

Self-contained module: own migrations (`dashboard_migrations` table), services, routes and views. Auth code is untouched; it is wired in with one line in `src/app.js`, and the user landing page in `src/config.js` now points to `/dashboard`.

| Route | Purpose |
|---|---|
| `GET /dashboard` | Totals (total/online/offline), resource overview, profile summary, server list with quick actions, recent activity |
| `GET /dashboard/servers` | Full server list |
| `GET /dashboard/activity` | Paginated activity history |
| `GET /dashboard/profile` | Profile information |
| `GET /dashboard/settings` | Edit profile, change password, manage signed-in devices |
| `POST /dashboard/servers/action` | Start / stop / restart (ownership + state validated, CSRF protected) |
| `GET /api/dashboard/summary` | JSON used for 10-second live refresh |

All routes use `requireAuth`; every query is scoped to `ctx.user.id`, so users only ever see their own servers and activity.

## Where the data comes from
Everything shown is read from SQLite (`servers`, `server_commands`, `activity_log`). Nothing is generated. A new account correctly shows zeros and empty states.

- **Servers:** register one for a user with `npm run add-server -- user@example.com "Survival" --ram 4096 --cpu 200 --disk 20480 --players 30 --address play.example.com:25565` (a server-creation UI is part of the later server-management work).
- **Live status/metrics:** reported by whatever process runs the Minecraft servers, through `src/dashboard/services/runtime.js`:
  - `reportStatus(serverId, { status, cpuUsedPct, ramUsedMb, diskUsedMb, playersOnline })`
  - `pendingCommands()` / `completeCommand(id, { ok, error })`
- **Quick actions** queue a `server_commands` row and move the server to `starting`/`stopping`; the **runtime** (see *Server controls* below) executes the command and reports the real outcome with the functions above.
- **Activity:** written by the dashboard (actions, profile/password/session changes) and by `reportStatus` (status changes). Sign-ins are not logged because that would require changing the auth system; last sign-in time is shown from the existing user record.

Counting rules: *Online* = `online`; *Offline* = `offline` + `crashed`; `starting`/`stopping` count toward the total and show as "changing state". Memory/CPU/player usage sums online servers; limits sum everything allocated to the user.

## Theming
Markup uses only `.mp-*` classes; `public/css/dashboard.css` (plus `auth.css`) is neutral placeholder styling, so replace those files. Progress bars use `<progress>` because the CSP forbids inline styles.

---

# Server Management List (`/dashboard/servers`)

Adds the full server list, search, filters, sorting, pagination and a details page. Everything is read from SQLite (`servers`, `nodes`, `server_commands`, `activity_log`); every query is scoped to the signed-in user.

| Route | Purpose |
|---|---|
| `GET /dashboard/servers` | List: name, identifier, status, RAM / CPU / disk allocation (with live usage), node. Search, status chips, node + software filters, sortable columns, 20 per page |
| `GET /dashboard/servers/:identifier` | Details: overview, resources (allocation + usage), node, actions, command history, recent activity |
| `GET /api/dashboard/servers` | Same list as JSON (same query parameters) |
| `GET /api/dashboard/servers/:identifier` | One server as JSON (polled every 10 s by the details page) |

**Query parameters** (list page and API): `q` (searches name, identifier, address, software, version, node name/location – case-insensitive, `%`/`_` are literal), `status` (`online|offline|starting|stopping|crashed`), `node` (node id or `none` for unassigned), `software`, `sort` (`name|status|ram|cpu|disk|node|created`), `dir` (`asc|desc`), `page`. Invalid values are ignored, and sort columns come from a whitelist (never interpolated from input).

**Identifiers:** every server gets a unique 8-character hex identifier (e.g. `a3f91c2e`) used in URLs. Servers that existed before this update are backfilled by migration #2. Unknown identifiers and other users' servers both return 404.

**Nodes:** a node is a machine that runs servers (`nodes` table: name, location, hostname, status, capacity). Users see the node name, location and status; the hostname is shown to admins only.
```bash
npm run add-node -- Frankfurt-1 fra1.example.com --location "Frankfurt, DE" --ram 65536 --cpu 1600 --disk 1048576
npm run add-server -- user@example.com "Survival" --ram 4096 --cpu 200 --disk 20480 --node Frankfurt-1
npm run assign-node -- <server-identifier> Frankfurt-1      # or "none" to unassign
```
**Allocation vs usage:** allocation is the server's limits (`ram_limit_mb`, `cpu_limit_pct` where 100 = one core, `disk_limit_mb`); usage comes from `runtime.reportStatus(...)` as before.

**Code touched outside `src/dashboard/`:** only `src/lib/http.js` – the router now understands `:param` path segments (exact paths still win; `ctx.params` is available). Nothing else in the auth system changed.

**Tests:** `tests/servers.test.js` (13 tests: search, filters, sorting, pagination, details, 404/isolation, actions, JSON API, admin-only node address, XSS escaping, CSP).


---

# Server controls (Start / Stop / Restart)

Nothing here is simulated. A button press queues a command; the **runtime** (`src/runtime/supervisor.js`) spawns or stops a real OS process and reports what actually happened back to the database; the UI reads that.

## Running it
```bash
npm start            # the web panel
npm run runtime      # the runtime: run exactly ONE per database (separate process, recommended)
# or run both in one process:  RUNTIME=embedded npm start
```
Each server lives in `<RUNTIME_DATA_DIR>/<identifier>/` (default: `servers/` next to the database) and starts with its `start_command`, run **without a shell** in that directory. The default is `java -Xmx{{HEAP_MB}}M -jar server.jar nogui`, so put the jar there. Per server: `npm run set-command -- <identifier> "<command>"` (or `add-server --command`). Placeholders: `{{RAM_MB}} {{HEAP_MB}} {{CPU_CORES}} {{DIR}} {{IDENTIFIER}}`. Game processes get a minimal environment, never the panel's secrets.

## What the runtime really does
| Action | Behaviour |
|---|---|
| Start | spawns the process → `starting` → `online` once the console prints the ready line (`RUNTIME_READY_REGEX`) → command `done`. Failure (missing binary, early exit, timeout) → `crashed`, with the real reason and last console lines in the command history |
| Stop | writes `stop` to the console → waits (`RUNTIME_STOP_TIMEOUT_MS`) → SIGTERM → SIGKILL (`RUNTIME_KILL_TIMEOUT_MS`) → `offline`. Stopping a server that is still booting cancels the startup |
| Restart | graceful stop, then a **new** process: `stopping → starting → online` |
| Crash | an unexpected non-zero exit is reported as `crashed`; a clean exit (operator typed `/stop`) as `offline` |
| Usage | RAM and CPU of the real process every `RUNTIME_METRICS_MS` (from `/proc` on Linux, `ps` elsewhere), disk size of the server directory, online players from the console's join/leave lines |
| Restart of the runtime | servers recorded as running with no process are corrected to `offline`; on shutdown all servers are stopped gracefully |

**Limits to know:** RAM is limited through the JVM heap flag in the command, not by the OS; CPU and disk allocations are *monitored and displayed*, not enforced (that needs containers/cgroups). Servers are children of the runtime, so a hard kill (`kill -9`) of the runtime can leave orphan processes.

## Permissions
The owner can do everything. Others see a server only if it was shared with them, with any of `start`, `stop`, `restart` (or view-only):
```bash
npm run grant-access -- <identifier> friend@example.com start,restart     # or: view | none
```
Enforced in one place (`servers.requestCommand`), so web and API behave the same: unrelated users get 404 (same as a missing server), missing permission gets 403. Buttons a user cannot use are not shown. Shared servers appear in the list marked **shared**.

## Confirmation
Stop and Restart open a confirmation page (works without JavaScript) and the service refuses them without `confirm` (web: `confirm=1`; API: `"confirm": true` → otherwise **428**). Start needs none.

## JSON API
`GET /api/dashboard/csrf` returns the token to send as `X-CSRF-Token`; requests need the session cookie and `Accept: application/json`.
```
POST /api/dashboard/servers/:identifier/power   { "action": "start|stop|restart", "confirm": true }
  202 queued · 403 no permission · 404 unknown · 409 invalid state / command in progress · 422 bad action · 428 confirmation required
GET  /api/dashboard/servers/:identifier         -> server, access role, permissions, allowedActions (permission AND state)
```

## Real-time updates
`GET /api/dashboard/events` is a Server-Sent Events stream (`snapshot` on connect, then `update` with every server that changed, including live usage). It reads the database once a second, so changes made by a separate runtime process show up too (states shorter than a second may be skipped). Pages reload when a server's status changes (the valid buttons change with it) and update usage numbers in place; if the stream is unavailable they fall back to polling. Streams are limited to 8 per user and recycle every 5 minutes.

**Tests:** `tests/controls.test.js` (permissions, confirmation, API, stream, end-to-end) and `tests/runtime.test.js` (real processes: start, stop, restart, crash, failures, stop-while-starting, SIGTERM/SIGKILL escalation, secret isolation). `tests/fixtures/fake-mc.js` stands in for the Minecraft *binary* only; the panel and runtime under test are the real ones.


---

# Live console (real-time logs + commands)

Open **Servers → a server → Open console** (`/dashboard/servers/:identifier/console`). Output of the real Minecraft process streams in as it is printed; commands you type are written to that process's console (stdin). Nothing is simulated.

## How it is wired
```
Minecraft process ──stdout/stderr──▶ runtime (Supervisor) ──batched writes──▶ console_lines ─┐
                                                                                               ├─ SQLite (shared by both processes)
browser ◀──WebSocket── panel (consoleSocket.js) ◀──polls every 100 ms───────────────────────────┘
browser ──WebSocket──▶ panel ──console_input queue──▶ runtime ──stdin──▶ Minecraft process
```
The panel and the runtime may be separate OS processes (recommended), so they meet in the database, exactly like the Start/Stop queue. The WebSocket server is a small RFC 6455 implementation in `src/lib/websocket.js` (still zero npm dependencies).

| File | Role |
|---|---|
| `src/runtime/supervisor.js` | captures stdout/stderr of every server, writes `[minePanel]` notices (start, stop, exit code), delivers queued commands to stdin |
| `src/dashboard/services/serverConsole.js` | buffered log writer (one transaction per 100 ms, retention pruning), command queue, per-user command history |
| `src/dashboard/consoleSocket.js` | WebSocket endpoint: auth, permissions, protocol, fan-out |
| `src/lib/websocket.js` | WebSocket protocol (framing, fragmentation, ping/pong, close codes, limits) |
| `public/js/console.js`, `public/css/console.css` | the console page |

## What the console does
- **Real-time logs**: new lines are pushed within ~100–200 ms. stdout and stderr are both shown; ANSI colours are rendered; `WARN`/`ERROR` lines are tinted; commands that were sent show as `username> command`.
- **Command input**: Enter sends. Disabled while the server is not `online`/`starting` and for users without permission. The result is whatever the process prints back.
- **Command history**: ↑/↓ walk through your previous commands (kept per user and server, last 100, stored in the database so it follows you across devices). Esc clears the input.
- **Auto-scroll**: follows the output while you are at the bottom; scrolling up pauses it and shows a "N new lines" button; sending a command resumes it. A toggle is in the toolbar.
- **Scrollback**: the first 500 lines load immediately, older lines load automatically when you scroll to the top. The database keeps `CONSOLE_KEEP_LINES` (default 5000) per server, across restarts of the server. The page keeps at most 3000 lines in the DOM.
- **Reconnect**: if the connection drops it reconnects with back-off and resumes from the last line it saw (no gaps, no duplicates). A ping every 20 s detects half-dead connections.
- **Clear** only clears your view; **Download** saves what is on screen as a `.log` file.

## Permissions
Owner: everything. Shared users need an explicit grant (a plain "view only" share does **not** show the console, because logs contain player IPs and chat):
```bash
npm run grant-access -- <identifier> friend@example.com console            # may watch
npm run grant-access -- <identifier> friend@example.com command            # may watch and type commands (implies console)
npm run grant-access -- <identifier> friend@example.com start,restart,command
```
`command` lets someone run any server command (`op`, `ban`, …). Typing `stop` / `restart` additionally requires the `stop` / `restart` grant, so the console cannot be used to bypass power permissions. Permissions are re-checked on **every command**, and open consoles are re-validated every 15 s (sign-out, "sign out other devices", removed grants and deleted servers close the socket).

## Security notes
- Session cookie authentication on the handshake, `Origin` must match `Host` (no cross-site WebSocket hijacking), max 10 consoles per user.
- Commands: max 1000 characters, no control characters or line breaks (a second command cannot be smuggled in), 5 per second per connection (bursts of 10). Every command is written to the owner's activity log with the name of whoever ran it.
- Messages are limited to 16 KB, only text frames are accepted, client frames must be masked, invalid UTF-8 and protocol violations close the connection with the proper code. A client that cannot keep up (4 MB unsent) is disconnected.
- Output is inserted into the page with `textContent` / element nodes only (never `innerHTML`), so a server (or a player's chat message) cannot inject markup. The CSP gained `connect-src 'self' ws(s)://<BASE_URL host>`.
- Commands queued while the runtime was down are **failed, never replayed** later. A command nobody picks up within 10 s is reported in the console as not delivered.

## Running behind a reverse proxy
The proxy must forward WebSocket upgrades and not buffer or time out idle connections too aggressively. nginx:
```nginx
location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection $connection_upgrade;   # map $http_upgrade $connection_upgrade { default upgrade; '' close; }
    proxy_set_header Host $host;
    proxy_read_timeout 120s;                           # the console pings every 15-20 s
}
```
Keep `Host` unchanged (the Origin check compares it) and set `BASE_URL` to the public https URL.

## Limits to know
- Output is what the process writes to stdout/stderr. Lines a server writes only to its own log file (e.g. `logs/latest.log` when the logger is configured to be file-only) do not appear.
- A line is stored up to 4000 characters. If a server prints more than ~5000 lines within one 100 ms flush, the excess is dropped and the console says how many.
- Latency is bounded by the 100 ms polling on both sides (tunable with `RUNTIME_CONSOLE_*`); this is what lets the panel and runtime run as separate processes without extra infrastructure.

**Tests:** `tests/console.test.js` (real WebSocket client, real runtime and child processes: handshake/auth/origin, live output, command → process → output, history, resume, scrollback, permissions re-checked per command, validation, rate limit, protocol violations, abrupt disconnects, stop via console, static assets) and `tests/console-runtime.test.js` (queued commands are not replayed after a runtime restart).

**Fixed along the way:** `src/lib/http.js` `serveStatic` returned before the file finished streaming, so the router answered 404 after sending the headers and destroyed the socket — CSS/JS under `/public` never loaded in a browser. It now waits for the stream to finish.

---

# ZynexNode theme

The whole panel was restyled to match the reference screenshots (login, register, dashboard, account, server console).

**Settings** (`.env`): `PANEL_NAME` (default `ZynexNode™`), `SUPPORT_URL`, `STATUS_URL`, `DOCS_URL`.

**Images** (`public/img/`) – replace any of them with the originals, keeping the file name:

| File | Used for | Origin |
|---|---|---|
| `logo.svg` | header, login card, favicon | recreation (gold burst) – replace with your real logo |
| `bg.svg` | sign-in background | generated purple "server racks" scene |
| `server-banner.jpg` | server card + console header | cropped from the reference screenshot (low resolution) |
| `console-art.png` | art card on the console page | cropped from the reference screenshot (low resolution) |
| `server-icon.svg` | server tile | generated grass-block icon |
| `avatar-steve.svg`, `avatar-alex.svg` | top-right avatar (by user id) | generated pixel heads |

**What changed**
- Sign-in / register: new layout, header links, hero + stats, optional *First/Last name* (stored in `users.first_name/last_name`, migration #2), usernames may contain dashes.
- Dashboard: banner cards, `...` menu, search modal (Ctrl+K), admin-only *Showing your/all servers* switch and *Create Server* (`/admin/servers/new`).
- Console: banner header with Start/Restart/Stop, spinner while connecting, Resources/Connection cards, Players / Network received / Network sent tiles, full server sidebar.
- Account: *My panel colours*, *Update Password*, *Update Email Address*, tabs *Account / API Credentials / SSH Keys / Activity*.
- **Administrators can now open and operate every server** (`access.forUser` returns full access for `role = admin`).

**Not built yet** (pages exist in the sidebar but say so; no fake data): Server Properties, Players Manager, World Manager, World Viewer, Versions Manager, Plugins Manager, Databases, Schedules, Backups, Startup, API Credentials, SSH Keys, Two-Step Verification. *Network received/sent* show "—" because the runtime does not report network traffic.


---

# File manager (`/dashboard/servers/:identifier/files`)

Works on the **real server directory** - the same `<RUNTIME_DATA_DIR>/<identifier>/` the runtime starts the game process in. Nothing is stored in the database and nothing is simulated. The panel and the runtime must see the same `RUNTIME_DATA_DIR` (same machine / same mounted volume).

## What it does
- **Browse + navigate:** folders first, natural sort (`2` before `10`), size and modified time, clickable breadcrumbs, browser back/forward and reload keep your place (`?path=`).
- **Search:** case-insensitive name search in the current folder and everything below it (`?q=`). Shows where each match lives. Capped at 200 results / 4 s / 100 000 entries; the page says when a cap was hit.
- **Create** file (empty) or folder, **rename** (stays in its folder), **delete** (files, folders with contents, multi-select; always asks for confirmation).
- Never overwrites: creating or renaming onto an existing name is refused (409).

## Permissions
Owner and administrators: everything. Shared users need a grant:
```bash
npm run grant-access -- <identifier> friend@example.com files        # browse + search
npm run grant-access -- <identifier> friend@example.com filewrite    # also create / rename / delete (implies files)
```
A user without `files` does not see the sidebar entry and gets 403; unrelated users get 404. Every create / rename / delete is written to the owner's activity log with the name of who did it. (Migration #5 adds the two columns to `server_access`.)

## JSON API
Same session cookie + `Accept: application/json`; mutations need `X-CSRF-Token` (`GET /api/dashboard/csrf`).
```
GET  /api/dashboard/servers/:identifier/files?path=/plugins
GET  /api/dashboard/servers/:identifier/files/search?path=/&q=essentials
POST /api/dashboard/servers/:identifier/files/create   { "path": "/plugins", "name": "notes.txt", "type": "file" | "folder" }
POST /api/dashboard/servers/:identifier/files/rename   { "path": "/plugins/old.jar", "name": "new.jar" }
POST /api/dashboard/servers/:identifier/files/delete   { "paths": ["/a", "/b.txt"], "confirm": true }   # no confirm -> 428; partial failure -> 207
```
Errors are `{ "error", "code" }`: 400 bad path, 403 forbidden / root protected, 404 not found, 409 exists / not a folder, 422 invalid name or query, 428 confirmation required, 429 rate limit or too many searches.

## Security
- `..` and NUL bytes in a path are rejected (never "collapsed"); names are validated (no `/`, control characters, leading/trailing spaces, max 255 bytes).
- **Symlinks cannot escape:** a folder is only opened if its real path is inside the server directory, and entries are addressed through their parent's real path. Links pointing outside show as `link` and cannot be opened. Deleting a link removes the link, never its target; search never follows links.
- The server root cannot be renamed or deleted. Error messages never contain host paths.
- File names are inserted with `textContent` only (a plugin or player can create a file named `<img onerror=...>`).
- Rate limits: 300 reads, 40 searches, 120 changes per minute per IP; at most 4 searches run at once.

## Limits to know
- Not part of this module (yet): upload, download, editing file contents, moving/copying, zip/unzip.
- Deleting files a running server uses (worlds, plugins, the jar) can corrupt data; the delete dialog warns while the server is online but does not block it.
- Check-then-act races exist as with any file manager: a game plugin that swaps a folder for a symlink in the microseconds between the panel's check and its operation is not covered. Run the panel and game processes as an unprivileged user and keep the server directory on its own volume if the games are untrusted.
- A folder is shown up to 5000 entries (the page says when more exist; use search).

**Tests:** `tests/files.test.js` (12 tests on a real temporary directory: listing/sorting, traversal, symlink escape via list/create/rename/delete, create/duplicates/invalid names, rename, recursive delete, search + caps, permissions, CSRF, activity log, XSS-safe page).
