'use strict';
// Admin-only "Create Server" page (the same thing `npm run add-server` does, from the browser).
//   /admin/servers/new?kind=mc    MC Host  -> a Paper server
//   /admin/servers/new?kind=bot   Bot Host -> a Python or Node.js bot (the runtimes are already installed)
const { requireAdmin } = require('../middleware/auth');
const { rateLimit } = require('../lib/rateLimit');
const { esc } = require('../views/layout');
const { icon } = require('../views/icons');
const users = require('../services/users');
const servers = require('./services/servers');
const capacity = require('./services/capacity');
const activity = require('./services/activity');
const { shell } = require('./views');

const ENTRY_RE = /^(?!.*\.\.)[A-Za-z0-9_][A-Za-z0-9_./-]{0,59}$/;     // a file inside the bot's folder: no "..", no leading "/" or "-"
const kindOf = (v) => (String(v) === 'bot' ? 'bot' : 'mc');

function page({ ctx, kind, errors = {}, values = {}, flash }) {
  const bot = kind === 'bot';
  const v = { name: '', owner: ctx.user.username, version: 'latest', address: '', ram: bot ? '512' : '2048', cpu: '100', disk: bot ? '2048' : '10240', players: '20', runtime: 'python', entry: '', ...values };
  const fld = (name, label, { type = 'text', hint = '' } = {}) => `<div class="mp-field${errors[name] ? ' has-error' : ''}"><label for="c-${name}">${label}</label>
<div class="mp-input-wrap"><input id="c-${name}" name="${name}" type="${type}" value="${esc(v[name])}" autocomplete="off"${type === 'number' ? ' min="1"' : ''}></div>
${hint ? `<p class="mp-hint">${hint}</p>` : ''}<p class="mp-error"${errors[name] ? '' : ' hidden'}>${esc(errors[name] || '')}</p></div>`;

  const runtimeField = `<div class="mp-field${errors.runtime ? ' has-error' : ''}"><label for="c-runtime">Runtime</label>
<div class="mp-input-wrap"><select id="c-runtime" name="runtime" class="mp-select">${Object.entries(servers.RUNTIMES).map(([k, r]) => `<option value="${k}"${v.runtime === k ? ' selected' : ''}>${r.label}</option>`).join('')}</select></div>
<p class="mp-hint">Python and Node.js are already installed, there is nothing to set up.</p><p class="mp-error"${errors.runtime ? '' : ' hidden'}>${esc(errors.runtime || '')}</p></div>`;
  const softwareField = `<div class="mp-field"><label for="c-software">Software</label><div class="mp-input-wrap"><input id="c-software" type="text" value="Paper" disabled></div>
<input type="hidden" name="software" value="paper"><p class="mp-hint">MC Host runs Paper.</p></div>`;

  const left = bot
    ? `${fld('name', 'Server name')}${fld('owner', 'Owner', { hint: 'Email or username of an existing account.' })}${runtimeField}${fld('entry', 'Start file', { hint: `Optional. Defaults to <code>${servers.RUNTIMES.python.defaultEntry}</code> (Python) or <code>${servers.RUNTIMES.nodejs.defaultEntry}</code> (Node.js).` })}`
    : `${fld('name', 'Server name')}${fld('owner', 'Owner', { hint: 'Email or username of an existing account.' })}${softwareField}${fld('version', 'Version')}`;
  const right = bot
    ? `${fld('ram', 'Memory limit (MB)', { type: 'number' })}${fld('cpu', 'CPU limit (%, 100 = one core)', { type: 'number' })}${fld('disk', 'Disk limit (MB)', { type: 'number' })}`
    : `${fld('address', 'Server address', { hint: 'Optional, e.g. play.example.com:25565' })}${fld('ram', 'Memory limit (MB)', { type: 'number' })}${fld('cpu', 'CPU limit (%, 100 = one core)', { type: 'number' })}${fld('disk', 'Disk limit (MB)', { type: 'number' })}`;
  const extra = bot ? '' : `<div class="mp-grid-2"><div>${fld('players', 'Max players', { type: 'number' })}</div></div>`;
  const full = !!capacity.warning();
  const label = bot ? 'Create Bot' : 'Create MC Server';
  const back = bot ? '/admin/servers/bots' : '/admin/servers/mc';
  const body = `<section class="mp-panel mp-acct mp-create"><form method="post" action="/admin/servers" class="mp-form" novalidate>
<input type="hidden" name="_csrf" value="${esc(ctx.csrfToken)}"><input type="hidden" name="kind" value="${kind}">
<div class="mp-grid-2"><div>${left}</div><div>${right}</div></div>
${extra}
<div class="mp-form-actions"><button type="submit" class="mp-button mp-btn-inline"${full ? ' disabled title="The VPS is full. Upgrade your VPS first."' : ''}>${icon('plus', 14)} ${label}</button><a class="mp-btn-sm mp-btn-link" href="${back}">Cancel</a></div>
</form></section>`;
  return shell({ title: bot ? 'Create Bot' : 'Create Server', sub: bot ? 'Add a bot to Bot Host.' : 'Add a Minecraft server to MC Host.', active: bot ? 'admin-bots' : 'admin-mc', admin: true, user: ctx.user, csrf: ctx.csrfToken, flash, body, styles: ['/css/admin.css'] });
}

const int = (raw, min, max) => { const n = Number(raw); return Number.isInteger(n) && n >= min && n <= max ? n : null; };

module.exports = function register(router) {
  router.get('/admin/servers/new', requireAdmin, (ctx) => ctx.html(200, page({ ctx, kind: kindOf(ctx.query.kind), flash: ctx.takeFlash() })));

  router.post('/admin/servers', requireAdmin, rateLimit({ name: 'server-create', windowMs: 60 * 60 * 1000, max: 60 }), (ctx) => {
    const b = ctx.body, errors = {}, kind = kindOf(b.kind), bot = kind === 'bot';
    const values = Object.fromEntries(['name', 'owner', 'version', 'address', 'ram', 'cpu', 'disk', 'players', 'runtime', 'entry'].map((k) => [k, String(b[k] ?? '').trim()]));
    const name = values.name;
    if (!name || name.length > 40) errors.name = 'Enter a name of up to 40 characters.';
    const owner = values.owner ? users.findByLogin(values.owner) : null;
    if (!owner) errors.owner = 'No account matches that email or username.';
    let startCommand = null;
    if (bot) {
      const rt = servers.RUNTIMES[values.runtime];
      if (!rt) errors.runtime = 'Choose Python or Node.js.';
      const entry = values.entry || (rt ? rt.defaultEntry : '');
      if (rt && !ENTRY_RE.test(entry)) errors.entry = 'Use a file name like main.py (letters, numbers, dots, dashes, underscores, slashes).';
      if (rt && !errors.entry) startCommand = rt.command(entry);
    } else {
      if (!/^[A-Za-z0-9_.+-]{1,30}$/.test(values.version)) errors.version = 'Use letters, numbers, dots, dashes or underscores.';
      if (values.address && !/^[A-Za-z0-9_.:-]{1,100}$/.test(values.address)) errors.address = 'Use a host name or IP, optionally with :port.';
    }
    const ram = int(values.ram, 128, 1048576), cpu = int(values.cpu, 10, 6400), disk = int(values.disk, 128, 10485760), players = bot ? 1 : int(values.players, 1, 10000);
    if (ram === null) errors.ram = 'Enter a whole number between 128 and 1048576.';
    if (cpu === null) errors.cpu = 'Enter a whole number between 10 and 6400.';
    if (disk === null) errors.disk = 'Enter a whole number between 128 and 10485760.';
    if (players === null) errors.players = 'Enter a whole number between 1 and 10000.';
    if (Object.keys(errors).length) return ctx.html(422, page({ ctx, kind, errors, values, flash: { type: 'error', message: 'Please fix the highlighted fields.' } }));
    const room = capacity.canCreate({ ram, cpu, disk });      // servers are unlimited, the VPS is not: at most 90% of its RAM / CPU / disk
    if (!room.ok) return ctx.html(422, page({ ctx, kind, errors, values, flash: { type: 'error', message: room.message } }));
    try {
      const s = servers.create({ kind, ownerId: owner.id, name, ramLimitMb: ram, cpuLimitPct: cpu, diskLimitMb: disk, playersMax: players,
        ...(bot ? { runtime: values.runtime, software: servers.RUNTIMES[values.runtime].label, version: 'latest', startCommand }
          : { software: 'paper', version: values.version, address: values.address || null }) });
      activity.record({ userId: owner.id, serverId: s.id, serverName: s.name, type: 'server.created', message: `${bot ? 'Bot' : 'Server'} ${s.name} was added to your account (by ${ctx.user.username})` });
      ctx.flash('success', `${bot ? 'Bot' : 'Server'} "${s.name}" created for ${owner.username}.`);
      return ctx.redirect(`/dashboard/servers/${s.identifier}`);
    } catch (err) {
      if (!/UNIQUE/.test(err.message)) throw err;
      errors.name = 'That user already has a server with this name.';
      return ctx.html(422, page({ ctx, kind, errors, values, flash: { type: 'error', message: 'Please fix the highlighted fields.' } }));
    }
  });
};
