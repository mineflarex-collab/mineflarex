'use strict';
// The process supervisor ("runtime"): the part that actually runs servers.
//
//  * polls the command queue (server_commands) that the panel fills when a user presses Start / Stop / Restart
//  * spawns / stops / restarts a real OS process per server, in <dataDir>/<identifier>/
//  * reports the REAL status back (runtime.reportStatus): starting -> online when the console says the server
//    is ready, crashed when the process dies unexpectedly, offline after a normal stop
//  * samples real RAM / CPU usage of the process, disk usage of the server directory, and online players
//    (from join/leave lines in the console), and reports them every few seconds
//
// Run exactly ONE supervisor per database (`npm run runtime`, or RUNTIME=embedded in the web process).
const fs = require('node:fs');
const path = require('node:path');
const { spawn, execFile } = require('node:child_process');
const { ensureServerJar, usesServerJar } = require('./jar');
const db = require('../db');
require('../dashboard/migrations');
const runtime = require('../dashboard/services/runtime');
const consoleStore = require('../dashboard/services/serverConsole');
const baseConfig = require('./config');

const byId = db.prepare('SELECT * FROM servers WHERE id = ?');
const ENV_ALLOW = ['PATH', 'LANG', 'LC_ALL', 'TZ', 'JAVA_HOME', 'JAVA_TOOL_OPTIONS', 'TMPDIR', 'SystemRoot'];

/** Splits a command line into argv (supports single/double quotes; never uses a shell). */
function tokenize(cmd) {
  const out = []; let cur = '', quote = null, has = false;
  for (const ch of String(cmd)) {
    if (quote) { if (ch === quote) quote = null; else cur += ch; }
    else if (ch === '"' || ch === "'") { quote = ch; has = true; }
    else if (/\s/.test(ch)) { if (cur || has) { out.push(cur); cur = ''; has = false; } }
    else cur += ch;
  }
  if (quote) throw new Error('Unterminated quote in start command');
  if (cur || has) out.push(cur);
  if (!out.length) throw new Error('Start command is empty');
  return out;
}

function lineReader(stream, onLine) {
  let buf = ''; stream.setEncoding('utf8');
  stream.on('data', (d) => {
    buf += d; let i;
    while ((i = buf.indexOf('\n')) >= 0) { onLine(buf.slice(0, i).replace(/\r$/, '')); buf = buf.slice(i + 1); }
    if (buf.length > 8192) buf = buf.slice(-8192);
  });
}

async function dirSizeMb(dir, cap = 500000) {
  let bytes = 0, n = 0; const stack = [dir];
  while (stack.length) {
    const d = stack.pop(); let ents;
    try { ents = await fs.promises.readdir(d, { withFileTypes: true }); } catch { continue; }
    for (const en of ents) {
      if (++n > cap) return Math.ceil(bytes / 1048576);
      const p = path.join(d, en.name);
      if (en.isDirectory()) stack.push(p);
      else if (en.isFile()) { try { bytes += (await fs.promises.stat(p)).size; } catch { /* vanished */ } }
    }
  }
  return Math.ceil(bytes / 1048576);
}

/** Real resource usage of a process: { cpu (% of one core), rssMb, sample } – /proc on Linux, `ps` elsewhere. */
async function procStats(pid, prev) {
  if (process.platform === 'linux') {
    const stat = fs.readFileSync(`/proc/${pid}/stat`, 'utf8');
    const f = stat.slice(stat.lastIndexOf(')') + 2).split(' ');
    const ticks = Number(f[11]) + Number(f[12]);                    // utime + stime (USER_HZ = 100)
    const m = /VmRSS:\s+(\d+) kB/.exec(fs.readFileSync(`/proc/${pid}/status`, 'utf8'));
    const now = Date.now(); let cpu = 0;
    if (prev) { const dt = (now - prev.t) / 1000; if (dt > 0) cpu = Math.max(0, ((ticks - prev.ticks) / 100) / dt * 100); }
    return { cpu, rssMb: m ? Number(m[1]) / 1024 : 0, sample: { ticks, t: now } };
  }
  const out = await new Promise((res, rej) => execFile('ps', ['-o', 'rss=,%cpu=', '-p', String(pid)], (e, so) => (e ? rej(e) : res(so))));
  const [rss, cpu] = out.trim().split(/\s+/).map(Number);
  return { cpu: cpu || 0, rssMb: (rss || 0) / 1024, sample: null };
}

const sleepRace = (promise, ms) => new Promise((resolve) => {
  const t = setTimeout(() => resolve(false), ms);
  promise.then(() => { clearTimeout(t); resolve(true); });
});

class Entry {
  constructor(server, dir) {
    this.server = server; this.dir = dir;
    this.state = 'starting';            // starting | online | stopping
    this.wasReady = false; this.stopRequested = false; this.quiet = false; this.done = false; this.timedOut = false;
    this.tail = []; this.players = new Set(); this.diskMb = server.disk_used_mb; this.diskAt = 0; this.cpuSample = null;
    this.exited = new Promise((r) => { this._exited = r; });
    this.ready = new Promise((r) => { this._ready = r; });   // resolves { ok, error?, cancelled? }
  }
}

class Supervisor {
  constructor(opts = {}) {
    this.o = { ...baseConfig, ...opts };
    this.log = opts.log || (() => {});
    this.entries = new Map();      // server id -> Entry (a live process)
    this.inflight = new Map();     // server id -> { cmd, promise }
    this.claimed = new Set();      // command ids being executed
    this.timer = null; this.closing = false;
    // Live console: output of every process is written to the database (the panel streams it to browsers) and
    // commands typed in the panel arrive through the console_input queue.
    this.console = new consoleStore.Writer({ flushMs: this.o.consoleFlushMs, keep: this.o.consoleKeepLines, onError: (err) => this.log(`console write failed: ${err.message}`) });
    this.inputTimer = null;
  }

  /** Reconciles what the database claims with reality (this process owns no servers yet), then starts polling. */
  start() {
    const queued = new Set(runtime.pendingCommands().map((c) => c.server_id));
    for (const s of db.prepare("SELECT * FROM servers WHERE status NOT IN ('offline', 'crashed')").all()) {
      if (!queued.has(s.id)) this.report(s.id, 'offline');   // marked running, but no process exists -> say so
    }
    // Commands typed while no runtime was running must not be replayed now, minutes or hours later.
    for (const r of consoleStore.pendingInput(1000)) consoleStore.markInput(r.id, 'failed', 'The server runtime was not running');
    this.timer = setInterval(() => this.poll(), this.o.pollMs);
    this.inputTimer = setInterval(() => this.pollInput(), this.o.consoleInputMs);
    this.poll();
    this.log(`runtime started (data dir: ${this.o.dataDir})`);
  }

  /** Gracefully stops every running server; queued commands stay queued for the next runtime. */
  async shutdown() {
    this.closing = true; clearInterval(this.timer); clearInterval(this.inputTimer);
    await Promise.allSettled([...this.entries.values()].map((e) => this.stopEntry(e)));
    await Promise.allSettled([...this.inflight.values()].map((i) => i.promise));
    this.console.flush();                                                  // the last lines (shutdown output) must not be lost
  }

  /** Writes commands queued by the panel to the console (stdin) of the running process. */
  pollInput() {
    if (this.closing) return;
    let rows;
    try { rows = consoleStore.pendingInput(50); } catch (err) { return this.log(`console input poll failed: ${err.message}`); }
    for (const r of rows) {
      const e = this.entries.get(r.server_id);
      let error = null;
      if (!e || e.done || e.state === 'stopping') error = 'The server is not running';
      else {
        try { if (!e.proc.stdin.writable) throw new Error('console closed'); e.proc.stdin.write(`${r.command}\n`); }
        catch (err) { error = `Could not write to the server console: ${err.message}`; }
      }
      if (!consoleStore.markInput(r.id, error ? 'failed' : 'sent', error)) continue;   // the panel already gave up on it
      if (error) this.console.push(r.server_id, 'sys', `[minePanel] Command not sent (${error.toLowerCase()}): ${r.command}`);
      else this.console.push(r.server_id, 'in', `${r.username}> ${r.command}`);
    }
  }

  report(serverId, status, x = {}) {
    const cur = byId.get(serverId); if (!cur) return;
    try {
      runtime.reportStatus(serverId, { status, diskUsedMb: x.diskUsedMb ?? cur.disk_used_mb, cpuUsedPct: x.cpuUsedPct ?? 0, ramUsedMb: x.ramUsedMb ?? 0, playersOnline: x.playersOnline ?? 0 });
    } catch (err) { this.log(`report failed: ${err.message}`); }
  }

  poll() {
    if (this.closing) return;
    for (const cmd of runtime.pendingCommands()) {
      if (this.claimed.has(cmd.id)) continue;
      const busy = this.inflight.get(cmd.server_id), entry = this.entries.get(cmd.server_id);
      const preempt = cmd.command === 'stop' && entry && entry.state === 'starting';   // stop a server that is still booting
      if (busy && !preempt) continue;                                                  // one command at a time per server
      this.claimed.add(cmd.id);
      const previous = busy ? busy.promise : null;
      const promise = this.execute(cmd, previous).catch((err) => {
        this.log(`command ${cmd.id} (${cmd.command}) failed: ${err.stack || err}`);
        try { runtime.completeCommand(cmd.id, { ok: false, error: err.message || String(err), status: this.entries.has(cmd.server_id) ? 'online' : 'crashed' }); } catch { /* ignore */ }
      }).finally(() => {
        this.claimed.delete(cmd.id);
        if (this.inflight.get(cmd.server_id)?.cmd.id === cmd.id) this.inflight.delete(cmd.server_id);
      });
      this.inflight.set(cmd.server_id, { cmd, promise });
    }
  }

  async execute(cmd, previous) {
    const server = byId.get(cmd.server_id);
    if (!server) return runtime.completeCommand(cmd.id, { ok: false, error: 'Server no longer exists' });
    const entry = this.entries.get(server.id);

    if (cmd.command === 'start') {
      if (entry) return this.finishStart(cmd, await entry.ready);          // already running / booting: report its outcome
      return this.finishStart(cmd, await this.launch(server));
    }
    if (cmd.command === 'stop') {
      if (entry) await this.stopEntry(entry);
      if (previous) await previous;                                       // let the cancelled start finish first
      this.report(server.id, 'offline', { diskUsedMb: await dirSizeMb(path.join(this.o.dataDir, server.identifier)) });
      return runtime.completeCommand(cmd.id);
    }
    // restart: stop (if running), then start again; status goes stopping -> starting -> online
    if (entry) await this.stopEntry(entry, { restarting: true });
    return this.finishStart(cmd, await this.launch(byId.get(server.id)));
  }

  finishStart(cmd, r) {
    if (r.ok) return runtime.completeCommand(cmd.id);
    return runtime.completeCommand(cmd.id, { ok: false, error: r.error, status: r.cancelled ? 'offline' : 'crashed' });
  }

  /** Spawns the server process. Resolves when it is ready ({ ok: true }) or failed ({ ok: false, error }). */
  async launch(server) {
    // A new server has an empty folder: fetch server.jar first (Minecraft servers using the stock command only).
    if (server.kind !== 'bot' && usesServerJar(server.start_command || this.o.defaultCommand)) {
      const dir = path.join(this.o.dataDir, server.identifier);
      try {
        fs.mkdirSync(dir, { recursive: true });
        await ensureServerJar({ dir, software: server.software, version: server.version, say: (l) => this.console.push(server.id, 'sys', l) });
      } catch (err) {
        this.console.push(server.id, 'sys', `[minePanel] Could not prepare server.jar: ${err.message}`);
        return { ok: false, error: `Could not prepare server.jar: ${err.message}` };
      }
    }
    return this.spawnServer(server);
  }

  spawnServer(server) {
    const dir = path.join(this.o.dataDir, server.identifier);
    const e = new Entry(server, dir);
    let tokens;
    try {
      fs.mkdirSync(dir, { recursive: true });
      const heap = Math.max(64, Math.floor(server.ram_limit_mb * 0.9));
      const vars = { RAM_MB: server.ram_limit_mb, HEAP_MB: heap, CPU_CORES: server.cpu_limit_pct / 100, DIR: dir, IDENTIFIER: server.identifier };
      tokens = tokenize(server.start_command || this.o.defaultCommand).map((t) => t.replace(/\{\{(\w+)\}\}/g, (m, k) => (k in vars ? String(vars[k]) : m)));
    } catch (err) { this.console.push(server.id, 'sys', `[minePanel] Could not start: ${err.message}`); return Promise.resolve({ ok: false, error: err.message }); }
    e.tokens = tokens;
    this.console.push(server.id, 'sys', '[minePanel] Starting server...');
    this.entries.set(server.id, e);
    this.report(server.id, 'starting');

    const env = Object.fromEntries(ENV_ALLOW.filter((k) => process.env[k] != null).map((k) => [k, process.env[k]]));   // never leak panel secrets to game processes
    const proc = spawn(tokens[0], tokens.slice(1), { cwd: dir, env: { ...env, HOME: dir }, stdio: ['pipe', 'pipe', 'pipe'] });
    e.proc = proc;
    proc.stdin.on('error', () => {});
    lineReader(proc.stdout, (l) => this.onLine(e, l, 'out'));
    lineReader(proc.stderr, (l) => this.onLine(e, l, 'err'));
    proc.on('error', (err) => this.onExit(e, null, null, err));
    proc.on('close', (code, signal) => this.onExit(e, code, signal));
    // A bot has no "Done!" line to wait for: it counts as online once the process has stayed alive for a moment.
    if (server.kind === 'bot') e.botReadyTimer = setTimeout(() => this.markReady(e), this.o.botReadyMs);
    e.startTimer = setTimeout(() => { if (!e.wasReady && !e.done) { e.timedOut = true; proc.kill('SIGKILL'); } }, this.o.startTimeoutMs);
    e.metricsTimer = setInterval(() => this.sample(e), this.o.metricsMs); e.metricsTimer.unref();
    dirSizeMb(dir).then((mb) => { e.diskMb = mb; e.diskAt = Date.now(); });
    return e.ready;
  }

  onLine(e, line, stream = 'out') {
    this.console.push(e.server.id, stream, line);
    e.tail.push(line); if (e.tail.length > 15) e.tail.shift();
    let m;
    if ((m = /: (\w{1,16}) joined the game/.exec(line))) e.players.add(m[1]);
    else if ((m = /: (\w{1,16}) left the game/.exec(line))) e.players.delete(m[1]);
    if (e.state === 'starting' && this.o.readyRegex.test(line)) this.markReady(e);
  }

  /** The server finished starting: report it online and start sampling usage. */
  markReady(e) {
    if (e.done || e.state !== 'starting') return;
    e.state = 'online'; e.wasReady = true; clearTimeout(e.startTimer); clearTimeout(e.botReadyTimer); e.diskAt = 0;   // re-measure disk now: files were created during startup
    this.report(e.server.id, 'online', { diskUsedMb: e.diskMb });
    this.sample(e);
    e._ready({ ok: true });
  }

  async sample(e) {
    if (e.done || e.state !== 'online') return;
    let cpu = 0, rssMb = 0;
    try { const st = await procStats(e.proc.pid, e.cpuSample); cpu = st.cpu; rssMb = st.rssMb; e.cpuSample = st.sample; } catch { /* process just exited */ }
    if (Date.now() - e.diskAt > 60000) { e.diskAt = Date.now(); try { e.diskMb = await dirSizeMb(e.dir); } catch { /* keep last value */ } }
    if (e.done || e.state !== 'online') return;
    this.report(e.server.id, 'online', { cpuUsedPct: Math.round(cpu * 10) / 10, ramUsedMb: Math.round(rssMb), diskUsedMb: e.diskMb, playersOnline: e.players.size });
  }

  onExit(e, code, signal, err) {
    if (e.done) return;
    e.done = true; clearTimeout(e.startTimer); clearTimeout(e.botReadyTimer); clearInterval(e.metricsTimer);
    this.console.push(e.server.id, 'sys', `[minePanel] Server process ended (${err ? err.message : signal ? `signal ${signal}` : `exit code ${code}`}).`);
    if (this.entries.get(e.server.id) === e) this.entries.delete(e.server.id);
    e._exited({ code, signal });
    if (!e.wasReady) {                       // it never became ready: the command that launched it records the outcome
      if (e.stopRequested) return e._ready({ ok: false, cancelled: true, error: 'Cancelled by a stop request' });
      let reason = err ? (err.code === 'ENOENT' ? `Could not run "${e.tokens[0]}" (not found)` : err.message)
        : e.timedOut ? `Server did not finish starting within ${Math.round(this.o.startTimeoutMs / 1000)}s`
          : `Process exited (${signal ? `signal ${signal}` : `code ${code}`}) before it was ready`;
      const tail = e.tail.slice(-3).join(' | ').slice(0, 300);
      if (tail) reason += `: ${tail}`;
      return e._ready({ ok: false, error: reason });
    }
    if (e.stopRequested) { if (!e.quiet) this.report(e.server.id, 'offline', { diskUsedMb: e.diskMb }); return; }
    // Exited on its own: a clean exit (e.g. an operator typed /stop in game) is offline, anything else is a crash.
    this.report(e.server.id, code === 0 ? 'offline' : 'crashed', { diskUsedMb: e.diskMb });
  }

  /** Graceful stop: console command, then SIGTERM, then SIGKILL. */
  async stopEntry(e, { restarting = false } = {}) {
    if (e.done) return;
    e.stopRequested = true; e.quiet = restarting;
    const bot = e.server.kind === 'bot';
    if (e.state !== 'stopping') this.console.push(e.server.id, 'sys', bot ? '[minePanel] Stopping bot...' : `[minePanel] Stopping server (sending "${this.o.stopCommand}")...`);
    if (e.state !== 'stopping') { e.state = 'stopping'; this.report(e.server.id, 'stopping', { diskUsedMb: e.diskMb }); }
    if (bot) e.proc.kill('SIGTERM');                      // bots have no console "stop" command: ask the process to exit
    else { try { e.proc.stdin.write(`${this.o.stopCommand}\n`); } catch { /* already closing */ } }
    if (await sleepRace(e.exited, bot ? this.o.botStopTimeoutMs : this.o.stopTimeoutMs)) return;
    this.log(`${e.server.name}: did not stop in time, sending SIGTERM`);
    e.proc.kill('SIGTERM');
    if (await sleepRace(e.exited, this.o.killTimeoutMs)) return;
    this.log(`${e.server.name}: still running, sending SIGKILL`);
    e.proc.kill('SIGKILL');
    await e.exited;
  }
}

module.exports = { Supervisor, tokenize };
