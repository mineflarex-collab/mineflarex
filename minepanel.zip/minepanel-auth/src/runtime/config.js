'use strict';
// Runtime (process supervisor) settings. All overridable through environment variables.
const path = require('node:path');
require('../lib/env');
const env = process.env;
const dbPath = env.DB_PATH || path.join(__dirname, '..', '..', 'data', 'minepanel.db');
const num = (v, d) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : d);

module.exports = {
  // Run the supervisor inside the web process (RUNTIME=embedded) instead of as `npm run runtime`.
  embedded: env.RUNTIME === 'embedded',
  // Each server lives in <dataDir>/<identifier>/ (that is its working directory).
  dataDir: env.RUNTIME_DATA_DIR || (dbPath === ':memory:' ? path.join(require('node:os').tmpdir(), 'minepanel-servers') : path.join(path.dirname(dbPath), 'servers')),
  pollMs: num(env.RUNTIME_POLL_MS, 1000),
  metricsMs: num(env.RUNTIME_METRICS_MS, 5000),
  startTimeoutMs: num(env.RUNTIME_START_TIMEOUT_MS, 5 * 60 * 1000),
  stopTimeoutMs: num(env.RUNTIME_STOP_TIMEOUT_MS, 60 * 1000),
  killTimeoutMs: num(env.RUNTIME_KILL_TIMEOUT_MS, 10 * 1000),
  // Live console: how often captured output is written to the database / queued commands are picked up,
  // and how many lines per server are kept for scrollback.
  consoleFlushMs: num(env.RUNTIME_CONSOLE_FLUSH_MS, 100),
  consoleInputMs: num(env.RUNTIME_CONSOLE_INPUT_MS, 100),
  consoleKeepLines: num(env.CONSOLE_KEEP_LINES, 5000),
  // Bot Host: a bot is "online" once its process has been alive this long; a bot gets this long to exit after SIGTERM.
  botReadyMs: num(env.RUNTIME_BOT_READY_MS, 2000),
  botStopTimeoutMs: num(env.RUNTIME_BOT_STOP_TIMEOUT_MS, 15 * 1000),
  stopCommand: env.RUNTIME_STOP_COMMAND || 'stop',
  // Used when a server has no start_command. {{HEAP_MB}} = 90% of the RAM allocation.
  defaultCommand: env.RUNTIME_DEFAULT_COMMAND || 'java -Xmx{{HEAP_MB}}M -jar server.jar nogui',
  // A console line matching this means the server finished starting.
  readyRegex: env.RUNTIME_READY_REGEX ? new RegExp(env.RUNTIME_READY_REGEX) : /Done \([\d.,]+s\)!|For help, type "help"/
};
