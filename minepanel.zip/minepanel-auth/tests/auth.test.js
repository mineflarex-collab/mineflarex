'use strict';
process.env.DB_PATH = ':memory:';
process.env.NODE_ENV = 'test';
process.env.MAIL_QUIET = 'true';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createServer } = require('../src/app');
const mailer = require('../src/lib/mailer');
const users = require('../src/services/users');
const { hashPassword } = require('../src/lib/crypto');

let server, base;
before(async () => { server = createServer(); await new Promise((r) => server.listen(0, '127.0.0.1', r)); base = `http://127.0.0.1:${server.address().port}`; });
after(() => server.close());

function client() {
  const jar = {};
  const store = (res) => { for (const c of res.headers.getSetCookie()) {
    const [kv] = c.split(';'); const i = kv.indexOf('='); const k = kv.slice(0, i), val = kv.slice(i + 1);
    if (/Max-Age=0/i.test(c)) delete jar[k]; else jar[k] = val; } };
  const c = {
    jar,
    async req(path, { method = 'GET', form } = {}) {
      const res = await fetch(base + path, { method, redirect: 'manual',
        headers: { cookie: Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; '), ...(form ? { 'content-type': 'application/x-www-form-urlencoded' } : {}) },
        body: form ? new URLSearchParams(form) : undefined });
      store(res); return res;
    },
    async csrf(path = '/login') { const html = await (await c.req(path)).text(); return /name="_csrf" value="([^"]+)"/.exec(html)[1]; },
    async post(path, form, from) { return c.req(path, { method: 'POST', form: { _csrf: await c.csrf(from || path), ...form } }); }
  };
  return c;
}
const good = { username: 'steve', email: 'Steve@Example.com', password: 'Cr4ftyPickaxe!', confirm: 'Cr4ftyPickaxe!' };

test('protected routes redirect guests to login', async () => {
  const c = client();
  const r = await c.req('/account');
  assert.equal(r.status, 303);
  assert.match(r.headers.get('location'), /^\/login\?next=%2Faccount/);
  assert.equal((await c.req('/api/me', {})).status, 303);
});

test('POST without CSRF token is rejected', async () => {
  const c = client();
  const r = await c.req('/register', { method: 'POST', form: good });
  assert.equal(r.status, 403);
});

test('register validation errors', async () => {
  const c = client();
  const r = await c.post('/register', { username: 'a', email: 'bad', password: 'short', confirm: 'x' }, '/register');
  assert.equal(r.status, 422);
  const html = await r.text();
  for (const m of ['3–20 characters', 'valid email', 'at least 10', 'do not match']) assert.match(html, new RegExp(m));
});

test('register -> duplicate -> login -> session -> logout', async () => {
  const c = client();
  assert.equal((await c.post('/register', good, '/register')).status, 303);
  const u = users.findByEmail('steve@example.com');
  assert.ok(u.password_hash.startsWith('scrypt$'));
  assert.ok(!u.password_hash.includes(good.password));
  assert.equal(u.role, 'user');

  const dup = await c.post('/register', { ...good, username: 'steve2' }, '/register');
  assert.equal(dup.status, 422);
  assert.match(await dup.text(), /already exists/);

  const bad = await c.post('/login', { identifier: 'steve', password: 'wrong-password1' });
  assert.equal(bad.status, 401);
  assert.match(await bad.text(), /Incorrect email\/username or password/);

  const ok = await c.post('/login', { identifier: 'STEVE@example.com', password: good.password, next: '/account' });
  assert.equal(ok.status, 303);
  assert.equal(ok.headers.get('location'), '/account');
  const sid = c.jar.mp_sid;
  assert.ok(sid);
  assert.match(ok.headers.getSetCookie().find((x) => x.startsWith('mp_sid')), /HttpOnly; ?|HttpOnly/);

  assert.equal((await c.req('/account')).status, 200);
  assert.equal((await c.req('/admin')).status, 403);          // role check
  assert.equal((await c.req('/login')).status, 303);          // guests-only page bounces

  const out = await c.post('/logout', {}, '/account');
  assert.equal(out.status, 303);
  assert.equal(c.jar.mp_sid, undefined);
  const stale = client(); stale.jar.mp_sid = sid;             // old cookie must be dead server-side
  assert.equal((await stale.req('/account')).status, 303);
});

test('open redirect via next is ignored', async () => {
  const c = client();
  const r = await c.post('/login', { identifier: 'steve', password: good.password, next: '//evil.com' }, '/login');
  assert.equal(r.headers.get('location'), '/dashboard');
});

test('admin role can reach /admin', async () => {
  users.create({ username: 'root', email: 'root@example.com', passwordHash: await hashPassword('Adm1nPassw0rd!'), role: 'admin' });
  const c = client();
  const r = await c.post('/login', { identifier: 'root', password: 'Adm1nPassw0rd!' }, '/login');
  assert.equal(r.headers.get('location'), '/admin');
  assert.equal((await c.req('/admin')).status, 200);
});

test('forgot + reset password flow, invalidates sessions, single use', async () => {
  const logged = client();
  await logged.post('/login', { identifier: 'steve', password: good.password });
  assert.equal((await logged.req('/account')).status, 200);

  const c = client();
  assert.equal((await c.post('/forgot-password', { email: 'nobody@example.com' })).status, 303);
  const before = mailer.outbox.length;
  assert.equal((await c.post('/forgot-password', { email: 'steve@example.com' })).status, 303);
  await new Promise((r) => setTimeout(r, 50));
  assert.equal(mailer.outbox.length, before + 1);
  const mail = mailer.outbox.at(-1);
  assert.equal(mail.to, 'steve@example.com');
  const link = /(\/reset-password\?token=[\w-]+)/.exec(mail.text)[1];

  assert.equal((await c.req('/reset-password?token=bogus-bogus-bogus-bogus')).status, 400);
  const form = await c.req(link); assert.equal(form.status, 200);
  const html = await form.text();
  const token = /name="token" value="([^"]+)"/.exec(html)[1];

  const weak = await c.post('/reset-password', { token, password: 'abc', confirm: 'abc' }, link);
  assert.equal(weak.status, 422);

  const done = await c.post('/reset-password', { token, password: 'N3wDiamondPick!', confirm: 'N3wDiamondPick!' }, link);
  assert.equal(done.status, 303);
  assert.equal((await c.post('/reset-password', { token, password: 'An0therPass123', confirm: 'An0therPass123' }, '/login')).status, 400); // reuse
  assert.equal((await logged.req('/account')).status, 303); // old session killed

  assert.equal((await client().post('/login', { identifier: 'steve', password: good.password })).status, 401);
  assert.equal((await client().post('/login', { identifier: 'steve', password: 'N3wDiamondPick!' })).status, 303);
});

test('account locks after repeated failures', async () => {
  users.create({ username: 'alex', email: 'alex@example.com', passwordHash: await hashPassword('Alex1234567!') });
  const c = client();
  for (let i = 0; i < 5; i++) assert.equal((await c.post('/login', { identifier: 'alex', password: 'nope-nope-1' })).status, 401);
  const locked = await c.post('/login', { identifier: 'alex', password: 'Alex1234567!' });
  assert.equal(locked.status, 429);
  assert.match(await locked.text(), /Too many failed attempts/);
});

test('security headers present', async () => {
  const r = await client().req('/login');
  assert.match(r.headers.get('content-security-policy'), /default-src 'self'/);
  assert.equal(r.headers.get('x-frame-options'), 'DENY');
  assert.equal(r.headers.get('cache-control'), 'no-store');
});
